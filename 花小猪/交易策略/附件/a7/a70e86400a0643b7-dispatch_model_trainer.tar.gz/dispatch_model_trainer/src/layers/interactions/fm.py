from torch.nn import Module
from torch import tensor

class FM(Module):

    def __init__(self):
        r"""Factor Machine key component.
        Shape:
            - Input: ``(batch_size, num_features, embedding_dim)``
            - Output: ``(batch_size, 1)``
        """
        super(FM, self).__init__()

    def forward(self, X: tensor):
        square_of_sum = X.sum(dim=1, keepdim=False).pow(2) # (batch_size, embedding_dim)
        sum_of_square = X.pow(2).sum(dim=1, keepdim=False) # (batch_size, embedding_dim)
        bi_interaction =  (sum_of_square - square_of_sum) * 0.5
        return bi_interaction.sum(dim=-1, keepdim=True) # (batch_size, 1)