# coding:utf-8

import torch
from torch import nn,Tensor
from torch.nn import Module,ModuleList,Dropout,Softmax
from .mlp import MLP


class GateNeuralUnit(Module):
    """
    门控神经单元类，继承自nn.Module，用于创建具有门控机制的神经网络单元。

    参数:
    - dim_in: int, 输入维度
    - dim_hidden: int, 隐藏层维度
    - dim_out: int, 输出维度
    - gamma: float, 门控系数，默认为2.0

    返回:
    - None
    """

    def __init__(
        self, dim_in: int, dim_hidden: int, dim_out: int, gamma: float = 2.0
    ) -> None:
        super().__init__()  # 初始化父类
        # 创建一个多层感知器（MLP），包含两个线性层和一个ReLU激活函数
        self.mlp = MLP(dim_in=dim_in,
                        hidden_units=[dim_hidden,dim_out],
                        hidden_activations=nn.ReLU
                    )

        self.gamma = gamma  # 门控系数

    def forward(
        self, f_domain: Tensor, f_general: Tensor = None
    ) -> Tensor:
        """
        执行前向传播操作，将特定领域的特征和通用特征结合起来，并通过门控机制产生最终输出。

        参数:
            f_domain (Tensor): 特定领域的特征向量。[batch_size, dim_in_1]
            f_general (Tensor): 通用特征向量。 [batch_size, dim_in_2]

        返回:
            Tensor: 经过门控机制处理后的综合特征向量。 [batch_size, dim_in_2]
        """
        if f_general is None:
            x = f_domain
        else:
            # 将特定领域的特征和通用特征在最后一个维度上连接
            x = torch.cat([f_domain, f_general.detach()], dim=-1)
        # 应用门控机制，并返回结果
        return self.gamma * torch.sigmoid(self.mlp(x))



class EPNet(Module):
    def __init__(
        self,
        gate_dim_in: int,
        gate_dim_hidden: int,
        gate_dim_out,
        gamma: float = 2.0,
    ) -> None:
        super().__init__()
        self.gate_nu = GateNeuralUnit(gate_dim_in, gate_dim_hidden, gate_dim_out, gamma)

    def forward(self, f_d: Tensor, f_g: Tensor) -> Tensor:
        f = torch.cat([f_d, f_g.detach()], dim=-1)
        return self.gate_nu(f) * f_g
