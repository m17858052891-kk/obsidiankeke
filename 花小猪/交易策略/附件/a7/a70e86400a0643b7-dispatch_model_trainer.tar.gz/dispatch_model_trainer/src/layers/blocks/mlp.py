from torch import nn
from typing import List

class MLP(nn.Module):
    def __init__(self, 
                 dim_in, 
                 hidden_units=[], 
                 hidden_activations=nn.ReLU,
                 dim_out=None,
                 output_activation=None, 
                 dropout_rates=0.0,
                 batch_norm=False, 
                 bn_only_once=False, # Set True for inference speed up
                 use_bias=True):
        super(MLP, self).__init__()
        dense_layers = []
        if not isinstance(dropout_rates, list):
            dropout_rates = [dropout_rates] * len(hidden_units)
        hidden_units = [dim_in] + hidden_units
        if batch_norm and bn_only_once:
            dense_layers.append(nn.BatchNorm1d(dim_in))
        for idx in range(len(hidden_units) - 1):
            dense_layers.append(nn.Linear(hidden_units[idx], hidden_units[idx + 1], bias=use_bias))
            if batch_norm and not bn_only_once:
                dense_layers.append(nn.BatchNorm1d(hidden_units[idx + 1]))
            dense_layers.append(hidden_activations[idx]() if isinstance(hidden_activations, List) else hidden_activations())
            if dropout_rates[idx] > 0:
                dense_layers.append(nn.Dropout(p=dropout_rates[idx]))
        if dim_out is not None:
            dense_layers.append(nn.Linear(hidden_units[-1], dim_out, bias=use_bias))
        if output_activation is not None:
            dense_layers.append(output_activation())
        self.dim_out = dim_out if dim_out is not None else hidden_units[-1]
        self.mlp = nn.Sequential(*dense_layers) # * used to unpack list
    
    def forward(self, inputs):
        return self.mlp(inputs)

class LogitLayer(MLP):
    def __init__(self, dim_in, dropout_rates=0.0, use_batch_norm=False, use_bias=True):
        super(LogitLayer, self).__init__(
            dim_in=dim_in, 
            dim_out=1, 
            output_activation=nn.Sigmoid, 
            dropout_rates=dropout_rates,
            batch_norm=use_batch_norm, 
            bn_only_once=use_batch_norm, 
            use_bias=use_bias
        )