import torch
from torch import nn, Tensor
from .mlp import MLP
from ..interactions import Autodis

class AutoDis_Embed_Layer(nn.Module):
    def __init__(
        self,
        dense,
        dense_layer_units,
        dropout_rates,
        is_field_embed=True,
        is_clip=None
    ):
        super(AutoDis_Embed_Layer, self).__init__()
        dense_dim = sum(emb.embedding_dim for _, emb in enumerate(dense))
        self.autodis_layer = Autodis(dense_dim, dense_dim)
        # self.dense_bn = torch.nn.BatchNorm1d(dense_dim)
        self.is_field_embed = is_field_embed
        if is_field_embed: 
            self.dense_bn1 = torch.nn.BatchNorm1d(dense_dim)
        self.is_clip = is_clip
        if is_clip:
            start_indices = [0] + is_clip
            end_indices = is_clip + [dense_dim]
            self.dense_layers = nn.ModuleList([
                MLP(dim_in=end - start, dim_out=dense_layer_units, hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)
                for start, end in zip(start_indices, end_indices)
            ])
        else:
            self.dense_layer = MLP(dim_in=dense_dim, dim_out=dense_layer_units, hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)
       

    def forward(self, dense: Tensor) -> Tensor: # dense -> [batch_size, num_features]
        assert len(dense.shape) == 2, f"AutoDis_Embed_Layer的input维度应为2维, 当前维度为{len(dense.shape)}"
        batch_size = dense.shape[0]
        dense_embed = self.autodis_layer(dense)
        # dense_embed = self.dense_bn(dense_embed)

        if self.is_field_embed: # 如果做field embedding
            dense_value = self.dense_bn1(dense)
            dense_embed = dense_value * dense_embed

        if self.is_clip:
            start_indices = [0] + self.is_clip
            end_indices = self.is_clip + [dense_embed.shape[1]]
            outputs = []
            for i, (start, end) in enumerate(zip(start_indices, end_indices)):
                sliced = dense_embed[:, start:end]
                output = self.dense_layers[i](sliced)
                outputs.append(output)
            dense_embed = torch.cat(outputs, dim=1)
        else:
            dense_embed = self.dense_layer(dense_embed)

        return dense_embed      