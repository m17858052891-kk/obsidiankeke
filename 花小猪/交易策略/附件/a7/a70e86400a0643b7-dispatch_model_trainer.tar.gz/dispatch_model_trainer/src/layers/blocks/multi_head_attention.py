import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 200):
        super().__init__()
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, d_model)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)  # [max_len, d_model]

    def forward(self, x):
        pe = self.pe[:x.size(1)]  # [seq_len, d_model]
        pe = pe.unsqueeze(0)  # [1, seq_len, d_model]
            
        return x + pe  # 广播到batch_size

class MultiHeadAttentionLayer(nn.Module):
    def __init__(self, d_model, num_heads, dropout=0.1):
        """
        Args:
            d_model: 输入特征维度（必须能被 num_heads 整除）
            num_heads: 注意力头的数量
            dropout: 注意力权重的 Dropout 概率
        """
        super().__init__()
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads  # 每个头的维度
        
        # 定义 Q/K/V 的线性变换层
        self.W_q = nn.Linear(d_model, d_model)
        self.W_k = nn.Linear(d_model, d_model)
        self.W_v = nn.Linear(d_model, d_model)
        
        # 输出线性层
        self.W_o = nn.Linear(d_model, d_model)
        
        # Dropout
        self.dropout = nn.Dropout(dropout)
        self.pos_encoder = PositionalEncoding(d_model)
        
    def split_heads(self, x):
        """
        将输入张量的最后一维拆分为 (num_heads, d_k)，
        并调整维度顺序以匹配注意力计算。
        Args:
            x: [batch_size, seq_len, d_model]
        Returns:
            [batch_size, num_heads, seq_len, d_k]
        """
        batch_size, seq_len, _ = x.size()
        return x.view(batch_size, seq_len, self.num_heads, self.d_k).transpose(1, 2)
    
    def scaled_dot_product_attention(self, Q, K, V, mask=None):
        """
        计算缩放点积注意力。
        Args:
            Q: [batch_size, num_heads, seq_len, d_k]
            K: [batch_size, num_heads, seq_len, d_k]
            V: [batch_size, num_heads, seq_len, d_k]
            mask: 可选的掩码张量（如 padding mask 或 future mask）
        Returns:
            output: [batch_size, num_heads, seq_len, d_k]
            attn_weights: [batch_size, num_heads, seq_len, seq_len]
        """
        # 计算 QK^T / sqrt(d_k)
        scores = torch.matmul(Q, K.transpose(-2, -1)) / (self.d_k ** 0.5)
        
        # 应用掩码（如 padding mask 或 future mask）
        # if mask is not None:
        #     scores = scores.masked_fill(mask == 0, float('-inf'))
        if mask is not None:
            mask[:,-1] = 1.0
            mask = mask.unsqueeze(1).unsqueeze(1)  # [batch_size, 1, 1, seq_len]
            scores = scores.masked_fill(mask==0, float('-inf'))  # 广播到 [batch_size, num_heads, seq_len, seq_len]

        # 计算 Softmax 和 Dropout
        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        
        # 加权求和
        output = torch.matmul(attn_weights, V)
        
        return output, attn_weights
    
    def forward(self, Q, K, V, mask=None):
        """
        Args:
            Q: [batch_size, seq_len, d_model]
            K: [batch_size, seq_len, d_model]
            V: [batch_size, seq_len, d_model]
            mask: 可选的掩码张量（如 padding mask 或 future mask）
        Returns:
            output: [batch_size, seq_len, d_model]
            attn_weights: [batch_size, num_heads, seq_len, seq_len]
        """
        batch_size = Q.size(0)
        
        Q = self.pos_encoder(Q)
        K = self.pos_encoder(K)
        V = self.pos_encoder(V)

        # 线性变换 + 分头
        Q = self.split_heads(self.W_q(Q))  # [batch_size, num_heads, seq_len, d_k]
        K = self.split_heads(self.W_k(K))
        V = self.split_heads(self.W_v(V))
        
        # 计算注意力
        attn_output, attn_weights = self.scaled_dot_product_attention(Q, K, V, mask)
        
        # 合并多头
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, -1, self.d_model)
        
        # 输出线性变换
        output = self.W_o(attn_output)  # [batch_size, seq_len, d_model]
        
        return output, attn_weights  # [batch_size, seq_len, d_model],  [batch_size * num_heads, seq_len, seq_len]