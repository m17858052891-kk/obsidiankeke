# coding:utf-8

import torch
from torch import nn
from torch.nn import Module,ModuleList,Dropout,Softmax
from .mlp import MLP


class CGC_Layer(Module):
    def __init__(self, num_shared_experts, num_specific_experts, num_tasks, input_dim,
                 expert_hidden_units, gate_hidden_units, hidden_activations,
                 net_dropout, batch_norm,is_last=False):
        super(CGC_Layer, self).__init__()
        self.num_shared_experts = num_shared_experts 
        self.num_specific_experts = num_specific_experts 
        self.num_tasks = num_tasks 
        self.gate_num = self.num_tasks + 1 if not is_last else self.num_tasks
        self.shared_experts = nn.ModuleList(
            [MLP(dim_in=input_dim,
             hidden_units=expert_hidden_units,
             hidden_activations=hidden_activations,
             output_activation=None,
             dropout_rates=net_dropout,
             batch_norm=batch_norm) for _ in range(self.num_shared_experts)]
        )
        self.specific_experts = nn.ModuleList(
            [nn.ModuleList([MLP(dim_in=input_dim,
             hidden_units=expert_hidden_units,
             hidden_activations=hidden_activations,
             output_activation=None,
             dropout_rates=net_dropout,
             batch_norm=batch_norm) for _ in range(self.num_specific_experts)]) for _ in range(num_tasks)]
        )
        self.gate = nn.ModuleList(
            [MLP(dim_in=input_dim,
             dim_out=num_specific_experts+num_shared_experts if i < num_tasks else num_shared_experts + num_specific_experts*num_tasks,
             hidden_units=gate_hidden_units,
             hidden_activations=hidden_activations,
             output_activation=None,
             dropout_rates=net_dropout,
             batch_norm=batch_norm) for i in range(self.gate_num)]
        )
        self.gate_activation = Softmax()


    def forward(self, x, require_gate=False,is_last=False):
        """
        x: list, len(x)==num_tasks+1
        """
        specific_expert_outputs = [] 
        shared_expert_outputs = []
        # specific experts
        for i in range(self.num_tasks):
            task_expert_outputs = []
            for j in range(self.num_specific_experts):
                task_expert_outputs.append(self.specific_experts[i][j](x[i]))
            specific_expert_outputs.append(task_expert_outputs)
        # shared experts 
        for i in range(self.num_shared_experts):
            shared_expert_outputs.append(self.shared_experts[i](x[-1]))
        # gate 
        cgc_outputs = [] 
        gates = [] 
        for i in range(self.num_tasks+1):
            if i < self.num_tasks:
                # for specific experts
                # gate_input: (?, num_specific_experts+num_shared_experts, dim)
                gate_input = torch.stack(specific_expert_outputs[i] + shared_expert_outputs, dim=1) 
                gate = self.gate_activation(self.gate[i](x[i])) # (?, num_specific_experts+num_shared_experts)
                gates.append(gate.mean(0))
                cgc_output = torch.sum(gate.unsqueeze(-1) * gate_input, dim=1) # (?, dim)
                cgc_outputs.append(cgc_output)
            elif not is_last: 
                # for shared experts 
                all_outputs = []
                for item in shared_expert_outputs:
                    all_outputs.append(item)
                for j in range(self.num_tasks):
                    all_outputs += specific_expert_outputs[j]
                gate_input = torch.stack(all_outputs, dim=1) # (?, num_shared_experts, dim)
                gate = self.gate_activation(self.gate[i](x[-1])) # (?, num_shared_experts)
                gates.append(gate.mean(0))
                cgc_output = torch.sum(gate.unsqueeze(-1) * gate_input, dim=1) # (?, dim)
                cgc_outputs.append(cgc_output)
        if require_gate:
            return cgc_outputs, gates 
        else: 
            return cgc_outputs