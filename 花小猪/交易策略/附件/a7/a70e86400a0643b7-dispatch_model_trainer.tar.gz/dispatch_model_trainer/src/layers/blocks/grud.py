import torch
import torch.nn as nn
import torch.nn.functional as F

class GRUDCell(nn.Module):
    def __init__(self, input_dim, hidden_dim, x_imputation='zero',
                 input_decay='exp_relu', hidden_decay='exp_relu', use_decay_bias=True,
                 feed_masking=True, masking_decay=None):
        super(GRUDCell, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.x_imputation = x_imputation
        self.input_decay = self._get_activation(input_decay)
        self.hidden_decay = self._get_activation(hidden_decay)
        self.use_decay_bias = use_decay_bias
        self.feed_masking = feed_masking
        self.masking_decay = self._get_activation(masking_decay) if feed_masking else None

        # GRU weights
        self.W_z = nn.Linear(input_dim, hidden_dim)
        self.U_z = nn.Linear(hidden_dim, hidden_dim)
        self.W_r = nn.Linear(input_dim, hidden_dim)
        self.U_r = nn.Linear(hidden_dim, hidden_dim)
        self.W_h = nn.Linear(input_dim, hidden_dim)
        self.U_h = nn.Linear(hidden_dim, hidden_dim)

        # Decay weights
        if self.input_decay is not None:
            self.input_decay_kernel = nn.Parameter(torch.zeros(input_dim))
            if self.use_decay_bias:
                self.input_decay_bias = nn.Parameter(torch.zeros(input_dim))

        if self.hidden_decay is not None:
            self.hidden_decay_kernel = nn.Parameter(torch.zeros(input_dim, hidden_dim))
            if self.use_decay_bias:
                self.hidden_decay_bias = nn.Parameter(torch.zeros(hidden_dim))

        if self.feed_masking:
            self.masking_kernel = nn.Parameter(torch.zeros(input_dim, hidden_dim * 3))
            if self.masking_decay is not None:
                self.masking_decay_kernel = nn.Parameter(torch.zeros(input_dim))
                if self.use_decay_bias:
                    self.masking_decay_bias = nn.Parameter(torch.zeros(input_dim))

    def _get_activation(self, activation):
        if activation == 'exp_relu':
            return lambda x: torch.exp(F.relu(x))
        return None

    def forward(self, input_x, input_m, input_s, h_tm1, x_keep_tm1, s_prev_tm1):
        input_1m = 1 - input_m
        input_d = input_s - s_prev_tm1

        # Compute decay if any
        gamma_di = None
        if self.input_decay is not None:
            gamma_di = input_d * self.input_decay_kernel
            if self.use_decay_bias:
                gamma_di = gamma_di + self.input_decay_bias
            gamma_di = self.input_decay(gamma_di)

        gamma_dh = None
        if self.hidden_decay is not None:
            gamma_dh = torch.matmul(input_d, self.hidden_decay_kernel)
            if self.use_decay_bias:
                gamma_dh = gamma_dh + self.hidden_decay_bias
            gamma_dh = self.hidden_decay(gamma_dh)

        gamma_dm = None
        if self.feed_masking and self.masking_decay is not None:
            gamma_dm = input_d * self.masking_decay_kernel
            if self.use_decay_bias:
                gamma_dm = gamma_dm + self.masking_decay_bias
            gamma_dm = self.masking_decay(gamma_dm)

        # Get the imputed or decayed input if needed
        if self.input_decay is not None:
            x_keep_t = torch.where(input_m.bool(), input_x, x_keep_tm1)
            x_t = torch.where(input_m.bool(), input_x, gamma_di * x_keep_t)
        elif self.x_imputation == 'forward':
            x_t = torch.where(input_m.bool(), input_x, x_keep_tm1)
            x_keep_t = x_t
        elif self.x_imputation == 'zero':
            x_t = torch.where(input_m.bool(), input_x, torch.zeros_like(input_x))
            x_keep_t = x_t
        elif self.x_imputation == 'raw':
            x_t = input_x
            x_keep_t = x_t
        else:
            raise ValueError('No input decay or invalid x_imputation.')

        # Get decayed hidden if needed
        h_tm1d = gamma_dh * h_tm1 if self.hidden_decay is not None else h_tm1

        # Get decayed masking if needed
        m_t = input_1m
        if self.feed_masking:
            if self.masking_decay is not None:
                m_t = gamma_dm * m_t

        # Compute GRU gates
        z_t = torch.sigmoid(self.W_z(x_t) + self.U_z(h_tm1d))
        r_t = torch.sigmoid(self.W_r(x_t) + self.U_r(h_tm1d))
        hh_t = torch.tanh(self.W_h(x_t) + self.U_h(r_t * h_tm1d))

        if self.feed_masking:
            m_z, m_r, m_h = torch.chunk(torch.matmul(m_t, self.masking_kernel), 3, dim=1)
            z_t = z_t + m_z
            r_t = r_t + m_r
            hh_t = hh_t + m_h

        # Compute hidden state
        h_t = (1 - z_t) * hh_t + z_t * h_tm1

        # get s_prev_t
        s_prev_t = torch.where(input_m.bool(), input_s.expand(-1, self.input_dim), s_prev_tm1)

        return h_t, x_keep_t, s_prev_t


class GRUD(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=1, x_imputation='zero',
                 input_decay='exp_relu', hidden_decay='exp_relu', use_decay_bias=True,
                 feed_masking=True, masking_decay=None):
        super(GRUD, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.cells = nn.ModuleList([GRUDCell(input_dim if i == 0 else hidden_dim, hidden_dim,
                                             x_imputation, input_decay, hidden_decay,
                                             use_decay_bias, feed_masking, masking_decay)
                                    for i in range(num_layers)])

    def forward(self, input_x, input_m, input_s):
        input_x = input_x.float()
        input_m = input_m.float()
        input_s = input_s.float()

        batch_size, seq_len, _ = input_x.size()
        h = [torch.zeros(batch_size, self.hidden_dim).to(input_x.device) for _ in range(self.num_layers)] # 
        x_keep = [torch.zeros(batch_size, self.input_dim if i == 0 else self.hidden_dim).to(input_x.device) for i in range(self.num_layers)] # 
        s_prev = [torch.zeros(batch_size, self.input_dim if i == 0 else self.hidden_dim).to(input_x.device) for i in range(self.num_layers)] #
        outputs = []
        for t in range(seq_len):
            x_t = input_x[:, t, :]
            m_t = input_m[:, t, :]
            s_t = input_s[:, t, :]

            for i, cell in enumerate(self.cells):
                if i == 0:
                    h[i], x_keep[i], s_prev[i] = cell(x_t, m_t, s_t, h[i], x_keep[i], s_prev[i])
                else:
                    h[i], x_keep[i], s_prev[i] = cell(h[i - 1], m_t, s_t, h[i], x_keep[i], s_prev[i])

            outputs.append(h[-1].unsqueeze(1))

        outputs = torch.cat(outputs, dim=1)
        return outputs
