import torch
from torch.nn import Module, ModuleList
from torch.nn import Dropout

class MMoE_Layer(Module):

    def __init__(self, num_experts, num_tasks, dim_in, dim_out, expert, gate, gate_dropout_rate=0.0):
        super(MMoE_Layer, self).__init__()
        self.num_experts, self.num_tasks = num_experts, num_tasks
        self.experts = ModuleList([expert(dim_in=dim_in, dim_out=dim_out) for _ in range(self.num_experts)])
        self.gates = ModuleList([expert(dim_in=dim_in, dim_out=num_experts) for _ in range(self.num_tasks)])
        self.gate_dropout = Dropout(p=gate_dropout_rate) \
            if gate_dropout_rate > 0.0 and gate_dropout_rate < 1.0 else None

    def forward(self, X):
        experts_output = torch.stack(
            [
                self.experts[i](X) 
                for i in range(self.num_experts)
            ], 
            dim=1
        )  # (batch_size, num_experts, dim)
        if self.gate_dropout:
            return torch.cat(
                [
                    torch.sum(
                        self.gate_dropout(
                            torch.softmax(self.gates[i](X), dim=-1).unsqueeze(-1) * experts_output
                        ), dim=1
                    ) for i in range(self.num_tasks) 
                ], 
                dim=-1
            )  # (batch_size, dim, num_tasks)
        else:
            return torch.cat(
                [
                    torch.sum(
                        torch.softmax(self.gates[i](X), dim=-1).unsqueeze(-1) * experts_output, 
                        dim=1
                    ) for i in range(self.num_tasks) 
                ], 
                dim=-1
            )  # (batch_size, dim, num_tasks)