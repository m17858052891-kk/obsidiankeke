# coding:utf-8

from typing import List
import torch
from torch import nn,Tensor
from torch.nn import Module,ModuleList,Dropout,Softmax
from .mlp import MLP
from .epnet import GateNeuralUnit


class PPNet(Module):
    """
    PPNet模型类，用于实现多任务学习中的门控神经网络。

    参数:
        gate_dim_in: 输入维度到门控单元。
        gate_dim_hidden: 隐藏层维度到门控单元。
        task_num: 任务数量。
        mlp_dims: 多层感知器的维度列表。
        gamma: 门控单元的缩放因子，默认为2.0。
        bias: 是否在线性层中使用偏置，默认为True。
        dropout: Dropout比例，默认为0.1。
    """

    def __init__(
        self,
        gate_dim_in: int,
        gate_dim_hidden: int,
        task_num: int,
        mlp_dims: List[int],
        gamma: float = 2.0,
        bias: bool = True,
        dropout: float = 0.1,
        batch_norm: bool = True,
    ) -> None:
        super().__init__()
        self.layer_num = len(mlp_dims) - 1  # 网络层数
        self.task_num = task_num  # 任务数量

        # # 初始化门控单元
        # self.gate_nus = nn.ModuleDict(
        #     {
        #         f"gate_nu_{layer}": GateNeuralUnit(
        #             gate_dim_in, gate_dim_hidden, mlp_dims[layer + 1] * task_num, gamma
        #         )
        #         for layer in range(self.layer_num)
        #     }
        # )

        # 初始化任务塔
        tower = dict()
        for t in range(task_num):
            for layer in range(self.layer_num):
                # 最后一层使用sigmoid激活函数，其他层使用relu激活函数
                if layer == self.layer_num - 1:
                    tower[f"task_{t}_layer_{layer}"] = MLP(
                                                            dim_in=mlp_dims[layer],
                                                            dim_out=mlp_dims[layer + 1],
                                                            use_bias=bias,
                                                            dropout_rates=0,
                                                            output_activation=nn.ReLU
                                                        )
                else:
                    tower[f"task_{t}_layer_{layer}"] = MLP(
                                                            dim_in=mlp_dims[layer],
                                                            dim_out=mlp_dims[layer + 1],
                                                            use_bias=bias,
                                                            dropout_rates=dropout,
                                                            output_activation=nn.ReLU,
                                                            batch_norm=batch_norm
                                                        )
        self.towers = nn.ModuleDict(tower)

    def forward(
        self,
        o_ep: Tensor,
    ) -> List[Tensor]:
        """
        前向传播函数。

        参数:
            f_s: 侧边特征，shape: (batch_size, emb_dim)。
            o_ep: 来自门控单元的特征，shape: (batch_size, dim_user)。

        返回值:
            一个列表，包含每个任务的特征。
        """
        #f = torch.cat([f_s, o_ep.detach()], dim=1)  # 合并输入特征
        # feat_list = list()
        # for i in range(self.layer_num):
        #     weight = self.gate_nus[f"gate_nu_{i}"](f)  # 通过门控单元处理
        #     weight = weight.view(f.shape[0], -1, self.task_num)  # 调整形状以适配任务塔
        #     feat_list.append(weight)

        task_feat = list()
        for t in range(self.task_num):
            x = o_ep
            for layer in range(self.layer_num):
                # 根据门控特征调整任务特征
                # x = (
                #     self.towers[f"task_{t}_layer_{layer}"](x)
                #     * feat_list[layer][:, :, t]
                # )
                x = (
                    self.towers[f"task_{t}_layer_{layer}"](x)
                )
            task_feat.append(x)
        return task_feat
