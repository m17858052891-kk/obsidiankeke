import torch
import torch.nn as nn
import torch.nn.init as init
from torch.distributions import Normal

# batch normalization first
class Autodis(nn.Module):
    """
    Args:
        H_j: Meta_embeddings units
        alpha: skip-connection factor
        t: Temperature Coefficient
    """
    def __init__(self, in_dim, out_dim, H_j=40, alpha=0.2, t=1e-5, t_hidden_units=32):
        super(Autodis, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.w_j = nn.Linear(in_dim, H_j)
        self.leak_relu = nn.LeakyReLU()
        self.W_j = nn.Linear(H_j, H_j)
        self.alpha = alpha
        self.bn = nn.BatchNorm1d(in_dim)
        
        self.t = t
        self.softmax = nn.Softmax(dim=-1)
        # self.ME = nn.Parameter(torch.randn(H_j, out_dim))
        
        # 使用Xavier初始化
        self.ME = nn.Parameter(torch.empty(H_j, out_dim))
        # init.xavier_normal_(self.ME)

        # 使用均匀分布初始化
        init.uniform_(self.ME, a=-1, b=1)

        # 使用正态分布初始化
        # init.normal_(self.ME, mean=0, std=1)

        # 添加温度系数神经网络
        self.leak_relu_t = nn.LeakyReLU()
        self.w_t1 = nn.Linear(2 * in_dim + 1, t_hidden_units) # [x | cdf | x_mean]
        self.w_t2 = nn.Linear(t_hidden_units, 1)
        self.sigmoid = nn.Sigmoid()
    
    def cal_global_statistics(self, x):
        dist = Normal(loc=0, scale=1)
        cdfs = dist.cdf(x)
        means = torch.mean(x, dim=1).unsqueeze(1)
        out = torch.cat((x, cdfs, means), dim=1)
        return out
 
    def forward(self, x):
        x = self.bn(x)
        x_with_global_stat = self.cal_global_statistics(x)
        h_j = self.leak_relu(self.w_j(x))
        x_hat_j = self.W_j(h_j) + self.alpha * h_j
        temp = self.leak_relu_t(self.w_t1(x_with_global_stat))
        temp = self.sigmoid(self.w_t2(temp))
        t = temp + 1e-7  # 避免除零

        x_hat_j_h = self.softmax(x_hat_j / t)
        e_j = x_hat_j_h @ self.ME
        return e_j
        