import torch
from torch import nn

class CrossInteraction(nn.Module):

    def __init__(self, in_features):
        super(CrossInteraction, self).__init__()
        self.weight = nn.Linear(in_features, 1, bias=False)
        self.bias = nn.Parameter(torch.zeros(in_features))

    def forward(self, X_0, X_i):
        interact_out = self.weight(X_i) * X_0 + self.bias
        return interact_out

class CrossNet(nn.Module):
    
    def __init__(self, num_layers, in_features):
        super(CrossNet, self).__init__()
        self.cross_layers = nn.ModuleList(CrossInteraction(in_features) for _ in range(num_layers))

    def forward(self, X_0):
        X_i = X_0 # b x dim
        for _, cross_layer in enumerate(self.cross_layers):
            X_i = X_i + cross_layer(X_0, X_i)
        return X_i

class CrossNetV2(nn.Module):
    def __init__(self, in_features, num_layers):
        super(CrossNetV2, self).__init__()
        self.num_layers = num_layers
        self.cross_layers = nn.ModuleList(nn.Linear(in_features, in_features)
                                          for _ in range(self.num_layers))
    def forward(self, X_0):
        X_i = X_0 # b x dim
        for _, cross_layer in enumerate(self.cross_layers):
            X_i = X_i + X_0 * cross_layer(X_i)
        return X_i

class GateCrossNet(nn.Module):
    #  The core structure： gated cross layer.
    def __init__(self, input_dim, num_layers=3):
        super().__init__()

        self.num_layers = num_layers

        self.w = nn.ModuleList([
            nn.Linear(input_dim, input_dim, bias=False) for _ in range(num_layers)
        ])
        self.wg = nn.ModuleList([
            nn.Linear(input_dim, input_dim, bias=False) for _ in range(num_layers)
        ])

        self.b = nn.ParameterList([nn.Parameter(
            torch.zeros((input_dim,))) for _ in range(num_layers)])

        for i in range(num_layers):
            nn.init.uniform_(self.b[i].data)

        self.activation = nn.Sigmoid()

    def forward(self, x):
        x0 = x
        for i in range(self.num_layers):
            xw = self.w[i](x) # Feature Crossing
            xg = self.activation(self.wg[i](x)) # Information Gate
            x = x0 * (xw + self.b[i]) * xg + x
        return x

class CrossNetMix(nn.Module):
    """ CrossNetMix improves CrossNetV2 by:
        1. add MOE to learn feature interactions in different subspaces
        2. add nonlinear transformations in low-dimensional space
    """
    def __init__(self, input_dim, num_layers=2, low_rank=32, num_experts=4):
        super(CrossNetMix, self).__init__()
        self.num_layers = num_layers
        self.num_experts = num_experts

        # U: (input_dim, low_rank)
        self.U_list = torch.nn.ParameterList([nn.Parameter(nn.init.xavier_normal_(
            torch.empty(num_experts, input_dim, low_rank))) for i in range(self.num_layers)])
        # V: (input_dim, low_rank)
        self.V_list = torch.nn.ParameterList([nn.Parameter(nn.init.xavier_normal_(
            torch.empty(num_experts, input_dim, low_rank))) for i in range(self.num_layers)])
        # C: (low_rank, low_rank)
        self.C_list = torch.nn.ParameterList([nn.Parameter(nn.init.xavier_normal_(
            torch.empty(num_experts, low_rank, low_rank))) for i in range(self.num_layers)])
        self.gating = nn.ModuleList([nn.Linear(input_dim, 1, bias=False) for i in range(self.num_experts)])

        self.bias = torch.nn.ParameterList([nn.Parameter(nn.init.zeros_(
            torch.empty(input_dim))) for i in range(self.num_layers)])
        # self.to(device)

    def forward(self, inputs):
        x_0 = inputs  # (bs, input_dim)
        x_l = x_0 # (bs, input_dim)
        for i in range(self.num_layers):
            output_of_experts = []
            gating_score_of_experts = []
            for expert_id in range(self.num_experts):
                # (1) G(x_l)
                # compute the gating score by x_l
                gating_score_of_experts.append(self.gating[expert_id](x_l)) # (bs, 1)

                # (2) E(x_l)
                # project the input x_l to $\mathbb{R}^{r}$
                v_x = torch.matmul(x_l, self.V_list[i][expert_id])  # (bs, input_dim)  mat (input_dim, low_rank) = (bs, low_rank)

                # nonlinear activation in low rank space
                v_x = torch.tanh(v_x)
                v_x = torch.matmul(v_x, self.C_list[i][expert_id]) # (bs, low_rank) mat (low_rank, low_rank) = (bs, low_rank)
                v_x = torch.tanh(v_x)
        # project back to $\mathbb{R}^{d}$
                uv_x = torch.matmul(v_x, self.U_list[i][expert_id].T)  # (bs, low_rank) mat (low_rank, input_dim) = (bs, input_dim)

                dot_ = uv_x + self.bias[i] # (bs, input_dim)
                dot_ = x_0 * dot_  # Hadamard-product, (bs, input_dim)

                output_of_experts.append(dot_)

            # (3) mixture of low-rank experts
            output_of_experts = torch.stack(output_of_experts, 2)  # (bs, input_dim, num_experts)
            gating_score_of_experts = torch.stack(gating_score_of_experts, 1)  # (bs, num_experts, 1)
            moe_out = torch.bmm(output_of_experts, gating_score_of_experts.softmax(1)) # (bs, input_dim, num_experts) bmm (bs, num_experts, 1) = (bs, input_dim, 1)
            x_l = moe_out.squeeze(2) + x_l  # (bs, input_dim)

        return x_l