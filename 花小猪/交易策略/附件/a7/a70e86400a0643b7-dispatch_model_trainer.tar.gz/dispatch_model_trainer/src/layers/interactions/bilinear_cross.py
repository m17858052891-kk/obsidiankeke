import torch
import torch.nn as nn
class BilinearCross(nn.Module):
    def __init__(self, features_num, output_dim):
        super(BilinearCross, self).__init__()
        self.bilinear = nn.Bilinear(features_num, features_num, output_dim)

    def forward(self, x):
        return self.bilinear(x, x)