import torch
from torch.nn import Module, Parameter, init, BatchNorm1d
from torch import softmax
from typing import Optional
class FeatureGroupLayer(Module):
    """FeatureGroupLayer module."""

    def __init__(self, num_features: int, embed_dim: int, num_groups: int=10, order: int=2, 
        topk_per_group: Optional[int]=None, temperature: float=1e-2, epsilon: float=1e-20):
        r"""AutoGroup key component, applies differentiable feature group selection.
        Args:
            num_features: number of features of the input.
            embed_dim: length of each feature's embedding vector.
            num_groups: number of groups of features. Default: 10
            order: order of feature interaction to be calculated. Default: 2
            temperature: temperature in Gumbel-Softmax. Default: 1e-2
            epsilon: term added to the denominator to improve numerical stability. Default: 1e-20
        Shape:
            - Input: ``(batch_size, num_features, embed_dim)``
            - Output: ``(batch_size, num_groups, embed_dim)``
        """
        super(FeatureGroupLayer, self).__init__()
        # integrity check
        if order < 1:
            raise ValueError("`order` should be a positive integer.")
        if temperature <= 0 or temperature > 1:
            raise ValueError("temperature supposed to be in range (0,1])")
        self.num_features = num_features
        self.embed_dim = embed_dim
        self.num_groups = num_groups
        self.order = order
        self.topk_per_group = topk_per_group
        self.dim_out = num_groups * embed_dim
        # params for gumbel-softmax sampling
        self.structure_logits = Parameter(
            torch.empty((num_features, num_groups, 2)).uniform_(-0.001, 0.001)) # (num_features, num_groups, 2)
        self.feature_weights = Parameter(
            init.xavier_uniform_(torch.empty(num_features, num_groups))) # (num_features, num_groups)
        self.register_buffer('temperature', torch.tensor(temperature))
        self.register_buffer('epsilon', torch.tensor(epsilon))
        self.register_buffer('noise', torch.zeros((num_features, num_groups, 2), dtype=torch.float))
        self.register_buffer('mask_choice', torch.tensor([[1.], [0.]]))
        self.bn = BatchNorm1d(num_features * embed_dim, affine=False)

    def forward(self, X):
        """Calculate grouped features' interaction score.
        Shape:
            - Input: ``(batch_size, num_features, embed_dim)``
            - Output: ``(batch_size, num_groups)``
        """
        # bn for embed
        X = self.bn(X.view(-1, X.shape[1] * X.shape[2])).view(*X.shape) # (batch_size, num_features, embed_dim)
        # gumbel sampling choices of fearures for each group
        choices = self._differentiable_sampling()  # (num_features, num_groups)
        # calculate weights for features of each groups, zero weight for features not choosed by the group
        weights = torch.mul(choices, self.feature_weights) # (num_features, num_groups)
        # feature interaction
        interactions = self._make_interactions(X, weights) # (batch_size, num_groups, embed_dim)
        return interactions

    def _differentiable_sampling(self):
        """Use Gumbel-Softmax trick to take argmax, while keeping differentiate w.r.t soft sample y_soft.
        Shape:
            - Output: ``(num_features, num_groups)``
        """
        if self.training:
            noise = self.noise.uniform_(0.0, 1.0)
            logits = self.structure_logits - \
                torch.log(-torch.log(noise + self.epsilon) + self.epsilon) # (num_features, num_groups, 2)
        else:
            logits = self.structure_logits # (num_features, num_groups, 2)

        probs = softmax(logits / self.temperature, dim=-1) # (num_features, num_groups, 2)
        y_soft = probs.matmul(self.mask_choice).squeeze(-1) # (num_features, num_groups)
        
        if self.topk_per_group:
            topk_value = y_soft.topk(k=self.topk_per_group, dim=0)[0] # (topk_per_group, num_groups)
            kth_value = topk_value.min(dim=0, keepdim=True)[0] # (1, num_groups)
            y_hard = y_soft.gt(kth_value).type(probs.dtype) # (num_features, num_groups)
            y_soft *= y_hard # (num_features, num_groups)
        else:
            y_hard = probs.eq(probs.max(dim=-1, keepdim=True).values).type(probs.dtype)
        return (y_hard - y_soft).detach() + y_soft

    def _make_interactions(self, X, weights):
        """Use Interaction trick of FM.
        Shape:
            - Input: ``(batch_size, num_features, embed_dim)``, ``(num_features, num_groups)``
            - Output: ``(num_features, num_groups, embed_dim)``
        """
        if self.order == 1:
            return torch.matmul(X.permute(0, 2, 1), weights).permute(0, 2, 1) # (batch_size, num_groups, embed_dim)
        embed_pow_of_sum = torch.pow(torch.matmul(X.permute(0, 2, 1), weights), self.order) # (batch_size, embed_dim, num_groups)
        embed_sum_of_pow = torch.matmul(X.permute(0, 2, 1).pow(self.order), weights.pow(self.order)) # (batch_size, embed_dim, num_groups)
        interacted_features = (embed_pow_of_sum - embed_sum_of_pow).permute(0, 2, 1) # (batch_size, num_groups, embed_dim)
        return interacted_features