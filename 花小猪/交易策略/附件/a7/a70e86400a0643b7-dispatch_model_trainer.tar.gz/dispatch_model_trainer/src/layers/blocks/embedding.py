from typing import List, Dict

import numpy as np
import torch
import torch.nn as nn

from dmlite.utils import logger, monitor_api
from dmlite.data.torch.config import (
    Numerical,
    FeatureConfig,
    Categorical,
    MultiCategorical,
)


class EmbeddingLayerBase:
    pass


class EmbeddingLayer(nn.Module, EmbeddingLayerBase):
    """
    General Embedding Layer. Adapted from the torch-rechub library with slight modifications.
    Stores all feature embeddings in embed_dict: `{feature_name: embedding table}`.

    Args:
        feature_list (list): List of `Class` objects representing the features for which we want to create embedding tables.
        fuse (bool): Try to fuse embedding in a feature group to acclerate speed. Note, in most case it works, but when ids are extremely sparse, it may be slow for it update the whole fused embbedding table.
        sparse (bool): Try to update in an sparse way with SparseAdam, SparseSGD etc.
        squeeze_dim (bool): Whether to squeeze the categorical feature embedding dimension.


    Shape:
        - Input:
            - x (dict): A dictionary where keys are feature names and values are feature values.
                        Sequence feature values are 2D tensors with shape `(batch_size, seq_len)`.
                        Sparse/dense feature values are 1D tensors with shape `(batch_size)`.
            - squeeze_dim (bool): Whether to squeeze the categorical feature embedding dimension.
        - Output:
            - For Dense input: `(batch_size, num_features_dense)`.
            - For Sparse input: `(batch_size, num_features, embed_dim)` or `(batch_size, num_features * embed_dim)`.
            - For Sequence input: Same as Sparse input or `(batch_size, num_features_seq, seq_length, embed_dim)` when `pooling=="concat"`.
            - For Dense and Sparse/Sequence input: `(batch_size, num_features_sparse * embed_dim)`. Note that `squeeze_dim` must be True to concatenate dense values with sparse embeddings.
    """

    def __new__(cls, feature_list, fuse=True, sparse=False, squeeze_dim=False):
        if feature_list is None or len(feature_list) == 0:
            return nn.Identity()
        fuse_cate = fuse
        fuse_num = fuse
        if fuse:
            embedding_dim = feature_list[0].embedding_dim
            for fea in feature_list:
                if (not isinstance(fea, Categorical)) or (
                    not embedding_dim == fea.embedding_dim
                ):
                    fuse_cate = False
                    break

            for fea in feature_list:
                if (not isinstance(fea, Numerical)) or (
                    (not embedding_dim == fea.embedding_dim) and fea.encoding is None
                ):
                    fuse_num = False
                    break

        if fuse_cate:
            return FusedCateEmbeddingLayer(feature_list, embedding_dim, sparse=sparse, squeeze_dim=squeeze_dim)
        elif fuse_num:
            return FusedNumEmbeddingLayer(feature_list)
        else:
            if fuse:
                logger.warning(
                    "We recommand to put homogeneous features in the feature group to fuse embedding."
                )
            return super().__new__(cls)

    @monitor_api("dmlite.layers.torch.EmbeddingLayer")
    def __init__(self, feature_list: List[FeatureConfig], fuse=True, sparse=False, squeeze_dim=False):
        super().__init__()
        assert feature_list is not None, "Feature list must be provided in the config."

        self.fuse = fuse
        self.sparse = sparse
        self.squeeze_dim = squeeze_dim
        self.embedding_dict = nn.ModuleDict(
            {fea.name: fea.build_embedding(sparse=self.sparse) for fea in feature_list}
        )

    def forward(self, x):
        emb_list = []
        # Potential bottleneck when all features in x are numerical
        for index, (name, emb) in enumerate(self.embedding_dict.items()):
            x_col = x[:, index]
            # if torch.jit.isinstance(x, torch.Tensor):
            #     x_col = x[:, index]
            # elif torch.jit.isinstance(x, Dict[str, torch.Tensor]):
            #     x_col = x[name]
            # elif torch.jit.isinstance(x, List[torch.Tensor]):
            #     x_col = x[index]
            # else:
            #     raise ValueError(
            #         "Input x must be Dict[str, torch.Tensor], List[torch.Tensor], or torch.Tensor."
            #     )
            x_col_emb = emb.forward(
                x_col, self.squeeze_dim
            )  # [batch_size, 1] | [batch_size, embed_dim] | [batch_size, seq_len, embed_dim]
            emb_list.append(x_col_emb)

        squeeze_dim = self.squeeze_dim
        if squeeze_dim:
            emb = torch.cat(emb_list, dim=-1)
        else:
            emb = torch.stack(emb_list, dim=1)
        return emb

    def set_sparse(self):
        self.sparse = True
        for fea, module in self.embedding_dict.items():
            module.sparse = True


class FusedNumEmbeddingLayer(nn.Module, EmbeddingLayerBase):
    """
    General Fused Embedding Layer for numerical features. It reduce cuda kernel launching times of embedding lookup.
    """

    def __init__(self, feature_list):
        super().__init__()
        self.fuse = True

    def forward(self, x):
        return x


class FusedCateEmbeddingLayer(nn.Module, EmbeddingLayerBase):
    """
    General Fused Embedding Layer for categorical features. It reduce cuda kernel launching times of embedding lookup.
    """

    def __init__(self, feature_list: List[Categorical], embedding_dim, sparse=False, squeeze_dim=False):
        super().__init__()
        assert feature_list is not None, "Feature list must be provided in the config."
        # embedding_dim = feature_list[0].embedding_dim
        # for fea in feature_list:
        #     assert embedding_dim == fea.embedding_dim, "`embedding_dim` should be equal."
        logger.warning("Fused embedding will omit the `encoding` options.")

        self.fuse = True
        self.sparse = sparse
        self.squeeze_dim = squeeze_dim
        # self.embedding_dim = embedding_dim
        self.num_embeddings_list = [fea.num_embeddings for fea in feature_list]
        self.encodings = [fea.encoding for fea in feature_list]


        offsets = np.cumsum([fea.num_embeddings for fea in feature_list])
        num_embeddings = int(offsets[-1])
        self.embedding = nn.Embedding(num_embeddings, embedding_dim, sparse=self.sparse)
        offsets = np.insert(offsets, 0, 0)
        for i, fea in enumerate(feature_list):
            initializer_fn = getattr(nn.init, fea.initializer + "_")
            initializer_fn(
                self.embedding.weight[offsets[i] : offsets[i + 1], :],
                **fea.initializer_kwargs
            )
        self.register_buffer("offsets", torch.from_numpy(offsets[:-1]))
        if isinstance(feature_list[0], MultiCategorical):
            self.offsets = self.offsets.unsqueeze(-1)

    def forward(self, x: torch.Tensor):
        x = x.int()
        for i, (num_emb, enc) in enumerate(zip(self.num_embeddings_list, self.encodings)):
            if enc == 'hash':
                x[:, i] = x[:, i] % num_emb
        x = x + self.offsets
        emb = self.embedding(x)
        squeeze_dim = self.squeeze_dim
        if squeeze_dim:
            emb = emb.flatten(1)
        return emb

    def set_sparse(self):
        self.sparse = True
        self.embedding.sparse = True
