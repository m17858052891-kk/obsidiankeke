import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 200):
        super().__init__()
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, d_model)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)  # [max_len, d_model]

    def forward(self, x):
        pe = self.pe[:x.size(1)]  # [seq_len, d_model]
        pe = pe.unsqueeze(0)  # [1, seq_len, d_model]
            
        return x + pe  # 广播到batch_size


class AttentionLayer(nn.Module):
    def __init__(self, d_model):
        super().__init__()
        self.d_model = d_model
        self.pos_encoder = PositionalEncoding(d_model)
        
        # 线性变换层
        self.query = nn.Linear(d_model, d_model)
        self.key = nn.Linear(d_model, d_model)
        self.value = nn.Linear(d_model, d_model)
        
        # self.pool = nn.AdaptiveAvgPool1d(1)  # 将seq_len维度压缩为1

    def forward(self, x):
        x = self.pos_encoder(x)
        
        # 将dim和seq_len转置以便线性层处理
        # x = x.permute(0, 2, 1)  # [batch_size, seq_len, dim]
        
        # 计算Q, K, V
        Q = self.query(x)  # [batch_size, seq_len, dim]
        K = self.key(x)    # [batch_size, seq_len, dim]
        V = self.value(x)  # [batch_size, seq_len, dim]
        
        # 计算注意力分数
        scores = torch.bmm(Q, K.transpose(1, 2)) / (self.d_model ** 0.5)
        attn_weights = F.softmax(scores, dim=-1)
        
        # 应用注意力权重
        output = torch.bmm(attn_weights, V)  # [batch_size, seq_len, dim]
        
        # output = output.permute(0, 2, 1)  # [batch_size, seq_len, dim]

        # output = self.pool(output)  # 压缩seq_len维度
        return output
