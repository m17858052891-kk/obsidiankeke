import torch
import torch.nn as nn

class SENetBlock(nn.Module):
    def __init__(self, num_features, reduction=16):
        super(SENetBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(num_features, num_features // reduction)
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Linear(num_features // reduction, num_features)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x): #x [batch_size, num_features, 1]
        b, c, _ = x.size()
        y = self.avg_pool(x).view(b, c)

        y = self.fc1(y)
        y = self.relu(y)
        y = self.fc2(y)
        y = self.sigmoid(y)

        # 将权重与原始输入相乘
        y = y.unsqueeze(-1)
        return x * y.expand_as(x)