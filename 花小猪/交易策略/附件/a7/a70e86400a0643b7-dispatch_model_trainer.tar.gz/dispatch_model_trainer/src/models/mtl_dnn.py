import torch
from typing import List
from dmlite.layers.torch import EmbeddingLayer
from dmlite.data.torch.feature_config import FeatureConfig
from ..layers import LogitLayer

class MtlDNN(torch.nn.Module):

    def __init__(self, common_feats: List[FeatureConfig],serial_feats: List[FeatureConfig],non_serial_feats: List[FeatureConfig],deep1,deep2):
        super(MtlDNN, self).__init__()
        common_dim = sum(emb.embedding_dim for _, emb in enumerate(common_feats))
        serial_dim = sum(emb.embedding_dim for _, emb in enumerate(serial_feats))
        non_serial_dim = sum(emb.embedding_dim for _, emb in enumerate(non_serial_feats))
        self.common_embedding_layer = torch.nn.Sequential(EmbeddingLayer(common_feats), torch.nn.BatchNorm1d(common_dim))   
        self.serial_embedding_layer = torch.nn.Sequential(EmbeddingLayer(serial_feats), torch.nn.BatchNorm1d(serial_dim)) 
        self.non_serial_embedding_layer = torch.nn.Sequential(EmbeddingLayer(non_serial_feats), torch.nn.BatchNorm1d(non_serial_dim))   
        self.deep1,self.deep2 = deep1(dim_in=common_dim+serial_dim,dim_out=1),deep2(dim_in=common_dim+non_serial_dim,dim_out=1)

    def forward(self, common_feats: torch.Tensor,serial_feats: torch.Tensor,non_serial_feats: torch.Tensor): # inputs: [B, C]
        X_common = self.common_embedding_layer(common_feats)
        X_serial = self.serial_embedding_layer(serial_feats)
        X_non_serial = self.non_serial_embedding_layer(non_serial_feats)
        deep_out1,deep_out2 = self.deep1(torch.cat([X_common,X_serial],dim=-1)),self.deep2(torch.cat([X_common,X_non_serial],dim=-1)) # dnn_out: [B, C_deep]
        return torch.cat([deep_out1,deep_out2], dim=1)