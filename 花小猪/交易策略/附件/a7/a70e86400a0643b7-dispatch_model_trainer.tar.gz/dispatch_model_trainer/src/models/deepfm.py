import torch
from ..layers import FM
from dmlite.layers.torch import EmbeddingLayer
from dmlite.data.torch.feature_config import FeatureConfig
from typing import List

class DeepFM(torch.nn.Module):

    def __init__(self, feature, inputs: List[FeatureConfig], deep):
        super().__init__()
        self.embedding_layer = torch.nn.Sequential(EmbeddingLayer(inputs), torch.nn.Dropout(0.5))   
        input_dim = sum(emb.embedding_dim for _, emb in enumerate(inputs))
        self.deep, self.fm = deep(dim_in=input_dim), FM()
        self.out = torch.nn.Sigmoid()

    def forward(self, inputs: torch.Tensor): # inputs: [B, C]
        X = self.embedding_layer(inputs, squeeze_dim=False) # X: [B, C, E]
        # FM part
        fm_out = self.fm(X) / (self.deep.dim_in * len(self.embedding_layer.embedding_dict) / 2) # [B, 1]
        # Deep part
        deep_in = torch.flatten(X, start_dim=1, end_dim=-1) # [B, C * E]
        deep_out = self.deep(dnn_in) # [B, 1]
        # out
        out = self.out(deep_out + fm_out) # [B, 1]
        return out