import torch
from typing import List
from dmlite.layers.torch import EmbeddingLayer
from dmlite.data.torch.feature_config import FeatureConfig
from ..layers import LogitLayer

class DNN(torch.nn.Module):

    def __init__(self, inputs: List[FeatureConfig], deep):
        super(DNN, self).__init__()
        input_dim = sum(emb.embedding_dim for _, emb in enumerate(inputs))
        self.embedding_layer = torch.nn.Sequential(EmbeddingLayer(inputs,squeeze_dim=True), torch.nn.BatchNorm1d(input_dim))   
        self.deep = deep(dim_in=input_dim)
        self.combine = LogitLayer(dim_in=self.deep.dim_out, use_bias=False, use_batch_norm=True)

    def forward(self, inputs: torch.Tensor): # inputs: [B, C]
        inputs[torch.isnan(inputs)] = 0
        X = self.embedding_layer(inputs) # X: [B, C * E]
        deep_out = self.deep(X) # dnn_out: [B, C_deep]
        out = self.combine(deep_out) # out: [B, 1]
        return out