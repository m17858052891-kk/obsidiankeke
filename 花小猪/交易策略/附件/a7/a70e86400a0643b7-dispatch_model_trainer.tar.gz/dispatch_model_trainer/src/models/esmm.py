from typing import Union, Optional, Iterable, Any, Dict, List
import torch
from lightning import LightningModule
from omegaconf import DictConfig
from torch import Tensor, cat, stack, sigmoid, flatten
from dmlite.data.torch.feature_config import FeatureConfig
from dmlite.layers.torch import EmbeddingLayer

class CTCVRmodel(LightningModule):

    def __init__(self, inputs: List[FeatureConfig], ctr_net, cvr_net1, cvr_net2, cvr_net3):
        '''
            feature当前不含embedding_dim, 故partially made outside
            net中有大量参数, 故partially made outside
            loss_fn中无参数, 故totally made outside
            optimizer需要net的参数为输入, 故partially made outside
            metrics存为了DictConfig, 故需将其提取出来
        '''
        super().__init__()
        # init net
        input_dim = sum(emb.embedding_dim for _, emb in enumerate(inputs))
        self.shared_emb = torch.nn.Sequential(
            EmbeddingLayer(inputs),
            torch.nn.BatchNorm1d(input_dim),
            torch.nn.Dropout(p=0.3)  # 添加 Dropout 层，这里假设 dropout 概率为 0.5，可以根据实际情况调整
        )
        self.ctr_net = ctr_net(dim_in=input_dim, dim_out=1)
        self.cvr_net1 = cvr_net1(dim_in=input_dim, dim_out=1)
        self.cvr_net2 = cvr_net2(dim_in=input_dim, dim_out=1)
        self.cvr_net3 = cvr_net3(dim_in=input_dim, dim_out=1)

    def forward(self, X):
        emb = self.shared_emb(X)
        ctr, cvr1, cvr2, cvr3 = self.ctr_net(emb), self.cvr_net1(emb), self.cvr_net2(emb), self.cvr_net3(emb)
        ctcvr = ctr * (1-cvr1-cvr2-cvr3)
        result = torch.where(ctcvr > 0, ctcvr, torch.tensor(0.000001))
        return torch.cat([ctr, cvr1, cvr2, cvr3, result], dim=1)