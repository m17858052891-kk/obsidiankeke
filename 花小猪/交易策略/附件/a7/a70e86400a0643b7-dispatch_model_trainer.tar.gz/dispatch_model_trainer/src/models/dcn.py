import torch
from typing import Optional, List
from dmlite.layers.torch import EmbeddingLayer
from dmlite.data.torch.feature_config import FeatureConfig
from ..layers import LogitLayer

class DCN(torch.nn.Module):

    def __init__(self, inputs: List[FeatureConfig], deep, cross):
        super(DCN, self).__init__()
        input_dim = sum(emb.embedding_dim for _, emb in enumerate(inputs))
        self.embedding_layer = torch.nn.Sequential(EmbeddingLayer(inputs,squeeze_dim=True), torch.nn.BatchNorm1d(input_dim))   
        self.deep, self.cross = deep(dim_in=input_dim), cross(in_features=input_dim)
        self.combine = LogitLayer(dim_in=input_dim+self.deep.dim_out, use_bias=False, use_batch_norm=True)

    def forward(self, inputs: torch.Tensor): # inputs: [B, C]
        X = self.embedding_layer(inputs) # X: [B, C * E]
        cross_out, deep_out = self.cross(X), self.deep(X) # cross_out: [B, C * E], dnn_out: [B, C_deep]
        out = self.combine(torch.cat([cross_out, deep_out], dim=-1)) # out: [B, 1]
        return out