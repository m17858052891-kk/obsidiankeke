# coding:utf-8

from typing import Union, Optional, Iterable, Any, Dict, List
from lightning import LightningModule
import torch
from torch import nn
from dmlite.layers.torch import EmbeddingLayer
from dmlite.data.torch.feature_config import FeatureConfig
from ..layers import MLP,CGC_Layer



class PLE(LightningModule):
    def __init__(self,
                 inputs:List[FeatureConfig],
                 num_tasks=1,
                 num_layers=1,
                 num_shared_experts=1,
                 num_specific_experts=1,
                 expert_hidden_units=[512, 256, 128],
                 gate_hidden_units=[128, 64],
                 tower_hidden_units=[128, 64],
                 hidden_activations=nn.ReLU,
                 net_dropout=0,
                 batch_norm=False,
                 **kwargs):

        super().__init__()
        input_dim = sum(emb.embedding_dim for _, emb in enumerate(inputs))
        self.shared_emb = torch.nn.Sequential(
            EmbeddingLayer(inputs),
            torch.nn.BatchNorm1d(input_dim),
            torch.nn.Dropout(p=0.5)  # 添加 Dropout 层，这里假设 dropout 概率为 0.5，可以根据实际情况调整
        )
        self.num_layers = num_layers
        self.num_tasks = num_tasks
        self.cgc_layers = nn.ModuleList(
            [CGC_Layer(num_shared_experts,
             num_specific_experts,
             num_tasks,
             input_dim=input_dim if i==0 else expert_hidden_units[-1],
             expert_hidden_units= expert_hidden_units,
             gate_hidden_units=gate_hidden_units,
             hidden_activations=hidden_activations,
             net_dropout=net_dropout,
             batch_norm=batch_norm,
             is_last=(i==self.num_layers-1)) for i in range(self.num_layers)]
        )
        self.tower = nn.ModuleList([MLP(dim_in=expert_hidden_units[-1],
                                              dim_out=1,
                                              hidden_units=tower_hidden_units,
                                              hidden_activations=hidden_activations,
                                              output_activation=None,
                                              dropout_rates=net_dropout,
                                              batch_norm=batch_norm)
                                    for _ in range(num_tasks)])
        self.output_activation = nn.ModuleList([nn.Sigmoid() for _ in range(num_tasks)])
                                
       

    def forward(self, inputs:torch.Tensor):
        # print(f"training:{self.training}")
        # print(f"Inputs: {inputs}, requires_grad={inputs.requires_grad}, type={type(inputs)}")
        X = self.shared_emb(inputs)
        # print(f"Shared embedding output: {X.requires_grad}")
        cgc_inputs = [X for _ in range(self.num_tasks+1)]
        for i in range(self.num_layers):
            if i != self.num_layers - 1:
                cgc_outputs = self.cgc_layers[i](cgc_inputs)
            # print(f"CGC layer {i} output requires_grad: {[out.requires_grad for out in cgc_outputs]}")
                cgc_inputs = cgc_outputs
            else:
                cgc_outputs = self.cgc_layers[i](cgc_inputs,is_last=True)
            
        # tower_output = [self.tower[i](torch.cat([cgc_outputs[i],cgc_outputs[-1]],dim=-1)) for i in range(self.num_tasks)]
        tower_output = [self.tower[i](cgc_outputs[i]) for i in range(self.num_tasks)]

        # for i, out in enumerate(tower_output):
        #     print(f"Task {i} tower output requires_grad: {out.requires_grad}")
        y_pred = [self.output_activation[i](tower_output[i]) for i in range(self.num_tasks)]
        # for i, pred in enumerate(y_pred):
        #     print(f"Task {i} y_pred requires_grad: {pred.requires_grad}")
        return torch.cat(y_pred, dim=-1) 


      