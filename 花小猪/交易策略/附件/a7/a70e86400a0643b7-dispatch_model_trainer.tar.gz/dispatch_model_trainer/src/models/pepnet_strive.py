# coding:utf-8

from typing import Union, Optional, Iterable, Any, Dict, List
from lightning import LightningModule
import torch
from torch import nn, Tensor
from ..layers import EPNet, PPNet, LogitLayer, AutoDis_Embed_Layer, MLP, MultiHeadAttentionLayer, EmbeddingLayer
import sys
from pathlib import Path
from hydra.utils import instantiate
from dmlite.data.torch.feature_config import FeatureConfig, Categorical, Numerical


class PEPNetStrive(LightningModule):
    def __init__(
        self,
        f_general_sparse: List[FeatureConfig],
        f_general_dense: List[FeatureConfig],
        f_domain_sparse: List[FeatureConfig], 
        f_sequence: List[FeatureConfig] = [],
        dim_hidden: int = 128,
        mlp_dims: List[int] = [512, 256, 128],
        task_num: int = 1,
        task_heads: List[Dict[str, Any]] = [],
        gamma: float = 2.0,
        dropout: float = 0.1,
        bias: bool = True,
        mlp_layer_units=[512, 256, 64, 128],  # [general_sparse, general_dense, domain_sparse, side_dense, f_sequence_eta, f_sequence_anycar_type]
        dropout_rates=0.2,
        aux_task: bool = False,
    ) -> None:
        super().__init__()
        # 初始化通用特征处理层
        general_sparse_dim = sum(emb.embedding_dim for _, emb in enumerate(f_general_sparse))
        general_dense_dim = sum(emb.embedding_dim for _, emb in enumerate(f_general_dense))
        domain_sparse_dim = sum(emb.embedding_dim for _, emb in enumerate(f_domain_sparse))

        # 通用特征处理层
        self.general_sparse_embedding_layer = torch.nn.Sequential(EmbeddingLayer(f_general_sparse,squeeze_dim=True), torch.nn.BatchNorm1d(general_sparse_dim))
        self.general_sparse_layer = MLP(dim_in=general_sparse_dim, dim_out=mlp_layer_units[0], hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)
        self.general_autodis_layer = AutoDis_Embed_Layer(dense=f_general_dense, dense_layer_units=mlp_layer_units[1], dropout_rates=dropout_rates, is_field_embed=True)
        
        # 领域特征处理层
        self.domain_sparse_embedding_layer = torch.nn.Sequential(EmbeddingLayer(f_domain_sparse,squeeze_dim=True), torch.nn.BatchNorm1d(domain_sparse_dim))
        self.domain_sparse_layer = MLP(dim_in=domain_sparse_dim, dim_out=mlp_layer_units[2], hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)

        # 序列
        # 特征配置
        self.sequence_feat_mask_config = {
            'all_dri_prev_anycar_type': 5,
            'all_pas_prev_anycar_type': 5,
            'all_dri_prev_to_area': 375,
            'all_dri_prev_append': 2,
            'all_dri_prev_ccf': 2,
            'all_dri_prev_area': 375,
            'all_pas_prev_to_area': 375,
            'all_pas_prev_append': 2,
            'all_pas_prev_ccf': 2,
            'all_pas_prev_area': 375,
        }
        self.seq_embedding_layer = torch.nn.ModuleDict()
        self.attention_layers = torch.nn.ModuleDict()
        self.seq_mlp_layers = torch.nn.ModuleDict()
        self.seq_feature_mask = {}
        for seq_item in f_sequence:
            self.seq_embedding_layer[seq_item.name] = EmbeddingLayer([seq_item],squeeze_dim=False)
            self.attention_layers[seq_item.name] = MultiHeadAttentionLayer(d_model=16, num_heads=2)
            self.seq_mlp_layers[seq_item.name] =  MLP(dim_in=16, dim_out=8, hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)
            if seq_item.name not in self.sequence_feat_mask_config:
                self.seq_feature_mask[seq_item.name] = 0
            else:
                self.seq_feature_mask[seq_item.name] = self.sequence_feat_mask_config[seq_item.name]
 
        # structure param init
        init_dim = mlp_layer_units[0] + mlp_layer_units[1] + 8*len(f_sequence)
        epnet_input_dim = mlp_layer_units[0] + mlp_layer_units[1] + mlp_layer_units[2] + 8 * len(f_sequence)
        epnet_output_dim = mlp_layer_units[0] + mlp_layer_units[1] + 8 * len(f_sequence)
        ppnet_input_dim = mlp_layer_units[0] + mlp_layer_units[1] + mlp_layer_units[3] + 8 * len(f_sequence)

        mlp_dims = [init_dim] + mlp_dims

        # 初始化EPNet模块，用于处理通用和领域特征
        self.epnet = EPNet(
            gate_dim_in=epnet_input_dim,
            gate_dim_hidden=dim_hidden,
            gate_dim_out=epnet_output_dim
        )
        
        # 初始化PPNet模块，用于处理侧边和经过EPNet处理的特征
        self.ppnet = PPNet(
            gate_dim_in=ppnet_input_dim,
            gate_dim_hidden=dim_hidden,
            task_num=task_num,
            mlp_dims=mlp_dims,
            gamma=gamma,
            dropout=dropout,
            bias=bias,
        )
        
        # 多任务输出层
        self.task_heads_info = []
        self.task_heads = nn.ModuleList()
        for task in task_heads:
            assert task['task_index'] < task_num, f"task_index {task['task_index']} is out of range {task_num}"
            self.task_heads_info.append({
                "task_index": task['task_index'],
            })
            self.task_heads.append(
                task['task_head'](dim_in=mlp_dims[-1])
            )
        
    def process_sequence_feature(self, name, feature, mask_value):
        """处理单个序列特征"""
        # 填充NaN值
        feature[torch.isnan(feature)] = mask_value
         
        # 嵌入和注意力处理
        embed = self.seq_embedding_layer[name](feature).squeeze(1)
        embed, _ = self.attention_layers[name](embed, embed, embed, mask=(feature.squeeze(1) != mask_value))
        output = self.seq_mlp_layers[name](embed[:,-1,:])
        
        return output
        
    def forward(
        self,
        f_general_sparse: Tensor,
        f_general_dense: Tensor,
        f_domain_sparse: Tensor,
        f_sequence: Tensor = None
    ) -> Tensor:
        """
        前向传播函数，输入领域特征、侧边特征和通用特征，输出任务特征。
        """
        # 填充NaN值
        f_general_sparse[torch.isnan(f_general_sparse)] = 0
        f_general_dense[torch.isnan(f_general_dense)] = 0
        f_domain_sparse[torch.isnan(f_domain_sparse)] = 0
        if f_sequence is not None:
            f_sequence[torch.isnan(f_sequence)] = 0

        # 补丁
        for i,feat in enumerate(self.seq_feature_mask):
            if f_sequence is None:
                break
            if feat in ['all_dri_prev_to_area','all_pas_prev_to_area','all_dri_prev_area','all_pas_prev_area']:
                f_sequence[:,i:i+1,:][(f_sequence[:,i:i+1,:] <0) | (f_sequence[:,i:i+1,:] > 375)] = 375
            if feat in ['all_dri_prev_ccf','all_pas_prev_ccf','all_dri_prev_append','all_pas_prev_append']:
                f_sequence[:,i:i+1,:][(f_sequence[:,i:i+1,:] <0)] = 2
       
        # 处理通用稀疏特征
        f_general_sparse_embed = self.general_sparse_embedding_layer(f_general_sparse)
        f_general_sparse_embed = self.general_sparse_layer(f_general_sparse_embed)

        # 处理通用稠密特征
        f_general_dense_embed = self.general_autodis_layer(f_general_dense)

        # 处理领域稀疏特征
        f_domain_sparse_embed = self.domain_sparse_embedding_layer(f_domain_sparse)
        f_domain_sparse_embed = self.domain_sparse_layer(f_domain_sparse_embed)
        f_domain = f_domain_sparse_embed

        # 处理所有序列特征
        sequence_outputs = []
        for i,(name,mask_value) in enumerate(self.seq_feature_mask.items()):
            if f_sequence is None:
                break
            # 从输入中获取对应的特征张量
            feature = f_sequence[:,i:i+1,:]
            output = self.process_sequence_feature(name, feature, mask_value)
            sequence_outputs.append(output)
        
        # 拼接所有特征
        f_general = torch.cat([f_general_sparse_embed, f_general_dense_embed] + sequence_outputs, dim=1)

        # 通过EPNet处理通用特征和领域特征
        f_g = self.epnet(f_domain, f_general)
        
        # 通过PPNet处理侧边特征和经过EPNet处理的特征，输出任务特征
        task_feats = self.ppnet(f_g)
        
        y_pred = []
        for i, head in enumerate(self.task_heads):
            y_pred.append(head(task_feats[self.task_heads_info[i]['task_index']]))
        return torch.cat(y_pred, dim=1)