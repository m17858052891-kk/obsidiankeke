# from torch import Tensor, cat, stack, flatten, sigmoid
# from torch.nn import Module, ModuleList
# from ..layers import EmbeddingLayer

# class AutoGroup(Module):

#     def __init__(self, feature, embedding_dim, feature_group, tower, lr, max_order=3):
#         super().__init__()
#         if not isinstance(embedding_dim, int):
#             raise TypeError('embedding_dim must be the same')
#         self.emb = EmbeddingLayer(feature=feature, embedding_dim=embedding_dim, initializer="normal", std=0.01)
#         self.feature_groups = ModuleList(
#             [
#                 feature_group(
#                     num_features=len(feature), 
#                     embed_dim=embedding_dim, 
#                     order=order,
#                     topk_per_group=order
#                 ) for order in range(1, max_order+1)
#             ]
#         )
#         self.tower = tower(
#             dim_in=sum(group.dim_out for group in self.feature_groups),
#             dim_out=1
#         )
#         self.lr = lr(feature=feature)

#     def forward(self, X: Tensor): # X: [B,F]
#         emb = self.emb(X, collect="stack")
#         g = cat(
#             [
#                 flatten(group(emb), start_dim=1, end_dim=-1) 
#                 for group in self.feature_groups
#             ], dim=-1
#         )
#         logit = self.lr(X) + self.tower(g)
#         return logit if self.training else sigmoid(logit)
