# coding:utf-8

from typing import Union, Optional, Iterable, Any, Dict, List
from lightning import LightningModule
import torch
from torch import nn,Tensor
from ..layers import EPNet,PPNet,LogitLayer,AutoDis_Embed_Layer,MLP,MultiHeadAttentionLayer
import sys
from pathlib import Path

from dmlite.layers.torch import EmbeddingLayer
from dmlite.data.torch.feature_config import FeatureConfig,Categorical,Numerical


class PEPNet(LightningModule):
    def __init__(
        self,
        f_general: List[FeatureConfig],
        f_domain: List[FeatureConfig], 
        f_sequence: List[FeatureConfig],
        f_his_sequence:List[FeatureConfig],
        f_seq_cur:List[FeatureConfig],
        dim_hidden: int,
        mlp_dims: List[int],
        task_num: int,
        gamma: float = 2.0,
        dropout: float = 0.1,
        bias: bool = True,
        mlp_layer_units=[512, 256, 64, 128],  # [general_sparse, general_dense, domain_sparse, side_dense, f_sequence_eta, f_sequence_anycar_type]
        dropout_rates=0.2,
    ) -> None:
        super().__init__()
        
        # f_general_sparse = []
        # f_general_dense = []
        # f_domain_sparse = []
        # self.f_general_sparse_idx = []
        # self.f_general_dense_idx = []
        # self.f_domain_sparse_idx = []
        # for i,feat_item in enumerate(f_general):
        #     if isinstance(feat_item, Numerical):
        #         self.f_general_dense_idx.append(i)
        #         f_general_dense.append(feat_item)
        #     else:
        #         self.f_general_sparse_idx.append(i)
        #         f_general_sparse.append(feat_item)
        # for i,feat_item in enumerate(f_domain):
        #     if not isinstance(feat_item, Numerical):
        #         self.f_domain_sparse_idx.append(i)
        #         f_domain_sparse.append(feat_item)


        # 初始化通用特征处理层
        general_dim = sum(emb.embedding_dim for _, emb in enumerate(f_general))
        # general_dense_dim = sum(emb.embedding_dim for _, emb in enumerate(f_general_dense))
        domain_dim = sum(emb.embedding_dim for _, emb in enumerate(f_domain))

        # 通用特征处理层
        self.general_embedding_layer = torch.nn.Sequential(EmbeddingLayer(f_general,squeeze_dim=True), torch.nn.BatchNorm1d(general_dim))
        # self.general_sparse_layer = MLP(dim_in=general_sparse_dim, dim_out=mlp_layer_units[0], hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)
        # self.general_autodis_layer = AutoDis_Embed_Layer(dense=f_general_dense, dense_layer_units=mlp_layer_units[1], dropout_rates=dropout_rates, is_field_embed=True)
        
        # 领域特征处理层
        self.domain_embedding_layer = torch.nn.Sequential(EmbeddingLayer(f_domain,squeeze_dim=True), torch.nn.BatchNorm1d(domain_dim))
        # self.domain_sparse_layer = MLP(dim_in=domain_sparse_dim, dim_out=mlp_layer_units[2], hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)

        # 侧边特征处理层:实际上ppnet里面把side的门控去掉了，这样在caa的效果更好，这块就注释了
        # self.side_autodis_layer = AutoDis_Embed_Layer(dense=f_side_dense, dense_layer_units=mlp_layer_units[3], dropout_rates=dropout_rates, is_field_embed=True)

        # 序列
        # 特征配置
        self.sequence_feat_mask_config = {
            'all_dri_prev_anycar_type_list': 5,
            'all_pas_prev_anycar_type_list': 5,
            'all_dri_prev_to_area_list': 375,
            'all_dri_prev_append_list': 2,
            'all_dri_prev_ccf_list': 2,
            'all_dri_prev_area_list': 375,
            'all_pas_prev_to_area_list': 375,
            'all_pas_prev_append_list': 2,
            'all_pas_prev_ccf_list': 2,
            'all_pas_prev_area_list': 375,
            'all_pas_prev_car_level_list':9
        }
        self.seq_embedding_layer = torch.nn.ModuleDict()
        self.attention_layers = torch.nn.ModuleDict()
        self.seq_mlp_layers = torch.nn.ModuleDict()
        # self.seq_feature_mask = {}
        self.seq_feature_mask = {'all_dri_prev_dist_list': 0, 'all_dri_prev_dur_list': 0, 'all_dri_prev_anycar_type_list': 5, 'all_dri_prev_fee_list': 0, 'all_pas_prev_dist_list': 0, 'all_pas_prev_dur_list': 0, 'all_pas_prev_anycar_type_list': 5, 'all_pas_prev_fee_list': 0, 'all_prev_sdd_list': 0, 'all_prev_sdt_list': 0, 'all_pas_prev_sdd_list': 0, 'all_pas_prev_sdt_list': 0, 'all_dri_prev_to_area_list': 375, 'all_dri_prev_append_list': 2, 'all_dri_prev_ccf_list': 2, 'all_dri_prev_area_list': 375, 'all_pas_prev_to_area_list': 375, 'all_pas_prev_append_list': 2, 'all_pas_prev_ccf_list': 2, 'all_pas_prev_area_list': 375, 'all_pas_prev_car_level_list': 9}
        self.his_seq_feature_mask = {'all_dri_prev_wt_list':0,'all_pas_prev_wt_list':0,'all_pas_prev_csd_list':0}
        self.his_feat_name = []
        f_total_sequence = []
        for seq_item in f_sequence:
            f_total_sequence.append(seq_item)
        for seq_item in f_his_sequence:
            self.his_feat_name.append(seq_item.name)
            f_total_sequence.append(seq_item)
        for seq_item in f_total_sequence:
            self.seq_embedding_layer[seq_item.name] = EmbeddingLayer([seq_item],squeeze_dim=False)
            self.attention_layers[seq_item.name] = MultiHeadAttentionLayer(d_model=16, num_heads=2)
            self.seq_mlp_layers[seq_item.name] =  MLP(dim_in=16, dim_out=8, hidden_activations=torch.nn.ReLU, dropout_rates=dropout_rates)
            # if seq_item.name not in self.sequence_feat_mask_config:
            #     self.seq_feature_mask[seq_item.name] = 0
            # else:
            #     self.seq_feature_mask[seq_item.name] = self.sequence_feat_mask_config[seq_item.name]
 
        # structure param init
        init_dim = general_dim + 8*len(f_total_sequence) 
        epnet_input_dim = domain_dim + general_dim + 8 * len(f_total_sequence) 
        epnet_output_dim = general_dim + 8 * len(f_total_sequence) 
        ppnet_input_dim = general_dim + 8 * len(f_total_sequence) 

        mlp_dims = [init_dim] + mlp_dims

        # 初始化EPNet模块，用于处理通用和领域特征
        self.epnet = EPNet(
            gate_dim_in=epnet_input_dim,
            gate_dim_hidden=dim_hidden,
            gate_dim_out=epnet_output_dim
        )
        
        # 初始化PPNet模块，用于处理侧边和经过EPNet处理的特征
        self.ppnet = PPNet(
            gate_dim_in=ppnet_input_dim,
            gate_dim_hidden=dim_hidden,
            task_num=task_num,
            mlp_dims=mlp_dims,
            gamma=gamma,
            dropout=dropout,
            bias=bias,
        )
        
        # 多任务输出层
        self.combine_layers = nn.ModuleList(
            [
                LogitLayer(dim_in=mlp_dims[-1], use_bias=False, use_batch_norm=True)
                for i in range(task_num)
            ]
        )
        
    def process_sequence_feature(self, name, feature, mask_value):
        """处理单个序列特征"""
        # feature: [batch_size, 1, seq_len]
        # 填充NaN值
        feature[torch.isnan(feature)] = mask_value
         
        # 嵌入和注意力处理
        embed = self.seq_embedding_layer[name](feature).squeeze(1)   # [b, 1, seq_len, embd_dim] -> [b, seq_len, embd_dim]
        embed, _ = self.attention_layers[name](embed[:, -1, :].unsqueeze(1), embed, embed, mask=(feature.squeeze(1) != mask_value)) # [b,seq_len,dim]
        output = self.seq_mlp_layers[name](embed[:,-1,:])
        
        return output
        
    def forward(
        self,
        f_general: Tensor,
        f_domain: Tensor,
        f_sequence: Tensor,
        f_his_sequence: Tensor,
        f_seq_cur:Tensor
    ) -> Tensor:
        """
        前向传播函数，输入领域特征、侧边特征和通用特征，输出任务特征。
        """
        # f_general_sparse = f_general[:,self.f_general_sparse_idx]
        # f_general_dense = f_general[:,self.f_general_dense_idx]
        # f_domain_sparse = f_general[:,self.f_domain_sparse_idx]

        # 填充NaN值
        f_general[torch.isnan(f_general)] = 0
        # f_general_dense[torch.isnan(f_general_dense)] = 0
        f_domain[torch.isnan(f_domain)] = 0

        # # 补丁
        for i,feat in enumerate(self.seq_feature_mask):
            if feat in ['all_dri_prev_to_area','all_pas_prev_to_area','all_dri_prev_area','all_pas_prev_area']:
                f_sequence[:,i:i+1,:][(f_sequence[:,i:i+1,:] <0) | (f_sequence[:,i:i+1,:] > 375)] = 375
            if feat in ['all_dri_prev_ccf','all_pas_prev_ccf','all_dri_prev_append','all_pas_prev_append']:
                f_sequence[:,i:i+1,:][(f_sequence[:,i:i+1,:] <0)] = 2
       
        # 处理通用稀疏特征
        f_general = self.general_embedding_layer(f_general)
        # f_general_sparse_embed = self.general_sparse_layer(f_general_sparse_embed)

        # 处理通用稠密特征
        # f_general_dense_embed = self.general_autodis_layer(f_general_dense)

        # 处理领域稀疏特征
        f_domain = self.domain_embedding_layer(f_domain)
        # f_domain_sparse_embed = self.domain_sparse_layer(f_domain_sparse_embed)
        # f_domain = f_domain_sparse_embed
        

        # 处理所有序列特征
        f_seq_cur = f_seq_cur.unsqueeze(dim=-1)
        f_sequence = torch.cat([f_sequence,f_seq_cur],dim=-1)
        sequence_outputs = []
        idx = 0
        for i,(name,mask_value) in enumerate(self.seq_feature_mask.items()):
            # if name in self.his_feat_name:
            #     continue
            # 从输入中获取对应的特征张量
            feature = f_sequence[:,idx:idx+1,:]
            output = self.process_sequence_feature(name, feature, mask_value)
            sequence_outputs.append(output)
            idx += 1
        idx = 0
        for i,(name,mask_value) in enumerate(self.his_seq_feature_mask.items()):
            # if name not in self.his_feat_name:
            #     continue
            # 从输入中获取对应的特征张量
            feature = f_his_sequence[:,idx:idx+1,:]
            output = self.process_sequence_feature(name, feature, mask_value)
            sequence_outputs.append(output)
            idx += 1
        
        # 拼接所有特征
        f_general = torch.cat([f_general] + sequence_outputs, dim=1)

        # 通过EPNet处理通用特征和领域特征
        f_g = self.epnet(f_domain, f_general)
        
        # 通过PPNet处理侧边特征和经过EPNet处理的特征，输出任务特征
        task_feats = self.ppnet(f_g)
        
        y_pred = [self.combine_layers[i](task_feats[i]) for i in range(len(task_feats))]
        return torch.cat(y_pred, dim=1)