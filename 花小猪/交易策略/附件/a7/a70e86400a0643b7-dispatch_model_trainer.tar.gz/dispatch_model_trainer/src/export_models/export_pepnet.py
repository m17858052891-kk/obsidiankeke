import torch
from torch import nn, Tensor
from registry import EXPORTS

@EXPORTS.register_module()
class ExportPEPNet(torch.nn.Module):
    def __init__(self, model):
        super().__init__()
        # 从原始PEPNet中复制核心层（保持与原始模型一致的结构）
        self.general_embedding_layer = model.general_embedding_layer
        self.domain_embedding_layer = model.domain_embedding_layer
        self.seq_embedding_layer = model.seq_embedding_layer
        self.attention_layers = model.attention_layers
        self.seq_mlp_layers = model.seq_mlp_layers
        self.epnet = model.epnet
        self.ppnet = model.ppnet
        self.combine_layers = model.combine_layers
        
        # 复制序列特征相关配置（确保与原始处理逻辑一致）
        self.seq_feature_mask = model.seq_feature_mask
        self.his_feat_name = model.his_feat_name  # 历史序列特征名
        self.his_seq_feature_mask = model.his_seq_feature_mask
        
    

    def process_sequence_feature(self, name, feature, mask_value):
        """处理单个序列特征"""
        # 填充NaN值
        feature[torch.isnan(feature)] = mask_value
        
        # 嵌入和注意力处理
        embed = self.seq_embedding_layer[name](feature).squeeze(1)
        embed, _ = self.attention_layers[name](embed, embed, embed, mask=(feature.squeeze(1) != mask_value))
        output = self.seq_mlp_layers[name](embed[:,-1,:])
        
        return output

    def forward(
        self, 
        f_general, 
        f_domain, 
        f_sequence,  # 普通序列特征，形状 [batch, num_seq_feats, seq_len]
        f_his_sequence,  # 历史序列特征，形状 [batch, num_his_feats, seq_len]
        f_seq_cur
    ):
        f_general[torch.isnan(f_general)] = 0
        f_domain[torch.isnan(f_domain)] = 0

        # 补丁
        for i,feat in enumerate(self.seq_feature_mask):
            if feat in ['all_dri_prev_to_area','all_pas_prev_to_area','all_dri_prev_area','all_pas_prev_area']:
                f_sequence[:,i:i+1,:][(f_sequence[:,i:i+1,:] <0) | (f_sequence[:,i:i+1,:] > 375)] = 375
            if feat in ['all_dri_prev_ccf','all_pas_prev_ccf','all_dri_prev_append','all_pas_prev_append']:
                f_sequence[:,i:i+1,:][(f_sequence[:,i:i+1,:] <0)] = 2
    
        # 处理通用稀疏特征
        f_general = self.general_embedding_layer(f_general)
        # f_general_sparse_embed = self.general_sparse_layer(f_general_sparse_embed)

        # 处理通用稠密特征
        # f_general_dense_embed = self.general_autodis_layer(f_general_dense)

        # 处理领域稀疏特征
        f_domain = self.domain_embedding_layer(f_domain)
        # f_domain_sparse_embed = self.domain_sparse_layer(f_domain_sparse_embed)
        # f_domain = f_domain_sparse_embed
        

        # 处理所有序列特征
        f_seq_cur = f_seq_cur.unsqueeze(dim=-1)
        f_sequence = torch.cat([f_sequence,f_seq_cur],dim=-1)
        sequence_outputs = []
        idx = 0
        for i,(name,mask_value) in enumerate(self.seq_feature_mask.items()):
            # if name in self.his_feat_name:
            #     continue
            # 从输入中获取对应的特征张量
            feature = f_sequence[:,idx:idx+1,:]
            output = self.process_sequence_feature(name, feature, mask_value)
            sequence_outputs.append(output)
            idx += 1
        idx = 0
        for i,(name,mask_value) in enumerate(self.his_seq_feature_mask.items()):
            # if name not in self.his_feat_name:
            #     continue
            # 从输入中获取对应的特征张量
            feature = f_his_sequence[:,idx:idx+1,:]
            output = self.process_sequence_feature(name, feature, mask_value)
            sequence_outputs.append(output)
            idx += 1
        
        # 拼接所有特征
        f_general = torch.cat([f_general] + sequence_outputs, dim=1)

        # 通过EPNet处理通用特征和领域特征
        f_g = self.epnet(f_domain, f_general)
        
        # 通过PPNet处理侧边特征和经过EPNet处理的特征，输出任务特征
        task_feats = self.ppnet(f_g)
        
        y_pred = [self.combine_layers[i](task_feats[i]) for i in range(len(task_feats))]
        return torch.cat(y_pred, dim=1)