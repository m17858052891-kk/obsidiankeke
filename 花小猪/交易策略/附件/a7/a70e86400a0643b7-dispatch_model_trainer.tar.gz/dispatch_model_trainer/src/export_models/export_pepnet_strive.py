import torch
from torch import nn, Tensor
from registry import EXPORTS

@EXPORTS.register_module()
class ExportPEPNetStrive(torch.nn.Module):
    def __init__(self, model, task_heads_info = []):
        super().__init__()
        # 从原始PEPNet中复制核心层（保持与原始模型一致的结构）
        self.general_sparse_embedding_layer = model.general_sparse_embedding_layer
        self.general_sparse_layer = model.general_sparse_layer
        self.general_autodis_layer = model.general_autodis_layer
        self.domain_sparse_embedding_layer = model.domain_sparse_embedding_layer
        self.domain_sparse_layer = model.domain_sparse_layer
        self.seq_embedding_layer = model.seq_embedding_layer
        self.attention_layers = model.attention_layers
        self.seq_mlp_layers = model.seq_mlp_layers
        self.epnet = model.epnet
        self.ppnet = model.ppnet
        self.task_heads = model.task_heads
        self.task_heads_info = []
        if not task_heads_info:
            for i in range(len(self.task_heads)):
                self.task_heads_info.append({"task_index": 0})
        else:
            self.task_heads_info = task_heads_info

        # 复制序列特征相关配置（确保与原始处理逻辑一致）
        self.seq_feature_mask = model.seq_feature_mask

    def process_sequence_feature(self, name, feature, mask_value):
        """处理单个序列特征"""
        # 填充NaN值
        feature[torch.isnan(feature)] = mask_value

        # 嵌入和注意力处理
        embed = self.seq_embedding_layer[name](feature).squeeze(1)
        embed, _ = self.attention_layers[name](
            embed, embed, embed, mask=(feature.squeeze(1) != mask_value))
        output = self.seq_mlp_layers[name](embed[:, -1, :])

        return output

    def forward(
        self,
        f_general_sparse: Tensor,
        f_general_dense: Tensor,
        f_domain_sparse: Tensor,
        f_sequence: Tensor = None
    ) -> Tensor:
        """
        前向传播函数，输入领域特征、侧边特征和通用特征，输出任务特征。
        """
        # 填充NaN值
        f_general_sparse[torch.isnan(f_general_sparse)] = 0
        f_general_dense[torch.isnan(f_general_dense)] = 0
        f_domain_sparse[torch.isnan(f_domain_sparse)] = 0
        if f_sequence is not None:
            f_sequence[torch.isnan(f_sequence)] = 0

        # 处理通用稀疏特征
        f_general_sparse_embed = self.general_sparse_embedding_layer(f_general_sparse)
        f_general_sparse_embed = self.general_sparse_layer(f_general_sparse_embed)

        # 处理通用稠密特征
        f_general_dense_embed = self.general_autodis_layer(f_general_dense)

        # 处理领域稀疏特征
        f_domain_sparse_embed = self.domain_sparse_embedding_layer(f_domain_sparse)
        f_domain_sparse_embed = self.domain_sparse_layer(f_domain_sparse_embed)
        f_domain = f_domain_sparse_embed

        # 处理所有序列特征
        sequence_outputs = []

        # 拼接所有特征
        f_general = torch.cat(
            [f_general_sparse_embed, f_general_dense_embed] + sequence_outputs, dim=1)

        # 通过EPNet处理通用特征和领域特征
        f_g = self.epnet(f_domain, f_general)

        # 通过PPNet处理侧边特征和经过EPNet处理的特征，输出任务特征
        task_feats = self.ppnet(f_g)
        
        y_pred = []
        for i, head in enumerate(self.task_heads):
            y_pred.append(head(task_feats[self.task_heads_info[i]['task_index']]))
        return torch.cat(y_pred, dim=1)