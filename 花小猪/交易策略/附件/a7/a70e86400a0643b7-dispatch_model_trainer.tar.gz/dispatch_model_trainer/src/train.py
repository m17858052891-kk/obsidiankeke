import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
os.environ['TORCH_USE_CUDA_DSA'] = '1'
from typing import Any, Dict, List, Optional, Tuple
import rootutils, hydra, torch
torch.set_printoptions(threshold=float('inf'), linewidth=200)
from omegaconf import DictConfig, OmegaConf
from utils import (
    RankedLogger,
    eve_decorator,
    extras_decorator,
    DatasetConfig, 
    TrainerConfig,
    Data,
    Trainer,
    find_best_ckpt,
    find_latest_ckpt
)
import losses, metrics, export_models
from registry import EXPORTS

ROOT_PATH = rootutils.setup_root(__file__, indicator=".project-root", pythonpath=True)  
log = RankedLogger(__name__, rank_zero_only=True)

class masker(torch.nn.Module):
    def __init__(self, num_tasks=5):
        super().__init__()
        self.num_tasks = num_tasks

    @torch.no_grad()
    def forward(self, batch):
        mask = torch.ones(batch.shape,dtype=torch.bool)
        mask[:,0] = (batch[:,1] < 1)
        mask[:,1] = (batch[:,0] < 1)
        return mask

@eve_decorator
@hydra.main(version_base="1.3", config_path="../cfg", config_name="train.yaml")
@extras_decorator
def train(cfg: DictConfig) -> Optional[float]:
    
    # 初始化配置
    log.info("Instantiating dataset_config and trainer_config")
    dataset_config: DatasetConfig = DatasetConfig.from_dict(OmegaConf.to_object(cfg.dataset_config))
    trainer_config: TrainerConfig = TrainerConfig.from_dict(OmegaConf.to_object(cfg.trainer_config))
    # 生成数据、模型、训练器
    log.info("Instantiating data, model and trainer")
    data = Data(
        dataset_config=dataset_config, 
        dataloader_config=cfg.dataloader_config, 
        train_table_input=cfg.train_input, 
        val_table_input=cfg.val_input
    )
    data.prepare_data()
    model: torch.nn.Module = hydra.utils.instantiate(
        cfg.model_config, 
        **dataset_config.get_all_group_features()
    )
    trainer: Trainer = trainer_config.build_trainer()
    # load checkpoint
    if cfg.ckpt_path:
        model = trainer.load_ckpt(path=cfg.ckpt_path, model=model)
    if cfg.model_input:
        model = trainer.load_model(model_path=cfg.model_input, model=model)
    if cfg.direct_output:
        model.eval()
        export_model_config = dict(cfg.export_model_config)
        export_model_config['model'] = model
        export_model = EXPORTS.build(export_model_config)
    else:
        export_model = None
    # resume from checkpoint
    if cfg.resume and not cfg.ckpt_path:
        base_dir = os.path.join(cfg.paths.root_dir, 'outputs')
        cfg.ckpt_path = None
        if cfg.resume == 'best':
            cfg.ckpt_path = find_best_ckpt(base_dir, cfg)
            print(f"Resuming from best checkpoint: {cfg.ckpt_path}")
        elif cfg.resume == 'latest':
            cfg.ckpt_path = find_latest_ckpt(base_dir, cfg)
            print(f"Resuming from latest checkpoint: {cfg.ckpt_path}")
        else:
            log.error(f"Unknown resume mode: {cfg.resume}")
        if cfg.ckpt_path:
            log.info(f"Resuming from checkpoint: {cfg.ckpt_path}")
            model = trainer.load_ckpt(path=cfg.ckpt_path, model=model)
        
    # losses/metrics掩码
    log.info("Instantiating mask makers")
    eval_masker: Optional[torch.nn.Module] = None
    # 训练
    if cfg.direct_output:
        log.info("Direct output mode, skip training")
    else:
        log.info("Start training")
        trainer.train(
            model=model, 
            data=data, 
            eval_masker=eval_masker
        )
    trainer.save_model(cfg.paths.save_dir or cfg.paths.output_dir, dataset_config, export_model)

if __name__ == "__main__":
    train()