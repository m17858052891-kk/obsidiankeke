from typing import Dict
import numpy as np

def concat_grouped_arrays(
    arrays: Dict[str, np.ndarray],
    feature_group_list,
    label_cols=None,
    meta_cols=None,
):
    # NumPy dtype mapping for compatibility with newer versions
    dtype_mapping = {
        'float32': np.float32,
        'float64': np.float64,
        'int32': np.int32,
        'int64': np.int64,
        'string': np.str_,  # Use np.str_ instead of deprecated np.string
        'str_': np.str_,
    }
    
    grouped_arrays = []
    for g in feature_group_list:
        ga = np.stack([arrays[name] for name in g.feature_names]).swapaxes(0, 1)
        # Use dtype mapping instead of getattr(np, g.dtype)
        target_dtype = dtype_mapping.get(g.dtype, getattr(np, g.dtype, None))
        if target_dtype is None:
            # Fallback to original behavior for unknown dtypes
            target_dtype = getattr(np, g.dtype)
        ga = ga.astype(target_dtype) if ga.dtype != target_dtype else ga
        grouped_arrays.append(ga)

    if label_cols:
        la = np.stack([arrays[name] for name in label_cols]).swapaxes(0, 1)
        la = la.astype(np.float32) if la.dtype != np.float32 else la
        grouped_arrays.append(la)
    if meta_cols:
        me = np.stack([arrays[name] for name in meta_cols]).swapaxes(0, 1)
        me = me.astype(np.int64) if me.dtype != np.int64 else me
        grouped_arrays.append(me)

    return tuple(grouped_arrays)