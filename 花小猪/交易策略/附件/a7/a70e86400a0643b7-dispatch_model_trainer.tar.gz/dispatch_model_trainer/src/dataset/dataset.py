from typing import List, Optional, Callable, Union, Dict, Tuple, Any
from abc import ABC
from functools import partial
import time
import torch
from torch.utils.data import IterableDataset, Dataset, default_convert
import torch.distributed as dist
from itertools import chain

from dataset.utils import concat_grouped_arrays

from dmlite.data.torch.dataset import IterableTabularDataset, TorchDatasetInterface
from dmlite.utils import logger, EVE_DT, monitor_api
from dmlite.data.torch.config import DatasetConfig, FeatureGroup
from dmlite.data.torch.feature_config import FeatureConfig
from dmlite.data.torch.utils import (
    detect_distributed_env,
    detect_worker_env,
    broadcast_obj,
)
from dmlite.data.common.dataset import (
    TabularDataset as DMTabularDataset,
    IterableTabularDataset as DMIterableTabularDataset,
)
from torch.utils.data import IterableDataset, Dataset, default_convert

class MetaDatasetConfig(DatasetConfig):
    def __init__(
        self,
        feature_list: List[Union[FeatureConfig, str]] = None,
        feature_group_list: Optional[List[FeatureGroup]] = None,
        label: Union[str, List[str]] = None,
        meta: Union[str, List[str]] = None,
        *,
        input_fmt: str = "list",  # 'dict'
        **kwargs,
    ):
        feature_list = feature_list or []
        if len(feature_list) > 0 and isinstance(feature_list[0], str):
            logger.info(
                "`feature_list` is suggested to be type of List[FeatureConfig], not List[str]."
            )
            self.feature_list = feature_list
            self.feature_group_list = feature_group_list or [
                FeatureGroup.default_group(self.feature_list)
            ]
            self._feature_map = None
            self._feature_group_map = None
        else:
            self.feature_list = feature_list
            self.feature_group_list = feature_group_list or [
                FeatureGroup.default_group([f.name for f in self.feature_list])
            ]
            self._feature_map = {f.name: f for f in self.feature_list}
            self._feature_group_map = {g.name: g for g in self.feature_group_list}
            for group in self.feature_group_list:
                group.feature_list = [
                    self._feature_map.get(name) for name in group.feature_names
                ]

        _feature_group_names = [
            na for group in self.feature_group_list for na in group.feature_names
        ]
        if isinstance(feature_list[0], FeatureConfig):
            _feature_list_names = [f.name for f in feature_list]
        else:
            _feature_list_names = feature_list
        assert set(_feature_group_names) <= set(
            _feature_list_names
        ), "feature_list should contain all the features in feature_group_list"

        if isinstance(label, str):
            label = [label]
        self.label = label
        if isinstance(meta, str):
            meta = [meta]
        self.meta = meta

        self.input_fmt = input_fmt
        self.__kwargs = kwargs
    def get_group_features(
        self, name: Optional[str] = None, *, index: Optional[int] = None
    ) -> List[FeatureConfig]:
        """
        Get the grouped features, for building embbedding larer.
        """
        if self._feature_map is None:
            return []

        if name is not None:
            return [
                self._feature_map.get(n)
                for n in self._feature_group_map[name].feature_names
            ]
        if index is not None:
            return [
                self._feature_map.get(n)
                for n in self.feature_group_list[index].feature_names
            ]

        logger.info("No group name or index provided, returning all features.")
        return self.feature_list

    def get_feature_names(self):
        if self._feature_map is not None:
            return [f.name for f in self.feature_list]
        else:
            return self.feature_list

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the class instance to a dictionary.
        """
        if len(self.feature_list) > 0 and isinstance(self.feature_list[0], str):
            feature_list_conf = self.feature_list
        else:
            feature_list_conf = [f.to_dict(save_cls=True) for f in self.feature_list]
        feature_group_list_conf = [g.to_dict() for g in self.feature_group_list]

        dic = {
            "label": self.label,
            "meta": self.meta,
            "feature_list": feature_list_conf,
            "feature_group_list": feature_group_list_conf,
        }
        dic.update(self.__kwargs)
        return dic

class MetaIterableTabularDataset(
    DMIterableTabularDataset, IterableDataset, TorchDatasetInterface
):
    def __init__(
        self,
        table_input: str,
        feature_cols: Optional[List[str]] = None,
        label_cols: Optional[List[str]] = None,
        meta_cols: Optional[List[str]] = None,
        partition_col: Optional[Union[str, List[str]]] = None,
        partition_val: Optional[Union[str, List[str], List[List[str]]]] = None,
        config: Optional[DatasetConfig] = None,
        *,
        sql_engine: Optional[str] = "pyhive",
        preprocess: Optional[Callable] = None,
        metadata_num_threads: Optional[int] = None,
        local_cache: bool = False,
        num_threads: int = 0,
        profiling_enabled: bool = False,
        failfast_if_partition_nonexist: bool = False,
        **kwargs
    ):
        if metadata_num_threads is not None:
            assert (
                metadata_num_threads >= 1
            ), f"`metadata_num_threads` should be a postive integer, got {metadata_num_threads}"
        assert (
            num_threads >= 0
        ), f"`num_threads` should be a natural integer, got {num_threads}"
        self.setup_inputs(
            table_input=table_input,
            feature_cols=feature_cols,
            label_cols=label_cols,
            meta_cols=meta_cols,
            config=config,
            preprocess=preprocess,
        )
        super().__init__(
            table_input=self.table_input,
            columns=self._selected_cols,
            partition_col=partition_col,
            partition_val=partition_val,
            sql_engine=sql_engine,
            metadata_num_threads=metadata_num_threads,
            local_cache=local_cache,
            num_threads=num_threads,
            profiling_enabled=profiling_enabled,
            failfast_if_partition_nonexist=failfast_if_partition_nonexist,
            **kwargs
        )
        self._world_size, self._global_rank, self._local_rank, num_nodes = (
            detect_distributed_env()
        )
    
    def setup_inputs(
        self,
        table_input,
        feature_cols,
        label_cols,
        meta_cols: Optional[List[str]] = None,
        config: Optional[DatasetConfig] = None,
        preprocess: Optional[Callable] = None,
    ):
        label_cols = label_cols or []
        meta_cols = meta_cols or []
        if isinstance(label_cols, str):
            label_cols = [label_cols]
        if isinstance(meta_cols, str):
            meta_cols = [meta_cols]
        if config is None:
            assert feature_cols is not None, "feature_cols or cfg must be provided."
            self.label_cols = label_cols or []
            self.meta_cols = meta_cols or []
            self.feature_cols = feature_cols
            self.config = None
            self._feature_group_list = [FeatureGroup.default_group(feature_cols)]
        else:
            self.config = config
            self.label_cols = label_cols or self.config.label or []
            self.meta_cols = meta_cols or self.config.meta or []
            self.feature_cols = feature_cols or self.config.get_feature_names()
            self._feature_group_list = self.config.feature_group_list
        self._selected_cols = self.label_cols + self.feature_cols + self.meta_cols
        if len(set(self._selected_cols)) != len(self._selected_cols):
            logger.warning(
                "Duplicate column names found in feature_cols and label_cols."
            )
            self._selected_cols = list(set(self._selected_cols))

        self.table_input = table_input
        self.preprocess = preprocess or partial(
            concat_grouped_arrays,
            feature_group_list=self._feature_group_list,
            label_cols=self.label_cols,
            meta_cols=self.meta_cols,
        )
    def _iter_batches(self):
        for batch in super()._iter_batches():
            arrays = self.preprocess(batch)
            yield default_convert(arrays)

    def read_metadata(self):
        if self._metas is not None:
            return

        self._world_size, self._global_rank, self._local_rank, num_nodes = (
            detect_distributed_env()
        )
        if self._global_rank == 0:
            self._metas = self._read_metadata()

        if self._world_size > 1:
            if dist.is_initialized():
                meta_size = len(self._metas) if self._metas is not None else 0
                logger.info(f"Distributed environment detected, broadcasting metas, meta size: {meta_size}, world size: {self._world_size}, global rank: {self._global_rank}, local rank: {self._local_rank}")
                start_time = time.time()
                self._metas = broadcast_obj(
                    self._metas, self._global_rank, self._local_rank, self._world_size
                )
                logger.debug(f"Broadcast metas completed, meta size: {len(self._metas)}, cost time: {time.time() - start_time} seconds.")
            else:
                logger.warning(
                    "Distributed environment detected, but the process group is not initialized."
                )
                logger.warning(
                    "We STRONGLY recommend to call `init_process_group()` before creating IterableTabularDataset for efficiency."
                )
                self._metas = self._read_metadata()

    def __getitem__(self, index):
        batch = super().__getitem__(index)
        arrays = self.preprocess(batch)
        return default_convert(arrays)

    def _associate_to_workers(self):
        num_workers, worker_rank = detect_worker_env()
        num_rows = super()._associate_to_workers(
            world_size=self._world_size,
            num_workers=num_workers,
            current_rank=self._global_rank,
            current_worker_rank=worker_rank,
        )
        return num_rows



