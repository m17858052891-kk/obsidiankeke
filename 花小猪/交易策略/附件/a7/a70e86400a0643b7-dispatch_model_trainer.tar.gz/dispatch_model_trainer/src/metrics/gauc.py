from collections import defaultdict
from torchmetrics import Metric
import numpy as np
from sklearn.metrics import roc_auc_score
import torch
from registry import METRICS


@METRICS.register_module("gauc")
class GroupAUC(Metric):
    def __init__(self):
        super().__init__()
        # 用 tensor 代替 list
        self.add_state("preds", default=torch.empty(0), dist_reduce_fx="cat")
        self.add_state("targets", default=torch.empty(0, dtype=torch.long), dist_reduce_fx="cat")
        self.add_state("groups", default=torch.empty(0, dtype=torch.long), dist_reduce_fx="cat")

    def update(self, preds: torch.Tensor, targets: torch.Tensor, groups: torch.Tensor):

        preds = preds.detach().flatten()
        targets = targets.detach().long().flatten()
        groups = groups.detach().long().flatten()

        # 拼接
        self.preds = torch.cat([self.preds, preds])
        self.targets = torch.cat([self.targets, targets])
        self.groups = torch.cat([self.groups, groups])

    def compute(self):
        device = self.preds.device
        preds = self.preds.flatten()
        targets = self.targets.flatten()
        groups = self.groups.flatten()

        unique_groups, group_idx = torch.unique(groups, return_inverse=True)
        group_counts = torch.bincount(group_idx)

        pos_mask = targets == 1
        neg_mask = targets == 0

        n_pos = torch.bincount(group_idx[pos_mask], minlength=len(unique_groups)).float()
        n_neg = torch.bincount(group_idx[neg_mask], minlength=len(unique_groups)).float()

        valid_mask = (n_pos > 0) & (n_neg > 0) & ((n_pos + n_neg) >= 1)

        group_offsets = torch.zeros(len(unique_groups)+1, device=device, dtype=torch.long)
        group_offsets[1:] = torch.cumsum(group_counts, dim=0)

        # 先按 group 排序
        sort_group_idx = torch.argsort(group_idx)
        preds = preds[sort_group_idx]
        targets = targets[sort_group_idx]
        group_idx = group_idx[sort_group_idx]

        ranks = torch.zeros_like(preds, dtype=torch.float, device=device)
        for g, start, end in zip(range(len(unique_groups)), group_offsets[:-1], group_offsets[1:]):
            ranks[start:end] = torch.arange(1, end-start+1, device=device, dtype=torch.float).float()[torch.argsort(preds[start:end])]

        # pos_ranks_sum
        pos_ranks_sum = torch.zeros(len(unique_groups), device=device)
        pos_ranks_sum.scatter_add_(0, group_idx[pos_mask[sort_group_idx]], ranks[pos_mask[sort_group_idx]])

        # 计算各组 AUC
        aucs = torch.zeros(len(unique_groups), device=device)
        aucs[valid_mask] = (pos_ranks_sum[valid_mask] - n_pos[valid_mask]*(n_pos[valid_mask]+1)/2) / (n_pos[valid_mask]*n_neg[valid_mask])

        # 加权平均
        weights = n_pos[valid_mask] + n_neg[valid_mask]
        gauc = (aucs[valid_mask] * weights).sum() / weights.sum()

        return gauc