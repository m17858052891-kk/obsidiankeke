from torch import Tensor
from typing import List, Optional, Any, Dict, Union
from torchmetrics.classification import BinaryAUROC as DefaultBinaryAUROC, BinaryAccuracy as DefaultBinaryAccuracy
from registry import METRICS

@METRICS.register_module("auc")
class BinaryAUROC(DefaultBinaryAUROC):
    def update(self, preds: Tensor, target: Tensor, meta_info: Optional[Tensor]=None):
        super().update(preds, target)

@METRICS.register_module("acc")
class BinaryAccuracy(DefaultBinaryAccuracy):
    def update(self, preds: Tensor, target: Tensor, meta_info: Optional[Tensor]=None):
        super().update(preds, target)