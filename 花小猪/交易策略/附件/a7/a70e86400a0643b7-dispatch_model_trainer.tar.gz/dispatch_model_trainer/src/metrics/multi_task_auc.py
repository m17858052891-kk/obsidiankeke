from torch import Tensor, nn
import torch
from typing import List, Optional, Any, Dict, Union
from torchmetrics.classification import BinaryAUROC as DefaultBinaryAUROC, BinaryAccuracy as DefaultBinaryAccuracy
from registry import METRICS
from torchmetrics import Metric

@METRICS.register_module("multi_task_auc")
class MultiTaskAUC(Metric):
    """
    Multi-task Binary AUC
    preds:  (B, N)
    target: (B, N)
    weights: (N,)  optional task weights
    """

    full_state_update = False  # allow streaming update

    def __init__(self, num_tasks: int, weights=None, dist_sync_on_step=False):
        super().__init__(dist_sync_on_step=dist_sync_on_step)

        self.num_tasks = num_tasks

        if weights is None:
            weights = [1.0] * num_tasks
        self.register_buffer("weights", torch.tensor(weights, dtype=torch.float))

        # create per-task auc calculators
        self.task_aucs = nn.ModuleList(
            [DefaultBinaryAUROC() for _ in range(num_tasks)]
        )

    def update(self, preds: Tensor, target: Tensor, meta_info: Optional[Tensor]=None):
        """
        preds: (B, N)
        target: (B, N)
        """
        assert preds.shape == target.shape
        assert preds.shape[1] == self.num_tasks

        # update each task independently
        for i in range(self.num_tasks):
            self.task_aucs[i].update(preds[:, i], target[:, i])

    def compute(self):
        """
        Returns:
        - weighted_auc: scalar
        - per_task_auc: list, length N
        """
        per_task = torch.stack([auc.compute() for auc in self.task_aucs])  # (N,)
        weighted_auc = (per_task * self.weights).sum() / self.weights.sum()
        return weighted_auc