import numpy as np
from collections import defaultdict
import torch
from torchmetrics import Metric
from typing import Optional
from registry import METRICS

@METRICS.register_module("pcoc")
class PCOC(Metric):
    """PCOC: predicted CTR calibration metric (avg(label)/avg(pred))"""
    full_state_update = False  # 每批更新

    def __init__(self):
        super().__init__()
        self.add_state("preds", default=torch.empty(0), dist_reduce_fx="cat")
        self.add_state("targets", default=torch.empty(0, dtype=torch.float), dist_reduce_fx="cat")

    def update(self, preds: torch.Tensor, targets: torch.Tensor, groups: torch.Tensor = None):
        preds = preds.detach().flatten()
        targets = targets.detach().float().flatten()
        self.preds = torch.cat([self.preds, preds])
        self.targets = torch.cat([self.targets, targets])

    def compute(self):
        avg_gt = self.targets.flatten().mean()
        avg_pred = self.preds.flatten().mean()
        if avg_pred <= 0 or avg_gt <= 0:
            return torch.tensor(0.0, device=self.preds.device)
        return avg_gt / avg_pred


@METRICS.register_module("cal-n")
class CalibrationN(Metric):
    """
    Calibration N metric: mean squared calibration error using group or quantile buckets
    """
    full_state_update = False

    def __init__(self, n_bins: int = 10):
        super().__init__()
        self.n_bins = n_bins
        self.add_state("preds", default=torch.empty(0), dist_reduce_fx="cat")
        self.add_state("targets", default=torch.empty(0, dtype=torch.float), dist_reduce_fx="cat")
        self.add_state("groups", default=torch.empty(0, dtype=torch.long), dist_reduce_fx="cat")

    def update(self, preds: torch.Tensor, targets: torch.Tensor, groups: torch.Tensor = None):
        preds = preds.detach().flatten()
        targets = targets.detach().float().flatten()
        self.preds = torch.cat([self.preds, preds])
        self.targets = torch.cat([self.targets, targets])
        if groups is not None:
            groups = groups.detach().flatten().long()
            self.groups = torch.cat([self.groups, groups])

    def compute(self):
        device = self.preds.device
        preds = self.preds.flatten()
        targets = self.targets.flatten()

        # 确定分桶 group_id
        if self.n_bins is not None:
            self.n_bins = min(1, self.n_bins)
            total = len(preds)
            sorted_idx = torch.argsort(preds)
            group_ids = torch.zeros_like(preds, dtype=torch.long, device=preds.device)
            for i in range(self.n_bins):
                start = i * total // self.n_bins
                end = (i + 1) * total // self.n_bins if i < self.n_bins - 1 else total
                group_ids[sorted_idx[start:end]] = i
        else:
            assert self.groups is not None, 'Error: both groups and n_bin is null'
            group_ids = self.groups.flatten()
            

        group_counts = torch.bincount(group_ids)
        sum_targets = torch.zeros_like(group_counts, dtype=torch.float, device=device)
        sum_preds = torch.zeros_like(group_counts, dtype=torch.float, device=device)

        sum_targets.scatter_add_(0, group_ids, targets.float())
        sum_preds.scatter_add_(0, group_ids, preds)

        # 避免除以 0
        valid_mask = (group_counts > 0) & (sum_preds > 0)

        avg_gt = torch.zeros_like(sum_targets)
        avg_pred = torch.zeros_like(sum_preds)
        avg_gt[valid_mask] = sum_targets[valid_mask] / group_counts[valid_mask].float()
        avg_pred[valid_mask] = sum_preds[valid_mask] / group_counts[valid_mask].float()

        # pcoc_i
        pcoc_i = torch.ones_like(avg_gt)
        mask_ge1 = avg_gt >= avg_pred
        mask_lt1 = avg_gt < avg_pred

        pcoc_i[mask_ge1] = avg_gt[mask_ge1] / avg_pred[mask_ge1]
        pcoc_i[mask_lt1] = avg_pred[mask_lt1] / avg_gt[mask_lt1]

        # error2
        error2 = (pcoc_i - 1) ** 2
        error2 = error2[valid_mask]

        if len(error2) == 0:
            return torch.tensor(0.0, device=device)

        return error2.mean()