import hydra, torch, functools
from typing import List, Optional, Any, Dict, Union
from dmlite.utils import BaseConfig
from dmlite.data.torch import DatasetConfig as dmDatasetConfig
from dmlite.data.torch.feature_config import FeatureConfig,register_feature_config
from dmlite.data.torch import IterableTabularDataset
from dataset import MetaIterableTabularDataset, MetaDatasetConfig

from dataclasses import dataclass
from torchmetrics.classification import BinaryAUROC, BinaryAccuracy

# Add MultiNumerical class in FeatureConfig
# 定义 MultiNumerical 类
@register_feature_config
class MultiNumerical(FeatureConfig):
    """
    The Feature Class for multiple numerical features. Processes sequences/sets of numerical values through encoding and pooling.

    Args:
        name (str): Feature name
        index (int): Feature index
        embedding_dim (int): Embedding dimension for each individual numerical value. Default: 1
        encoding (str): Encoding method, options: 'linear' (linear transformation), 'bucketize' (discretization), None (direct pass). Default: None
        boundaries (List[float]): Boundaries for bucketize encoding (required if encoding='bucketize')
        pooling (str): Pooling method to combine multiple numerical embeddings. Options: 'sum', 'mean', 'concat'. Default: 'mean'
        max_length (int): Maximum number of numerical values in the feature (must be provided)
    """

    def __init__(
        self,
        name: str,
        index: int,
        embedding_dim: int = 1,
        encoding: Optional[str] = None,
        boundaries: Optional[List[float]] = None,
        pooling: str = "mean",
        max_length: Optional[int] = None,
    ):
        assert pooling in ["sum", "mean", "concat"], \
            f"pooling must be one of ['sum', 'mean', 'concat'], got {pooling}"
        assert max_length is not None, "max_length must be provided for MultiNumerical feature"
        super().__init__()

        self.name = name
        self.index = index
        self.embedding_dim = embedding_dim
        self.encoding = encoding
        self.boundaries = boundaries
        self.pooling = pooling
        self.max_length = max_length

    def forward(self, x: torch.Tensor, squeeze_dim: bool = True) -> torch.Tensor:
        """
        Args:
            x (torch.Tensor): Input tensor with shape (batch_size, max_length)
            squeeze_dim (bool): Whether to flatten concatenated dimensions. Default: True

        Returns:
            torch.Tensor: Pooled embedding tensor
        """
        x = x.float()  # Ensure numerical input

        # Apply encoding
        if self.encoding == "bucketize":
            # Bucketize each value (shape: [batch_size, max_length])
            x_bucket = torch.bucketize(x, self._boundaries)
            # Convert to embeddings (shape: [batch_size, max_length, embedding_dim])
            emb = self._embedding(x_bucket)
        else:
            # Reshape for linear/identity processing (shape: [batch_size, max_length, 1])
            x_reshaped = x.unsqueeze(-1)
            # Apply encoding (shape remains [batch_size, max_length, embedding_dim])
            emb = self._embedding(x_reshaped)

        # Apply pooling
        if self.pooling == "sum":
            pooled = torch.sum(emb, dim=1)  # [batch_size, embedding_dim]
        elif self.pooling == "mean":
            pooled = torch.mean(emb, dim=1)  # [batch_size, embedding_dim]
        else:  # concat
            pooled = emb  # [batch_size, max_length, embedding_dim]

        # Handle dimension squeezing for concatenated case
        if squeeze_dim and self.pooling == "concat":
            pooled = pooled.flatten(start_dim=1)  # [batch_size, max_length*embedding_dim]

        return pooled

    def build_embedding(self) -> "MultiNumerical":
        """Build encoding layers based on specified encoding method"""
        if hasattr(self, "_embedding"):
            return self

        if self.encoding == "linear":
            self._embedding = nn.Linear(1, self.embedding_dim, bias=False)
        elif self.encoding == "bucketize":
            assert self.boundaries is not None, "boundaries required for bucketize encoding"
            self.register_buffer("_boundaries", torch.tensor(self.boundaries))
            num_buckets = len(self.boundaries) + 1
            self._embedding = nn.Embedding(num_buckets, self.embedding_dim)
        else:
            assert self.embedding_dim == 1, "embedding_dim must be 1 when no encoding is used"
            self._embedding = nn.Identity()

        return self

    def __repr__(self) -> str:
        return (f"<MultiNumerical(name={self.name}, index={self.index}, "
                f"embedding_dim={self.embedding_dim}, pooling={self.pooling}, "
                f"max_length={self.max_length})>")

    
# dataset
class DatasetConfig(MetaDatasetConfig):
    def get_all_group_features(self) -> Dict[str, List[FeatureConfig]]:
        assert self._feature_map is not None, '`self._feature_map` is None, check feature config.'
        return {name : self.get_group_features(name=name) for name in self._feature_group_map}
    def build_dataset(self, table_input):
        data = MetaIterableTabularDataset(table_input=table_input, config=self)
        return data

@dataclass
class TrainerConfig(BaseConfig):
    losses_config: Dict[str, Any]
    metrics_config: Dict[str, Any]
    optimizer_config: Dict[str, Any]
    callbacks: Dict[str, Any]
    loggers: Dict[str, Any]
    accelerator: Union[str, Dict[str, Any]] = "auto"
    strategy: Union[str, Dict[str, Any]] = "auto"
    devices: Union[List[int], str, int] = "auto"
    num_nodes: int = 1
    precision: Optional[str] = None
    max_epochs: Optional[int] = None
    min_epochs: Optional[int] = None
    max_steps: int = -1
    min_steps: Optional[int] = None
    limit_train_batches: Optional[Union[int, float]] = None
    limit_val_batches: Optional[Union[int, float]] = None
    limit_test_batches: Optional[Union[int, float]] = None
    limit_predict_batches: Optional[Union[int, float]] = None
    log_every_n_steps: Optional[int] = None
    accumulate_grad_batches: int = 1
    gradient_clip_val: Optional[Union[int, float]] = None
    gradient_clip_algorithm: Optional[str] = None
    default_root_dir: Optional[str] = None
    
    def __post_init__(self):
        self.sync_batchnorm: bool = True
        self.use_distributed_sampler: bool = False
        self.check_val_every_n_epoch = None

    @classmethod
    def from_dict(cls, trainer_dict):
        return cls(**trainer_dict)
    
    def to_dict(self):
        return self.__dict__.copy()

    def build_trainer(self):
        from .core import Trainer
        config_dict = self.__dict__.copy()
        callbacks = config_dict.pop('callbacks', None)
        loggers = config_dict.pop('loggers', None)
        accelerator = config_dict.pop('accelerator', None)
        strategy = config_dict.pop('strategy', None)
        return Trainer(
            callbacks=[hydra.utils.instantiate(cb_conf) for _, cb_conf in callbacks.items() if "_target_" in cb_conf] if callbacks else None,
            logger=[hydra.utils.instantiate(lg_conf) for _, lg_conf in loggers.items() if "_target_" in lg_conf] if loggers else None,
            accelerator=accelerator if not accelerator or isinstance(accelerator, str) else hydra.utils.instantiate(accelerator),
            strategy=strategy if not strategy or isinstance(strategy, str) else hydra.utils.instantiate(strategy),
            **config_dict)
