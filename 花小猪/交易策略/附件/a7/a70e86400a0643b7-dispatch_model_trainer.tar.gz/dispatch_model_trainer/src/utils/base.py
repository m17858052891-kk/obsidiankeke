
import logging, warnings, os, argparse, sys, functools
from typing import Mapping, Any, Callable, Dict, Optional, Tuple
from lightning_utilities.core.rank_zero import rank_prefixed_message, rank_zero_only
from omegaconf import DictConfig
from lightning import seed_everything

class RankedLogger(logging.LoggerAdapter):
    """A multi-GPU-friendly python command line logger."""

    def __init__(
        self,
        name: str = __name__,
        rank_zero_only: bool = False,
        extra: Optional[Mapping[str, object]] = None,
    ) -> None:
        """Initializes a multi-GPU-friendly python command line logger that logs on all processes
        with their rank prefixed in the log message.

        :param name: The name of the logger. Default is ``__name__``.
        :param rank_zero_only: Whether to force all logs to only occur on the rank zero process. Default is `False`.
        :param extra: (Optional) A dict-like object which provides contextual information. See `logging.LoggerAdapter`.
        """
        logger = logging.getLogger(name)
        super().__init__(logger=logger, extra=extra)
        self.rank_zero_only = rank_zero_only

    def log(self, level: int, msg: str, rank: Optional[int] = None, *args, **kwargs) -> None:
        """Delegate a log call to the underlying logger, after prefixing its message with the rank
        of the process it's being logged from. If `'rank'` is provided, then the log will only
        occur on that rank/process.

        :param level: The level to log at. Look at `logging.__init__.py` for more information.
        :param msg: The message to log.
        :param rank: The rank to log at.
        :param args: Additional args to pass to the underlying logging function.
        :param kwargs: Any additional keyword args to pass to the underlying logging function.
        """
        if self.isEnabledFor(level):
            msg, kwargs = self.process(msg, kwargs)
            current_rank = getattr(rank_zero_only, "rank", None)
            if current_rank is None:
                raise RuntimeError("The `rank_zero_only.rank` needs to be set before use")
            msg = rank_prefixed_message(msg, current_rank)
            if self.rank_zero_only:
                if current_rank == 0:
                    self.logger.log(level, msg, *args, **kwargs)
            else:
                if rank is None:
                    self.logger.log(level, msg, *args, **kwargs)
                elif current_rank == rank:
                    self.logger.log(level, msg, *args, **kwargs)

def transform_eve_args():
    args_map = {
        'trainInputs': 'train_input',
        'valInputs': 'val_input',
        'saveDir': 'paths.save_dir',
        'modelInputs': 'model_input',
        'featureCols': None,
        'labelCols': None
        # 'featureCols': ['data.train_loader.feature_cols', 'data.val_loader.feature_cols'],
        # 'labelCols': ['data.train_loader.label_cols', 'data.val_loader.label_cols']
    }
    parser = argparse.ArgumentParser()
    for k in args_map:
        parser.add_argument(f'--{k}', type=str, required=False, default=None)
    args, _ = parser.parse_known_args()
    sys.argv = [arg for arg in sys.argv if not (arg.startswith('--') and arg[2:].split('=')[0] in args_map)] + \
        [f'{args_map[k]}={v}' for k,v in vars(args).items() if args_map.get(k, None) and v is not None]

def eve_decorator(task_function):
    @functools.wraps(task_function)
    def wrapper(*args, **kwargs):
        transform_eve_args()
        return task_function(*args, **kwargs)
    return wrapper

def extras(cfg: DictConfig) -> None:
    if cfg.get("ignore_warnings"):
        warnings.filterwarnings("ignore")
    if cfg.get("seed"):
        seed_everything(cfg.seed, workers=True)

def extras_decorator(task_function):
    @functools.wraps(task_function)
    def wrapper(cfg: DictConfig):
        extras(cfg)
        return task_function(cfg)
    return wrapper
    