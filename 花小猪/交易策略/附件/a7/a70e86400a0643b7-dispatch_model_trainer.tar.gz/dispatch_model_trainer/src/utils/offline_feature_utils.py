# coding:utf-8

import yaml

def gen_feature_group_config():
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_pepnet.yaml'
    outpath = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_pepnet1.yaml'
    f_domain = ['is_serial_driver','is_serial']
    f_side = ['call_cnt_p7d','call_cnt_p14d','call_cnt_p30d','call_cnt_p90d']
    add_feats = [['start_county_id',2758],['dest_county_id',2758],['skycon_sparse',11],['dest_poi_l1_type_sparse',27],
                    ['is_cross_county',2],['has_coupon',2]]
    f_general = []
    real_f_domain = []
    real_f_side = []
    with open(path) as f:
        feature_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_group_list = feature_dict['feature_group_list']
        feature_list = feature_dict['feature_list']
        feature_names = []
        idx = len(feature_list)
        for item in feature_group_list:
            for name in item['feature_names']:
                feature_names.append(name)
        for feat,num in add_feats:
            feature_list.append({
                        'cls': 'Categorical',
                        'embedding_dim': 16,
                        'encoding': 'hash',
                        'index': idx,
                        'name': feat,
                        'num_embeddings': num
            })
            feature_names.append(feat)
            idx += 1
        for feat in f_domain:
            if feat in feature_names:
                real_f_domain.append(feat)
        for feat in f_side:
            if feat in feature_names:
                real_f_side.append(feat)
        for feat in feature_names:
            if feat not in real_f_domain and feat not in real_f_side:
                f_general.append(feat)
        feature_group_list = []
        for k,v in [('f_general',f_general),('f_domain',real_f_domain),('f_side',real_f_side)]:
            feature_group_list.append({
                                        'dtype':'float32',
                                        'feature_names':v,
                                        'name':k,
                                        'shape':[-1,len(v)]
                                    })
        feature_dict['feature_group_list'] = feature_group_list    
        feature_dict['feature_list'] = feature_list



    with open(outpath,'w') as w:
        yaml.dump(feature_dict, w)
    print(f_general)
    print('-----')
    print(real_f_domain)
    print('------')
    print(real_f_side)
    print('------')
    print(','.join(feature_names))

def gen_feat_map():
    path = 'dispatch_model_trainer/cfg/dataset_config/county_id_map.txt'
    outpath = 'dispatch_model_trainer/cfg/dataset_config/feat_map.yaml'
    res = {}
    mapping = ''
    mappingObj = {}
    with open(path) as f:
        for line in f:
            fields = line.strip().split('\t')
            county,cid = fields
            county = county.strip()
            cid = cid.strip()
            mapping += f'{county}:{cid},'
            mappingObj[county] = cid
        mapping += f'elseValue:{int(cid)+1}'
        mappingObj['elseValue'] = int(cid)+1
        res = [{
            'new_column':'start_county_id',
            'operate':'feature_mapping',
            'selected':{
                'feature': 'start_county_id',
                'type': 'int',
                'fromAdd': False
            },
            'returnType':'int',
            'mapping':mapping,
            'mappingObj':mappingObj
        }]
    with open(outpath,'w') as w:
        yaml.dump(res, w)






def gen_feature_list_str():
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_pepnet1.yaml'
    with open(path) as f:
        feature_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_group_list = feature_dict['feature_group_list']
        feature_names = []
        group_feature_names_dict = {}
        for item in feature_group_list:
            group_feature_names = []
            for name in item['feature_names']:
                group_feature_names.append(name)
                feature_names.append(name)
            print(item['name'],'=',group_feature_names)
    print(','.join(feature_names))


def remove_idx():
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_dri_caa_sparse_dense2.yaml'
    with open(path) as f:
        feature_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_list = feature_dict['feature_list']
        new_feature_list = []
        for item in feature_list:
            item.pop('index')
            new_feature_list.append(item)
        feature_dict['feature_list'] = new_feature_list
    outpath = 'dispatch_model_trainer/cfg/dataset_config/pas_dri_caa_sparse_dense3.yaml'
    with open(outpath,'w') as w:
        yaml.dump(feature_dict, w)


def gen_newtop_config():
    path = 'dispatch_model_trainer/cfg/dataset_config/feature_selects.txt'
    with open(path) as f:
        for line in f:
            feats = line.strip().split(',')
    path = 'dispatch_model_trainer/cfg/dataset_config/seq_config.yaml'
    seq_config = {}
    with open(path) as f:
        data_dict = yaml.load(f,Loader=yaml.SafeLoader)
        for item in data_dict:
            seq_config[item['name']] = item
        
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_newtop.yaml'
    category_config = {}
    with open(path) as f:
        data_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_list = data_dict['feature_list']
        for item in feature_list:
            if item['cls'] == 'Categorical':
                item.pop('index')
                category_config[item['name']] = item
    category_config['is_offline_rq'] = {
        'cls': 'Categorical',
        'embedding_dim': 16,
        'encoding': 'hash',
        'name': 'is_offline_rq',
        'num_embeddings': 2
    }
    category_config['is_yidi'] = {
        'cls': 'Categorical',
        'embedding_dim': 16,
        'encoding': 'hash',
        'name': 'is_yidi',
        'num_embeddings': 2
    }
    new_feature_list = []
    new_group_list = []
    group_dict = {'f_general':[],'f_domain':[],'f_sequence':[],'f_his_sequence':[]}
    for feat in feats:
        feat = feat.strip()
        if feat in category_config:
            new_feature_list.append(category_config[feat])
        elif feat in seq_config:
            new_feature_list.append(seq_config[feat])
        else:
            new_feature_list.append({
                'name':feat,
                'cls':'Numerical'
            })
        if feat in ['is_serial_driver']:
            group_dict['f_domain'].append(feat)
        elif feat in seq_config.keys():
            if feat not in ['all_dri_prev_wt','all_pas_prev_wt','all_pas_prev_csd']:
                group_dict['f_sequence'].append(feat)
            else:
                group_dict['f_his_sequence'].append(feat)
        else:
            group_dict['f_general'].append(feat)
    for type in ['f_general','f_domain','f_sequence','f_his_sequence']:
        new_group_list.append({
                'dtype': 'float32',
                'feature_names':group_dict[type],
                'name': type,
                'shape':[-1,len(group_dict[type])]
        })
        print(f"{type}=",group_dict[type])
    res = {}
    res['feature_group_list'] = new_group_list
    res['feature_list'] = new_feature_list
    res['label'] = 'is_pas_cancel_after'
    outpath = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_seq.yaml'
    with open(outpath,'w') as w:
        yaml.dump(res, w)


def filter_useless_opreator():
    path = 'dispatch_model_trainer/cfg/dataset_config/all_feat.txt'
    with open(path) as f:
        for line in f:
            feats = line.strip().split(',')
        feats = [feat.strip() for feat in feats]
    path = 'dispatch_model_trainer/cfg/dataset_config/cur_opreator.yaml'
    new_op_list = []
    new_cols = []
    with open(path) as f:
        op_list = yaml.load(f,Loader=yaml.SafeLoader)
        for item in op_list:
            feat = item['selected']['feature']
            new_col = item['new_column']
            if new_col not in new_cols:
                new_cols.append(new_col)
            if feat.endswith('_transform'):
                feat = feat.replace('_transform','')
            if feat not in feats:
                print(feat)
                # continue
            # if feat not in new_cols:
            #     print(feat)
            #     continue
            if feat not in ['intensity']:
                new_op_list.append(item)
        a = 1
    outpath = 'dispatch_model_trainer/cfg/dataset_config/dri_opreator.yaml'
    with open(outpath,'w') as w:
        yaml.dump(new_op_list, w)
   

    
 
def merge_opreator():
    merge_op_list = []
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_opreator.yaml'
    with open(path) as f:
        pas_op_list = yaml.load(f,Loader=yaml.SafeLoader)
        merge_op_list.extend(pas_op_list)
    path = 'dispatch_model_trainer/cfg/dataset_config/dri_opreator.yaml'
    with open(path) as f:
        dri_op_list = yaml.load(f,Loader=yaml.SafeLoader)
        for item in dri_op_list:
            if item not in merge_op_list:
                print(item)
                merge_op_list.append(item)
    outpath = 'dispatch_model_trainer/cfg/dataset_config/merge_opreator.yaml'
    with open(outpath,'w') as w:
        yaml.dump(merge_op_list, w)



def merge_feat_selected():
    merge_feats = []
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_feat_selected.txt'
    with open(path) as f:
        for line in f:
            feats = line.strip().split(',')
            for feat in feats:
                feat = feat.strip()
                if feat not in merge_feats:
                    merge_feats.append(feat)
    path = 'dispatch_model_trainer/cfg/dataset_config/dri_feature_selected.txt'
    with open(path) as f:
        for line in f:
            feats = line.strip().split(',')
            for feat in feats:
                feat = feat.strip()
                if feat not in merge_feats:
                    merge_feats.append(feat)
    outpath = 'dispatch_model_trainer/cfg/dataset_config/merge_feat_selected.txt'
    with open(outpath,'w') as w:
        w.write(','.join(merge_feats))


def merge_feature_config_yaml():
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_pepnet1.yaml'
    new_f_general_list = []
    new_f_domain_list = []
    new_feature_group_list = []
    new_feature_list = []
    new_label_list = []
    with open(path) as f:
        pas_config_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_group_list = pas_config_dict['feature_group_list']
        new_f_general_list = feature_group_list[0]['feature_names']
        new_f_domain_list = feature_group_list[1]['feature_names']
        feature_list = pas_config_dict['feature_list']
        new_label_list.extend(pas_config_dict['label'])
    path = 'dispatch_model_trainer/cfg/dataset_config/dri_caa_pepnet1.yaml'
    with open(path) as f:
        dri_config_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_group_list = dri_config_dict['feature_group_list']
        dri_f_general_list = feature_group_list[0]['feature_names']
        dri_f_domain_list = feature_group_list[1]['feature_names']
        dri_feature_list = dri_config_dict['feature_list']
        new_label_list.extend(dri_config_dict['label'])
        for item in dri_feature_list:
            if item not in feature_list:
                feature_list.append(item)
        for feat in dri_f_general_list:
            if feat not in new_f_general_list:
                new_f_general_list.append(feat)
            print(f'f_general=',new_f_general_list)
        for feat in dri_f_domain_list:
            if feat not in new_f_domain_list:
                new_f_domain_list.append(feat)
            print(f'f_domain=',new_f_domain_list)
        idx = 0
        for item in feature_list:
            if item['name'] in new_f_general_list or item['name'] in new_f_domain_list: 
                # item['index'] = idx
                new_feature_list.append(item)
                idx += 1
        new_feature_group_list.append({
            'dtype':'float32',
            'feature_names':new_f_general_list,
            'name':'f_general',
            'shape':[-1,len(new_f_general_list)]
        })
        new_feature_group_list.append({
            'dtype':'float32',
            'feature_names':new_f_domain_list,
            'name':'f_domain',
            'shape':[-1,len(new_f_domain_list)]
        })
    res = {
        'feature_group_list':new_feature_group_list,
        'feature_list':new_feature_list,
        'label':new_label_list
    }
    outpath = 'dispatch_model_trainer/cfg/dataset_config/pas_dri_caa_pepnet.yaml'
    with open(outpath,'w') as w:
        yaml.dump(res, w)
        






def remove_idx():
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_pepnet1.yaml'
    with open(path) as f:
        feature_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_list = feature_dict['feature_list']
        new_feature_list = []
        for item in feature_list:
            item.pop('index')
            new_feature_list.append(item)
        feature_dict['feature_list'] = new_feature_list
    outpath = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_pepnet6.yaml'
    with open(outpath,'w') as w:
        yaml.dump(feature_dict, w)

def gen_dnn_feat_file():
    path = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_pepnet6.yaml'
    with open(path) as f:
        feature_dict = yaml.load(f,Loader=yaml.SafeLoader)
        feature_group = feature_dict['feature_group_list'][0]
        feature_group['name'] = 'inputs'
        new_feature_group_list = [feature_group]
        feature_list = feature_dict['feature_list']
        new_feature_list = []
        sparse_list = []
        dense_list = []
        for item in feature_list:
            if item['name'] not in feature_group['feature_names']:
                continue
            if item['cls'] == 'Categorical':
                sparse_list.append([item['name'],item['embedding_dim'],item['num_embeddings']])
            if item['cls'] == 'Numerical':
                dense_list.append(item['name'])
            new_feature_list.append(item)
    feature_dict['feature_group_list'] = new_feature_group_list
    feature_dict['feature_list'] = new_feature_list
    outpath = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_dnn.yaml'
    with open(outpath,'w') as w:
        yaml.dump(feature_dict, w)
    outpath = 'dispatch_model_trainer/cfg/dataset_config/dense.txt'
    with open(outpath,'w') as w:
        for r in dense_list:
            w.write(r+'\n')
    outpath = 'dispatch_model_trainer/cfg/dataset_config/sparse.txt'
    with open(outpath,'w') as w:
        for r in sparse_list:
            w.write('\t'.join(map(str,r))+'\n')    


def gen_dnn_feat_config():
    feature_list = []
    feature_group = []
    path = 'dispatch_model_trainer/cfg/dataset_config/sparse.txt'
    with open(path) as f:
        for line in f:
            fields = line.strip().split('\t')
            name,embedding_dim,num_embeddings = fields
            embedding_dim = int(embedding_dim)
            num_embeddings = int(num_embeddings)
            feature_list.append({
                'cls':'Categorical',
                'name':name,
                'embedding_dim':embedding_dim,
                'num_embeddings':num_embeddings,
                'encoding':'hash'
            })
            feature_group.append(name)
    path = 'dispatch_model_trainer/cfg/dataset_config/dense.txt'
    with open(path) as f:
        for line in f:
            feat = line.strip()
            feature_list.append({
                'cls':'Numerical',
                'name':feat
            })
            feature_group.append(feat)
    feature_group_list = [{'dtype':'float32','feature_names':feature_group,'name':'inputs','shape':[-1,len(feature_group)]}]
    res = {
        'feature_group_list':feature_group_list,
        'feature_list':feature_list,
        'label':['finish_5min_label']
    }
    outpath = 'dispatch_model_trainer/cfg/dataset_config/pas_caa_dnn1.yaml'
    with open(outpath,'w') as w:
        yaml.dump(res, w)








def stat_id_feature():
    from dmlite.common.table import DataFrameIO
    dfio = DataFrameIO()
    df = dfio.read_table(table_name='match_strategy.ether_self_sql_139149_c6007390407584045_1751965379304_2135305611456444_temp_1752214818464',columns=['f_grid_id'])
    # passenger_freq = df['passenger_id'].value_counts()
    # print("Passenger ID 分布：\n", passenger_freq.describe())
    # driver_freq = df['driver_id'].value_counts()
    # print("Driver ID 分布：\n", driver_freq.describe())
    driver_freq = df['f_grid_id'].value_counts()
    print("fgird ID 分布：\n", driver_freq.describe())



    



if __name__ == '__main__':
    # gen_feature_group_config()
    # gen_feature_list_str()
    # stat_id_feature()
    # remove_idx()
    # gen_dnn_feat_file()
    # gen_dnn_feat_config()
    # gen_feat_map()
    # gen_feature_list_str()
    # remove_idx()
    # gen_newtop_config()
    # merge_opreator()
    # filter_useless_opreator()
    # merge_feat_selected()
    merge_feature_config_yaml()
