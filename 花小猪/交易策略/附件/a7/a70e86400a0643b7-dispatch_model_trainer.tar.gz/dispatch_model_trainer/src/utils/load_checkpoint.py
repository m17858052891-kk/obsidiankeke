import os
import glob
import yaml
import re
from omegaconf import OmegaConf, DictConfig
from datetime import datetime

def safe_get_cfg(cfg, keys, default=None):
    """从 DictConfig 中安全取值"""
    try:
        return OmegaConf.select(cfg, ".".join(keys), default=default)
    except Exception:
        return default


def safe_get_dict(d, keys, default=None):
    """从普通 dict 中安全取值"""
    for k in keys:
        if not isinstance(d, dict) or k not in d:
            return default
        d = d[k]
    return d

def parse_ckpt_info(ckpt_path):
    # 解析 ckpt 文件名中的 epoch 和 step
    # 例如 epoch=20-step=6000.ckpt
    fname = os.path.basename(ckpt_path)
    match = re.search(r'epoch=(\d+)-step=(\d+)', fname)
    if match:
        epoch = int(match.group(1))
        step = int(match.group(2))
        return epoch, step
    return 0, 0

def config_match(cfg: DictConfig, config_file: str):
    if not os.path.exists(config_file):
        return False

    # 读取保存的 hydra config.yaml
    with open(config_file, "r") as f:
        saved = yaml.safe_load(f)

    # 取 saved 配置字段
    saved_feat_group = safe_get_dict(saved, ["dataset_config", "feature_group_list"])
    saved_feat_list = safe_get_dict(saved, ["dataset_config", "feature_list"])
    saved_label = safe_get_dict(saved, ["dataset_config", "label"])
    saved_model_cfg = safe_get_dict(saved, ["model_config"])

    # 从当前 DictConfig 中取
    cur_feat_group = safe_get_cfg(cfg, ["dataset_config", "feature_group_list"])
    cur_feat_list = safe_get_cfg(cfg, ["dataset_config", "feature_list"])
    cur_label = safe_get_cfg(cfg, ["dataset_config", "label"])
    cur_model_cfg = safe_get_cfg(cfg, ["model_config"])

    # 直接比较（OmegaConf 对象可以先转 dict）
    return (
        saved_feat_group == cur_feat_group and
        saved_feat_list == cur_feat_list and
        saved_label == cur_label and
        saved_model_cfg == OmegaConf.to_container(cur_model_cfg)
    )

def find_best_ckpt(base_dir, cfg):
    best_ckpt = None
    best_epoch, best_step = -1, -1

    for subdir in os.listdir(base_dir):
        exp_dir = os.path.join(base_dir, subdir)
        hydra_cfg = os.path.join(exp_dir, ".hydra", "config.yaml")
        if not os.path.isdir(exp_dir) or not os.path.exists(hydra_cfg):
            continue

        # 配置不一致则跳过
        if not config_match(cfg, hydra_cfg):
            continue

        ckpts = glob.glob(os.path.join(exp_dir, "epoch=*-step=*.ckpt"))
        for ckpt in ckpts:
            epoch, step = parse_ckpt_info(ckpt)
            if (epoch > best_epoch) or (epoch == best_epoch and step > best_step):
                best_epoch, best_step = epoch, step
                best_ckpt = ckpt
    return best_ckpt

def extract_timestamp(subdir_name):
    """
    从目录名中解析日期时间。格式如：2025-11-21_15-25-26_debug
    只取前面的日期+时间部分：2025-11-21_15-25-26
    """
    try:
        ts_str = subdir_name.split("_debug")[0]   # 或者 split("_")[0:3]
        ts_str = "_".join(ts_str.split("_")[:2])  # 保留 YYYY-MM-DD_HH-MM-SS
        return datetime.strptime(ts_str, "%Y-%m-%d_%H-%M-%S")
    except:
        return None

def find_latest_ckpt(base_dir, cfg):
    latest_ckpt = None
    latest_ts = None

    for subdir in os.listdir(base_dir):
        exp_dir = os.path.join(base_dir, subdir)
        hydra_cfg = os.path.join(exp_dir, ".hydra", "config.yaml")
        if not os.path.isdir(exp_dir) or not os.path.exists(hydra_cfg):
            continue
        # 配置不一致则跳过
        if not config_match(cfg, hydra_cfg):
            continue
        ts = extract_timestamp(subdir)
        if ts is None or (latest_ts is not None and ts <= latest_ts):
            continue
        
        ckpts = glob.glob(os.path.join(exp_dir, "epoch=*-step=*.ckpt"))
        best_epoch, best_step = -1, -1
        for ckpt in ckpts:
            epoch, step = parse_ckpt_info(ckpt)
            if (epoch > best_epoch) or (epoch == best_epoch and step > best_step):
                best_epoch, best_step = epoch, step
                latest_ckpt = ckpt
                latest_ts = ts
    return latest_ckpt