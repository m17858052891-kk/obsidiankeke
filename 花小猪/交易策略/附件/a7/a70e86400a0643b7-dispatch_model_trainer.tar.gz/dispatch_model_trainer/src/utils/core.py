import hydra, torch
from lightning import Trainer as plTrainer, LightningModule, LightningDataModule
from typing import List, Optional, Any, Dict, Union
from dmlite.data.torch import IterableTabularDataLoader, IterableTabularDataset
from dmlite.train.torch import save_model as dm_save_model, load_model as dm_load_model
import dmlite.tracing as tracing
from dmlite.utils import is_hdfs_path, is_o3fs_path, ONLINE_DIR, EXPORT_DIR, TORCH_SCRIPT_MODEL, TORCH_MODEL_STATE_DICT
import tempfile, os
import os.path as osp
from collections import OrderedDict

# metrics
from torchmetrics.metric import Metric
from torchmetrics.wrappers import MultitaskWrapper
from torchmetrics.collections import MetricCollection
from registry import LOSSES, METRICS, OPTIMIZERS, SCHEDULERS

class Losses(torch.nn.Module):
    def __init__(self, task_losses_config: Dict[str, Any]):
        super(Losses, self).__init__()
        self.task_idx = []
        self.task_dim = []
        self.task_weights = []
        self.task_losses = torch.nn.ModuleDict()
        cur_idx = 0
        # TODO: consider if len(gt) != 1
        for task_name, task_loss_config in task_losses_config.items():
            if task_loss_config:
                idx = cur_idx
                if "idx" in task_loss_config:
                    idx = task_loss_config.pop("idx")
                dim = 1
                if "dim" in task_loss_config:
                    dim = task_loss_config.pop("dim")
                weight = 1.0
                if "weight" in task_loss_config:
                    weight = task_loss_config.pop("weight")
                
                self.task_idx.append(idx)
                self.task_dim.append(dim)
                self.task_weights.append(weight)
                cur_idx += dim
                loss_fn_name = task_loss_config.get('cls')
                loss_fn = LOSSES.build(task_loss_config)
                self.task_losses.update({f"{task_name}/{loss_fn_name}" : loss_fn})

    def forward(self, ypreds: torch.Tensor, ys: torch.Tensor, masks: Optional[torch.Tensor]=None, prefix: Optional[str]=None,step: Optional[int]=None,tracer: Optional[tracing.Tracer]=None):
        total_loss, task_loss_info = torch.zeros(1, device=ypreds.device), {}
        task_num = len(self.task_idx)
        for i, (task_loss_name, loss_fn) in enumerate(self.task_losses.items()):
            idx = self.task_idx[i]
            dim = self.task_dim[i]
            weight = self.task_weights[i]
            ypred, y = ypreds[:, idx:idx+dim].squeeze(), ys[:, idx:idx+dim].squeeze()
            if masks is not None:
                # TODO: adapt mask
                mask = masks[:, idx:idx+dim].detach()
                ypred, y = ypred[mask], y[mask]
            task_loss = loss_fn(input=ypred, target=y.float()).squeeze()
            # 记录每个任务的损失
            if step is not None:
                tracer.log(name=f"{prefix}/{task_loss_name}", value=task_loss.item(), global_step=step)
            task_loss_info[f'{prefix}/{task_loss_name}'] = task_loss.detach()
            total_loss += weight * task_loss
        # 记录总损失
        if step is not None:
            tracer.log(name=f"{prefix}/total_loss", value=total_loss.item(), global_step=step)
        return total_loss, task_loss_info

class Metrics(MultitaskWrapper): 

    def __init__(self, task_metrics_config: Dict[str, Dict[str, Any]]):
        task_metrics = {}
        self.task_idx_dim = {}

        for task_name, metrics_config in task_metrics_config.items():
            if metrics_config:
                idx = 0
                dim = 1
                for config in metrics_config:
                    if "idx" in config and "dim" in config:
                        idx = config.pop("idx")
                        dim = config.pop("dim")
                        metrics_config.remove(config)
                        break
                self.task_idx_dim[task_name] = (idx, dim)

                metrics_collection = {}
                for metric_config in metrics_config:
                    if "cls" not in metric_config:
                        continue
                    metric_name = metric_config.get('cls')
                    metric_fn = METRICS.build(metric_config)
                    metrics_collection[metric_name] = metric_fn
                task_metrics[task_name] = MetricCollection(metrics_collection)
        super(Metrics, self).__init__(task_metrics=task_metrics)

    def update(self, preds: torch.Tensor, targets: torch.Tensor, masks: Optional[torch.Tensor]=None, meta_info: Optional[torch.Tensor]=None) -> None:
        if not preds.shape == targets.shape:
            raise ValueError(
                "Expected arguments `preds` and `targets` to have the same shape of (batch_size, num_tasks)."
                f"Found preds.shape={preds.shape} and targets.shape={targets.shape}" 
            )
        if masks is not None and not preds.shape == masks.shape:
            raise ValueError(
                "Expected arguments `preds` and `masks` to have the same shape of (batch_size, num_tasks)."
                f"Found preds.shape={preds.shape} and masks.shape={masks.shape}" 
            )

        for task_name, metric in self.task_metrics.items():
            if task_name not in self.task_idx_dim:
                raise ValueError(
                    f"Task {task_name} not found in `task_idx_dim`."
                )
            idx, dim = self.task_idx_dim[task_name]
            pred, target = preds[:, idx:idx+dim].detach(), targets[:, idx:idx+dim].detach()
            
            meta_info_exp = meta_info.repeat(1, dim) if meta_info is not None else None
            if masks is not None:
                mask = masks[:, idx:idx+dim].detach()
                pred, target = pred[mask], target[mask]
                meta_info_exp = meta_info_exp[mask] if meta_info_exp is not None else None
            metric.update(pred, target, meta_info_exp)
    
    def compute(self, prefix : Optional[str]=None):
        metrics = {}
        for task_name, task_metrics in super(Metrics, self).compute().items():
            for name, val in task_metrics.items():
                metrics[f'{prefix}/{task_name}/{name}'] = val
        return metrics

# model_wrapper
class ModelWrapper(LightningModule):

    def __init__(
        self, 
        model: torch.nn.Module, 
        task_losses_config, 
        task_metrics_config, 
        optimizer_config,
        eval_masker: Optional[torch.nn.Module]=None,
        include_meta: bool=False
    ):
        super(ModelWrapper, self).__init__()
        self.model = model
        self.loss = Losses(task_losses_config)
        self.metrics = Metrics(task_metrics_config)
        self.eval_masker = eval_masker
        self.optimizer_config = optimizer_config
        self.tracer = tracing.init()
        self.include_meta = include_meta

        self.automatic_optimization = False

    def forward(self, *X):
        return self.model(*X)

    def training_step(self, batch, batch_idx):
        optimizers = self.optimizers()
        if not isinstance(optimizers, list):
            optimizers = [optimizers]
        schedulers_config = [config for config in self.trainer.lr_scheduler_configs]

        ind_dic = self.data_split_indexes(len(batch))
        y_pred = self.forward(*batch[:ind_dic['input']])
        y = batch[ind_dic['gt']].squeeze(dim=0)
        mask = self.eval_masker(y) if self.eval_masker else None
        step = self.global_step if self.global_rank == 0 else None

        loss, task_loss_info = self.loss(y_pred, y, mask, prefix='train', step=step, tracer=self.tracer)
        self.log_dict(task_loss_info, prog_bar=True, on_epoch=False, on_step=True, rank_zero_only=True, sync_dist=True)
        

        for optimizer in optimizers:
            optimizer.zero_grad()
        self.manual_backward(loss)
        for optimizer in optimizers:
            optimizer.step()
        for scheduler_cfg in schedulers_config:
            if scheduler_cfg is None:
                continue
            scheduler = scheduler_cfg.scheduler
            interval = scheduler_cfg.interval
            freq = scheduler_cfg.frequency
            if interval == "step":
                if (self.global_step + 1) % freq == 0:
                    scheduler.step()
        return loss
    def on_train_epoch_end(self):
        schedulers_config = [config for config in self.trainer.lr_scheduler_configs]
        for scheduler_cfg in schedulers_config:
            if scheduler_cfg is None:
                continue
            # TODO: frequence is not used for epoch scheduler
            if scheduler_cfg.interval == "epoch":
                scheduler_cfg.scheduler.step()

    def validation_step(self, batch, batch_idx):
        ind_dic = self.data_split_indexes(len(batch))
        y_pred = self.forward(*batch[:ind_dic['input']])
        y = batch[ind_dic['gt']].squeeze(dim=0)
        if 'meta_info' in ind_dic:
            meta_info = batch[ind_dic['meta_info']].squeeze(dim=0)
        else:
            meta_info = None

        mask = self.eval_masker(y) if self.eval_masker else None
        step = self.global_step if self.global_rank == 0 else None
        loss, task_loss_info = self.loss(y_pred, y, mask, prefix='val',step=step,tracer=self.tracer)
        self.log_dict(task_loss_info, prog_bar=True, on_epoch=True, on_step=False, rank_zero_only=True, sync_dist=True)
        self.metrics.update(y_pred, y, mask, meta_info)

    def on_validation_epoch_end(self):
        self.log_dict(self.metrics.compute(prefix='val'), prog_bar=True, on_epoch=True, on_step=False, rank_zero_only=True, sync_dist=True)
        self.metrics.reset()

    def test_step(self, batch, batch_idx):
        ind_dic = self.data_split_indexes(len(batch))
        y_pred = self.forward(*batch[:ind_dic['input']])
        y = batch[ind_dic['gt']].squeeze(dim=0)
        mask = self.eval_masker(y) if self.eval_masker else None        
        self.metrics.update(y_pred, y, mask)

    def on_test_epoch_end(self):
        self.log_dict(self.metrics.compute(prefix='test'), prog_bar=True, on_epoch=True, on_step=False, rank_zero_only=True, sync_dist=True)
        self.metrics.reset()

    def configure_optimizers(self):
        optimizers = []
        schedulers = []
        used_params = set()  # 记录已经分配给优化器的参数ID

        post_opt_cfgs = []
        for opt_cfg in self.optimizer_config:
            opt_cfg = opt_cfg.copy()

            params_cfg = opt_cfg.pop("params", None)
            if params_cfg is None:
                # 先占位，后续自动补充未分配的参数
                params = []
                fill_remaining_params = True
            else:
                fill_remaining_params = False
                params = []

                if isinstance(params_cfg, str):
                    params_cfg = [params_cfg]
                if isinstance(params_cfg, (list, tuple)):
                    for module_name in params_cfg:
                        module = getattr(self.model, module_name, None)
                        if module is None:
                            raise ValueError(f"Model has no module named '{module_name}'")
                        for p in module.parameters():
                            if id(p) not in used_params:
                                params.append(p)
                                used_params.add(id(p))
                else:
                    raise TypeError(f"params must be None, str, or list[str], but got {params_cfg}")

            opt_cfg["params"] = params  # 不为空的部分先设上
            opt_cfg["fill_remaining_params"] = fill_remaining_params
            post_opt_cfgs.append(opt_cfg)

        remaining_params = [
            p for p in self.model.parameters() if id(p) not in used_params
        ]
        if remaining_params:
            for opt_cfg in post_opt_cfgs:
                if opt_cfg.pop("fill_remaining_params", False):
                    opt_cfg["params"].extend(remaining_params)
                    for p in remaining_params:
                        used_params.add(id(p))
                    break
        for opt_cfg in post_opt_cfgs:
            opt_cfg.pop("fill_remaining_params", False)
            sched_cfg = opt_cfg.pop("scheduler", None)            

            optimizer = OPTIMIZERS.build(opt_cfg)
            optimizers.append(optimizer)

            if sched_cfg is not None:
                interval = sched_cfg.pop("interval", "epoch")
                frequency = sched_cfg.pop("frequency", 1)
                scheduler = SCHEDULERS.build({"optimizer": optimizer, **sched_cfg})
                schedulers.append({
                    "scheduler": scheduler,
                    "interval": interval,
                    "frequency": frequency,
                })

        if len(schedulers) > 0:
            return optimizers, schedulers
        return optimizers

    def teardown(self, stage: str):
        super(ModelWrapper, self).teardown(stage)
        if stage == "fit" and self.global_rank == 0 and \
            self.trainer.checkpoint_callback and self.trainer.checkpoint_callback.best_model_path:
            ckp = torch.load(self.trainer.checkpoint_callback.best_model_path, weights_only=True)
            self.load_state_dict(ckp['state_dict'])

    def on_after_backward(self):
        # print('on_after_backward')
        for name, param in self.named_parameters():
            if param.grad is None:
                print(name)
    def data_split_indexes(self, batch_length):
        if self.include_meta:
            return {
                "input": batch_length-2,
                "gt": batch_length-2,
                "meta_info": batch_length-1
            }
        else:
            return {
                "input": batch_length-1,
                "gt": batch_length-1,
            }


class Data(LightningDataModule):
    
    from .configs import DatasetConfig
    def __init__(
        self, 
        dataset_config: DatasetConfig, 
        dataloader_config: Dict[str, Any], 
        train_table_input: Optional[str]=None, 
        val_table_input: Optional[str]=None, 
        test_table_input: Optional[str]=None, 
        predict_table_input: Optional[str]=None
    ):
        super().__init__()
        self.dataset_config = dataset_config
        self.dataloader_config = dataloader_config
        self.save_hyperparameters(ignore=['dataset_config', 'dataloader_config'])
        self.include_meta = False
        if self.dataset_config.meta:
            self.include_meta = True
    
    def prepare_data(self):
        self.ds_train = self.dataset_config.build_dataset(table_input=self.hparams.train_table_input) \
            if self.hparams.train_table_input else None
        self.ds_val = self.dataset_config.build_dataset(table_input=self.hparams.val_table_input) \
            if self.hparams.val_table_input else None
        self.ds_test = self.dataset_config.build_dataset(table_input=self.hparams.test_table_input) \
            if self.hparams.test_table_input else None
        self.ds_predict = self.dataset_config.build_dataset(table_input=self.hparams.predict_table_input) \
            if self.hparams.predict_table_input else None

    def train_dataloader(self): 
        return IterableTabularDataLoader(dataset=self.ds_train, **self.dataloader_config.get('train', {})) if self.ds_train else None

    def val_dataloader(self):
        return IterableTabularDataLoader(dataset=self.ds_val, **self.dataloader_config.get('val', {})) if self.ds_val else None

    def test_dataloader(self):
        return IterableTabularDataLoader(dataset=self.ds_test, **self.dataloader_config.get('test', {})) if self.ds_test else None
    
    def predict_dataloader(self):
        return IterableTabularDataLoader(dataset=self.ds_predict, **self.dataloader_config.get('predict', {})) if self.ds_predict else None

class Trainer(plTrainer):

    def __init__(self, **kwargs):
        self.losses_config = kwargs.pop('losses_config', None)
        self.metrics_config = kwargs.pop('metrics_config', None)
        self.optimizer_config = kwargs.pop('optimizer_config', None)
        super(Trainer, self).__init__(**kwargs)

    def train(
        self, 
        model: torch.nn.Module, 
        data: Data,
        eval_masker: Optional[torch.nn.Module] = None,
        ckpt_path: Optional[str] = None
    ):
        super(Trainer, self).fit(
            model=ModelWrapper(
                model=model, 
                task_losses_config=self.losses_config, 
                task_metrics_config=self.metrics_config,
                optimizer_config=self.optimizer_config,
                eval_masker=eval_masker,
                include_meta=data.include_meta
            ), 
            datamodule=data,
            ckpt_path=ckpt_path
        )
    
    def load_ckpt(self, path, model=None, map_location='cuda'):
         ## treat path as local path
        if model is None:
            with open(path, 'rb') as f:
                model = torch.jit.load(f, map_location=map_location)
        elif isinstance(model, torch.nn.Module):
            checkpoint = torch.load(path, map_location=map_location)
            state_dict = checkpoint["state_dict"]
            new_state_dict = {}
            for k, v in state_dict.items():
                if k.startswith("model."):
                    new_state_dict[k[6:]] = v  # 去除 "model." 前缀
                else:
                    new_state_dict[k] = v  # 若没有前缀则直接保留
            # 加载权重到模型
            model.load_state_dict(new_state_dict, strict=False)
            
        else:
            raise ValueError(f'type(model) expect `None` or `torch.nn.Module`, but got {type(model)}"')
        return model
    
    def load_model(self, model_path, model=None, map_location='cuda'):
        if is_hdfs_path(model_path) or is_o3fs_path(model_path):
            with tempfile.TemporaryDirectory() as tmp_dir:
                os.system(f'hdfs dfs -get {osp.join(model_path, ONLINE_DIR, EXPORT_DIR)} {osp.join(tmp_dir, EXPORT_DIR)}')
                if model is None:
                    with open(osp.join(tmp_dir, EXPORT_DIR, TORCH_SCRIPT_MODEL), 'rb') as f:
                        model = torch.jit.load(f, map_location=map_location)
                elif isinstance(model, torch.nn.Module):
                    with open(osp.join(tmp_dir, EXPORT_DIR, TORCH_MODEL_STATE_DICT), 'rb') as f:
                        w_dict = torch.load(f)
                        new_w_dict = OrderedDict()
                        for k,v in w_dict.items():
                            k = k.split('model.')[1]
                            new_w_dict[k] = v
                        model.load_state_dict(new_w_dict)
                else:
                    raise ValueError(f'type(model) expect `None` or `torch.nn.Module`, but got {type(model)}"')
        return model
    
    from .configs import DatasetConfig
    def save_model(self, save_dir: str, dataset_config: DatasetConfig, model:torch.nn.Module = None):
        if self.is_global_zero:
            example_inputs = []
            for g in dataset_config.feature_group_list:
                input_shape = g.shape.copy()
                input_shape[0] = 1
                if g.name == 'f_sequence':
                    input_shape.append(51)
                if g.name == 'f_his_sequence':
                    input_shape.append(50)
                example_inputs.append(
                    torch.rand(input_shape).to(getattr(torch, g.dtype))
                )
            if model is None:
                model = self.model
            dm_save_model(
                model=model,
                output_dir=save_dir,
                example_inputs=example_inputs,
                config=dataset_config
            )

    def eval(
        self, 
        model: torch.nn.Module, 
        data: Data,
        eval_masker: Optional[torch.nn.Module] = None,
        ckpt_path: Optional[str] = None
    ):
        super(Trainer, self).validate(
            model=ModelWrapper(
                model=model, 
                task_losses_config=self.losses_config, 
                task_metrics_config=self.metrics_config,
                optimizer_config=self.optimizer_config,
                eval_masker=eval_masker
            ), 
            datamodule=data,
            ckpt_path=ckpt_path
        )
