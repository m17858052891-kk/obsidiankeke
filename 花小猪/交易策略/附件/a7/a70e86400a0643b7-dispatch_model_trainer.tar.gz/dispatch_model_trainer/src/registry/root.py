from .registry import Registry
import torch.nn as nn
import torch
import torch.optim.lr_scheduler as lrs


LOSSES = Registry("LOSSES")
LOSSES.add_module("mse_loss", nn.MSELoss)
LOSSES.add_module("bce_loss", nn.BCELoss)
LOSSES.add_module("bce_with_logits_loss", nn.BCEWithLogitsLoss)
LOSSES.add_module("ce_loss", nn.CrossEntropyLoss)


METRICS = Registry("METRICS")


OPTIMIZERS = Registry("OPTIMIZERS")
OPTIMIZERS.add_module("adam", torch.optim.Adam)


# 向外输出的模型类
EXPORTS = Registry("EXPORTS")


SCHEDULERS = Registry("SCHEDULERS")
SCHEDULERS.add_module("StepLR", lrs.StepLR) # Step 学习率衰减
SCHEDULERS.add_module("MultiStepLR", lrs.MultiStepLR) # Multi Step 衰减
SCHEDULERS.add_module("ExponentialLR", lrs.ExponentialLR) # 指数衰减
SCHEDULERS.add_module("CosineAnnealingLR", lrs.CosineAnnealingLR) # Cosine 衰减
SCHEDULERS.add_module("CosineAnnealingWarmRestarts", lrs.CosineAnnealingWarmRestarts) # Cosine + 重启
SCHEDULERS.add_module("OneCycleLR", lrs.OneCycleLR) # One Cycle 动态大起大落策略
SCHEDULERS.add_module("ReduceLROnPlateau", lrs.ReduceLROnPlateau) # Plateau 调度器（依赖监控指标，如 val_loss）
SCHEDULERS.add_module("PolynomialLR", lrs.PolynomialLR)
SCHEDULERS.add_module("ChainedScheduler", lrs.ChainedScheduler)