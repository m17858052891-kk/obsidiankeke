class Registry:
    def __init__(self,name):
        self.registry = {}
        self._name=name

    def register_module(self, name=None):
        def decorator(cls):
            nonlocal name
            name = name or cls.__name__
            if name in self.registry:
                raise KeyError('{} is already registered in {}'.format(name,self.__class__.__name__))
            self.registry[name] = cls
            return cls
        return decorator
    def add_module(self, name, module):
        if name in self.registry:
            raise KeyError(f'{name} is already registered in {self._name}')
        self.registry[name] = module

    def build(self,cfg):
        if not isinstance(cfg, dict):
            raise TypeError('cfg must be a dict, but got {}'.format(type(cfg)))

        if 'cls' not in cfg:
            raise KeyError('The cfg dictionary must contain the key "cls" to specify the object type.')

        obj_type = cfg.pop('cls')
        if obj_type not in self.registry:
            raise KeyError('Unknown type {}. Please register it first.'.format(obj_type))

        obj_cls = self.registry[obj_type]
        return obj_cls(**cfg)


# 示例使用注册表的类装饰器
# COMPONENT_REGISTRY = Registry('projector')


# @COMPONENT_REGISTRY.register_module()
# class ExampleClass:
#     def __init__(self, a,b,c):
#         self.a=a
#         self.b=b
#         self.c=c

#     def print_parameter(self):
#         print('a: {}'.format(self.a))
#         print('b: {}'.format(self.b))
#         for key,value in self.c.items():
#             print('{}:{}'.format(key,value))


# # 示例使用注册表的配置文件
# config_dict = {'cls': 'ExampleClass', 'a': 4,'b':9,'c':{'m':0,'n':7}}

# # 实例化对象
# example_instance = COMPONENT_REGISTRY.build(config_dict)

# # 调用实例方法
# example_instance.print_parameter()