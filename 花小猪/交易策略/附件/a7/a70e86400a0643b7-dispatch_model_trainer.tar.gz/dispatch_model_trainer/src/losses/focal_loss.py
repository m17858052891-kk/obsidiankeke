import torch
import torch.nn as nn
import torch.nn.functional as F
from registry import LOSSES

@LOSSES.register_module("focal_loss")
class FocalLoss(nn.Module):
    """
    Focal Loss
    支持二分类 (binary) 和多分类 (multi-class)
    Args:
        alpha: 类别平衡因子 (scalar 或 tensor)
        gamma: 难例调节参数
        reduction: 'mean' | 'sum' | 'none'
        task: 'binary' 或 'multi'
    """
    def __init__(self, alpha=1.0, gamma=2.0, reduction="mean", task="multi"):
        super().__init__()
        self.alpha = torch.tensor(alpha, dtype=torch.float32)
        self.gamma = gamma
        self.reduction = reduction
        assert task in ["binary", "multi"], "task must be binary or multi"
        self.task = task

    def forward(self, input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        if self.task == "binary":
            # Binary classification (BCEWithLogitsLoss + focal)
            target = target.float()
            if self.alpha.device != target.device:
                self.alpha = self.alpha.to(target.device)
            bce_loss = F.binary_cross_entropy_with_logits(input, target, reduction="none")
            prob = torch.sigmoid(input)
            p_t = prob * target + (1 - prob) * (1 - target)  # p_t
            focal_weight = (1 - p_t) ** self.gamma
            alpha_t = self.alpha * target + (1 - self.alpha) * (1 - target)
            loss = focal_weight * alpha_t * bce_loss
        else:
            # Multi-class classification
            target = target.long()
            if self.alpha.device != target.device:
                self.alpha = self.alpha.to(target.device)
            ce_loss = F.cross_entropy(input, target, reduction="none")
            logpt = -ce_loss
            pt = torch.exp(logpt)
            focal_weight = (1 - pt) ** self.gamma
            if len(self.alpha.shape) == 1:
                alpha_t = self.alpha
            else:
                alpha_t = self.alpha[target.squeeze()]
            loss = focal_weight * alpha_t * ce_loss

        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        else:
            return loss
