import torch
import torch.nn as nn
from registry import LOSSES

@LOSSES.register_module("robust_ce_loss")
class RobustCrossEntropyLoss(nn.CrossEntropyLoss):
    """
    CrossEntropyLoss的子类，在forward时自动将target转换为long类型
    解决因target为float类型导致的类型不匹配问题
    """
    def forward(self, input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # 将target转换为long类型，确保与CrossEntropyLoss要求一致
        target = target.long()
        # 调用父类的forward方法
        return super().forward(input, target)