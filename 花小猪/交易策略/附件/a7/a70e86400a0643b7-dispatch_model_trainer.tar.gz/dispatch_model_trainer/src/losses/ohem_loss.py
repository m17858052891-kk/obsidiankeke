import torch
import torch.nn as nn
import torch.nn.functional as F
from registry import LOSSES


@LOSSES.register_module("ohem_loss")
class OHEMLoss(nn.Module):
    """
    Online Hard Example Mining (OHEM) Loss
    支持二分类和多分类任务:
        - 二分类: input=[B,1] 或 [B,n_class<=2], 使用 BCEWithLogitsLoss
        - 多分类: input=[B,n_class], 使用 CrossEntropyLoss

    Args:
        ratio: 选取困难样本比例 (0,1]
        min_kept: 最少保留样本数
        ignore_index: 忽略标签
        criterion: "bce" 或 "ce"
        pos_weight: 二分类中正样本权重
        weight: 多分类中各类别权重
    """
    def __init__(self, ratio=0.7, min_kept=100, ignore_index=-100,
                 topk_index=0, criterion="auto", pos_weight=None, weight=None):
        super().__init__()
        self.ratio = ratio
        self.min_kept = min_kept
        self.ignore_index = ignore_index
        self.topk_index = topk_index
        self.criterion_type = criterion
        self.pos_weight = pos_weight
        self.weight = weight

    def forward(self, input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        input: [B, 1] 或 [B, n_class]
        target: [B, 1] 或 [B]
        """
        if target.ndim == 1:
            target = target.unsqueeze(1)  # 统一成 [B,1]
        B = target.size(0)
        if input.ndim == 1:
            input = input.unsqueeze(1)  # [B] -> [B,1]
        # 自动判断模式
        if self.criterion_type == "auto":
            if input.size(1) == 1 or input.size(1) == 2:
                mode = "bce"
            else:
                mode = "ce"
        else:
            mode = self.criterion_type

        # ========== 二分类 ==========
        if mode == "bce":
            criterion = nn.BCEWithLogitsLoss(reduction='none', pos_weight=self.pos_weight)
            if input.size(1) == 1:
                loss = criterion(input, target.float())
            elif input.size(1) == 2:
                # 将 logits 的正类部分用于 BCE
                pos_logit = input[:, 1].unsqueeze(1)
                loss = criterion(pos_logit, target.float())
            else:
                raise ValueError(f"Invalid input shape {input.shape} for BCE mode")

            loss = loss.view(-1)
            valid_mask = (target != self.ignore_index).view(-1)
            valid_losses = loss[valid_mask]

            if valid_losses.numel() == 0:
                return loss.mean()

            # 正负样本区分：只对负样本排序
            t = target.view(-1)[valid_mask]
            neg_mask = (t == 0)
            pos_mask = (t == 1)

            pos_losses = valid_losses[pos_mask]
            neg_losses = valid_losses[neg_mask]

            # 对负样本排序取 top-k
            num_neg = neg_losses.numel()
            kept_neg = max(int(num_neg * self.ratio), self.min_kept)
            kept_neg = min(kept_neg, num_neg)

            if num_neg > 0:
                topk_neg, _ = torch.topk(neg_losses, kept_neg)
                combined_losses = torch.cat([pos_losses, topk_neg])
            else:
                combined_losses = valid_losses

            return combined_losses.mean()

        # ========== 多分类 ==========
        elif mode == "ce":
            if self.topk_index >= input.shape[1]:
                self.topk_index = 0
            criterion = nn.CrossEntropyLoss(reduction='none', weight=self.weight,
                                            ignore_index=self.ignore_index)
            target_ce = target.view(-1).long()
            input_ce = input  # [B, C]

            losses = criterion(input_ce, target_ce).view(-1)
            valid_mask = target_ce != self.ignore_index
            valid_losses = losses[valid_mask]
            if valid_losses.numel() == 0:
                return losses.mean()

            t = target_ce[valid_mask]
            neg_mask = (t == self.topk_index)
            pos_mask = (t != self.topk_index)

            pos_losses = valid_losses[pos_mask]
            neg_losses = valid_losses[neg_mask]

            # 对负样本排序取 top-k
            num_neg = neg_losses.numel()
            kept_neg = max(int(num_neg * self.ratio), self.min_kept)
            kept_neg = min(kept_neg, num_neg)

            if num_neg > 0:
                topk_neg, _ = torch.topk(neg_losses, kept_neg)
                combined_losses = torch.cat([pos_losses, topk_neg])
            else:
                combined_losses = valid_losses
            return combined_losses.mean()

        else:
            raise ValueError(f"Unsupported criterion: {mode}")
