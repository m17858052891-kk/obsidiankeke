# dispatch_model_trainer

# 0820 更新：

模型训练框架大更新❗️❗️

训练镜像：matching_strategy_deep_model_env_v11，

训练脚本：sudo mkdir -p /tmp/sparktmp/ && sudo chmod -R 777 /tmp/sparktmp/ && sudo chmod -R 777 ./ && HYDRA_FULL_ERROR=1 python dispatch_model_trainer/src/train.py

预测镜像：dmlite:1.0.6-tensorflow2.10-pytorch2.4-python3.8-ubuntu20.04

训练代码更新：http://git.xiaojukeji.com/mpt_dispatch_matching/scene_dispatch_algorithms/dispatch_model_trainer/tree/seq-model-paradigm

更新：

1.适配dmilte 1.x，支持tensorboard

2.序列特征模块重构，之后添加序列特征只需要改特征配置文件的group_feature_list

3.预测部分的代码用predict.py，用的时候直接复制到组件内，调整特征就好



# 前言

- 分单基础模型优化、前沿技术探索，都需要一套轻代码、高性能的基建，使用户专注于业务和算法本身。
- 在大模型快速发展的背景下，深度学习相关基建得到快速的发展，为我们pipeline的设计提供了思路。

# 1. 设计思路

模型训练四要素: 配置化(Cfg)、数据集(Data)、模型(Model)、训练器(Trainer)。其中，模型为User-defined, 其余为pipeline提供。
- 配置化: 基于Hydra实现。
- 数据集、训练器由pipeline提供。
    - 训练器: 基于Lightning.Trainer扩展
    - 数据集:

| Type | Task           | Data                       |
| ---- | -------------- | -------------------------- | 
| 在线  | 分单基础深度模型 | Kafka+Flink+PyArrow+LitData | 
| 离线  | 分单基础深度模型 | Hive+PyArrow+LitData        | 
| 在线  | RL分单(仿真)    | torchRL+短时分单仿真器        | 
| 在线/离线 | RL分单      | Kafka+Flink+PyArrow+LitData |
| 离线  | 预训练          | Hive+PyArrow+LitData       |

- 模型: torch.nn.Module，用户自定义

当前进展:

| Type | Task           | Data     | Trainer | 
| ---- | -------------- | -------- | ------- | 
| 在线  | 分单基础深度模型 | todo     | **done** |
| 离线  | 分单基础深度模型 | **done** | **done** |
| 在线  | RL分单(仿真)    | todo     | todo    |
| 在线/离线 | RL分单      | todo     | todo    |
| 离线  | 预训练          | todo    | todo     |

# 2. 项目结构

```
├── cfg                   <- Hierarchical配置
│   ├── dataset_config                <- 回调函数
│   ├── model_config                     <- 数据集
│   └── train.yaml                   <- 额外配置
│
├── src                 <- Source code
│   ├── dataset             <- 重定义数据读取类
│   ├── export_models       <- 模型导出类
│   ├── layers              <- 常用layers
│   ├── losses              <- 常用losses
│   ├── metrics             <- 常用metrics
│   ├── models              <- 常用models
│   ├── registry            <- 注册器组件
│   ├── utils               <- Utilities
│   │   ├── base.py             <- 基础类、函数
│   │   │   ├── RankedLogger        <- 主进程主线程日志
│   │   │   ├── eve_decorator       <- 主函数装饰器，eve输入转换为hydra格式
│   │   │   └── extras_decorator    <- 主函数装饰器，训练前处理
│   │   │
│   │   ├── core.py             <- 核心类、函数
│   │   │   ├── Losses              <- 多任务Loss
│   │   │   ├── Metrics             <- 多任务Metric
│   │   │   ├── ModelWrapper        <- 模型wrapper，在model基础上添加train/val/test的具体逻辑
│   │   │   └── Trainer             <- 训练器
│   │   │   
│   │   └── configs.py          <- 配置相关
│   │       ├── DatasetConfig       <- 数据集配置
│   │       └── TrainerConfig       <- 训练器配置
│   │
│   └── train.py                 <- 训练脚本
│
├── .gitignore                <- git忽略的文件列表
├── .project-root             <- 用来推断项目根目录的文件
└── README.md
```
<br>

# 3. 如何使用

- 训练脚本

![train_script](./docs/pipeline_main_script.png)

- 训练配置

```
cfg
├── dataset_config                <- 数据集
├── model_config                  <- 模型配置
├── train_input                   <- 训练集hive表名
├── val_input                     <- 验证集hive表名
├── model_input                   <- 模型文件(hdfs路径)
├── experiment_name               <- 实验名
├── paths                         <- 路径
├── hydra                         <- Hydra配置
├── dataloader_config             <- 数据加载器配置
└── trainer_config                <- 训练器配置
```
<br>

- 损失函数配置
```yaml
losses_config: 
  sr: # 损失函数1
    cls: bce_loss # 损失函数1的类名
    idx: 0 # 损失函数1在输出中的索引
    dim: 1 # 损失函数1在输出中的长度
    weight: 1.0 # 损失函数1的权重
  caa: # 损失函数2
    cls: bce_loss # 损失函数2的类名
    idx: 1 # 损失函数2在输出中的索引
    dim: 1 # 损失函数2在输出中的长度
    weight: 1.0 # 损失函数2的权重
```

- 指标函数配置
```yaml
metrics_config:
  sr: # 任务1
    - idx: 0 # 任务1在输出中的索引
      dim: 1 # 任务1在输出中的长度
    - cls: auc # 任务1的auc指标
    - cls: acc # 任务1的acc指标
    - cls: pcoc # 任务1的pcoc指标
    - cls: cal-n # 任务1的cal-n指标
      n_bins: 10 # cal-n的参数
  caa_sr: # 任务2
    - idx: 0 # 任务2在输出中的索引
      dim: 2 # 任务2在输出中的长度
    - cls: multi_task_auc # 任务2的multi_task_auc指标
      num_tasks: 2
      weights: [1.0, 1.0]
```

- 优化器配置
```yaml
optimizer_config:
  - cls: adam # 优化器注册名
    lr: 0.0001 # 学习率
    scheduler: # (可选) 学习率调度器配置
      cls: CosineAnnealingLR
      T_max: 50
      eta_min: 1e-6
      interval: epoch # 学习率调度器更新间隔
      frequency: 1 # 学习率调度器更新频率
  - cls: adam
    params: general_sparse_embedding_layer # (可选) 对特定参数应用优化器
    lr: 0.001
    scheduler:
      cls: CosineAnnealingLR
      T_max: 50
      eta_min: 1e-6
      interval: step
      frequency: 1
```

## 3.1. 模型导入/导出
- 从eve导入模型: 直接把**训练完成**的模型接入模型组件
<!-- ![alt text](./docs/eve_model_input.png) -->
<img src="./docs/eve_model_input.png" alt="eve_model_input" width="40%">

- 指定 checkpoint 路径读取:

    - ckpt_path: 模型 checkpoint 路径, **'=' 前要用 '\\' 转义**

```bash
python src/train.py 'ckpt_path=outputs/2025-10-26_20-54-09_debug/epoch\=1-step\=1024.ckpt'
```

- 从checkpoint导出模型到 eve: 跳过训练过程, 直接从导出中间结果

    - ckpt_path: 模型 checkpoint 路径
    - direct_output: 是否直接导出模型到 eve
    - export_model_config.cls: 模型导出类

```bash
python src/train.py 'ckpt_path=outputs/2025-10-26_20-54-09_debug/epoch\=1-step\=1024.ckpt' direct_output=True export_model_config.cls=ExportPEPNetStrive
```

- 自动导入最新checkpoint
    - 在`train.yaml`中设置`resume: null # best or latest`
    - 训练时会自动导入最新的checkpoint


## 3.2. 模块介绍

### 注册器使用

如下图, 在 `registry/root.py` 路径下注册一个新的注册器。可以选择使用 `.add_module("name", module)` 直接把现有的模块加入到注册器中。

<img src="./docs/add_new_registry.png" alt="add_new_registry" width="80%">

对于已经注册的模块，使用 `build(cfg)` 来生成对应的实例:

```python
from registry import LOSSES
cfg = {
    "cls": "focal_loss", # 注册时的名称
    # 其他参数
    "alpha"=1.0,
    "gamma"=2.0,
    "reduction"="mean",
    "task"="binary"
}
loss_fn = LOSSES.build(cfg)
```

### 损失函数注册器

如下图，在 `losses` 目录下注册新的自定义损失函数, 并在同目录下的 `__init__.py` 中导入。
<img src="./docs/loss_registry.png" alt="loss_registry" width="80%">

### 指标函数注册器

如下图，在 `metrics` 目录下注册新的自定义指标函数, 并在同目录下的 `__init__.py` 中导入。
<img src="./docs/metric_registry.png" alt="metric_registry" width="80%">