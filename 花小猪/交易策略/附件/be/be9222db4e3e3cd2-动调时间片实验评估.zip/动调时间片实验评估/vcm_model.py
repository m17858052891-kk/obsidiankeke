import os
import numpy as np
import matplotlib . pyplot as plt
from scipy import stats
from scipy . stats import norm
import pandas as pd
from copy import deepcopy
import scipy
import matplotlib . pyplot as plt
import statsmodels . api as sm
import sys
import io
import seaborn as sns
import pandas as pd
from tqdm import tqdm
if 82 - 82: Iii1i
if 87 - 87: Ii % i1i1i1111I . Oo / OooOoo * I1Ii1I1 - I1I
pd . set_option ( 'display.max_columns' , None )
if 81 - 81: i1 + ooOOO / oOo0O00 * i1iiIII111 * IiIIii11Ii
# D  nsamples_per_day x nfeatures, multiindex - one day
# Vi pandas Series
# W  pandas DataFrame    
def OOoOoo000O00 ( D , Vi ) :
 Ooo0Ooo = D . index . get_level_values ( 1 )
 return np . dot ( D . T . values * Vi [ Ooo0Ooo ] . values , D . values )
 if 15 - 15: IiII1I1I1i1 * IIiIIiIi11I1
def iI111iiIi11i ( D , Vi , y ) :
 Ooo0Ooo = D . index . get_level_values ( 1 )
 return np . dot ( D . T . values * Vi [ Ooo0Ooo ] . values , y . values )
 if 77 - 77: iIiii1i - ooo0O0oO00 . o00o0OO00O
def Ooo ( D , Vi , W ) :
 Ooo0Ooo = D . index . get_level_values ( 1 )
 I1 , ii = Vi . loc [ Ooo0Ooo ] , W . loc [ Ooo0Ooo , Ooo0Ooo ]
 iiI = ( D . T . values * I1 . values )
 return np . dot ( np . dot ( iiI , ii . values ) , iiI . T )
 if 10 - 10: O0o00 / oOooo0OOO % o00ooO0Ooooo - iIiii1i % OooOoo
def oOooO0 ( df ) :
 if 13 - 13: O0o00
 oOooO0 = df . reset_index ( drop = True )
 oOooO0 [ 'exp_group' ] = oOooO0 [ 'exp_group' ] . map ( { 'treatment_group' : + 1 , 'control_group' : - 1 } )
 oOooO0 = oOooO0 . rename ( columns = { 'tdate' : 'date' , 'exp_group' : 'A' } )
 oOooO0 [ 'time' ] = oOooO0 . minf - oOooO0 . minf . min ( )
 oOooO0 = oOooO0 . groupby ( [ 'date' , 'time' , 'A' ] ) . sum ( ) . reset_index ( )
 oOooO0 = oOooO0 . set_index ( [ "date" , "time" ] )
 return oOooO0
 if 2 - 2: i1
def IIiIiiIiI ( df , df_all , evaluate_dict , city_results ) :
 if 34 - 34: IIiIIiIi11I1 + O0o00 * ooo0O0oO00 * OooOoo
 Ii111 = len ( df . tdate . unique ( ) ) / 2
 for Iio0 in evaluate_dict :
  if evaluate_dict [ Iio0 ] [ 0 ] == 'type1' :
   if 11 - 11: o00ooO0Ooooo . i1i1i1111I
   I1i = oOooO0 ( df )
   i1111IIi = oOo00O ( I1i , ycol = evaluate_dict [ Iio0 ] [ 1 ] ,
 xcols = evaluate_dict [ Iio0 ] [ 2 ] , acol = 'A' , interaction = False )
   i1111IIi . estimate ( )
   i1111IIi . inference ( )
   if 59 - 59: Iii1i . o00ooO0Ooooo - oOooo0OOO
   ii1IiIiiII = i1111IIi . holder
   I1I111i11I = ii1IiIiiII [ 'gamma' ]
   iii11i = ii1IiIiiII [ 'gamma_se' ]
   Oo0Oo00O0OO = ii1IiIiiII [ 'pvalue' ]
   if 7 - 7: IIiIIiIi11I1
   oO = len ( df . tdate . unique ( ) )
   I1I1 = df . city_id . unique ( ) [ 0 ]
   oo0 = I1i [ I1i [ 'A' ] == - 1 ]
   i11iIii = I1i [ I1i [ 'A' ] == 1 ]
   OO = Ii111 * ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) ) / ( oO / 2 )
   iiI1I11iiiiI = Ii111 * ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) / ( oO / 2 ) + 2 * I1I111i11I ) )
   if 4 - 4: i1iiIII111 * IIiIIiIi11I1
   I1iI = 2 * I1I111i11I * Ii111
   IiIII = ( I1I111i11I + 1.96 * iii11i ) * 2
   i1IIiII11 = ( I1I111i11I - 1.96 * iii11i ) * 2
   if 52 - 52: i1iiIII111 % Oo . I1Ii1I1 + ooOOO % Oo . o00ooO0Ooooo
   OOO00oO0oOo0O = ( I1iI / OO )
   iIi1I1I = IiIII / OO
   II1III1I1i = i1IIiII11 / OO
   if 25 - 25: IiII1I1I1i1 * I1Ii1I1 * oOooo0OOO % oOo0O00
   oOoO00 = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) ) / ( oO / 2 ) )
   OO0o0O0o0 = np . nan
   if 11 - 11: o00ooO0Ooooo % i1i1i1111I + i1
   city_results . append ( [ I1I1 , Iio0 , OO , iiI1I11iiiiI , I1iI , i1IIiII11 , IiIII , OOO00oO0oOo0O , II1III1I1i , iIi1I1I , Oo0Oo00O0OO , I1I111i11I , iii11i , oOoO00 , OO0o0O0o0 , np . nan , np . nan ] )
  elif evaluate_dict [ Iio0 ] [ 0 ] == 'type2' :
   if 87 - 87: I1I / Iii1i / Ii
   I1i = oOooO0 ( df )
   i1111IIi = oOo00O ( I1i , ycol = evaluate_dict [ Iio0 ] [ 1 ] ,
 xcols = evaluate_dict [ Iio0 ] [ 2 ] , acol = 'A' , interaction = False )
   i1111IIi . estimate ( )
   i1111IIi . inference ( )
   if 32 - 32: i1i1i1111I % IIiIIiIi11I1 - oOooo0OOO * I1I
   ii1IiIiiII = i1111IIi . holder
   I1I111i11I = ii1IiIiiII [ 'gamma' ]
   iii11i = ii1IiIiiII [ 'gamma_se' ]
   Oo0Oo00O0OO = ii1IiIiiII [ 'pvalue' ]
   if 92 - 92: ooo0O0oO00 - i1 - Iii1i / IIiIIiIi11I1 . I1Ii1I1 / o00o0OO00O
   oO = len ( df . tdate . unique ( ) )
   I1I1 = df . city_id . unique ( ) [ 0 ]
   oo0 = I1i [ I1i [ 'A' ] == - 1 ]
   i11iIii = I1i [ I1i [ 'A' ] == 1 ]
   if 60 - 60: O0o00
   OO = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) ) / ( oO / 2 ) ) / ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   iiI1I11iiiiI = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) / ( oO / 2 ) + 2 * I1I111i11I ) ) / ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   if 32 - 32: iIiii1i
   oOoO00 = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) ) / ( oO / 2 ) )
   OO0o0O0o0 = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   if 18 - 18: o00o0OO00O * o00ooO0Ooooo % iIiii1i + o00ooO0Ooooo
   I1iI = 2 * I1I111i11I / ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   IiIII = ( I1I111i11I + 1.96 * iii11i ) * 2 / ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   i1IIiII11 = ( I1I111i11I - 1.96 * iii11i ) * 2 / ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   if 93 - 93: O0o00 - I1Ii1I1 - ooo0O0oO00 * ooOOO - i1
   OOO00oO0oOo0O = ( I1iI / OO )
   iIi1I1I = IiIII / OO
   II1III1I1i = i1IIiII11 / OO
   if 82 - 82: ooo0O0oO00 % i1 * ooOOO
   city_results . append ( [ I1I1 , Iio0 , OO , iiI1I11iiiiI , I1iI , i1IIiII11 , IiIII , OOO00oO0oOo0O , II1III1I1i , iIi1I1I , Oo0Oo00O0OO , I1I111i11I , iii11i , oOoO00 , OO0o0O0o0 , np . nan , np . nan ] )
  elif evaluate_dict [ Iio0 ] [ 0 ] == 'type3' :
   if 57 - 57: oOo0O00
   I1i = oOooO0 ( df )
   i1111IIi = oOo00O ( I1i , ycol = evaluate_dict [ Iio0 ] [ 1 ] ,
 xcols = evaluate_dict [ Iio0 ] [ 2 ] , acol = 'A' , interaction = False )
   i1111IIi . estimate ( )
   i1111IIi . inference ( )
   ii1IiIiiII = i1111IIi . holder
   I1I111i11I = ii1IiIiiII [ 'gamma' ]
   if 31 - 31: i1iiIII111 + i1i1i1111I % OooOoo
   i1i1iiII = oOo00O ( I1i , ycol = evaluate_dict [ Iio0 ] [ 3 ] ,
 xcols = evaluate_dict [ Iio0 ] [ 4 ] , acol = 'A' , interaction = False )
   i1i1iiII . estimate ( )
   i1i1iiII . inference ( )
   OooOO00o = i1i1iiII . holder
   OOO00000oO = OooOO00o [ 'gamma' ]
   if 29 - 29: ooo0O0oO00 - IiII1I1I1i1 . i1iiIII111
   oo00oO000 = I1i [ I1i [ 'A' ] == - 1 ]
   iIiIiiIIIiII = oo00oO000 [ evaluate_dict [ Iio0 ] [ 1 ] ] . mean ( ) / oo00oO000 [ evaluate_dict [ Iio0 ] [ 3 ] ] . mean ( )
   I1i [ 'newy' ] = 2 * I1i [ evaluate_dict [ Iio0 ] [ 1 ] ] - 2 * iIiIiiIIIiII * I1i [ evaluate_dict [ Iio0 ] [ 3 ] ]
   if 44 - 44: IIiIIiIi11I1 + i1i1i1111I + Iii1i - O0o00
   if 7 - 7: i1i1i1111I / Ii * Iii1i
   i1iI1i = oOo00O ( I1i , ycol = 'newy' ,
 xcols = evaluate_dict [ Iio0 ] [ 2 ] , acol = 'A' , interaction = False )
   i1iI1i . estimate ( )
   i1iI1i . inference ( )
   IIIi1111iiIi1 = i1iI1i . holder
   I1II1ii111i = IIIi1111iiIi1 [ 'pvalue' ]
   if 14 - 14: o00ooO0Ooooo + oOooo0OOO . IiIIii11Ii . IIiIIiIi11I1 % IiIIii11Ii * i1i1i1111I
   oOoOO0O0 = [ ]
   I111 = df_all [ df_all [ 'exp_group' ] == 'control_group' ]
   OO00OOooO = I111 [ evaluate_dict [ Iio0 ] [ 1 ] ] . mean ( ) / I111 [ evaluate_dict [ Iio0 ] [ 3 ] ] . mean ( )
   oOoOO0O0 . append ( [ Iio0 , OO00OOooO ] )
   oOoOO0O0 = pd . DataFrame ( oOoOO0O0 , columns = [ 'zb' , 'delta0' ] )
   if 58 - 58: oOooo0OOO - o00ooO0Ooooo
   OOooOOOO00O = oOoOO0O0 [ oOoOO0O0 . zb == Iio0 ] [ 'delta0' ] . values [ 0 ]
   I1i [ 'newy_combine' ] = 2 * I1i [ evaluate_dict [ Iio0 ] [ 1 ] ] - 2 * OOooOOOO00O * I1i [ evaluate_dict [ Iio0 ] [ 3 ] ]
   ii1 = oOo00O ( I1i , ycol = 'newy_combine' ,
 xcols = evaluate_dict [ Iio0 ] [ 2 ] , acol = 'A' , interaction = False )
   ii1 . estimate ( )
   ii1 . inference ( )
   Oo0O00OOoo = ii1 . holder
   o0oO00OO = Oo0O00OOoo [ 'gamma' ]
   O0OO0OOOOoo0o = Oo0O00OOoo [ 'gamma_se' ]
   if 41 - 41: O0o00
   oO = len ( df . tdate . unique ( ) )
   I1I1 = df . city_id . unique ( ) [ 0 ]
   oo0 = I1i [ I1i [ 'A' ] == - 1 ]
   i11iIii = I1i [ I1i [ 'A' ] == 1 ]
   if 98 - 98: I1I / ooo0O0oO00 / oOooo0OOO + o00ooO0Ooooo % Oo + I1I
   OO = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) ) / ( oO / 2 ) ) / ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   iiI1I11iiiiI = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) / ( oO / 2 ) + 2 * I1I111i11I ) ) / ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) + 2 * OOO00000oO )
   I1iI = ( iiI1I11iiiiI - OO )
   OOO00oO0oOo0O = ( I1iI / OO )
   if 38 - 38: I1Ii1I1 + oOo0O00
   iIi1I1I = np . nan
   II1III1I1i = np . nan
   IiIII = np . nan
   i1IIiII11 = np . nan
   if 2 - 2: OooOoo % Ii + O0o00 . OooOoo + ooo0O0oO00 * Oo
   oOoO00 = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 1 ] ] . sum ( ) ) / ( oO / 2 ) )
   OO0o0O0o0 = ( ( oo0 [ evaluate_dict [ Iio0 ] [ 3 ] ] . sum ( ) ) / ( oO / 2 ) )
   if 2 - 2: ooo0O0oO00 + iIiii1i - I1Ii1I1 + ooOOO . ooo0O0oO00
   city_results . append ( [ I1I1 , Iio0 , OO , iiI1I11iiiiI , I1iI , i1IIiII11 , IiIII , OOO00oO0oOo0O , II1III1I1i , iIi1I1I , I1II1ii111i , o0oO00OO , O0OO0OOOOoo0o , oOoO00 , OO0o0O0o0 , I1I111i11I , OOO00000oO ] )
   if 15 - 15: IiII1I1I1i1
class oOo00O ( object ) :
 def __init__ ( self , df , ycol , xcols , acol ,
 interaction = False , two_sided = True , wild_bootstrap = False , copy = True ,
 center_x = True , scale_x = True , center_y = False , scale_y = False ,
 keep_ratio = 0.95 , he = 0.05 , smooth_coef = False , hc = 0.05 ) :
  self . df = df . copy ( ) if copy else df
  if 63 - 63: oOooo0OOO
  if 81 - 81: OooOoo . oOooo0OOO / i1i1i1111I + Oo / IIiIIiIi11I1 % o00ooO0Ooooo
  if 77 - 77: o00o0OO00O / iIiii1i - oOo0O00 - IIiIIiIi11I1 % oOo0O00
  if 73 - 73: o00ooO0Ooooo . Oo * I1I / i1i1i1111I + I1Ii1I1
  if 31 - 31: i1i1i1111I % I1Ii1I1
  if 1 - 1: o00ooO0Ooooo - oOo0O00 - i1 . oOo0O00
  if 91 - 91: iIiii1i * i1 . ooOOO
  if 81 - 81: I1I * Oo - i1 % OooOoo * ooOOO
  if 19 - 19: Ii
  if 22 - 22: oOooo0OOO % iIiii1i + Oo
  if 60 - 60: IiII1I1I1i1 + o00o0OO00O + ooo0O0oO00 % i1i1i1111I - Ii % IIiIIiIi11I1
  if 95 - 95: ooOOO % i1i1i1111I . i1
  if 87 - 87: Iii1i % ooOOO * Ii % ooo0O0oO00 / o00o0OO00O
  if 84 - 84: I1Ii1I1 + IIiIIiIi11I1 % ooo0O0oO00 * i1i1i1111I
  if 61 - 61: i1iiIII111 - Oo + I1Ii1I1
  if 43 - 43: ooo0O0oO00 * IiII1I1I1i1 + Ii % iIiii1i
  if 12 - 12: i1iiIII111 + IiII1I1I1i1 . o00o0OO00O
  if 1 - 1: iIiii1i % Ii - o00o0OO00O / o00ooO0Ooooo + iIiii1i - Ii
  if 27 - 27: OooOoo % iIiii1i + ooo0O0oO00
  if 16 - 16: o00ooO0Ooooo
  if 31 - 31: oOo0O00 / Iii1i % IIiIIiIi11I1 % i1 . iIiii1i . Oo
  if 83 - 83: oOo0O00 - o00o0OO00O
  if 91 - 91: ooo0O0oO00 - i1 - iIiii1i
  self . df . sort_index ( inplace = True , level = [ 0 , 1 ] )
  self . df [ 'const' ] = 1
  if 71 - 71: I1I - o00ooO0Ooooo
  if xcols is None : xcols = [ ]
  if 66 - 66: i1i1i1111I / IIiIIiIi11I1 + o00o0OO00O + Iii1i + oOo0O00 + oOooo0OOO
  if 75 - 75: OooOoo - O0o00 - IiIIii11Ii - O0o00 + IiII1I1I1i1 % iIiii1i
  if 42 - 42: i1 * oOooo0OOO
  for ooO0O0OO in xcols + [ acol , ycol ] :
   Iioo0Oo0oO0 = self . df [ ooO0O0OO ] . isnull ( ) . groupby ( 'date' ) . sum ( )
   if ( Iioo0Oo0oO0 > 0.001 ) . any ( ) :
    iII11I1iI = Iioo0Oo0oO0 [ Iioo0Oo0oO0 > 0.001 ] . index . tolist ( )
    raise ValueError ( '{} has NANs on dates: {}' . format ( ooO0O0OO , iII11I1iI ) )
    if 87 - 87: i1iiIII111 - ooo0O0oO00 * Ii % i1i1i1111I % i1
    if 81 - 81: i1 + i1i1i1111I * Oo - Oo * I1Ii1I1 - oOo0O00
  if len ( xcols ) > 0 :
   iiIIIIi = ( self . df . groupby ( 'time' ) [ xcols ] . sum ( ) . abs ( ) > 1e-6 ) . all ( axis = 1 )
   iiIIIIi = iiIIIIi [ iiIIIIi . values ] . index
   self . df = self . df . loc [ ( slice ( None ) , iiIIIIi ) , : ]
   if 32 - 32: oOooo0OOO - I1Ii1I1 * I1Ii1I1 / o00ooO0Ooooo . IiII1I1I1i1
   if 80 - 80: ooo0O0oO00 / OooOoo % iIiii1i / ooOOO * ooOOO - Iii1i
  self . dates = self . df . index . get_level_values ( 0 ) . unique ( )
  if 60 - 60: O0o00 * i1i1i1111I / iIiii1i
  self . times = self . df . index . get_level_values ( 1 ) . unique ( )
  if 45 - 45: IIiIIiIi11I1 + ooOOO * oOo0O00 - IiII1I1I1i1 / ooo0O0oO00
  self . N = len ( self . dates )
  if 14 - 14: oOooo0OOO - IiIIii11Ii
  self . Ms = self . df [ acol ] . groupby ( 'date' ) . count ( )
  if 74 - 74: oOo0O00 * IiII1I1I1i1 . ooOOO
  self . M = self . Ms . max ( )
  if 2 - 2: Ii * ooo0O0oO00 % i1 + IiIIii11Ii % i1
  self . NM = self . df . shape [ 0 ]
  if 82 - 82: ooOOO % OooOoo
  self . px = len ( xcols )
  if 81 - 81: Ii
  if 40 - 40: oOooo0OOO . OooOoo + oOo0O00 . i1iiIII111
  if self . N < self . px + 3 :
   raise ValueError ( 'Number of days {} < number of features {} + 3,' . format ( self . N , self . px ) + 'VCM fails to conduct statistical inference!' )
   if 96 - 96: I1I / O0o00 / o00o0OO00O + o00o0OO00O
   if 35 - 35: ooo0O0oO00 + oOo0O00
   if 96 - 96: iIiii1i . OooOoo . i1
  if len ( xcols ) != 0 :
   self . mx = self . df [ xcols ] . groupby ( 'time' ) . mean ( )
   self . df [ xcols ] -= self . mx
   self . sx = self . df [ xcols ] . groupby ( 'time' ) . std ( ) + 1e-6
   self . df [ xcols ] /= self . sx
  self . sy = self . df [ ycol ] . std ( ) + 1e-6
  self . df [ ycol ] /= self . sy
  if 87 - 87: IiII1I1I1i1 * IiIIii11Ii % IiII1I1I1i1 . ooOOO . Oo % iIiii1i
  if 48 - 48: ooOOO * IiII1I1I1i1 % IiIIii11Ii * i1 . Iii1i - o00ooO0Ooooo
  oo0O0O0Ooooo = [ ]
  if interaction and len ( xcols ) > 0 :
   OooII1111I11 = { ooO0O0OO : acol + '_' + ooO0O0OO for ooO0O0OO in xcols }
   for ooO0O0OO in xcols :
    self . df [ OooII1111I11 [ ooO0O0OO ] ] = self . df [ acol ] * self . df [ ooO0O0OO ]
   oo0O0O0Ooooo = list ( OooII1111I11 . values ( ) )
  self . regcols1 = [ 'const' ] + xcols + [ acol ] + oo0O0O0Ooooo
  self . regcols0 = [ 'const' ] + xcols + oo0O0O0Ooooo
  if 94 - 94: Oo - ooo0O0oO00
  if 79 - 79: Ii + IiIIii11Ii * iIiii1i / iIiii1i
  self . regcols1_ = [ ooO0O0OO + str ( I1IoOooOo0o ) for I1IoOooOo0o in self . times for ooO0O0OO in self . regcols1 ]
  self . regcols0_ = [ ooO0O0OO + str ( I1IoOooOo0o ) for I1IoOooOo0o in self . times for ooO0O0OO in self . regcols0 ]
  self . df_ = pd . DataFrame ( 0 , index = self . df . index , columns = self . regcols1_ )
  for I1IoOooOo0o in self . times :
   iii1ii1 = [ ooO0O0OO + str ( I1IoOooOo0o ) for ooO0O0OO in self . regcols1 ]
   self . df_ . loc [ ( slice ( None ) , I1IoOooOo0o ) , iii1ii1 ] = self . df . loc [ ( slice ( None ) , I1IoOooOo0o ) , self . regcols1 ] . values
  self . df_ [ ycol ] = self . df [ ycol ] . values
  if 27 - 27: i1 / OooOoo + Iii1i % OooOoo + OooOoo
  if 70 - 70: Oo / Iii1i * OooOoo
  self . ycol = ycol
  self . xcols = xcols
  self . acol = acol
  self . axcols = oo0O0O0Ooooo
  self . interaction = interaction
  self . two_sided = two_sided
  self . wild_bootstrap = wild_bootstrap
  self . copy = copy
  if 2 - 2: oOooo0OOO / Iii1i + I1Ii1I1
  self . keep_ratio = keep_ratio
  self . he = he
  self . smooth_coef = smooth_coef
  self . hc = hc
  if 34 - 34: OooOoo
  self . pr = len ( self . regcols1 )
  if 95 - 95: Oo % i1i1i1111I * iIiii1i - IiIIii11Ii
  self . null , self . alternative = False , False
  if 66 - 66: iIiii1i . i1 % Ii % o00o0OO00O * oOo0O00
  self . holder = { }
  if 59 - 59: Ii . IiII1I1I1i1 - Oo - iIiii1i - i1i1i1111I . i1iiIII111
 def estimate ( self , ycol = None , null = False , suffix = '' , max_iter = 20 , eps = 1e-3 ) :
  if null : suffix = '0'
  if ycol is None : ycol = self . ycol
  iI11 , O0OO00Oo0o0 = self . xcols , self . acol
  IiIIIII1i , oo0O0O0Ooooo = self . interaction , self . axcols
  if 41 - 41: ooOOO + OooOoo + ooo0O0oO00 * i1i1i1111I
  iIi = self . df_
  if 96 - 96: OooOoo + Ii % O0o00 % i1iiIII111 % Oo * IIiIIiIi11I1
  OoO0OOo00oo0O = self . regcols0_ if null else self . regcols1_
  i1IiI1i = self . regcols0 if null else self . regcols1
  if 55 - 55: o00ooO0Ooooo % O0o00 * o00ooO0Ooooo . ooOOO * Iii1i
  if 24 - 24: oOo0O00 * IiIIii11Ii + Iii1i
  i1Iii11ii11 , IIIiII1I = self . px , self . pr
  ii1i , I1II1IIIi , IiI111I1 = self . N , self . M , len ( i1IiI1i )
  if 86 - 86: i1 . o00ooO0Ooooo - Ii
  iiIIIIi = self . times
  iiiIII = self . holder
  if 16 - 16: ooo0O0oO00
  if 96 - 96: OooOoo / O0o00 - i1 * o00o0OO00O
  o0oOoOoO = iIi . groupby ( 'date' ) . apply ( lambda O0OOoOoOo0O0O : np . dot ( O0OOoOoOo0O0O [ OoO0OOo00oo0O ] . T , O0OOoOoOo0O0O [ OoO0OOo00oo0O ] ) ) . sum ( )
  IiI = iIi . groupby ( 'date' ) . apply ( lambda O0OOoOoOo0O0O : np . dot ( O0OOoOoOo0O0O [ OoO0OOo00oo0O ] . T , O0OOoOoOo0O0O [ ycol ] ) ) . sum ( )
  if 76 - 76: i1i1i1111I % oOo0O00 - i1iiIII111 * i1
  o00 = np . eye ( o0oOoOoO . shape [ 0 ] ) * 1e-3
  iI11iii = np . linalg . solve ( o0oOoOoO + o00 , IiI )
  for Ii1i1 in range ( max_iter ) :
   iII11I11111I = iIi [ ycol ] - iIi [ OoO0OOo00oo0O ] . dot ( iI11iii )
   ooOO0OO0o = iII11I11111I . unstack ( ) . var ( axis = 0 ) + 1e-3
   oOOooO = 1.0 / ooOO0OO0o
   if 37 - 37: i1i1i1111I
   o0oOoOoO = iIi . groupby ( 'date' ) . apply ( lambda O0OOoOoOo0O0O : OOoOoo000O00 ( O0OOoOoOo0O0O [ OoO0OOo00oo0O ] , oOOooO ) ) . sum ( )
   IiI = iIi . groupby ( 'date' ) . apply ( lambda O0OOoOoOo0O0O : iI111iiIi11i ( O0OOoOoOo0O0O [ OoO0OOo00oo0O ] , oOOooO , O0OOoOoOo0O0O [ ycol ] ) ) . sum ( )
   if 79 - 79: IiII1I1I1i1 % oOooo0OOO - Ii % oOooo0OOO - I1I
   OooOoO0o00 = np . linalg . solve ( o0oOoOoO + o00 , IiI )
   if np . abs ( iI11iii - OooOoO0o00 ) . sum ( ) / np . abs ( iI11iii ) . sum ( ) < eps :
    break
   iI11iii = OooOoO0o00
  if Ii1i1 == max_iter - 1 :
   print ( 'warning: max iteration reached!' )
   if 23 - 23: i1
  iIi [ 'fittedvalues' + suffix ] = iIi [ OoO0OOo00oo0O ] . dot ( iI11iii )
  iIi [ 'resid' + suffix ] = iIi [ ycol ] - iIi [ 'fittedvalues' + suffix ]
  if 91 - 91: o00o0OO00O - o00ooO0Ooooo % IiIIii11Ii / IiIIii11Ii
  if not null :
   OO00o00O = iIi [ 'resid' + suffix ] . unstack ( ) . fillna ( 0 ) . groupby ( 'date' ) . apply ( lambda O0OOoOoOo0O0O : np . outer ( O0OOoOoOo0O0O , O0OOoOoOo0O0O ) ) . sum ( ) / ( ii1i - IIIiII1I )
   OO00o00O = pd . DataFrame ( OO00o00O , index = iiIIIIi , columns = iiIIIIi )
   if 9 - 9: O0o00 . IiII1I1I1i1 * oOo0O00
   oo00oOO = np . linalg . pinv ( o0oOoOoO + o00 )
   o0oO0O0Oo00 = iIi . groupby ( 'date' ) . apply ( lambda O0OOoOoOo0O0O : Ooo ( O0OOoOoOo0O0O [ OoO0OOo00oo0O ] , oOOooO , OO00o00O ) ) . sum ( )
   IIiIIiiIIi = np . dot ( np . dot ( oo00oOO , o0oO0O0Oo00 ) , oo00oOO )
   if 29 - 29: i1i1i1111I / oOo0O00
   Ii1i1 = i1Iii11ii11 + 1 + IIIiII1I * np . arange ( I1II1IIIi )
   iI1i1Iiii11i = iI11iii [ Ii1i1 ]
   oO00oO0O = IIiIIiiIIi [ Ii1i1 , : ] [ : , Ii1i1 ]
   if 97 - 97: i1 - i1 % ooo0O0oO00 + IiIIii11Ii / oOooo0OOO * iIiii1i
   I1I111i11I = iI1i1Iiii11i . sum ( )
   iii11i = oO00oO0O . sum ( ) ** 0.5 + 1e-6
   O00Ooo0o = I1I111i11I / iii11i
   iiiIII [ 'gamma' + suffix ] = I1I111i11I * self . sy
   iiiIII [ 'gamma_se' + suffix ] = iii11i * self . sy
   iiiIII [ 'test_stats' + suffix ] = O00Ooo0o
   if 33 - 33: ooo0O0oO00
  iI11iii = pd . DataFrame ( iI11iii . reshape ( ( I1II1IIIi , IiI111I1 ) ) , columns = i1IiI1i )
  if len ( iI11 ) > 0 :
   iI11iii [ iI11 ] /= self . sx . values
   iI11iii [ 'const' ] -= ( iI11iii [ iI11 ] * self . mx . values ) . sum ( axis = 1 )
   if IiIIIII1i :
    iI11iii [ oo0O0O0Ooooo ] /= self . sx . values
    iI11iii [ 'const' ] -= ( iI11iii [ oo0O0O0Ooooo ] * self . mx . values ) . sum ( axis = 1 )
  iI11iii *= self . sy
  if 48 - 48: o00o0OO00O . oOo0O00 . I1Ii1I1 . iIiii1i + o00o0OO00O
  iiiIII [ 'thetas' + suffix ] = iI11iii
  iiiIII [ ycol ] = iIi [ ycol ] * self . sy
  iiiIII [ ycol + '_hat' + suffix ] = iIi [ 'fittedvalues' + suffix ] * self . sy
  iiiIII [ 'resid' + suffix ] = iIi [ 'resid' + suffix ] * self . sy
  if 19 - 19: i1 . IiIIii11Ii - IIiIIiIi11I1 . Ii
  if null : self . null = True
  else : self . alternative = True
  if 51 - 51: i1 + i1i1i1111I - i1 + i1iiIII111 . Oo
 def inference ( self , nb = 100 , max_iter = 20 , eps = 1e-3 ) :
  if 92 - 92: OooOoo + Ii / ooo0O0oO00 + OooOoo * ooo0O0oO00 * iIiii1i
  if not self . alternative :
   self . estimate ( null = False )
   if 79 - 79: i1i1i1111I
  iiiIII = self . holder
  iIi = self . df_
  ii1i , I1II1IIIi , Ii111ooOooo , OoO = self . N , self . M , self . Ms , self . NM
  iiIIi1Ii1Ii11 = self . two_sided
  I11 = self . wild_bootstrap
  O00Ooo0o = iiiIII [ 'test_stats' ]
  if 65 - 65: Iii1i % ooo0O0oO00 - IiII1I1I1i1 . ooOOO + Iii1i
  if I11 :
   if 46 - 46: IiIIii11Ii
   if not self . null :
    self . estimate ( null = True )
   i1IiiI1I1i1 = iIi [ 'fittedvalues0' ]
   Oooo0OoOoooo = iIi [ 'resid0' ]
   if 41 - 41: IiII1I1I1i1 % ooo0O0oO00 % ooOOO
   iIi1II = np . zeros ( nb )
   for Ii1i1 in range ( nb ) :
    if 16 - 16: IiII1I1I1i1 - iIiii1i * IiII1I1I1i1
    iIi [ 'Yb' ] = i1IiiI1I1i1 + np . repeat ( np . random . randn ( ii1i ) , Ii111ooOooo ) * Oooo0OoOoooo
    if 44 - 44: ooo0O0oO00 - IiIIii11Ii
    self . estimate ( ycol = 'Yb' , null = False , suffix = '_b' , max_iter = max_iter , eps = eps )
    iIi1II [ Ii1i1 ] = iiiIII [ 'test_stats_b' ]
    if 67 - 67: IIiIIiIi11I1 . IIiIIiIi11I1 . o00ooO0Ooooo
   IiiI1II = ( iIi1II > O00Ooo0o ) . mean ( )
   O0OO = min ( 1.0 , 2.0 * ( iIi1II > abs ( O00Ooo0o ) ) . mean ( ) )
   iiiIII [ 'test_stats_wb' ] = iIi1II
  else :
   from scipy . stats import norm
   IiiI1II = 1 - norm . cdf ( O00Ooo0o )
   O0OO = 2 - 2 * norm . cdf ( abs ( O00Ooo0o ) )
   if 58 - 58: IiIIii11Ii
  Ooo00OO000oo = O0OO if iiIIi1Ii1Ii11 else IiiI1II
  iiiIII [ 'test_stats' ] = O00Ooo0o
  iiiIII [ 'pvalue' ] = Ooo00OO000oo
  iiiIII [ 'pvalue1' ] = IiiI1II
  iiiIII [ 'pvalue2' ] = O0OO
  if 19 - 19: iIiii1i * OooOoo . i1 . IiIIii11Ii * IiIIii11Ii
class vcm_result ( object ) :
 def __init__ ( self , data , evaluate_dict , output_path = None ) :
  if output_path :
   if 47 - 47: ooOOO + Oo / I1Ii1I1 . ooo0O0oO00
   if 67 - 67: Oo % ooOOO + iIiii1i * I1I
   if 79 - 79: ooo0O0oO00 * Oo / OooOoo
   if 10 - 10: iIiii1i / i1iiIII111 . IiIIii11Ii * i1i1i1111I
   if 71 - 71: oOo0O00 + I1Ii1I1 / o00o0OO00O + Oo / I1I
   if 18 - 18: Iii1i - IiIIii11Ii
   if 71 - 71: iIiii1i + OooOoo % i1i1i1111I % oOo0O00 . IiII1I1I1i1
   if 92 - 92: o00o0OO00O - IIiIIiIi11I1 - i1i1i1111I % i1iiIII111 / i1i1i1111I * iIiii1i
   self . output_path = output_path
  else :
   self . output_path = os . path . join ( os . getcwd ( ) , 'Result' )
  if not os . path . exists ( self . output_path ) :
   os . makedirs ( self . output_path )
   if 60 - 60: IiIIii11Ii % O0o00 / oOooo0OOO * OooOoo / o00o0OO00O - Ii
  self . data = data
  self . evaluate_dict = evaluate_dict
  if 16 - 16: oOo0O00 / I1Ii1I1 / i1 + o00o0OO00O + oOo0O00
 def run ( self ) :
  I11Ii = [ ]
  o0o00oo000 = [ ]
  Ii111 = len ( self . data . tdate . unique ( ) ) / 2
  for Iio0 in tqdm ( self . data . city_id . unique ( ) ) :
   oo = self . data [ self . data [ 'city_id' ] == Iio0 ] . reset_index ( )
   IIiIiiIiI ( df = oo , df_all = self . data , evaluate_dict = self . evaluate_dict , city_results = I11Ii )
  I11Ii = pd . DataFrame ( I11Ii , columns = [ 'city_id' , 'index' , 'control_value' , 'treatment_value' ,
 'abs_diff' , 'abs_diff_lower' , 'abs_diff_up' ,
 'relative_diff' , 'relative_diff_lower' , 'relative_diff_up' ,
 'pvalue' , 'gamma' , 'gamma_se' ,
 'numerator_c' , 'denominator_c' ,
 'fz_gamma' , 'fm_gamma' ] )
  if 6 - 6: ooOOO % I1I * IIiIIiIi11I1 % Iii1i % O0o00 - oOo0O00
  for Iio0 in self . evaluate_dict :
   O0OOO = I11Ii [ I11Ii [ 'index' ] == Iio0 ]
   if 10 - 10: I1Ii1I1 . IIiIIiIi11I1 - iIiii1i - i1iiIII111 / OooOoo % i1iiIII111
   OoO00oOo = np . sum ( O0OOO . gamma . values )
   oOoooo = np . sqrt ( np . sum ( np . square ( O0OOO . gamma_se . values ) ) )
   OOooO00OooO = OoO00oOo / oOoooo
   if 66 - 66: oOo0O00 - Iii1i - IiII1I1I1i1 . o00o0OO00O
   o0Ooo = 2 - 2 * norm . cdf ( abs ( OOooO00OooO ) )
   if 37 - 37: ooo0O0oO00 % O0o00 + Oo . IIiIIiIi11I1
   if self . evaluate_dict [ Iio0 ] [ 0 ] == 'type2' :
    if 18 - 18: IiIIii11Ii * IiIIii11Ii - Ii
    I1iI = ( 2 * OoO00oOo ) / np . sum ( O0OOO . denominator_c . values )
    IiIII = ( OoO00oOo + 1.96 * oOoooo ) * 2 / np . sum ( O0OOO . denominator_c . values )
    i1IIiII11 = ( OoO00oOo - 1.96 * oOoooo ) * 2 / np . sum ( O0OOO . denominator_c . values )
    if 52 - 52: oOooo0OOO
    OO = np . sum ( O0OOO . numerator_c . values ) / np . sum ( O0OOO . denominator_c . values )
    iiI1I11iiiiI = ( 2 * OoO00oOo + np . sum ( O0OOO . numerator_c . values ) ) / np . sum ( O0OOO . denominator_c . values )
    if 72 - 72: O0o00 + oOo0O00
    OOO00oO0oOo0O = ( I1iI / OO )
    iIi1I1I = IiIII / OO
    II1III1I1i = i1IIiII11 / OO
    if 10 - 10: iIiii1i % ooOOO % o00ooO0Ooooo % Oo
   elif self . evaluate_dict [ Iio0 ] [ 0 ] == 'type3' :
    if 17 - 17: IiII1I1I1i1
    OO = np . sum ( O0OOO . numerator_c . values ) / np . sum ( O0OOO . denominator_c . values )
    iiI1I11iiiiI = ( np . sum ( O0OOO . numerator_c . values ) + 2 * np . sum ( O0OOO . fz_gamma . values ) ) / ( np . sum ( O0OOO . denominator_c . values ) + 2 * np . sum ( O0OOO . fm_gamma . values ) )
    if 48 - 48: IiIIii11Ii % I1I / o00ooO0Ooooo
    I1iI = ( iiI1I11iiiiI - OO )
    OOO00oO0oOo0O = ( I1iI / OO )
    if 66 - 66: Ii % Ii . i1iiIII111 / ooo0O0oO00
    iIi1I1I = np . nan
    II1III1I1i = np . nan
    IiIII = np . nan
    i1IIiII11 = np . nan
    if 67 - 67: o00ooO0Ooooo / OooOoo % o00ooO0Ooooo + i1iiIII111
   elif self . evaluate_dict [ Iio0 ] [ 0 ] == 'type1' :
    if 21 - 21: oOo0O00 % i1iiIII111 % o00o0OO00O % O0o00
    I1iI = ( 2 * OoO00oOo ) * Ii111
    IiIII = ( OoO00oOo + 1.96 * oOoooo ) * 2
    i1IIiII11 = ( OoO00oOo - 1.96 * oOoooo ) * 2
    if 63 - 63: oOo0O00 % Iii1i - i1iiIII111 + Oo * oOooo0OOO - oOo0O00
    OO = np . sum ( O0OOO . numerator_c . values ) * Ii111
    iiI1I11iiiiI = ( 2 * OoO00oOo + np . sum ( O0OOO . numerator_c . values ) ) * Ii111
    if 93 - 93: Iii1i * ooo0O0oO00 % oOooo0OOO + i1 % Ii * oOooo0OOO
    OOO00oO0oOo0O = ( I1iI / OO )
    iIi1I1I = IiIII / OO
    II1III1I1i = i1IIiII11 / OO
    if 62 - 62: o00ooO0Ooooo % IiII1I1I1i1
   o0o00oo000 . append ( [ '整体' , Iio0 , OO , iiI1I11iiiiI , I1iI , i1IIiII11 , IiIII , OOO00oO0oOo0O , II1III1I1i , iIi1I1I , o0Ooo , OoO00oOo , oOoooo ] )
   if 19 - 19: Ii / Oo % Iii1i / i1iiIII111 - OooOoo - IIiIIiIi11I1
  o0o00oo000 = pd . DataFrame ( o0o00oo000 , columns = [ 'city_id' , 'index' , 'control_value' , 'treatment_value' ,
 'abs_diff' , 'abs_diff_lower' , 'abs_diff_up' ,
 'relative_diff' , 'relative_diff_lower' , 'relative_diff_up' ,
 'pvalue' , 'gamma' , 'gamma_se' , ] )
  I1I11i1i1i = I11Ii [ [ 'city_id' , 'index' , 'control_value' , 'treatment_value' ,
 'abs_diff' , 'abs_diff_lower' , 'abs_diff_up' ,
 'relative_diff' , 'relative_diff_lower' , 'relative_diff_up' ,
 'pvalue' , 'gamma' , 'gamma_se' ] ]
  if 72 - 72: ooo0O0oO00 * IiII1I1I1i1 % i1iiIII111
  II1I11111I = pd . concat ( [ o0o00oo000 , I1I11i1i1i ] )
  II1I11111I = II1I11111I [ [ 'city_id' , 'index' , 'control_value' , 'treatment_value' ,
 'abs_diff' , 'relative_diff' , 'pvalue' , 'gamma' , 'gamma_se' ,
 'abs_diff_lower' , 'abs_diff_up' , 'relative_diff_lower' , 'relative_diff_up' ] ]
  II1I11111I . columns = [ '城市' , '指标' , '对照组' , '实验组' , '绝对提升' , '相对提升' , 'P值' , 'gamma' , 'gamma_se' , '绝对提升置信区间_lower' , '绝对提升置信区间_up' , '相对提升置信区间_lower' , '相对提升置信区间_up' ]
  II1I11111I = II1I11111I [ [ '指标' , '城市' , '对照组' , '实验组' , 'P值' , '绝对提升' , '相对提升' , '绝对提升置信区间_lower' , '绝对提升置信区间_up' ] ]
  II1I11111I . to_csv ( self . output_path + '/vcm_result.csv' , encoding = "gbk" , index = False )
  return II1I11111I
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
