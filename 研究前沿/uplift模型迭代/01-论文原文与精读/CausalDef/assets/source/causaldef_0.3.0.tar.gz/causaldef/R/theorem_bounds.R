# =============================================================================
# Theorem-Oriented Bounds & Diagnostics (Manuscript-aligned utilities)
# =============================================================================

#' Nonparametric Rate for Back-Door Kernels (Result 1)
#'
#' Order-of-magnitude rate for the total-variation estimation error of the
#' back-door plug-in interventional law (manuscript Remark on nonparametric
#' rates): \eqn{(n\eta)^{-\beta/(2\beta + d_W + d_Y)}}, up to constants and
#' logarithmic factors. Here \eqn{n\eta} is the effective number of observations at
#' the treatment level of interest. For finite outcome spaces use `d_y = 0`.
#'
#' Versions up to 0.2.1 returned \eqn{n^{-\beta/(2\beta+d_W)} + \eta^{-1}\sqrt{\log(1/\xi)/n}},
#' which ignored the outcome dimension and misplaced the positivity constant.
#'
#' @param n Sample size.
#' @param beta Smoothness exponent (\eqn{\beta} in a \eqn{\beta}-H\"older class).
#' @param d_w Covariate dimension (\eqn{d_W}).
#' @param eta Positivity constant (\eqn{\eta>0}) such that \eqn{P(A=a|W=w) \ge \eta}.
#' @param xi Unused; retained for backward compatibility.
#' @param d_y Outcome dimension (\eqn{d_Y}); 0 for finite outcome spaces (default).
#'
#' @return Numeric rate (an O(.) rate; constants and log factors are not pinned down).
#' @export
rkhs_rate_bound <- function(n, beta, d_w, eta, xi = 0.05, d_y = 0) {
  checkmate::assert_integerish(n, lower = 1)
  checkmate::assert_number(beta, lower = 0)
  checkmate::assert_integerish(d_w, lower = 1)
  checkmate::assert_number(eta, lower = 0, upper = 1)
  checkmate::assert_number(xi, lower = 0, upper = 1)
  checkmate::assert_integerish(d_y, lower = 0)
  if (eta == 0) {
    return(Inf)
  }

  n_eff <- as.numeric(n) * eta
  (n_eff)^(-beta / (2 * beta + as.numeric(d_w) + as.numeric(d_y)))
}

#' Finite-Sample Policy Regret Bound with VC Term (Result 3)
#'
#' Regret bound for the empirical welfare maximizer under inverse propensity
#' weighting with a known propensity in \eqn{[\eta, 1-\eta]} (binary treatment),
#' following the manuscript's Finite-Sample Policy Regret Transfer theorem:
#' \deqn{Regret_{do}(\hat\pi_n) \le 4M\delta + C\frac{M}{\eta}\left(\sqrt{\frac{v}{n}} + \sqrt{\frac{\log(1/\xi)}{n}}\right),}
#' where \eqn{\delta} is the worst-case error of the back-door kernels used and
#' \eqn{v} is the VC dimension of the policy class.
#'
#' Versions up to 0.2.1 used \eqn{\delta M + C M\sqrt{(v\log n + \log(1/\xi))/n}},
#' which omitted the factor 4 on the deficiency term and the \eqn{1/\eta} factor.
#'
#' @param deficiency A `deficiency` object or numeric \eqn{\delta}.
#' @param vc_dim VC dimension of the policy class.
#' @param n Sample size used to learn the policy.
#' @param xi Failure probability (\eqn{\xi}).
#' @param utility_range Numeric vector c(min, max) of utility bounds.
#' @param obs_regret Deprecated and ignored: the bound applies to the empirical
#'   welfare maximizer, whose simulated regret is controlled by the complexity term.
#' @param delta_mode Passed through to `policy_regret_bound()` when `deficiency` is an object.
#' @param C Absolute constant multiplying the statistical term. It is not pinned down
#'   by the theorem; the default 2 is illustrative.
#' @param eta Overlap constant: the known propensity satisfies
#'   \eqn{\eta \le P(A=1|W) \le 1-\eta}. Required.
#'
#' @return An object of class `policy_bound` with additional field `complexity_penalty`;
#'   `regret_bound` equals `transfer_penalty + complexity_penalty`.
#' @export
policy_regret_bound_vc <- function(deficiency,
                                   vc_dim,
                                   n,
                                   xi = 0.05,
                                   utility_range = c(0, 1),
                                   obs_regret = NULL,
                                   delta_mode = c("point", "upper"),
                                   C = 2,
                                   eta = NULL) {
  checkmate::assert_number(vc_dim, lower = 0)
  checkmate::assert_integerish(n, lower = 1)
  checkmate::assert_number(xi, lower = 0, upper = 1)
  checkmate::assert_number(C, lower = 0)
  if (is.null(eta)) {
    cli::cli_abort(c(
      "{.arg eta} is required.",
      "i" = "The finite-sample bound needs the overlap constant: a known propensity in [eta, 1 - eta].",
      "i" = "Versions up to 0.2.1 omitted it; see NEWS for the corrected bound."
    ))
  }
  checkmate::assert_number(eta, lower = 0, upper = 0.5)
  if (!is.null(obs_regret)) {
    cli::cli_warn("{.arg obs_regret} is ignored by {.fn policy_regret_bound_vc}; the bound applies to the empirical welfare maximizer.")
  }

  base <- policy_regret_bound(
    deficiency = deficiency,
    utility_range = utility_range,
    obs_regret = NULL,
    delta_mode = delta_mode,
    n_actions = 2,
    policy_type = "covariate"
  )

  if (xi == 0) {
    xi <- .Machine$double.eps
  }
  if (eta == 0) {
    complexity_penalty <- Inf
  } else {
    n <- as.numeric(n)
    complexity_penalty <- C * (base$M / eta) *
      (sqrt(as.numeric(vc_dim) / n) + sqrt(log(1 / xi) / n))
  }
  base$complexity_penalty <- complexity_penalty
  base$eta <- eta
  base$regret_bound <- base$transfer_penalty + complexity_penalty

  class(base) <- unique(c("policy_bound_vc", class(base)))
  base
}

#' Wasserstein Deficiency (Linear Gaussian) (Result 6)
#'
#' Closed-form Wasserstein-1 deficiency for the two-point construction in Result 6:
#' \eqn{\delta_{W_1}(a) = |a \alpha \gamma| / (\alpha^2 + \sigma_A^2)}.
#'
#' @param alpha Confounding strength U -> A.
#' @param gamma Confounding strength U -> Y.
#' @param sigma_A Treatment noise standard deviation.
#' @param a Intervention level \eqn{do(A=a)}.
#'
#' @return Numeric deficiency value.
#' @export
wasserstein_deficiency_gaussian <- function(alpha, gamma, sigma_A = 1, a = 1) {
  checkmate::assert_number(alpha)
  checkmate::assert_number(gamma)
  checkmate::assert_number(sigma_A, lower = 0)
  checkmate::assert_number(a)
  denom <- alpha^2 + sigma_A^2
  if (!is.finite(denom) || denom <= 0) {
    return(0)
  }
  abs(a * alpha * gamma) / denom
}

#' Sharp Two-Point Bounds (Result 4)
#'
#' Computes matching lower/upper bounds (sharpness) in the linear Gaussian model,
#' for either TV-based (two-point construction underlying `thm:confounding_lb`) or Wasserstein-1-based
#' (Result 6 two-point construction) deficiencies.
#'
#' @param alpha Confounding strength U -> A.
#' @param gamma Confounding strength U -> Y.
#' @param sigma_A Treatment noise standard deviation.
#' @param sigma_Y Outcome noise standard deviation (TV case).
#' @param a Intervention level.
#' @param metric One of `"tv"` or `"wasserstein"`.
#'
#' @return List with fields: `lower`, `upper`, `ratio`, and `metric`.
#' @export
sharp_lower_bound <- function(alpha,
                             gamma,
                             sigma_A = 1,
                             sigma_Y = 1,
                             a = 1,
                             metric = c("tv", "wasserstein")) {
  metric <- match.arg(metric)
  checkmate::assert_number(alpha)
  checkmate::assert_number(gamma)
  checkmate::assert_number(sigma_A, lower = 0)
  checkmate::assert_number(a)

  if (metric == "wasserstein") {
    delta <- wasserstein_deficiency_gaussian(alpha = alpha, gamma = gamma, sigma_A = sigma_A, a = a)
    return(list(
      metric = "wasserstein",
      lower = delta,
      upper = delta,
      ratio = if (delta == 0) 1 else 1
    ))
  }

  checkmate::assert_number(sigma_Y, lower = 0)

  # Reuse the package's exact two-point TV computation (confounding_frontier).
  # .deficiency_gaussian returns (1/2)*TV between two do-laws in the two-point pair,
  # which is both a lower bound and (by midpoint kernel) an upper bound for the
  # two-point subexperiment.
  delta <- .deficiency_gaussian(alpha = alpha, gamma = gamma, sigma_A = sigma_A, sigma_Y = sigma_Y)

  list(
    metric = "tv",
    lower = delta,
    upper = delta,
    ratio = if (delta == 0) 1 else 1
  )
}

#' Partial Identification Set from a Delta Radius (Result 8)
#'
#' Converts a deficiency radius \eqn{\delta} into a conservative identified interval
#' for bounded functionals under TV.
#'
#' For a mean functional with \eqn{Y \in [y_{min}, y_{max}]}, TV control yields
#' \eqn{|E_Q[Y] - E_{Q_0}[Y]| \le 2\delta (y_{max}-y_{min})}.
#' For an ATE (difference of two means), the half-width doubles again.
#'
#' @param estimate Point estimate of the functional (numeric).
#' @param delta Deficiency radius \eqn{\delta \in [0,1]}.
#' @param estimand One of `"mean"` or `"ate"`.
#' @param outcome_range Numeric vector c(min, max) bounding the outcome.
#'
#' @return An object of class `"partial_id_set"` containing:
#'   \itemize{
#'     \item `estimand`: whether the interval applies to a bounded mean or an ATE
#'     \item `estimate`: the supplied point estimate
#'     \item `delta`: the deficiency radius used to widen the estimate
#'     \item `outcome_range`: assumed outcome bounds
#'     \item `half_width`: worst-case expansion implied by `delta`
#'     \item `lower`, `upper`: conservative identification limits
#'   }
#'   The interval describes all values consistent with the supplied estimate and
#'   the chosen total-variation deficiency radius.
#' @export
partial_id_set <- function(estimate,
                           delta,
                           estimand = c("ate", "mean"),
                           outcome_range = c(0, 1)) {
  estimand <- match.arg(estimand)
  checkmate::assert_number(estimate)
  checkmate::assert_number(delta, lower = 0, upper = 1)
  checkmate::assert_numeric(outcome_range, len = 2)

  y_min <- outcome_range[1]
  y_max <- outcome_range[2]
  if (!is.finite(y_min) || !is.finite(y_max) || y_max <= y_min) {
    cli::cli_abort("outcome_range must be c(min, max) with min < max.")
  }
  span <- y_max - y_min

  factor <- if (estimand == "mean") 2 else 4
  half_width <- factor * delta * span

  out <- list(
    estimand = estimand,
    estimate = estimate,
    delta = delta,
    outcome_range = outcome_range,
    half_width = half_width,
    lower = estimate - half_width,
    upper = estimate + half_width
  )

  class(out) <- "partial_id_set"
  out
}

#' Overlap Diagnostic
#'
#' Summarizes overlap/positivity issues via propensity score distribution and
#' effective sample size under IPTW weights.
#'
#' @param spec A `causal_spec`.
#' @param trim Trimming threshold in (0, 0.5). Values outside \eqn{[trim, 1 - trim]}
#'   are flagged as extreme.
#'
#' @return An object of class `"overlap_diagnostic"` containing:
#'   \itemize{
#'     \item `trim`: trimming threshold used to classify extreme propensity scores
#'     \item `n`: sample size
#'     \item `extreme_n`: number of observations with propensity scores outside
#'     the acceptable overlap region
#'     \item `kept_n`: number of observations remaining after trimming
#'     \item `ps_summary`: selected propensity-score quantiles
#'     \item `ess_iptw`: effective sample size under IPTW weights
#'   }
#'   These quantities summarize how much practical overlap is available for
#'   weighted causal estimation.
#' @export
overlap_diagnostic <- function(spec, trim = 0.01) {
  validate_causal_spec(spec)
  checkmate::assert_number(trim, lower = 0, upper = 0.49)

  if (is.null(spec$covariates) || length(spec$covariates) == 0) {
    cli::cli_abort("overlap_diagnostic() requires covariates in the causal_spec.")
  }
  if (spec$treatment_type != "binary") {
    cli::cli_abort("overlap_diagnostic() currently supports only binary treatments.")
  }

  data <- spec$data
  A <- data[[spec$treatment]]
  if (is.factor(A) || is.character(A)) {
    A <- as.numeric(as.factor(A)) - 1
  }

  ps_formula <- stats::as.formula(paste(spec$treatment, "~", paste(spec$covariates, collapse = " + ")))
  ps_model <- stats::glm(ps_formula, data = data, family = stats::binomial())
  ps <- stats::predict(ps_model, type = "response")

  ps_bounded <- pmax(1e-6, pmin(1 - 1e-6, ps))
  w <- A / ps_bounded + (1 - A) / (1 - ps_bounded)

  ess <- (sum(w)^2) / sum(w^2)
  extreme <- sum(ps < trim | ps > (1 - trim))
  kept <- sum(ps >= trim & ps <= (1 - trim))

  out <- list(
    trim = trim,
    n = nrow(data),
    extreme_n = extreme,
    kept_n = kept,
    ps_summary = stats::quantile(ps, probs = c(0, 0.01, 0.05, 0.1, 0.5, 0.9, 0.95, 0.99, 1)),
    ess_iptw = ess
  )
  class(out) <- "overlap_diagnostic"
  out
}
