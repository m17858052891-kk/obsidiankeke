# =============================================================================
# Print Methods for causaldef Classes
# =============================================================================

#' Print method for causal_spec
#'
#' @param x A causal_spec object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed summary reports the
#'   treatment and outcome variables with their inferred types, the adjustment
#'   covariates, sample size, estimand, and any registered negative control or
#'   instrument.
#' @export
print.causal_spec <- function(x, ...) {
  cat("\n-- Causal Specification ", paste(rep("-", 50), collapse = ""), "\n\n", sep = "")
  cat("* Treatment:", x$treatment, "(", x$treatment_type, ")\n")
  cat("* Outcome:", x$outcome, "(", x$outcome_type, ")\n")
  cat("* Covariates:", paste(x$covariates, collapse = ", "), "\n")
  cat("* Sample size:", x$n, "\n")
  cat("* Estimand:", x$estimand, "\n")
  
  if (!is.null(x$negative_control)) {
    cat("* Negative control:", x$negative_control, "\n")
  }
  if (!is.null(x$instrument)) {
    cat("* Instrument:", x$instrument, "\n")
  }
  cat("\n")
  invisible(x)
}

#' Print method for deficiency
#'
#' @param x A deficiency object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed summary shows the
#'   method-specific deficiency estimates, optional standard errors and
#'   confidence intervals, qualitative traffic-light labels, any PS-TV proxy
#'   note, and the method with the smallest reported deficiency.
#' @export
print.deficiency <- function(x, ...) {
  title <- if (!is.null(x$metric) && identical(x$metric, "ps_tv")) {
    "Deficiency Proxy Estimates (PS-TV)"
  } else {
    "Deficiency Proxy Estimates"
  }
  cat("\n-- ", title, " ", paste(rep("-", max(0, 40 - nchar(title))), collapse = ""), "\n\n", sep = "")
  
  # Create results table
  results_df <- data.frame(
    Method = names(x$estimates),
    Delta = round(x$estimates, 4),
    SE = if (all(is.na(x$se))) "-" else round(x$se, 4),
    stringsAsFactors = FALSE
  )
  
  if (!all(is.na(x$ci))) {
    results_df$CI <- paste0("[", round(x$ci[, 1], 4), ", ", round(x$ci[, 2], 4), "]")
  }
  
  results_df$Quality <- sapply(x$estimates, function(d) {
    if (d < 0.05) return("Excellent (Green)")
    if (d < 0.10) return("Caution (Yellow)")
    return("Insufficient (Red)")
  })

  print(results_df, row.names = FALSE)

  if (!is.null(x$metric) && identical(x$metric, "ps_tv")) {
    cat("Note: delta is a propensity-score TV proxy (overlap/balance diagnostic).\n")
  }

  # Best method
  best_idx <- which.min(x$estimates)
  cat("\nBest method:", names(x$estimates)[best_idx],
      "(delta =", round(x$estimates[best_idx], 4), ")\n")

  invisible(x)
}

#' Print method for nc_diagnostic
#'
#' @param x An nc_diagnostic object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed summary reports the
#'   screening statistic, observed negative-control proxy `delta_nc`, the
#'   translated deficiency bound `delta_bound`, the chosen `kappa`, the
#'   permutation p-value, and whether the negative-control screen was rejected.
#' @export
print.nc_diagnostic <- function(x, ...) {
  cat("\n-- Negative Control Diagnostic ", paste(rep("-", 40), collapse = ""), "\n\n", sep = "")
  if (!is.null(x$screening$statistic)) {
    cat("* screening statistic (weighted corr):", round(x$screening$statistic, 4), "\n")
  }
  cat("* delta_NC (association proxy):", round(x$delta_nc, 4), "\n")
  cat("* delta bound (under kappa alignment):", round(x$delta_bound, 4), "(kappa =", x$kappa, ")\n")
  cat("* screening p-value:", format.pval(x$p_value), "\n")
  if (!is.null(x$screening$method)) {
    cat("* screening method:", x$screening$method, "\n")
  }
  cat("\n")
  
  if (x$falsified) {
    cat("RESULT: REJECTED. Residual negative-control association was detected.\n")
  } else {
    cat("RESULT: NOT REJECTED. This is a screening result, not proof that confounding is absent.\n")
    cat("NOTE: Your effect estimate must exceed the Noise Floor (delta_bound) to be meaningful.\n")
  }
  cat("\n")
  invisible(x)
}

#' Print method for policy_bound
#'
#' @param x A policy_bound object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed summary reports the
#'   deficiency value used in the regret bound, how that value was selected,
#'   the utility range, transfer-penalty and minimax components, any observed
#'   regret supplied by the user, and the resulting interpretation on the
#'   utility scale.
#' @export
print.policy_bound <- function(x, ...) {
  cat("\n-- Policy Regret Bounds ", paste(rep("-", 49), collapse = ""), "\n\n", sep = "")
  cat("* Deficiency delta:", round(x$delta, 4), "\n")
  if (!is.null(x$delta_mode)) {
    mode_label <- if (identical(x$delta_mode, "upper")) "upper CI" else "point"
    cat("* Delta mode:", mode_label, "\n")
  }
  if (!is.null(x$delta_method) && nzchar(x$delta_method)) {
    cat("* Delta method:", x$delta_method, "\n")
  }
  if (!is.null(x$delta_selection)) {
    selection_label <- switch(
      x$delta_selection,
      explicit_method = "pre-specified method",
      single_method = "single fitted method",
      optimistic_minimum = "minimum across fitted methods",
      numeric_input = "numeric input",
      x$delta_selection
    )
    cat("* Delta selection:", selection_label, "\n")
  }
  cat("* Utility range: [", x$utility_range[1], ", ", x$utility_range[2], "]\n", sep = "")
  if (!is.null(x$policy_type)) {
    cat("* Policies:", x$policy_type, "with", x$n_actions, "actions\n")
  }
  if (!is.null(x$value_error)) {
    cat("* Value error:", round(x$value_error, 4), "(bound on |simulated - interventional| value)\n")
  }
  if (!is.null(x$transfer_penalty)) {
    cat("* Transfer penalty:", round(x$transfer_penalty, 4), "(additive regret upper bound)\n")
  } else {
    cat("* Transfer penalty:", round(x$safety_floor, 4), "(additive regret upper bound)\n")
  }
  if (!is.null(x$minimax_floor)) {
    cat("* Minimax floor:", round(x$minimax_floor, 4), "(worst-case lower bound)\n")
  }
  if (!is.null(x$complexity_penalty)) {
    cat("* Complexity penalty:", round(x$complexity_penalty, 4), "(VC / finite-sample term)\n")
  }

  if (!is.null(x$obs_regret)) {
    cat("\n* Simulated (adjusted) regret:", round(x$obs_regret, 4), "\n")
    cat("* Interventional bound:", round(x$regret_bound, 4), "\n")
  } else if (!is.null(x$complexity_penalty) && !is.null(x$regret_bound)) {
    cat("\n* Regret bound for the empirical welfare maximizer:", round(x$regret_bound, 4), "\n")
  }
  
  penalty <- if (!is.null(x$transfer_penalty)) x$transfer_penalty else x$safety_floor
  pct <- round(100 * penalty / x$M, 1)
  if (isTRUE(x$delta_is_proxy)) {
    cat("\nNote: this is a plug-in bound using a deficiency proxy rather than an identified exact deficiency.\n")
  }
  if (identical(x$delta_selection, "optimistic_minimum")) {
    cat("Note: minimum-across-methods selection is optimistic after model selection.\n")
  }
  cat("\nInterpretation: Transfer penalty is", pct, "% of utility range given delta\n\n")
  
  invisible(x)
}

#' Print method for partial_id_set
#'
#' @param x A partial_id_set object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed summary reports the
#'   target estimand, point estimate, chosen deficiency radius, resulting
#'   half-width, and the conservative identification interval implied by that
#'   radius.
#' @export
print.partial_id_set <- function(x, ...) {
  cat("\n-- Partial Identification Set ", paste(rep("-", 46), collapse = ""), "\n\n", sep = "")
  cat("* Estimand:", x$estimand, "\n")
  cat("* Point estimate:", round(x$estimate, 6), "\n")
  cat("* Delta:", round(x$delta, 6), "\n")
  cat("* Half-width:", round(x$half_width, 6), "\n")
  cat("* Interval: [", round(x$lower, 6), ", ", round(x$upper, 6), "]\n\n", sep = "")
  invisible(x)
}

#' Print method for overlap_diagnostic
#'
#' @param x An overlap_diagnostic object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed summary reports the
#'   sample size, trimming threshold, number of extreme propensity scores,
#'   number retained after trimming, IPTW effective sample size, and propensity
#'   score quantiles.
#' @export
print.overlap_diagnostic <- function(x, ...) {
  cat("\n-- Overlap Diagnostic ", paste(rep("-", 52), collapse = ""), "\n\n", sep = "")
  cat("* n:", x$n, "\n")
  cat("* trim:", x$trim, "\n")
  cat("* extreme ps count:", x$extreme_n, "\n")
  cat("* kept after trim:", x$kept_n, "\n")
  cat("* ESS (IPTW):", round(x$ess_iptw, 2), "\n")
  cat("\nPropensity quantiles:\n")
  print(round(x$ps_summary, 4))
  cat("\n")
  invisible(x)
}

#' Print method for confounding_frontier
#'
#' @param x A confounding_frontier object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed summary reports the
#'   sensitivity-grid dimensions, alpha and gamma ranges, model label, summary
#'   statistics of the deficiency surface, and the proportion of the grid with
#'   near-zero deficiency.
#' @export
print.confounding_frontier <- function(x, ...) {
  cat("\n-- Confounding Frontier (Confounding Lower Bound) ", paste(rep("-", 26), collapse = ""), "\n\n", sep = "")
  cat("* Grid size:", x$params$grid_size, "x", x$params$grid_size, "\n")
  cat("* alpha range: [", x$params$alpha_range[1], ", ", x$params$alpha_range[2], "]\n", sep = "")
  cat("* gamma range: [", x$params$gamma_range[1], ", ", x$params$gamma_range[2], "]\n", sep = "")
  cat("* Model:", x$model, "\n\n")
  
  # Summary statistics
  cat("-- Deficiency Summary --\n\n")
  cat("* Min delta:", round(min(x$grid$delta), 4), "\n")
  cat("* Max delta:", round(max(x$grid$delta), 4), "\n")
  cat("* Mean delta:", round(mean(x$grid$delta), 4), "\n\n")
  
  # Identification zone
  n_identified <- sum(x$grid$delta < 0.01)
  pct_identified <- round(100 * n_identified / nrow(x$grid), 1)
  cat(pct_identified, "% of grid has near-zero deficiency (delta < 0.01)\n\n")
  
  invisible(x)
}

#' Print method for data_audit_report
#'
#' @param x A data_audit_report object
#' @param ... Additional arguments (unused)
#'
#' @return Invisibly returns `x`, unchanged. The printed report summarizes the
#'   audited treatment/outcome pair, number of variables reviewed, number of
#'   flagged issues, a table of non-safe findings, and the recommended next
#'   actions.
#' @export
print.data_audit_report <- function(x, ...) {
  cat("\n")
  cat("==============================================================================\n")
  cat("                         Data Integrity Report\n")
  cat("==============================================================================\n\n")
  
  cat("Treatment:", x$treatment, "| Outcome:", x$outcome, "\n")
  cat("Variables audited:", x$summary_stats$n_vars_audited, "\n")
  cat("Issues found:", x$summary_stats$n_issues, "\n\n")
  
  if (nrow(x$issues) > 0) {
    # Filter to show only significant issues (not "Safe")
    significant <- x$issues[!x$issues$issue_type %in% c("Safe", "Valid Negative Control"), ]
    
    if (nrow(significant) > 0) {
      cat("-- Issues Detected ", paste(rep("-", 50), collapse = ""), "\n\n", sep = "")
      
      # Print table
      display <- data.frame(
        Variable = significant$variable,
        Type = significant$issue_type,
        `p-value` = format.pval(significant$p_value, digits = 3),
        Recommendation = significant$recommendation,
        check.names = FALSE
      )
      print(display, row.names = FALSE, right = FALSE)
      cat("\n")
    }
  }
  
  cat("-- Recommendations ", paste(rep("-", 50), collapse = ""), "\n\n", sep = "")
  for (rec in x$recommendations) {
    cat("*", rec, "\n")
  }
  cat("\n")
  
  invisible(x)
}
