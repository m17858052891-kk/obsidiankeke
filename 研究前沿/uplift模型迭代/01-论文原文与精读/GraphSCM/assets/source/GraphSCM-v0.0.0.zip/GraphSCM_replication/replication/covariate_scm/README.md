# Covariate-only SCM

See [publication instructions](../../README_R.md). Full mode now uses D1–D5 with 100 repetitions each; test mode uses one per design. The supplied 100-repetition references allow regeneration with base R alone. Beyond those references, use `input_root` with matching completed datasets and CF/ATT tables. Features are two planar coordinates and three PRE economic proxies, with pooled standardization and ridge 1e-10. D1–D8 are supported; D9/D10 are not part of this comparator.
