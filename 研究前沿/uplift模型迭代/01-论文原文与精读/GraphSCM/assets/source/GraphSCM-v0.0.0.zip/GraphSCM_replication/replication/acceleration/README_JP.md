# Rcpp版FISTA：実行手順

Graph-SCM・GeoEco-SCMのCVで繰り返すFISTAをC++で実行する追加機能です。元の目的関数、グラフ構築、CV候補、停止基準、最終OSQP推定は維持しています。元のR版も残しており、既定の実行エンジンはRです。

## 1. 準備

公開ZIPをすべて展開し、`replication/` と `data/` がある階層をRStudioの作業フォルダにします。

Rcppを導入してください。

```r
install.packages("Rcpp")
```

Windowsでは、使用するRに対応する[Rtools](https://cran.r-project.org/bin/windows/Rtools/)も必要です。RcppArmadilloは不要です。初回はC++をコンパイルし、以後はキャッシュを使います。キャッシュ先は通常のユーザー用キャッシュフォルダです。変更する場合は、実行前に `Sys.setenv(GRAPHSCM_RCPP_CACHE="D:/GraphSCM_cache")` などと指定します。

## 2. まず、軽い比較を実行する

```r
source("replication/run_from_RStudio.R")
run_replication("benchmark", designs="D1", reps="1")
```

追加パッケージはRcppとMatrixだけです。元のHドライブは不要です。元と同じ数式・seedで合成データを生成し、アーカイブされたUniformのCF・ATT指標との一致を確認してから、同じ入力に対するR版・C++版を比較します。

これは、時間方向と疑似post-onlyの代表的な検証問題を使った**FISTA部分の比較**です。全CV探索・最終OSQP・時空間ベンチマークを含むモンテカルロ全体の計時ではありません。各設定を3回ずつ計時し、中央値を使います。コンパイルとデータ生成の時間は比較から除きます。

結果は `replication/output/acceleration_benchmark/` に保存します。

| ファイル | 内容 |
|---|---|
| `speed_summary.csv` | FISTAの時間比、重み・予測値の最大差、収束回数の一致 |
| `fit_comparisons.csv` | マスク・正則化設定ごとの比較 |
| `candidate_choices.csv` | 小規模な候補集合での選択結果の一致 |
| `original_data_alignment.csv` | 生成した入力と元のUniform評価値との照合 |
| `README_results.txt` | 計測した範囲 |

複数の本文DGPを確認する場合：

```r
run_replication("benchmark", designs="D1,D3", reps="1", benchmark_repeats=3)
```

自動再生成に対応するのはD1–D8です。D9–D10は元のRDSを含む出力フォルダを `input_root` で指定してください。

## 3. 実際の推定をC++版で実行する

この段階では、元の全推定用パッケージも必要です。まず1ケースで確認します。

```r
run_replication("full", engine="Rcpp", designs="D1", reps="1",
  output_root="D:/GraphSCM_fast_check")
```

出力は `D:/GraphSCM_fast_check/full_Rcpp/` です。R版の `full/` と分けています。各ケースの `fista_execution_engine.txt` にエンジンを記録します。コンパイルに失敗した場合、R版へ黙って切り替えず停止します。既に完了したケースは従来どおりスキップします。

元のR版との比較には同じdesign・repを使います。

```r
run_replication("full", engine="R", designs="D1", reps="1",
  output_root="D:/GraphSCM_fast_check")
```

Rcpp化してもCVの反復解には浮動小数点の差が生じ得るため、使用環境での最初の確認では、選択パラメータと最終予測も比較してください。最終OSQPは従来と同じ実装です。

## 4. 反復数を増やす

既定の反復数は元の20回のままです。Graph・時空間推定器の追加反復は、明示的に指定できます。

```r
# 計画だけを確認。推定は実行しません。
run_replication("full", engine="Rcpp", designs="primary", reps="1:100",
  dry_run=TRUE, output_root="D:/GraphSCM_100rep")

# 上の計画で実際に実行する場合
run_replication("full", engine="Rcpp", designs="primary", reps="1:100",
  output_root="D:/GraphSCM_100rep")

# 完了結果を集計
run_replication("collect", engine="Rcpp", output_root="D:/GraphSCM_100rep")
```

primaryは本文の5DGPなので、100回なら計500ケースです。21回目以降も同じseed規則を延長します。1–20回目のseedは変更していません。集計は完了ファイルのある反復を読み、20回目で打ち切りません。追加反復の重み診断には `weights` でも `reps="1:100"` と指定してください。

`summary` は同梱された現在の100反復の再集計です。公開版1.4.2以降のCov-SCMは、`reps="1:100"` と `input_root="D:/GraphSCM_100rep/full_Rcpp"` を指定すると同じ保存済みデータで追加反復を実行できます。`full` はGraph・時空間推定器を対象とし、Cov-SCMは別に `covariate` で実行します。全設計をそろえる手順は[実行案内（英語）](../../README_R.md)を参照してください。

## コマンドラインから実行する場合

```sh
Rscript --vanilla replication/run.R --task=benchmark --designs=D1 --reps=1
Rscript --vanilla replication/run.R --task=full --engine=Rcpp --designs=D1 --reps=1
```

WindowsのPowerShell起動ファイルでは `-Engine Rcpp` を指定できます。

## 検証と実装の範囲

公開版1.4.1では、本番推定が正常に終わっても完了ファイルがないとして停止する不具合を修正しました。起動側が最終出力・scenario/seed・重み制約・保存済み重みから再構成したCF評価値を確認し、その後に完了ファイルを作成します。相対指定の保存先も、作業フォルダの変更に影響されない絶対パスに変換します。数値推定処理は変更していません。

修正版では本番D1・1反復の正常終了、全手法の重み保存、完了済みケースの再開時スキップも確認しました。記録は `validation/completion_integration.csv` にあります。

同梱した検証では、D1・D3の各1データセットから作った16問題で、各設定3回の中央値の合計がR版53.16秒、C++版1.12秒でした。FISTA部分で約47.5倍の高速化です。重み・PRE予測値の最大差は約4×10^-13で、収束回数と小規模候補集合での選択も一致しました。全モンテカルロが同じ倍率で速くなることを示すものではありません。

```sh
Rscript --vanilla replication/acceleration/tests/run_tests.R
```

欠測・初期値・正則化を変えた比較、単体への射影、対称疎行列の展開、収束診断、入力を変更しないこと、元の推定器へ切り替えを挿入する処理を確認します。計測結果と範囲は `validation/` に収録します。

FISTAの勾配、重み更新、射影、加速、収束判定を一つのC++呼び出し内で行います。行列積にはRと同じBLASを使います。元の数値バックエンド5ファイルは変更していません。Rcpp化による新しい全200ケースの再推定や、並列実行機能の追加は行っていません。原稿の既存数値結果も変更していません。
