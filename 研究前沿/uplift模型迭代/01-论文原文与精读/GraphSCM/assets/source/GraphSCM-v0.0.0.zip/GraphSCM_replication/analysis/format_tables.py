"""Keep tables within page bounds, with independently centered panels.

threeparttable measures a single tabular. It must not be used as the outer
container for consecutive tabular panels of different sizes.
"""
from pathlib import Path
import re


def format_table_tex(text):
    # Let TeX move a table to the next available page instead of forcing
    # several consecutive non-floating H tables into an overfull output page.
    text = text.replace(r'\begin{table}[H]', r'\begin{table}[!htbp]')
    if text.count(r'\begin{tabular}') < 2 or r'\begin{threeparttable}' not in text:
        return text
    assert text.count(r'\begin{threeparttable}') == 1
    assert text.count(r'\begin{tablenotes}') == 1
    text = text.replace(r'\begin{threeparttable}',
                        r'\begin{minipage}{\linewidth}\centering', 1)
    text, count = re.subn(
        r'\\begin\{tablenotes\}(?:\[flushleft\])?\s*\\scriptsize\s*\\item\s*',
        lambda _: r'\par\medskip{\raggedright\scriptsize\noindent ', text)
    assert count == 1
    text = text.replace(r'\end{tablenotes}', r'\par}', 1)
    text = text.replace(r'\end{threeparttable}', r'\end{minipage}', 1)
    return text


if __name__ == '__main__':
    folder = Path(__file__).resolve().parents[1] / 'tables'
    changed = []
    for path in sorted(folder.glob('*.tex')):
        old = path.read_text(encoding='utf-8')
        new = format_table_tex(old)
        if new != old:
            path.write_text(new, encoding='utf-8')
            changed.append(path.name)
    print('Table layouts corrected: ' + ', '.join(changed))
