# Full estimation is separate from the quick archived-result reproduction.
# Open GraphSCM_replication.Rproj first. Package/compiler setup: README_R.md.
# This file runs a PLAN ONLY until the last commented line is enabled.
if (!file.exists("replication/run_100_replications.R")) {
  stop("Open GraphSCM_replication.Rproj or set the working directory to the extracted project root.")
}
source("replication/run_100_replications.R")
output_root <- file.path(path.expand("~"), "GraphSCM_100rep")
run_graphscm_100(output_root=output_root, engine="Rcpp", dry_run=TRUE)

# After checking the plan and installing the documented dependencies,
# remove the first '# ' on the next line to start/resume the 1,000-case study.
# run_graphscm_100(output_root=output_root, engine="Rcpp", dry_run=FALSE)
