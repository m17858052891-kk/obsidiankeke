# Base-R reproduction of archived means, MCSEs and paired performance intervals.
summarize_archived <- function(project_root, output_root) {
  catalog <- read.csv(file.path(project_root, "replication", "design_catalog.csv"), stringsAsFactors = FALSE)
  read <- function(file) read.csv(file.path(project_root, "data", file), na.strings = c("NA", ""), stringsAsFactors = FALSE)
  cf <- rbind(read("counterfactual_replications.csv"), read("covariate_scm/covariate_CF_replications.csv"))
  att <- rbind(read("ATT_replications.csv"), read("covariate_scm/covariate_ATT_replications.csv"))
  full <- c("Graph_SCM", "GeoEco_SCM", "Covariate_SCM_geo_econ", "uniform_weights",
    "Gneiting_kriging_then_SCM", "Gneiting_kriging_EconX_then_SCM", "direct_Gneiting_kriging", "direct_Gneiting_kriging_EconX")
  summarize <- function(rows, metric) {
    rows <- rows[rows$method %in% full, ]
    groups <- split(rows, interaction(rows$scenario, rows$method, rows$obs_group, drop = TRUE))
    result <- lapply(groups, function(x) {
      values <- x[[metric]]
      if (length(values) != 100L || any(!is.finite(values)) || any(x$n_sites != x$n_eval_sites)) stop("Invalid evaluation cell.")
      data.frame(design = catalog$paper_id[match(x$scenario[1], catalog$scenario)],
        scenario = x$scenario[1], method = x$method[1], obs_group = x$obs_group[1],
        n = length(values), n_sites = x$n_sites[1], mean = mean(values), MCSE = sd(values) / sqrt(length(values)))
    })
    answer <- do.call(rbind, result); rownames(answer) <- NULL
    answer[order(match(answer$design, catalog$paper_id), answer$method, answer$obs_group), ]
  }
  cf_summary <- summarize(cf, "CF_RMSE_log")
  att_summary <- summarize(att, "ATT_RMSE_pp")
  bias_summary <- summarize(att, "ATT_mean_bias_pp")
  dir.create(output_root, recursive = TRUE, showWarnings = FALSE)
  write.csv(cf_summary, file.path(output_root, "CF_summary.csv"), row.names = FALSE)
  write.csv(att_summary, file.path(output_root, "ATT_RMSE_summary.csv"), row.names = FALSE)
  write.csv(bias_summary, file.path(output_root, "ATT_bias_summary.csv"), row.names = FALSE)
  pairs_out <- list()
  for (scenario in catalog$scenario) for (group in c("post_only", "ALL")) {
    pairs <- list(c("Graph_SCM", "GeoEco_SCM"), c("Gneiting_kriging_EconX_then_SCM", "GeoEco_SCM"))
    if (scenario %in% catalog$scenario[catalog$role == "primary"]) pairs <- c(pairs, list(c("GeoEco_SCM", "Covariate_SCM_geo_econ")))
    for (pair in pairs) for (metric in c("CF_RMSE_log", "ATT_RMSE_pp")) {
      data <- if (metric == "CF_RMSE_log") cf else att
      a <- data[data$scenario == scenario & data$obs_group == group & data$method == pair[2], ]
      b <- data[data$scenario == scenario & data$obs_group == group & data$method == pair[1], ]
      b <- b[match(a$seed, b$seed), ]
      if (nrow(a) != 100L || anyNA(b$seed) || any(a$n_eval_sites != b$n_eval_sites)) stop("Invalid paired population.")
      d <- a[[metric]] - b[[metric]]; se <- sd(d) / sqrt(100)
      pairs_out[[length(pairs_out) + 1L]] <- data.frame(
        design = catalog$paper_id[match(scenario, catalog$scenario)], scenario = scenario,
        obs_group = group, metric = metric, left = pair[2], right = pair[1], n = 100L,
        mean_difference = mean(d), MCSE = se, lower_95 = mean(d) - qt(.975, 99) * se,
        upper_95 = mean(d) + qt(.975, 99) * se)
    }
  }
  write.csv(do.call(rbind, pairs_out), file.path(output_root, "paired_differences.csv"), row.names = FALSE)
  cat("Archived summaries written to:", normalizePath(output_root, winslash = "/"), "\n")
  invisible(list(cf = cf_summary, att = att_summary))
}
