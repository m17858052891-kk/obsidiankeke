args_all <- commandArgs(trailingOnly = FALSE)
file_arg <- grep('^--file=', args_all, value = TRUE)
R_DIR <- if (length(file_arg)) normalizePath(dirname(sub('^--file=', '', file_arg[1])), winslash='/', mustWork=TRUE) else normalizePath(getwd(), winslash='/', mustWork=TRUE)
source(file.path(R_DIR, '00_config.R'))

missing <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly=TRUE)]
cat('Project root :', PROJECT_ROOT, '\n')
cat('Output root  :', OUTPUT_ROOT, '\n')
cat('R version    :', R.version.string, '\n')
cat('Scenarios    :', length(SCENARIOS_ALL), '\n')
if (length(missing)) {
  cat('Missing packages:', paste(missing, collapse=', '), '\n')
  cat('Install them before the full run. spCF and sdmTMB are not required for the published benchmark.\n')
  quit(status=2)
}
cat('Dependency check passed.\n')
