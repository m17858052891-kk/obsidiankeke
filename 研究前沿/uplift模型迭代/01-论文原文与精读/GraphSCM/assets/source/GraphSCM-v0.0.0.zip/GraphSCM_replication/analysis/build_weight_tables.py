"""Build donor-weight tables from the 100-replication saved evaluations."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from format_tables import format_table_tex
import csv,math,statistics as st
P=Path(__file__).resolve().parents[1];N=100;T99=1.9842169515086827
def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def build():
    rows=read(P/'data/weight_diagnostics/weight_replications.csv');plan=read(P/'data/study_plan.csv')
    catalog=read(P/'replication/design_catalog.csv')
    assert len(rows)==len({(r['scenario'],r['seed'],r['method'],r['obs_group']) for r in rows})==20000
    assert {(r['scenario'],r['rep'],r['seed']) for r in rows}=={(r['scenario'],r['rep'],r['seed']) for r in plan}
    cells=[]
    panel_a=[]; panel_b=[]
    for i,design in enumerate(catalog):
        groups={m:sorted((r for r in rows if r['scenario']==design['scenario'] and r['method']==m and r['obs_group']=='post_only'),key=lambda r:int(r['seed'])) for m in ['Graph_SCM','GeoEco_SCM','uniform_weights']}
        a=groups['GeoEco_SCM'];result=dict(design=design['paper_id'],scenario=design['scenario'],n_rep=N);display=[]
        for method,label in [('Graph_SCM','Graph'),('GeoEco_SCM','GeoEco'),('uniform_weights','Uniform')]:
            b=groups[method];assert len(a)==len(b)==N
            assert all(x['seed']==y['seed'] and x['data_signature']==y['data_signature'] and x['evaluated_population']==y['evaluated_population'] for x,y in zip(a,b))
            values=[float(r['mean_weight_RMSE']) for r in b];mean=st.mean(values);se=st.stdev(values)/10
            result[label+'_weight_RMSE']=mean;result[label+'_MCSE']=se
            display.append(r'\shortstack[r]{%.4f\\(%.4f)}'%(mean,se))
        for method,label in [('Graph_SCM','GeoEco_minus_Graph'),('uniform_weights','GeoEco_minus_Uniform')]:
            delta=[float(x['mean_weight_RMSE'])-float(y['mean_weight_RMSE']) for x,y in zip(a,groups[method])]
            mean=st.mean(delta);se=st.stdev(delta)/10;lo=mean-T99*se;hi=mean+T99*se
            result.update({label:mean,label+'_MCSE':se,label+'_lower_95':lo,label+'_upper_95':hi})
            display.append(r'\shortstack[r]{%.4f\\$[%.4f,\ %.4f]$}'%(mean,lo,hi))
        values=[float(r['mean_effective_donors']) for r in a]
        result['GeoEco_effective_donors']=st.mean(values);result['GeoEco_effective_donors_MCSE']=st.stdev(values)/10
        display.append(r'\shortstack[r]{%.2f\\(%.2f)}'%(st.mean(values),st.stdev(values)/10))
        if i==5:panel_a.append(r'\midrule');panel_b.append(r'\midrule')
        panel_a.append(design['paper_id']+' & '+' & '.join([display[0],display[1],display[2],display[5]])+r' \\')
        paired=[]
        for label in ['GeoEco_minus_Graph','GeoEco_minus_Uniform']:
            paired += [f"{result[label]:.4f}",f"[{result[label+'_lower_95']:.4f}, {result[label+'_upper_95']:.4f}]"]
        panel_b.append(design['paper_id']+' & '+' & '.join(paired)+r' \\');cells.append(result)
    lines=[r'\begin{table}[H]\centering',r'\caption{Post-only donor-weight recovery and concentration.}\label{tab:weight-recovery-postonly}',
      r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{4pt}',
      r'\begin{tabular}{@{}lrrrr@{}}\toprule',
      r'\multicolumn{5}{@{}l}{\textit{A. Weight recovery and concentration}}\\',
      r'DGP & \shortstack{Weight RMSE\\Graph} & \shortstack{Weight RMSE\\GeoEco} & \shortstack{Weight RMSE\\Uniform} & \shortstack{Effective donors\\GeoEco} \\\midrule']+panel_a+[
      r'\bottomrule\end{tabular}\par\medskip',r'\begin{tabular}{@{}lrrrr@{}}\toprule',
      r'\multicolumn{5}{@{}l}{\textit{B. Paired weight-RMSE differences}}\\',
      r' & \multicolumn{2}{c}{GeoEco $-$ Graph} & \multicolumn{2}{c}{GeoEco $-$ Uniform} \\',
      r'DGP & Difference & 95\% MC interval & Difference & 95\% MC interval \\\midrule']+panel_b+[
      r'\bottomrule\end{tabular}',r'\begin{tablenotes}[flushleft]\scriptsize\item Each DGP uses 100 replications and 24 post-only targets per replication. Parentheses in panel A contain Monte Carlo standard errors. Panel B gives paired means and 95\% MC intervals; negative differences favor GeoEco. Effective donors are averaged over targets and replications; Uniform has 24. D1--D5 are primary and D6--D10 supplementary.',r'\end{tablenotes}\end{threeparttable}\end{table}']
    (P/'tables/weight_recovery_postonly.tex').write_text(format_table_tex('\n'.join(lines)+'\n'),encoding='utf-8')
    with (P/'data/weight_diagnostics/post_only_table_values.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(cells[0]));w.writeheader();w.writerows(cells)
    print('Weight table rebuilt: 1000 datasets; Graph, GeoEco and Uniform.')
if __name__=='__main__':build()
