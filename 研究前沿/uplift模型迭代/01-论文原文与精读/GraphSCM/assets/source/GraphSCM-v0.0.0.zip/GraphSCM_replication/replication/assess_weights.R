# Read saved weights/diagnostics only. This entry point never estimates a model.
entry <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
replication_root <- dirname(normalizePath(entry, winslash = "/", mustWork = TRUE))
source(file.path(replication_root, "weight_diagnostics", "R", "core.R"))
source(file.path(replication_root, "weight_diagnostics", "R", "io.R"))
args <- list()
for (arg in commandArgs(TRUE)) {
  if (arg == "--dry-run") { args$dry_run <- TRUE; next }
  if (!grepl("^--(input-root|output-root|designs|reps)=", arg)) stop("Unknown argument: ", arg)
  cut <- regexpr("=", arg, fixed = TRUE)[1]
  name <- substr(arg, 3, cut - 1L)
  if (!is.null(args[[name]])) stop("Repeated argument: ", name)
  args[[name]] <- substring(arg, cut + 1L)
}
catalog <- utils::read.csv(file.path(replication_root, "design_catalog.csv"), stringsAsFactors = FALSE)
if (is.null(args[["input-root"]])) stop("Supply --input-root pointing to saved simulation output; no fits will be rerun.")
input <- normalizePath(args[["input-root"]], winslash = "/", mustWork = TRUE)
if (!dir.exists(input)) stop("The input root must be a directory.")
designs <- if (is.null(args$designs) || args$designs == "all") catalog$paper_id else
  if (args$designs == "primary") catalog$paper_id[catalog$role == "primary"] else strsplit(args$designs, ",", fixed = TRUE)[[1]]
if (!length(designs) || anyDuplicated(designs) || any(!designs %in% catalog$paper_id)) stop("Select current D1-D10, primary, or all.")
rep_text <- if (is.null(args$reps)) "1:20" else args$reps
if (grepl("^[0-9]+:[0-9]+$", rep_text)) {
  bounds <- as.integer(strsplit(rep_text, ":", fixed = TRUE)[[1]])
  if (anyNA(bounds) || any(bounds<1L | bounds>10000L)) stop("Replication range must be within 1-10000.")
  reps <- seq.int(bounds[1], bounds[2])
} else if (grepl("^[0-9]+(,[0-9]+)*$", rep_text)) {
  reps <- as.integer(strsplit(rep_text, ",", fixed = TRUE)[[1]])
} else stop("Use replication numbers, a comma list, or 1:20.")
if (anyNA(reps) || anyDuplicated(reps) || any(reps < 1 | reps > 10000)) stop("Replication IDs must be 1-10000; archived defaults remain 1-20.")
selected <- catalog[catalog$paper_id %in% designs, , drop = FALSE]
snapshots <- list.files(input, "^weight_assessment[.]rds$", recursive = TRUE, full.names = TRUE)
legacy <- list.files(input, "^(joint_scm_weights|simulation_weight_recovery_by_site)[.]csv$", recursive = TRUE, full.names = TRUE)
legacy_dirs <- setdiff(unique(dirname(legacy)), dirname(snapshots))
sources <- c(snapshots, legacy_dirs)
if (!length(sources)) stop("No saved weight snapshots or legacy weight files found. Point --input-root to original simulation output, not the manuscript's evaluation CSV folder.")
audit <- list(); sites <- list()
for (path in sources) {
  result <- tryCatch({
    if (file.exists(path) && !dir.exists(path)) {
      case <- readRDS(path)
      if (!identical(case$schema, "graphscm_weight_case_v1")) stop("Unknown weight snapshot schema.")
      expected <- wd_case_metadata(case$metadata$scenario, case$metadata$seed, catalog)
      if (as.integer(case$metadata$rep) != expected$rep) stop("Snapshot replication/seed mismatch.")
      case$metadata$paper_id <- expected$paper_id
      list(sites = wd_evaluate(case), kind = "weight_snapshot", methods = names(case$estimates))
    } else wd_read_legacy(path, catalog)
  }, error = function(e) structure(list(message = conditionMessage(e)), class = "weight_input_error"))
  if (inherits(result, "weight_input_error")) {
    audit[[length(audit) + 1L]] <- data.frame(source = path, status = "invalid_input", detail = result$message)
    next
  }
  x <- result$sites
  if (!x$scenario[1] %in% selected$scenario || !x$rep[1] %in% reps) {
    audit[[length(audit) + 1L]] <- data.frame(source = path, status = "outside_selection", detail = result$kind)
    next
  }
  x$source <- path
  sites[[length(sites) + 1L]] <- x
  audit[[length(audit) + 1L]] <- data.frame(source = path, status = "loaded", detail = result$kind)
}
audit <- do.call(rbind, audit)
if (!length(sites)) {
  print(audit)
  stop("No usable cases in the requested selection; no estimates were rerun.")
}
sites <- do.call(rbind, sites)
# Do not silently combine conflicting copies of the same case/method/site.
id <- do.call(paste, c(lapply(sites[c("study_id", "scenario", "seed", "method", "point_id", "n_target",
  "n_donor", "n_pre_periods", "n_post_periods")], as.character), sep = "|"))
keep <- rep(TRUE, nrow(sites))
for (positions in split(seq_len(nrow(sites)), id)) if (length(positions) > 1L) {
  richer <- positions[which.max(nzchar(sites$data_signature[positions]))]
  for (other in setdiff(positions, richer)) {
    if (!identical(sites$obs_group[richer], sites$obs_group[other]) ||
        !identical(sites$evaluated[richer], sites$evaluated[other]))
      stop("Conflicting population/coverage copies; select one source version: ", id[richer])
    for (field in c("weight_RMSE", "weight_L1", "weight_cosine")) {
      a <- sites[[field]][richer]; b <- sites[[field]][other]
      if (!(is.na(a) && is.na(b)) && (!is.finite(a) || !is.finite(b) || abs(a-b) > 1e-10))
        stop("Conflicting saved weight results; select one source version: ", id[richer])
    }
    if (nzchar(sites$data_signature[richer]) && nzchar(sites$data_signature[other]) &&
        sites$data_signature[richer] != sites$data_signature[other])
      stop("Input data versions differ: ", id[richer])
    keep[other] <- FALSE
  }
}
sites <- sites[keep, , drop = FALSE]
replications <- wd_replications(sites)
summary <- wd_summary(replications)
paired <- wd_paired(replications)
coverage <- list(); k <- 0L
methods <- union(c("GeoEco_SCM", "Graph_SCM", "Ordinary_SCM", "uniform_weights"), unique(sites$method))
for (i in seq_len(nrow(selected))) for (rep in reps) for (method in methods) {
  seed <- selected$seed_base[i] + rep
  z <- replications[replications$scenario == selected$scenario[i] & replications$seed == seed &
    replications$method == method & replications$obs_group == "ALL", , drop = FALSE]
  present <- any(sites$scenario == selected$scenario[i] & sites$seed == seed)
  status <- if (!nrow(z)) if (present) "method_weights_not_saved" else "case_not_found" else
    if (z$n_eval_sites[1] == z$n_sites[1]) "complete" else "partial_scientific_coverage"
  k <- k + 1L; coverage[[k]] <- data.frame(design = selected$paper_id[i], scenario = selected$scenario[i],
    rep = rep, seed = seed, method = method, status = status,
    n_sites = if (nrow(z)) z$n_sites[1] else NA_integer_,
    n_eval_sites = if (nrow(z)) z$n_eval_sites[1] else NA_integer_)
}
coverage <- do.call(rbind, coverage)
if (isTRUE(args$dry_run)) {
  print(table(coverage$status)); cat("Read-only scan completed; no models were fitted and no files written.\n")
  quit(status = 0L)
}
output <- if (is.null(args[["output-root"]])) file.path(replication_root, "output", "weights") else args[["output-root"]]
dir.create(output, recursive = TRUE, showWarnings = FALSE)
write <- function(value, name) utils::write.csv(value, file.path(output, name), row.names = FALSE, na = "")
write(sites, "weight_by_site.csv"); write(replications, "weight_replications.csv")
write(summary, "weight_summary.csv"); write(paired, "paired_weight_differences.csv")
write(coverage, "weight_coverage_audit.csv"); write(audit, "weight_input_audit.csv")
writeLines(c(
  "Saved-output weight diagnostics; no model estimation was executed.",
  "Primary weight summary: average of site-specific donor-weight RMSEs, then average over datasets.",
  "pooled_weight_RMSE is a different statistic: sqrt(mean squared weight error across sites and donors).",
  "MCSEs and paired t intervals use independent datasets/seed pairs, not individual target rows.",
  "Paired comparisons require matching input-data fingerprints and the exact same evaluated target IDs.",
  "Ordinary SCM post-only rows are not estimable and remain missing. Its ALL row covers PRE-observed targets only.",
  "effective_donors/max_weight describe concentration across donors, not estimator variance across repetitions.",
  "The publication changes truth and locations across replications. Raw weight variance is therefore not conditional estimator variance.",
  "Legacy diagnostic-only inputs have no verified cross-method data signature and do not enter paired intervals.",
  "Inspect coverage and input audits: missing Graph/Ordinary weights are not reconstructed from outcome predictions.",
  "Weight accuracy is secondary to counterfactual prediction because donor weights can be nonunique."
), file.path(output, "README_results.txt"))
writeLines(capture.output(utils::sessionInfo()), file.path(output, "sessionInfo.txt"))
cat("Weight diagnostics written to:", normalizePath(output, winslash = "/"), "\n")
cat("Loaded", length(unique(paste(sites$scenario, sites$seed))), "case(s); no model was rerun.\n")
if (any(audit$status == "invalid_input")) warning("Some inputs were rejected; inspect weight_input_audit.csv.")
