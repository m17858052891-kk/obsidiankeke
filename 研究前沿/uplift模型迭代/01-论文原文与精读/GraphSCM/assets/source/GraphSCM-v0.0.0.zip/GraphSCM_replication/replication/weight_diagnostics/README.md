# Saved donor-weight diagnostics

See [publication instructions](../../README_R.md). The supplied archive contains all 1,000 cases, 100 per DGP, and four methods: Graph-SCM, GeoEco-SCM, ordinary SCM and Uniform. Ordinary SCM has no post-only weights. Run `summary` to reproduce the supplied results without fitting; run `weights` with an explicit input root and repetition selection to evaluate raw saved snapshots. MC intervals pair datasets and identical target populations. Effective donor counts are concentration measures.
