"""Reaggregate existing evaluations; no estimator or Monte Carlo run is executed."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from format_tables import format_table_tex
from collections import defaultdict
import csv, math, statistics, json

P=Path(__file__).resolve().parents[1] if Path(__file__).parent.name=='analysis' else Path(__file__).resolve().parents[2]/'outputs/spatialstat_revised'
with (P/'replication/design_catalog.csv').open(encoding='utf-8',newline='') as f:
    DESIGN_CATALOG=list(csv.DictReader(f))
SC=[r['scenario'] for r in DESIGN_CATALOG]
CODES={r['scenario']:r['paper_id'] for r in DESIGN_CATALOG}
METHODS=['Graph_SCM','GeoEco_SCM','uniform_weights','Gneiting_kriging_then_SCM','Gneiting_kriging_EconX_then_SCM','direct_Gneiting_kriging','direct_Gneiting_kriging_EconX']
NAMES=dict(zip(METHODS,['Graph','GeoEco','Uniform','STI','STI-X','STD','STD-X']))
ORD='Ordinary_SCM'
T99=1.9842169515086827
def read(name):
    with (P/'data'/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def save_csv(name,rows):
    with (P/'data'/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def write(name,lines):
    (P/'tables'/name).write_text(format_table_tex('\n'.join(lines)+'\n'),encoding='utf-8')
cf=read('counterfactual_replications.csv');att=read('ATT_replications.csv')
ordinary={r['method'] for r in cf if r['method'] not in METHODS}
assert len(ordinary)==1,ordinary
ORD=ordinary.pop();NAMES[ORD]='Ordinary SCM'
def summarize(rows,metric):
    g=defaultdict(list)
    for r in rows:
        try:v=float(r[metric])
        except (ValueError,KeyError):continue
        if math.isfinite(v):g[(r['scenario'],r['method'],r['obs_group'])].append(v)
    return {k:(statistics.mean(v),statistics.stdev(v)/math.sqrt(len(v)),len(v)) for k,v in g.items()}
cs=summarize(cf,'CF_RMSE_log');ar=summarize(att,'ATT_RMSE_pp');ab=summarize(att,'ATT_mean_bias_pp')
save_csv('CF_summary.csv',[dict(scenario=k[0],method=k[1],obs_group=k[2],mean=v[0],mcse=v[1],n=v[2]) for k,v in cs.items()])
save_csv('ATT_summary.csv',[dict(scenario=k[0],method=k[1],obs_group=k[2],mean_RMSE=v[0],mcse_RMSE=v[1],n=v[2],mean_bias=ab[k][0],mcse_bias=ab[k][1]) for k,v in ar.items()])
legend='Graph/GeoEco: graph estimators; Uniform: equal donor weights; STI: spatio-temporal PRE imputation followed by SCM; STD: direct spatio-temporal prediction; -X: PRE economic covariates.'
def cf_table(name,group,methods,caption,label,placement='!t'):
    lines=[r'\begin{table}['+placement+r']\centering',r'\caption{'+caption+r'}\label{'+label+'}',r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{3pt}',r'\begin{tabular}{@{}l'+'r'*len(methods)+r'@{}}\toprule','DGP & '+' & '.join(NAMES[m] for m in methods)+r' \\\midrule']
    for sc in SC:
        vals=[]
        for m in methods:
            v=cs[(sc,m,group)];assert v[2]==100
            vals.append(r'\shortstack[r]{%.4f\\(%.4f)}'%(v[0],v[1]))
        lines.append(CODES[sc]+' & '+' & '.join(vals)+r' \\')
    lines += [r'\bottomrule\end{tabular}',r'\begin{tablenotes}[flushleft]\scriptsize\item Means of replication-specific latent-signal RMSEs across 100 replications. Parentheses contain Monte Carlo standard errors. Lower is better. '+legend+(r' Ordinary SCM is evaluated on the same PRE-observed group only.' if ORD in methods else ''),r'\end{tablenotes}\end{threeparttable}\end{table}']
    write(name,lines)
cf_table('all_existing.tex','ALL',METHODS,'All-target counterfactual signal RMSE and Monte Carlo standard errors.','tab:s_all')
cf_table('postonly_existing.tex','post_only',METHODS,'Post-only counterfactual signal RMSE and Monte Carlo standard errors.','tab:postonly')
cf_table('cf_complete_existing.tex','complete_pre',METHODS+[ORD],'Complete-PRE counterfactual signal RMSE and Monte Carlo standard errors.','tab:cf-complete-existing','H')
cf_table('cf_partial_existing.tex','partial_pre',METHODS+[ORD],'Partial-PRE counterfactual signal RMSE and Monte Carlo standard errors.','tab:cf-partial-existing','H')

ordinary_rows=[]
for sc in SC:
    c=cs[(sc,ORD,'ALL')];a=ar[(sc,ORD,'ALL')];b=ab[(sc,ORD,'ALL')]
    ordinary_rows.append(dict(scenario=sc,design=CODES[sc],population='96 PRE-observed targets; excludes 24 post-only targets',CF_RMSE=c[0],CF_RMSE_MCSE=c[1],ATT_RMSE_pp=a[0],ATT_RMSE_MCSE=a[1],ATT_bias_pp=b[0],ATT_bias_MCSE=b[1],n=100))
save_csv('Ordinary_SCM_covered_population.csv',ordinary_rows)
lines=[r'\begin{table}[H]\centering\caption{Ordinary SCM on its PRE-observed population.}\label{tab:ordinary-covered}',r'\begin{threeparttable}\footnotesize\begin{tabular}{@{}lrrr@{}}\toprule',r'DGP & CF RMSE & ATT RMSE (pp) & ATT bias (pp) \\\midrule']
for r in ordinary_rows:
    vals=[r'\shortstack[r]{%.4f\\(%.4f)}'%(r['CF_RMSE'],r['CF_RMSE_MCSE']),r'\shortstack[r]{%.3f\\(%.3f)}'%(r['ATT_RMSE_pp'],r['ATT_RMSE_MCSE']),r'\shortstack[r]{%.3f\\(%.3f)}'%(r['ATT_bias_pp'],r['ATT_bias_MCSE'])]
    lines.append(r['design']+' & '+' & '.join(vals)+r' \\')
lines += [r'\bottomrule\end{tabular}\begin{tablenotes}[flushleft]\scriptsize\item Each evaluation covers the 96 targets with any PRE history, not all 120 targets. Means over 100 replications; parentheses contain Monte Carlo standard errors. These entries are not an all-target ranking. ATT errors refer to the PRE-observed estimand.\end{tablenotes}\end{threeparttable}\end{table}']
write('ordinary_covered_existing.tex',lines)

pairs=[]
for sc in SC:
    for group in ['ALL','post_only']:
        for left,right in [('GeoEco_SCM','Graph_SCM'),('GeoEco_SCM','Gneiting_kriging_EconX_then_SCM')]:
            a={int(r['seed']):float(r['CF_RMSE_log']) for r in cf if (r['scenario'],r['method'],r['obs_group'])==(sc,left,group)}
            b={int(r['seed']):float(r['CF_RMSE_log']) for r in cf if (r['scenario'],r['method'],r['obs_group'])==(sc,right,group)}
            assert a.keys()==b.keys() and len(a)==100
            d=[a[k]-b[k] for k in sorted(a)];mu=statistics.mean(d);se=statistics.stdev(d)/math.sqrt(100)
            pairs.append(dict(scenario=sc,design=CODES[sc],obs_group=group,left=left,right=right,mean_diff=mu,mcse=se,ci_lo=mu-T99*se,ci_hi=mu+T99*se,n=100))
save_csv('paired_CF_differences.csv',pairs)
for group,name,label in [('post_only','paired_existing.tex','tab:paired-existing'),('ALL','paired_all_existing.tex','tab:paired-all-existing')]:
    lines=[r'\begin{table}['+('!t' if group=='post_only' else 'H')+r']\centering',r'\caption{Paired differences in mean signal RMSE: '+group.replace('_',' ')+r'.}\label{'+label+'}',r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{5pt}',r'\begin{tabular}{@{}lrrrr@{}}\toprule',r' & \multicolumn{2}{c}{GeoEco $-$ Graph} & \multicolumn{2}{c}{GeoEco $-$ STI-X} \\',r'DGP & Mean difference & 95\% MC interval & Mean difference & 95\% MC interval \\\midrule']
    for sc in SC:
        vals=[]
        for right in ['Graph_SCM','Gneiting_kriging_EconX_then_SCM']:
            x=next(r for r in pairs if (r['scenario'],r['obs_group'],r['right'])==(sc,group,right))
            vals += [f"{x['mean_diff']:.4f}",f"[{x['ci_lo']:.4f}, {x['ci_hi']:.4f}]"]
        lines.append(CODES[sc]+' & '+' & '.join(vals)+r' \\')
    lines += [r'\bottomrule\end{tabular}\begin{tablenotes}[flushleft]\scriptsize\item Negative differences favor GeoEco. Intervals are unadjusted paired $t_{99}$ Monte Carlo intervals over 100 datasets. They quantify uncertainty in average simulation performance and are not treatment-effect confidence intervals.\end{tablenotes}\end{threeparttable}\end{table}']
    write(name,lines)

def att_table(name,group,label,placement='H'):
    # Two vertical panels preserve legibility without shrinking a fourteen-column table.
    lines=[r'\begin{table}['+placement+r']\centering',r'\caption{ATT recovery: '+('all targets' if group=='ALL' else 'post-only targets')+r'.}\label{'+label+'}',r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{3pt}']
    for title,methods in [('A. Graph methods and uniform weights',METHODS[:3]),('B. Spatio-temporal benchmarks',METHODS[3:])]:
        lines += [r'\begin{tabular}{@{}l'+'rr'*len(methods)+r'@{}}\toprule',r'\multicolumn{'+str(1+2*len(methods))+r'}{@{}l}{\textit{'+title+r'}}\\', 'DGP & '+' & '.join(r'\multicolumn{2}{c}{'+NAMES[m]+'}' for m in methods)+r' \\', ' & '+' & '.join(['RMSE & Bias']*len(methods))+r' \\\midrule']
        for sc in SC:
            vals=[]
            for m in methods:
                k=(sc,m,group);assert ar[k][2]==100
                vals += [f'{ar[k][0]:.3f}',f'{ab[k][0]:.3f}']
            lines.append(CODES[sc]+' & '+' & '.join(vals)+r' \\')
        lines += [r'\bottomrule\end{tabular}',r'\par\medskip']
    lines += [r'\begin{tablenotes}[flushleft]\scriptsize\item Percentage points, averaged across 100 replications. Each replication evaluates annual errors over 2005--2015. ATT is $100\{\exp(\overline\tau_t)-1\}$, the percentage transformation of the mean log effect. Bias is estimated minus true ATT. All methods evaluate the same indicated target group. Monte Carlo standard errors are given in the Online Appendix. '+legend,r'\end{tablenotes}\end{threeparttable}\end{table}']
    write(name,lines)
att_table('att_existing_main.tex','ALL','tab:att-existing','!t')
att_table('att_post_existing.tex','post_only','tab:att-post-existing')
for g,n in [('ALL','all'),('post_only','post')]:
    lines=[r'\begin{table}[H]\centering\caption{ATT RMSE and Monte Carlo standard errors: '+g.replace('_',' ')+r'.}\label{tab:att-mcse-'+n+'}',r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{3pt}',r'\begin{tabular}{@{}lrrrrrrr@{}}\toprule','DGP & '+' & '.join(NAMES[m] for m in METHODS)+r' \\\midrule']
    for sc in SC:
        vals=[r'\shortstack[r]{%.3f\\(%.3f)}'%(ar[(sc,m,g)][0],ar[(sc,m,g)][1]) for m in METHODS]
        lines.append(CODES[sc]+' & '+' & '.join(vals)+r' \\')
    lines += [r'\bottomrule\end{tabular}\begin{tablenotes}[flushleft]\scriptsize\item Percentage points. Parentheses contain Monte Carlo standard errors over 100 replication-specific annual ATT RMSEs. These are not standard errors for an empirical treatment effect.\end{tablenotes}\end{threeparttable}\end{table}']
    write('att_mcse_'+n+'_existing.tex',lines)

selection=read('selection_bias.csv')
lines=[r'\begin{table}[!t]\centering\caption{How selective post-only coverage changes the estimand.}\label{tab:selection}',r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{3pt}',r'\begin{tabular}{@{}lrrrrrr@{}}\toprule',r'DGP & \shortstack{True ALL\\ATT} & \shortstack{True PRE\\ATT} & \shortstack{True post-only\\ATT} & \shortstack{Ordinary SCM\\estimate} & \shortstack{Bias vs. PRE\\estimand} & \shortstack{Bias vs. ALL\\estimand} \\\midrule']
for code,r in zip(['D6','D3'],selection):
    lines.append(code+' & '+' & '.join(f'{float(r[k]):.2f}' for k in ['true_all','true_pre','true_post','ordinary','bias_pre','bias_all'])+r' \\')
lines += [r'\bottomrule\end{tabular}\begin{tablenotes}[flushleft]\scriptsize\item Percentage points, averaged over POST years and 100 replications. Ordinary SCM estimates the effect for the 96 PRE-observed targets (60 complete-PRE plus 36 partial-PRE). Comparing that estimate with the all-target truth mixes estimation error with a change of population. As a separate summary for the later POST years 2010--2015, after the five-year treatment-effect ramp-up, the corresponding true-ATT population gaps are @D6@\% in D6 and @D3@\% in D3.\end{tablenotes}\end{threeparttable}\end{table}']
lines = [line.replace("@D6@", format(float(selection[0]["mature_under_pct"]), ".1f")).replace("@D3@", format(float(selection[1]["mature_under_pct"]), ".1f")) for line in lines]
write('selection_existing.tex',lines)

beta=read('beta_selection_frequency.csv')
lines=[r'\begin{table}[H]\centering\caption{Selected economic attenuation across 100 replications.}\label{tab:beta-existing}',r'\begin{tabular}{@{}lrrr@{}}\toprule',r'DGP & $\beta=0$ count & Median $\beta$ & Range \\\midrule']
for sc in SC:
    vals=[float(r['beta_econ']) for r in beta if r['scenario']==sc for _ in range(int(r['n']))];assert len(vals)==100
    lines.append(CODES[sc]+f' & {sum(x==0 for x in vals)}/100 & {statistics.median(vals):g} & {min(vals):g}--{max(vals):g}'+r' \\')
lines += [r'\bottomrule\end{tabular}\end{table}'];write('beta_existing.tex',lines)
local=read('local_paired_contrast.csv')
lines=[r'\begin{table}[H]\centering\caption{Change in the GeoEco-minus-Graph RMSE difference under local misalignment.}\label{tab:local-existing}',r'\begin{threeparttable}\footnotesize\begin{tabular}{@{}lrrr@{}}\toprule',r'Group & Mean change & MCSE & 95\% MC interval \\\midrule']
for r in local:
    lines.append(r['obs_group'].replace('_',' ')+f" & {float(r['mean_change']):.5f} & {float(r['mcse']):.5f} & [{float(r['ci_lo']):.5f}, {float(r['ci_hi']):.5f}]"+r' \\')
lines += [r'\bottomrule\end{tabular}\begin{tablenotes}[flushleft]\scriptsize\item D10 minus D9, paired by seed. Intervals concern mean performance changes and are not treatment-effect intervals.\end{tablenotes}\end{threeparttable}\end{table}'];write('local_existing.tex',lines)

audit={'designs':CODES,'CF_rows':len(cf),'ATT_rows':len(att),'full_coverage_methods':METHODS,'replications_per_design':100,'paired_comparisons':len(pairs),'all_reported_CF_cells_n100':all(v[2]==100 for v in cs.values()),'all_reported_ATT_cells_n100':all(v[2]==100 for v in ar.values()),'additional_estimation_executed_for_revision':False}
(P/'data/build_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(json.dumps(audit,ensure_ascii=False))

# Add the primary five-design comparison, including the completed Cov-SCM run.
import runpy
runpy.run_path(str(P/'analysis/build_five_design_tables.py'), run_name='__main__')
runpy.run_path(str(P/'analysis/build_weight_tables.py'), run_name='__main__')
