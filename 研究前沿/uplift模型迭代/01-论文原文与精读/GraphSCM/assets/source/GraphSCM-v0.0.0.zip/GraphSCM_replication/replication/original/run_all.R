# Full estimator reproduction. --dry-run writes the plan without fitting models.
entry <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
CODE_ROOT <- dirname(normalizePath(entry, winslash = "/", mustWork = TRUE))
source(file.path(CODE_ROOT, "R", "00_config.R"))
args <- commandArgs(TRUE)
value <- function(option) {
  hits <- grep(paste0("^--", option, "="), args, value = TRUE)
  if (length(hits) > 1L) stop("Repeated option: ", option)
  if (length(hits)) sub(paste0("^--", option, "="), "", hits) else NULL
}
scenes <- value("scenario")
scenarios <- if (is.null(scenes)) SCENARIOS_ALL else scenario_for(strsplit(scenes, ",", fixed = TRUE)[[1]])
rep_text <- value("rep")
reps <- if (!is.null(rep_text)) as.integer(strsplit(rep_text, ",", fixed = TRUE)[[1]]) else
  if ("--test" %in% args) 1L else seq_len(N_REPS_DEFAULT)
if (anyNA(reps) || any(reps < 1L | reps > N_REPS_MAX) || anyDuplicated(reps)) stop("Invalid replication IDs.")
plan <- do.call(rbind, lapply(scenarios, function(sc) data.frame(
  design = DESIGN_CATALOG$paper_id[match(sc, SCENARIOS_ALL)], scenario = sc,
  rep = reps, seed = vapply(reps, function(r) seed_for(sc, r), integer(1)))))
utils::write.csv(plan, file.path(OUTPUT_ROOT, "run_plan.csv"), row.names = FALSE)
if ("--dry-run" %in% args) {
  print(utils::head(plan, 12), row.names = FALSE)
  cat("Plan only:", nrow(plan), "cases. No generator or estimator was executed.\n")
  quit(status = 0)
}
missing <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
engine <- Sys.getenv("GRAPHSCM_ENGINE",unset="R")
if (!engine %in% c("R","Rcpp")) stop("Choose GRAPHSCM_ENGINE=R or Rcpp.")
if (engine=="Rcpp" && !requireNamespace("Rcpp",quietly=TRUE)) missing <- c(missing,"Rcpp")
if (length(missing)) stop("Install full-estimator dependencies first: ", paste(missing, collapse = ", "),
  "\nArchived summaries and Cov-SCM need no extra packages; see the publication README.")
if (engine=="Rcpp") {
  source(file.path(PROJECT_ROOT,"acceleration/R/backend.R"))
  scm_load_rcpp()
}
rscript <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
runner <- file.path(CODE_ROOT, "R", "02_run_one.R")
status <- vector("list", nrow(plan))
for (i in seq_len(nrow(plan))) {
  cat(sprintf("\n[%d/%d] %s %s rep %d\n", i, nrow(plan), plan$design[i], plan$scenario[i], plan$rep[i]))
  code <- system2(rscript, c("--vanilla", shQuote(runner), shQuote(plan$scenario[i]), as.character(plan$rep[i])))
  status[[i]] <- cbind(plan[i, ], exit_status = code)
  if (code != 0L) stop("Run failed: ", plan$design[i], " rep ", plan$rep[i])
}
utils::write.csv(do.call(rbind, status), file.path(OUTPUT_ROOT, "run_status.csv"), row.names = FALSE)
cat("All requested full-estimator runs completed.\n")
