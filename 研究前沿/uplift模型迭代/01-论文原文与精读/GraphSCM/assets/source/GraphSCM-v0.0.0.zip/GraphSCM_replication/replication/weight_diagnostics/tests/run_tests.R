entry <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
root <- dirname(dirname(normalizePath(entry, winslash = "/", mustWork = TRUE)))
replication <- dirname(root)
source(file.path(root, "R", "core.R")); source(file.path(root, "R", "io.R"))
catalog <- utils::read.csv(file.path(replication, "design_catalog.csv"), stringsAsFactors = FALSE)
near <- function(a,b,tol=1e-12) stopifnot(isTRUE(all.equal(as.numeric(a),as.numeric(b),tolerance=tol)))
fails <- function(expr,pattern=NULL) {
  error <- tryCatch({ force(expr); NULL }, error=function(e)e)
  stopifnot(inherits(error,"error"))
  if (!is.null(pattern)) stopifnot(grepl(pattern,conditionMessage(error),fixed=TRUE))
}
truth <- matrix(c(1,0,.25,.75),2,2,byrow=TRUE,dimnames=list(c("T1","T2"),c("C1","C2")))
estimate <- matrix(.5,2,2,dimnames=dimnames(truth))
case <- wd_case(list(scenario=catalog$scenario[1],seed=catalog$seed_base[1]+1L,rep=1),truth,
  c(T1="complete_pre",T2="post_only"),list(GeoEco_SCM=estimate,Ordinary_SCM=estimate))
site <- wd_evaluate(case); rep <- wd_replications(site)
geo <- rep[rep$method=="GeoEco_SCM" & rep$obs_group=="ALL",]
near(geo$mean_weight_RMSE,.375); near(geo$pooled_weight_RMSE,sqrt(.15625))
near(geo$mean_weight_L1,.75); near(geo$mean_effective_donors,2)
ordinary <- site[site$method=="Ordinary_SCM" & site$obs_group=="post_only",]
stopifnot(!ordinary$evaluated,is.na(ordinary$weight_RMSE))
reshuffled <- wd_case(case$metadata,truth[2:1,2:1],case$groups[2:1],
  list(GeoEco_SCM=estimate[2:1,2:1]))
near(wd_evaluate(reshuffled)$weight_RMSE,c(.5,.25))
bad <- estimate;colnames(bad)[1]<-"wrong"
fails(wd_case(case$metadata,truth,case$groups,list(GeoEco_SCM=bad)),"IDs")
bad <- estimate;bad[1,]<-c(-.1,1.1)
fails(wd_case(case$metadata,truth,case$groups,list(GeoEco_SCM=bad)),"simplex")

make_fixture <- function(rep=1L,delta=.05) {
  tids<-paste0("T",1:3);dids<-paste0("C",1:2);years<-2003:2005
  attrs<-function(ids) data.frame(point_id=ids,X_m=seq_along(ids)*10,Y_m=seq_along(ids)*20,
    pre_employment_density_z=seq_along(ids),pre_commercial_share_z=-seq_along(ids),
    pre_income_z=seq_along(ids)/2,stringsAsFactors=FALSE)
  meta<-attrs(tids);meta$obs_group<-c("complete_pre","partial_pre","post_only")
  donor<-matrix(c(1,1.5,2,2,2.5,3),2,3,byrow=TRUE,dimnames=list(dids,as.character(years)))
  observed<-rbind(c(1.5,2,2.5),c(1.5,NA,2.5),c(NA,NA,2.5))
  rownames(observed)<-tids;colnames(observed)<-as.character(years)
  points<-meta["point_id"]
  for(k in seq_along(years)) points[[paste0("price_",years[k])]]<-exp(observed[,k])
  all_points<-rbind(attrs(dids),attrs(tids))
  for(k in seq_along(years)) all_points[[paste0("price_",years[k])]]<-c(exp(donor[,k]),exp(observed[,k]))
  true<-matrix(.5,3,2,dimnames=list(tids,dids))
  obj<-list(config=list(years=years,period_pre=2003:2004,period_post=2005L,scenario=catalog$scenario[1]),
    target_meta=meta,target_points=points,all_points=all_points,
    simulation_truth=list(scenario=catalog$scenario[1],seed=catalog$seed_base[1]+rep,W_true=true,control_log=donor))
  data<-wd_original_data(obj)
  weights<-true;weights[,1]<-.5+delta;weights[,2]<-.5-delta
  env<-new.env(parent=baseenv());env$dataset<-obj;env$target_meta<-meta;env$control_df<-attrs(dids)
  env$post_pos_truth<-3L;env$W_hat<-true;env$geo_only_fit<-list(W=weights)
  env$fit_lambda0<-list(W=weights);env$Y0_raw<-matrix(1,3,3)
  env$Y0_geo_only<-matrix(1,3,3);env$Y0_lambda0<-matrix(1,3,3);env$Y0_lambda0[3,]<-NA_real_
  env$best_lambda<-.1;env$best_beta<-1
  list(obj=obj,data=data,env=env,weights=weights)
}
bad_data<-make_fixture()$obj
bad_data$all_points$price_2003[1]<-bad_data$all_points$price_2003[1]*2
fails(wd_original_data(bad_data),"Observed donor PRE prices and simulation truth disagree")
scratch<-file.path(tempdir(),"重みの確認 with spaces")
dir.create(scratch,recursive=TRUE,showWarnings=FALSE)
snapshots<-list()
for(r in 1:3) {
  f<-make_fixture(r,.05*r)
  destination<-file.path(scratch,"new",paste0("seed_",f$data$seed),f$data$scenario,"results_graph_geoeco")
  path<-wd_export_environment(f$env,catalog,destination)
  snapshots[[r]]<-readRDS(path)
  stamp<-file.info(path)$mtime
  wd_export_environment(f$env,catalog,destination)
  stopifnot(identical(file.info(path)$mtime,stamp))
}
all_sites<-do.call(rbind,lapply(snapshots,wd_evaluate))
rr<-wd_replications(all_sites);paired<-wd_paired(rr)
p<-paired[paired$right=="Graph_SCM" & paired$obs_group=="post_only" & paired$metric=="mean_weight_RMSE",]
near(p$mean_difference,-.1);near(p$MCSE_difference,.05/sqrt(3));stopifnot(p$n_rep==3)
stopifnot(!any(paired$right=="Ordinary_SCM" & paired$obs_group %in% c("ALL","post_only")))
stopifnot(any(paired$right=="Ordinary_SCM" & paired$obs_group=="PRE_observed"))
v<-wd_fixed_design_variance(snapshots,"Graph_SCM")
near(v$empirical_squared_bias,.01);near(v$empirical_variance,mean(c(-.05,0,.05)^2))
near(v$mean_squared_error,v$empirical_squared_bias+v$empirical_variance)
wrong<-snapshots;wrong[[2]]$truth[1,]<-c(.6,.4)
fails(wd_fixed_design_variance(wrong,"Graph_SCM"),"Truth/design differs")
wrong<-snapshots;wrong[[2]]$design$target_attributes$X_m[1]<-99
fails(wd_fixed_design_variance(wrong,"Graph_SCM"),"Truth/design differs")
f<-make_fixture()
legacy_dir<-file.path(scratch,"legacy",paste0("seed_",f$data$seed),f$data$scenario,"results_graph_geoeco")
dir.create(legacy_dir,recursive=TRUE,showWarnings=FALSE)
saveRDS(f$obj,file.path(dirname(legacy_dir),"M1_LP_synthetic_dataset.rds"))
utils::write.csv(data.frame(point_id=rownames(f$data$truth),f$data$truth,check.names=FALSE),
  file.path(dirname(legacy_dir),"truth_weights.csv"),row.names=FALSE)
utils::write.csv(data.frame(point_id=rownames(f$data$truth),f$data$truth,check.names=FALSE),
  file.path(legacy_dir,"joint_scm_weights.csv"),row.names=FALSE)
utils::write.csv(data.frame(point_id=rownames(f$data$truth),model_data_identified=TRUE),
  file.path(legacy_dir,"postonly_graph_anchor_diagnostics.csv"),row.names=FALSE)
legacy<-wd_read_legacy(legacy_dir,catalog)
stopifnot(identical(legacy$kind,"legacy_weights"),all(legacy$sites$weight_RMSE[legacy$sites$method=="GeoEco_SCM"]==0))
wrong_truth<-f$data$truth;wrong_truth[1,]<-c(.6,.4)
utils::write.csv(data.frame(point_id=rownames(wrong_truth),wrong_truth,check.names=FALSE),
  file.path(dirname(legacy_dir),"truth_weights.csv"),row.names=FALSE)
fails(wd_read_legacy(legacy_dir,catalog),"Truth CSV and original RDS disagree")
utils::write.csv(data.frame(point_id=rownames(f$data$truth),f$data$truth,check.names=FALSE),
  file.path(dirname(legacy_dir),"truth_weights.csv"),row.names=FALSE)
diagnostic_dir<-file.path(scratch,"diagnostic_only",paste0("seed_",f$data$seed),f$data$scenario,"results_graph_geoeco")
dir.create(diagnostic_dir,recursive=TRUE,showWarnings=FALSE)
z<-wd_evaluate(snapshots[[1]]);z<-z[z$method=="GeoEco_SCM",c("point_id","obs_group","weight_RMSE","weight_L1","weight_cosine")]
utils::write.csv(z,file.path(diagnostic_dir,"simulation_weight_recovery_by_site.csv"),row.names=FALSE)
utils::write.csv(data.frame(point_id=z$point_id,model_data_identified=c(TRUE,TRUE,FALSE)),
  file.path(diagnostic_dir,"postonly_graph_anchor_diagnostics.csv"),row.names=FALSE)
diagnostic<-wd_read_legacy(diagnostic_dir,catalog)
stopifnot(diagnostic$kind=="legacy_diagnostic_only",sum(diagnostic$sites$evaluated)==2,
  all(diagnostic$sites$data_signature==""),is.na(diagnostic$sites$weight_RMSE[3]))

rscript<-file.path(R.home("bin"),if(.Platform$OS.type=="windows")"Rscript.exe" else "Rscript")
cli<-file.path(replication,"run.R")
run_cli<-function(input,output,extra=character()) {
  log<-tempfile("weight_cli_",fileext=".log")
  args<-c("--vanilla",cli,"--task=weights",paste0("--input-root=",input),paste0("--output-root=",output),
    "--designs=D1","--reps=1,2,3",extra)
  status<-system2(rscript,vapply(args,shQuote,character(1)),stdout=log,stderr=log)
  if(status!=0L) {cat(readLines(log,warn=FALSE),sep="\n");stop("Weight CLI failed.")}
}
out<-file.path(scratch,"generated")
input_files<-list.files(file.path(scratch,"new"),recursive=TRUE,full.names=TRUE)
input_hashes<-tools::md5sum(input_files)
run_cli(file.path(scratch,"new"),out)
stopifnot(identical(unname(tools::md5sum(input_files)),unname(input_hashes)))
summ<-wd_read_csv(file.path(out,"weights","weight_summary.csv"))
stopifnot(any(summ$n_rep==3),all(summ$n_rep %in% c(0,3)))
paired_cli<-wd_read_csv(file.path(out,"weights","paired_weight_differences.csv"))
near(paired_cli$mean_difference[paired_cli$right=="Graph_SCM" & paired_cli$obs_group=="post_only" &
  paired_cli$metric=="mean_weight_RMSE"],-.1)
dry<-file.path(scratch,"should_not_exist")
run_cli(file.path(scratch,"new"),dry,"--dry-run");stopifnot(!dir.exists(dry))
legacy_out<-file.path(scratch,"legacy_generated")
run_cli(file.path(scratch,"legacy"),legacy_out)
coverage<-wd_read_csv(file.path(legacy_out,"weights","weight_coverage_audit.csv"))
stopifnot(any(coverage$method=="Graph_SCM" & coverage$status=="method_weights_not_saved"))
duplicate<-file.path(scratch,"duplicates")
for(name in c("first","second")) {
  dir.create(file.path(duplicate,name),recursive=TRUE)
  saveRDS(snapshots[[1]],file.path(duplicate,name,"weight_assessment.rds"))
}
run_cli(duplicate,file.path(scratch,"duplicate_output"))
dup_summary<-wd_read_csv(file.path(scratch,"duplicate_output","weights","weight_summary.csv"))
stopifnot(all(dup_summary$n_rep %in% c(0,1)))
conflict<-snapshots[[1]];conflict$estimates$GeoEco_SCM[1,]<-c(.6,.4)
saveRDS(conflict,file.path(duplicate,"second","weight_assessment.rds"))
conflict_log<-tempfile("conflicting_weights_",fileext=".log")
conflict_args<-c("--vanilla",cli,"--task=weights",paste0("--input-root=",duplicate),
  paste0("--output-root=",file.path(scratch,"conflicting_output")),"--designs=D1","--reps=1")
conflict_status<-suppressWarnings(system2(rscript,vapply(conflict_args,shQuote,character(1)),stdout=conflict_log,stderr=conflict_log))
stopifnot(conflict_status!=0L,any(grepl("Conflicting saved weight results",readLines(conflict_log,warn=FALSE),fixed=TRUE)))
if(.Platform$OS.type=="windows") {
  pslog<-tempfile("weight_ps_",fileext=".log")
  arguments<-c("-NoProfile","-ExecutionPolicy","Bypass","-File",file.path(replication,"run_windows.ps1"),
    "-Task","weights","-InputRoot",file.path(scratch,"new"),"-OutputRoot",file.path(scratch,"powershell_output"),
    "-Designs","D1","-Reps","1,2,3")
  status<-system2("powershell.exe",vapply(arguments,shQuote,character(1)),stdout=pslog,stderr=pslog)
  if(status!=0L){cat(readLines(pslog,warn=FALSE),sep="\n");stop("Windows weight launcher failed.")}
  stopifnot(file.exists(file.path(scratch,"powershell_output","weights","weight_summary.csv")))
}
cat("PASS: analytic errors, exact ID alignment, ordinary post-only masking, snapshot export/resumption, paired dataset intervals, fixed-design variance safeguards, legacy imports, Unicode/space paths and read-only CLI.\n")
