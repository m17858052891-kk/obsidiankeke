# Representative PRE-validation problems, not the full adaptive CV search.
scm_benchmark_graph <- function(meta,beta,k=8L) {
  n <- nrow(meta)
  xy <- as.matrix(meta[c("X_m","Y_m")])
  distances <- as.matrix(stats::dist(xy)); diag(distances) <- Inf
  neighbors <- t(vapply(seq_len(n),function(i) order(distances[i,],seq_len(n))[seq_len(min(k,n-1L))],integer(min(k,n-1L))))
  edge_i <- rep(seq_len(n),each=ncol(neighbors)); edge_k <- as.vector(t(neighbors))
  geo <- sqrt(rowSums((xy[edge_i,,drop=FALSE]-xy[edge_k,,drop=FALSE])^2))
  h_geo <- median(geo[is.finite(geo)&geo>0]); if (!is.finite(h_geo)) h_geo <- 1
  econ <- as.matrix(meta[c("pre_employment_density_z","pre_commercial_share_z","pre_income_z")])
  ss <- apply(econ,2,sd); ss[!is.finite(ss)|ss<=0] <- 1
  z <- sweep(sweep(econ,2,colMeans(econ),"-"),2,ss,"/")
  covariance <- stats::cov(z)
  precision <- solve(.85*covariance+.15*diag(diag(covariance),ncol(covariance))+diag(1e-6,ncol(covariance)))
  delta <- z[edge_i,,drop=FALSE]-z[edge_k,,drop=FALSE]
  economic <- sqrt(pmax(rowSums((delta%*%precision)*delta),0))
  h_econ <- median(economic[is.finite(economic)&economic>0]); if (!is.finite(h_econ)) h_econ <- 1
  a <- exp(-geo/h_geo-beta*economic/h_econ)
  directed <- data.frame(i=pmin(edge_i,edge_k),k=pmax(edge_i,edge_k),a=a)
  edges <- stats::aggregate(a~i+k,directed,mean)
  edges <- edges[order(edges$i,edges$k),,drop=FALSE]
  edges$a <- edges$a/mean(edges$a)
  e <- nrow(edges)
  list(edges=edges,Dg=Matrix::sparseMatrix(i=rep(seq_len(e),each=2L),
    j=as.vector(t(as.matrix(edges[c("i","k")]))),
    x=as.vector(t(cbind(sqrt(edges$a),-sqrt(edges$a)))),dims=c(e,n)))
}

scm_run_benchmark <- function(project_root,designs="D1",reps=1L,output_root,
                              input_root=NULL,repeats=3L) {
  if (!is.numeric(repeats) || length(repeats)!=1L || anyNA(repeats) || !is.finite(repeats) || repeats<1L || repeats>20L || repeats!=as.integer(repeats))
    stop("Choose 1-20 timing repeats.")
  native <- scm_load_rcpp()  # Compilation is excluded from the measured solves.
  cov_root <- file.path(project_root,"replication/covariate_scm")
  data_env <- new.env(parent=globalenv())
  sys.source(file.path(cov_root,"R/core.R"),envir=data_env)
  # data.R locates its catalog using source's ofile; use source, not sys.source.
  source(file.path(cov_root,"R/data.R"),local=data_env)
  catalog <- read.csv(file.path(project_root,"replication/design_catalog.csv"),stringsAsFactors=FALSE)
  cf <- read.csv(file.path(project_root,"data/counterfactual_replications.csv"),stringsAsFactors=FALSE)
  att <- read.csv(file.path(project_root,"data/ATT_replications.csv"),stringsAsFactors=FALSE)
  reference <- scm_reference_environment(project_root)
  accelerated <- scm_accelerate_function(reference$fit_smooth_scm,native)
  rows <- list(); archive_checks <- list(); case_inputs <- list()
  dir.create(output_root,recursive=TRUE,showWarnings=FALSE)
  for (design in designs) for (rep in reps) {
    row <- catalog[match(design,catalog$paper_id),,drop=FALSE]
    if (nrow(row)!=1L || is.na(row$scenario)) stop("Unknown design: ",design)
    seed <- as.integer(row$seed_base+rep)
    if (is.null(input_root)) {
      if (row$backend!="legacy8") stop("D9-D10 benchmarks require --input-root with original saved datasets.")
      dat <- data_env$cov_generate(file.path(cov_root,"vendor/generator_legacy8.R"),row$scenario,seed)
      origin <- "regenerated_original_numeric_DGP"
    } else {
      candidates <- c(file.path(input_root,paste0("seed_",seed),row$scenario,"M1_LP_synthetic_dataset.rds"),
        file.path(input_root,"M1_LP_synthetic_dataset.rds"),input_root)
      candidates <- candidates[file.exists(candidates)&!dir.exists(candidates)]
      if (!length(candidates)) stop("Cannot find this benchmark's saved dataset.")
      dat <- data_env$cov_read_original(candidates[1],row$scenario,seed)
      origin <- "original_saved_dataset"
    }
    check <- data_env$cov_archive_check(dat,cf,att,row$scenario,seed)
    check$design <- design; check$rep <- rep; archive_checks[[length(archive_checks)+1L]] <- check
    pre <- match(dat$pre_years,dat$years)
    yt <- dat$observed_log[,pre,drop=FALSE]; yc <- t(dat$donor_log[,pre,drop=FALSE])
    reference$target_meta <- dat$target
    reference$control_df <- dat$donor
    complete <- which(rowSums(is.finite(yt))==ncol(yt))
    if (length(complete)<4L) stop("Need complete-PRE targets for the representative validation masks.")
    temporal <- matrix(FALSE,nrow(yt),ncol(yt)); temporal[,tail(seq_len(ncol(yt)),2)] <- is.finite(yt[,tail(seq_len(ncol(yt)),2),drop=FALSE])
    pseudo <- matrix(FALSE,nrow(yt),ncol(yt)); pseudo[head(complete,6),] <- TRUE
    masks <- list(temporal=temporal,pseudo_post_only=pseudo)
    case_inputs[[paste(design,rep,sep="_")]] <- list(design=design,rep=rep,seed=seed,
      origin=origin,observed_pre=yt,donor_pre=yc,target_attributes=dat$target,donor_attributes=dat$donor)
    for (mask_name in names(masks)) for (beta in c(0,2)) {
      graph <- scm_benchmark_graph(dat$target,beta)
      held <- masks[[mask_name]]; train <- yt; train[held] <- NA_real_
      for (lambda in c(.001,.05)) {
        cat("Benchmark",design,"rep",rep,mask_name,"beta",beta,"lambda",lambda,"\n")
        timings <- list(R=numeric(),Rcpp=numeric()); fits <- list()
        for (repeat_id in seq_len(repeats)) {
          order <- if (repeat_id%%2L) c("R","Rcpp") else c("Rcpp","R")
          for (engine in order) {
            fn <- if (engine=="R") reference$fit_smooth_scm else accelerated
            elapsed <- system.time(fit <- fn(train,yc,graph,lambda=lambda,
              max_iter=1500L,min_iter=100L,tol=2e-5,fit_label="benchmark"))[["elapsed"]]
            timings[[engine]] <- c(timings[[engine]],elapsed); fits[[engine]] <- fit
          }
        }
        a <- fits$R; b <- fits$Rcpp
        pred_a <- a$W%*%t(yc); pred_b <- b$W%*%t(yc)
        error_a <- sqrt(mean((pred_a[held]-yt[held])^2))
        error_b <- sqrt(mean((pred_b[held]-yt[held])^2))
        weight_difference <- max(abs(a$W-b$W)); pred_difference <- max(abs(pred_a-pred_b))
        stopifnot(weight_difference<1e-7,pred_difference<1e-8,abs(a$value-b$value)<1e-8,
          identical(a$fista_iter,b$fista_iter),identical(a$status,b$status),abs(error_a-error_b)<1e-8)
        rows[[length(rows)+1L]] <- data.frame(design=design,rep=rep,seed=seed,
          data_origin=origin,mask=mask_name,beta=beta,lambda=lambda,repeats=repeats,
          n_target=nrow(yt),n_donor=ncol(yc),n_pre=ncol(yt),
          R_elapsed_sec=median(timings$R),Rcpp_elapsed_sec=median(timings$Rcpp),
          speedup=median(timings$R)/median(timings$Rcpp),
          R_iter=a$fista_iter,Rcpp_iter=b$fista_iter,status=b$status,
          max_weight_difference=weight_difference,max_prediction_difference=pred_difference,
          objective_difference=abs(a$value-b$value),R_validation_RMSE=error_a,Rcpp_validation_RMSE=error_b)
      }
    }
  }
  results <- do.call(rbind,rows)
  groups <- split(results,interaction(results$design,results$rep,results$mask,drop=TRUE))
  selections <- do.call(rbind,lapply(groups,function(x) {
    ia <- which.min(x$R_validation_RMSE); ib <- which.min(x$Rcpp_validation_RMSE)
    stopifnot(ia==ib)
    data.frame(design=x$design[1],rep=x$rep[1],mask=x$mask[1],
      selected_beta=x$beta[ia],selected_lambda=x$lambda[ia],R_and_Rcpp_same_candidate=TRUE)
  }))
  summary <- data.frame(n_datasets=length(case_inputs),n_validation_problems=nrow(results),
    timing_repeats=repeats,R_total_median_sec=sum(results$R_elapsed_sec),
    Rcpp_total_median_sec=sum(results$Rcpp_elapsed_sec),
    speedup=sum(results$R_elapsed_sec)/sum(results$Rcpp_elapsed_sec),
    max_weight_difference=max(results$max_weight_difference),
    max_prediction_difference=max(results$max_prediction_difference),
    all_iteration_counts_identical=all(results$R_iter==results$Rcpp_iter),
    all_candidate_choices_identical=all(selections$R_and_Rcpp_same_candidate))
  write.csv(results,file.path(output_root,"fit_comparisons.csv"),row.names=FALSE)
  write.csv(summary,file.path(output_root,"speed_summary.csv"),row.names=FALSE)
  write.csv(selections,file.path(output_root,"candidate_choices.csv"),row.names=FALSE)
  write.csv(do.call(rbind,archive_checks),file.path(output_root,"original_data_alignment.csv"),row.names=FALSE)
  saveRDS(case_inputs,file.path(output_root,"benchmark_observed_inputs.rds"))
  writeLines(capture.output(sessionInfo()),file.path(output_root,"sessionInfo.txt"))
  writeLines(c("Representative PRE-validation FISTA solves; not the full adaptive CV search or an end-to-end Monte Carlo timing.",
    "Both engines use the same observed inputs, graph, cold start, 1500-iteration cap, minimum 100 iterations and 2e-5 tolerance.",
    "Timing excludes compilation and data generation. Each cell is the median of the specified repeats; engine order alternates.",
    "Geographic/economic graphs are constructed with base R for this benchmark; validation masks and candidates are deliberately small representative sets.",
    "Uniform CF/ATT agreement verifies regenerated or saved input data against the archived experiment.",
    "Final OSQP fits, full adaptive searches, spatio-temporal benchmarks and all-200-case timings are not measured here."),
    file.path(output_root,"README_results.txt"))
  print(summary,row.names=FALSE)
  invisible(summary)
}
