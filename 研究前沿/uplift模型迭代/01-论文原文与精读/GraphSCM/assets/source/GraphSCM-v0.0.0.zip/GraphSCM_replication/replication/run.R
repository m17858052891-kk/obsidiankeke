# Unified entry point: checks, summaries, Cov-SCM, full estimation and saved weights.
entry <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
REPLICATION_ROOT <- dirname(normalizePath(entry, winslash = "/", mustWork = TRUE))
PROJECT_ROOT <- dirname(REPLICATION_ROOT)
options <- list()
for (arg in commandArgs(TRUE)) {
  if (arg == "--dry-run") { options[["dry-run"]] <- TRUE; next }
  if (!grepl("^--[a-z-]+=", arg)) stop("Use --option=value: ", arg)
  cut <- regexpr("=", arg, fixed = TRUE)[1]; key <- substr(arg, 3, cut - 1L)
  if (!key %in% c("task", "mode", "designs", "reps", "output-root", "input-root", "engine", "benchmark-repeats")) stop("Unknown option: ", key)
  if (!is.null(options[[key]])) stop("Repeated option: ", key)
  options[[key]] <- substring(arg, cut + 1L)
}
option <- function(key, default = NULL) if (is.null(options[[key]])) default else options[[key]]
task <- option("task", "check")
if (!task %in% c("check", "summary", "covariate", "full", "collect", "weights", "benchmark")) stop("Unknown task.")
engine <- option("engine", "R")
if (!engine %in% c("R","Rcpp")) stop("Choose --engine=R or --engine=Rcpp.")
mode <- option("mode", "test")
if (!mode %in% c("test", "full")) stop("Choose --mode=test or --mode=full.")
catalog <- read.csv(file.path(REPLICATION_ROOT, "design_catalog.csv"), stringsAsFactors = FALSE)
designs <- option("designs", if (task == "covariate") "primary" else if (task == "benchmark") "D1" else "all")
designs <- if (designs == "all") catalog$paper_id else if (designs == "primary")
  catalog$paper_id[catalog$role == "primary"] else strsplit(designs, ",", fixed = TRUE)[[1]]
if (!length(designs) || anyDuplicated(designs) || any(!designs %in% catalog$paper_id)) stop("Choose D1-D10, primary, or all.")
rep_text <- option("reps")
if (!is.null(rep_text) && !grepl("^[0-9]+([,:][0-9]+)*$", rep_text)) stop("Invalid --reps syntax.")
reps <- if (is.null(rep_text)) if (task == "covariate" && mode == "full") 1:100 else if (task == "weights" || mode == "full") 1:20 else 1L else
  if (grepl("^[0-9]+:[0-9]+$", rep_text)) {
    bounds <- as.integer(strsplit(rep_text, ":", fixed = TRUE)[[1]])
    if (anyNA(bounds) || any(bounds<1L | bounds>10000L)) stop("Replication range must be within 1-10000.")
    seq.int(bounds[1], bounds[2])
  } else as.integer(strsplit(rep_text, ",", fixed = TRUE)[[1]])
rep_limit <- if (task %in% c("full","weights","covariate")) 10000L else 20L
if (anyNA(reps) || anyDuplicated(reps) || any(reps < 1L | reps > rep_limit))
  stop("Choose replication IDs between 1 and ",rep_limit,". Defaults retain the archived 20 replications.")
output <- option("output-root", file.path(REPLICATION_ROOT, "output"))
rscript <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
execute <- function(file, args = character()) {
  status <- system2(rscript, c("--vanilla", shQuote(file), vapply(args, shQuote, character(1))))
  if (status != 0L) stop("Child R process failed with exit code ", status)
}
if (task == "check") {
  source(file.path(REPLICATION_ROOT, "validate_public.R")); validate_public(PROJECT_ROOT)
} else if (task == "summary") {
  source(file.path(REPLICATION_ROOT, "summarize_archived.R"))
  summarize_archived(PROJECT_ROOT, file.path(output, "archived_summary"))
  source(file.path(REPLICATION_ROOT, "summarize_weights_archived.R"))
  summarize_weights_archived(PROJECT_ROOT, file.path(output, "archived_summary", "weight_diagnostics"))
  source(file.path(REPLICATION_ROOT, "plot_archived.R"))
  plot_archived(PROJECT_ROOT, file.path(output, "archived_summary", "GeoEco_vs_Graph_post_only.png"))
} else if (task == "weights") {
  input <- option("input-root", file.path(output, "full"))
  arguments <- c(paste0("--input-root=", input), paste0("--output-root=", file.path(output, "weights")),
    paste0("--designs=", paste(designs, collapse = ",")), paste0("--reps=", paste(reps, collapse = ",")))
  if (isTRUE(option("dry-run", FALSE))) arguments <- c(arguments, "--dry-run")
  execute(file.path(REPLICATION_ROOT, "assess_weights.R"), arguments)
} else if (task == "benchmark") {
  if (isTRUE(option("dry-run",FALSE))) {
    cat("Benchmark plan only:",length(designs)*length(reps),
      "datasets; representative PRE-validation problems. No compilation, generation or fitting was executed.\n")
    quit(status=0)
  }
  source(file.path(REPLICATION_ROOT,"acceleration/R/backend.R"))
  source(file.path(REPLICATION_ROOT,"acceleration/R/benchmark.R"))
  timing_repeats <- suppressWarnings(as.numeric(option("benchmark-repeats","3")))
  scm_run_benchmark(PROJECT_ROOT,designs=designs,reps=reps,
    output_root=file.path(output,"acceleration_benchmark"),
    input_root=option("input-root"),repeats=timing_repeats)
} else if (task == "covariate") {
  if (any(!designs %in% paste0("D", 1:8))) stop("The Cov-SCM numeric adapter supports D1-D8; the published comparison uses D1-D5.")
  arguments <- c(paste0("--mode=", mode), paste0("--scenarios=", paste(designs, collapse = ",")),
    paste0("--reps=", paste(reps, collapse = ",")), paste0("--output-root=", file.path(output, "covariate")))
  if (!is.null(option("input-root"))) arguments <- c(arguments, paste0("--input-root=", option("input-root")))
  if (isTRUE(option("dry-run", FALSE))) arguments <- c(arguments, "--dry-run")
  execute(file.path(REPLICATION_ROOT, "covariate_scm", "run_covariate_scm.R"), arguments)
} else {
  Sys.setenv(GRAPHSCM_OUTPUT_ROOT = file.path(output, if (engine=="Rcpp") "full_Rcpp" else "full"),
    GRAPHSCM_ENGINE=engine)
  if (task == "collect") {
    execute(file.path(REPLICATION_ROOT, "original", "R", "05_summarize_results.R"))
    execute(file.path(REPLICATION_ROOT, "original", "R", "04_audit_local_pair.R"))
  } else {
    arguments <- c(paste0("--scenario=", paste(designs, collapse = ",")), paste0("--rep=", paste(reps, collapse = ",")))
    if (isTRUE(option("dry-run", FALSE))) arguments <- c(arguments, "--dry-run")
    execute(file.path(REPLICATION_ROOT, "original", "run_all.R"), arguments)
  }
}
