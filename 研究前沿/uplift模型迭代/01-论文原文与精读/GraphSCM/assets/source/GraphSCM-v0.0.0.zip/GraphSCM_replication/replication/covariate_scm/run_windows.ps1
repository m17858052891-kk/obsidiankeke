param(
    [ValidateSet('test','full')][string]$Mode = 'test',
    [string]$RscriptPath = '',
    [string]$Scenarios = 'D1,D2,D3,D4,D5',
    [ValidateSet('geo_econ','econ','geo')][string]$FeatureSet = 'geo_econ',
    [string]$InputRoot = '',
    [string]$OutputRoot = ''
)
$ErrorActionPreference = 'Stop'
if (-not $RscriptPath) {
    $rCommand = Get-Command Rscript.exe -ErrorAction SilentlyContinue
    if ($rCommand) { $RscriptPath = $rCommand.Source }
}
if (-not $RscriptPath) {
    $rCandidates = @()
    foreach ($rBase in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
        if (-not $rBase) { continue }
        $rFolder = Join-Path $rBase 'R'
        if (Test-Path -LiteralPath $rFolder) {
            $rCandidates += Get-ChildItem -LiteralPath $rFolder -Filter 'R-*' -Directory |
                ForEach-Object {
                    @((Join-Path $_.FullName 'bin\Rscript.exe'),
                      (Join-Path $_.FullName 'bin\x64\Rscript.exe'))
                } | Where-Object { Test-Path -LiteralPath $_ }
        }
    }
    if ($rCandidates.Count) {
        $RscriptPath = $rCandidates | Sort-Object -Descending | Select-Object -First 1
    }
}
if (-not $RscriptPath -or -not (Test-Path -LiteralPath $RscriptPath)) {
    throw 'Rscript.exe was not found. Install R, or supply -RscriptPath with its full path.'
}
if (-not $OutputRoot) { $OutputRoot = Join-Path $PSScriptRoot 'output' }
$rArguments = @('--vanilla', (Join-Path $PSScriptRoot 'run_covariate_scm.R'),
    "--mode=$Mode", "--scenarios=$Scenarios", "--feature-set=$FeatureSet",
    "--output-root=$OutputRoot")
if ($InputRoot) { $rArguments += "--input-root=$InputRoot" }
# R for Windows uses a Windows locale name. An inherited C.UTF-8 can leave
# LC_CTYPE=C and break non-ASCII paths. Override only for this child process.
$previousLocale = [Environment]::GetEnvironmentVariable('LC_ALL', 'Process')
try {
    $env:LC_ALL = 'English_United States.utf8'
    & $RscriptPath @rArguments
    if ($LASTEXITCODE -ne 0) { throw "R stopped with exit code $LASTEXITCODE." }
} finally {
    if ($null -eq $previousLocale) {
        Remove-Item Env:\LC_ALL -ErrorAction SilentlyContinue
    } else {
        $env:LC_ALL = $previousLocale
    }
}
