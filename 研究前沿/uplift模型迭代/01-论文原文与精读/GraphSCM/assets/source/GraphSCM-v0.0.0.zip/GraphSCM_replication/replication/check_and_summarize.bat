@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_windows.ps1" -Task check
if errorlevel 1 goto end
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_windows.ps1" -Task summary
:end
pause
