# Base-R weight-recovery diagnostics. Estimation functions never receive truth.
wd_digest <- function(x) {
  path <- tempfile("weight_fingerprint_")
  on.exit(unlink(path), add = TRUE)
  writeBin(serialize(x, NULL, version = 2), path)
  unname(tools::md5sum(path))
}

wd_ids <- function(x, label) {
  x <- as.character(x)
  if (!length(x) || anyNA(x) || any(!nzchar(x)) || anyDuplicated(x))
    stop("Invalid or duplicated ", label, ".")
  x
}

wd_align <- function(x, target_ids, donor_ids, label, allow_missing = FALSE) {
  x <- as.matrix(x)
  if (!is.numeric(x) || is.null(rownames(x)) || is.null(colnames(x)) ||
      anyDuplicated(rownames(x)) || anyDuplicated(colnames(x)) ||
      !setequal(rownames(x), target_ids) || !setequal(colnames(x), donor_ids))
    stop(label, ": explicit target/donor IDs must match the truth exactly.")
  x <- x[target_ids, donor_ids, drop = FALSE]
  finite <- rowSums(is.finite(x))
  if (any(!is.na(x) & !is.finite(x)) ||
      any(finite != ncol(x) & !(allow_missing & finite == 0L & rowSums(is.na(x)) == ncol(x))))
    stop(label, ": incomplete or nonfinite weight row.")
  used <- finite == ncol(x)
  if ((!allow_missing && any(!used)) ||
      any(x[used, , drop = FALSE] < -1e-8) ||
      any(abs(rowSums(x[used, , drop = FALSE]) - 1) > 1e-6))
    stop(label, ": simplex constraints failed.")
  x
}

wd_case <- function(metadata, truth, groups, estimates, design = list()) {
  truth <- as.matrix(truth)
  tids <- sort(wd_ids(rownames(truth), "truth target IDs"))
  dids <- sort(wd_ids(colnames(truth), "truth donor IDs"))
  truth <- wd_align(truth, tids, dids, "Truth")
  if (is.null(names(groups)) || anyDuplicated(names(groups)) ||
      !setequal(names(groups), tids)) stop("Observation groups need matching target IDs.")
  groups <- as.character(groups[tids]); names(groups) <- tids
  if (anyNA(groups) || any(!groups %in% c("complete_pre", "partial_pre", "post_only")))
    stop("Unknown observation group.")
  if (!is.list(estimates) || !length(estimates) || is.null(names(estimates)) ||
      any(!nzchar(names(estimates))) || anyDuplicated(names(estimates)))
    stop("Provide a named list of method weight matrices.")
  estimates <- lapply(names(estimates), function(method) {
    value <- wd_align(estimates[[method]], tids, dids, method, allow_missing = TRUE)
    # A numerical lambda=0 continuation is not a fitted post-only ordinary SCM.
    if (method == "Ordinary_SCM") value[groups == "post_only", ] <- NA_real_
    value
  }) |> stats::setNames(names(estimates))
  if (is.null(metadata$scenario) || is.null(metadata$seed) || is.null(metadata$rep))
    stop("Scenario, seed and replication metadata are required.")
  metadata$scenario <- as.character(metadata$scenario)
  metadata$seed <- as.integer(metadata$seed); metadata$rep <- as.integer(metadata$rep)
  if (length(metadata$scenario) != 1L || length(metadata$seed) != 1L ||
      length(metadata$rep) != 1L || anyNA(c(metadata$seed, metadata$rep)) || metadata$rep < 1L)
    stop("Invalid case metadata.")
  metadata$n_target <- nrow(truth); metadata$n_donor <- ncol(truth)
  if (is.null(metadata$study_id)) metadata$study_id <- "publication"
  if (is.null(metadata$paper_id)) metadata$paper_id <- NA_character_
  if (is.null(metadata$n_pre_periods)) metadata$n_pre_periods <- NA_integer_
  if (is.null(metadata$n_post_periods)) metadata$n_post_periods <- NA_integer_
  metadata$data_complete <- all(c("donor_pre", "observed_pre", "observation_mask",
    "target_attributes", "donor_attributes", "years", "pre_years", "post_years") %in% names(design))
  if (metadata$data_complete) {
    for (field in c("observed_pre", "observation_mask", "target_attributes", "donor_pre", "donor_attributes")) {
      ids <- if (field %in% c("donor_pre", "donor_attributes")) dids else tids
      value <- design[[field]]
      if (is.null(rownames(value)) || anyDuplicated(rownames(value)) || !setequal(rownames(value), ids))
        stop("Design row IDs disagree: ", field)
      design[[field]] <- value[ids, , drop = FALSE]
    }
    pre <- as.character(design$pre_years)
    for (field in c("observed_pre", "observation_mask", "donor_pre")) {
      if (is.null(colnames(design[[field]])) || !setequal(colnames(design[[field]]), pre))
        stop("Design PRE dates disagree: ", field)
      design[[field]] <- design[[field]][, pre, drop = FALSE]
    }
    if (length(intersect(design$pre_years, design$post_years)) ||
        !setequal(design$years, c(design$pre_years, design$post_years)) ||
        anyDuplicated(design$years) || max(design$pre_years) >= min(design$post_years))
      stop("Invalid design time partition.")
    if (any(!is.finite(as.matrix(design$donor_pre))) ||
        any(!is.na(design$observed_pre) & !is.finite(design$observed_pre)) ||
        !identical(unname(as.matrix(design$observation_mask)), unname(is.finite(design$observed_pre))))
      stop("Design PRE values/mask disagree.")
    counts <- rowSums(is.finite(design$observed_pre))
    expected <- ifelse(counts == 0, "post_only", ifelse(counts == length(pre), "complete_pre", "partial_pre"))
    if (!identical(unname(groups), unname(expected))) stop("Design masks and observation groups disagree.")
    for (field in c("target_attributes", "donor_attributes"))
      if (any(!is.finite(as.matrix(design[[field]])))) stop("Incomplete observed attributes.")
    metadata$n_pre_periods <- length(design$pre_years)
    metadata$n_post_periods <- length(design$post_years)
    if (metadata$n_target != 120L || metadata$n_donor != 24L ||
        metadata$n_pre_periods != 11L || metadata$n_post_periods != 11L)
      if (metadata$study_id == "publication") metadata$study_id <- paste0("custom_N", metadata$n_target,
        "_J", metadata$n_donor, "_PRE", metadata$n_pre_periods, "_POST", metadata$n_post_periods)
  }
  # Collectors recompute fingerprints in one R session; stored hashes are not
  # used as cross-version serialization checksums.
  list(schema = "graphscm_weight_case_v1", metadata = metadata, truth = truth,
       groups = groups, estimates = estimates, design = design)
}

wd_evaluate <- function(case) {
  case <- wd_case(case$metadata, case$truth, case$groups, case$estimates, case$design)
  meta <- case$metadata
  data_id <- if (isTRUE(meta$data_complete)) wd_digest(list(case$truth, case$groups, case$design)) else ""
  # This signature excludes observation noise but includes the observation mask
  # when the exporting workflow supplies the design fields.
  fixed_id <- wd_digest(list(case$truth, case$groups, case$design[setdiff(names(case$design), "observed_pre")]))
  rows <- list()
  for (method in names(case$estimates)) {
    w <- case$estimates[[method]]; used <- rowSums(is.finite(w)) == ncol(w)
    error <- w - case$truth
    norm <- sqrt(rowSums(w^2) * rowSums(case$truth^2))
    rows[[method]] <- data.frame(
      study_id = meta$study_id, scenario = meta$scenario, design = meta$paper_id,
      rep = meta$rep, seed = meta$seed, n_target = meta$n_target, n_donor = meta$n_donor,
      n_pre_periods = meta$n_pre_periods, n_post_periods = meta$n_post_periods,
      method = method, point_id = rownames(w), obs_group = unname(case$groups),
      evaluated = used, weight_RMSE = sqrt(rowMeans(error^2)),
      weight_L1 = rowSums(abs(error)), weight_cosine = rowSums(w * case$truth) / norm,
      effective_donors = 1 / rowSums(w^2), max_weight = apply(w, 1, max),
      data_signature = data_id, fixed_design_signature = fixed_id,
      input_kind = "weights_and_truth", stringsAsFactors = FALSE)
  }
  do.call(rbind, rows)
}

wd_mean <- function(x) if (any(is.finite(x))) mean(x[is.finite(x)]) else NA_real_

wd_replications <- function(sites) {
  rows <- list(); index <- 0L
  fields <- c("study_id", "scenario", "design", "rep", "seed", "n_target", "n_donor",
              "n_pre_periods", "n_post_periods", "method", "data_signature", "input_kind")
  key <- do.call(paste, c(lapply(sites[c("study_id", "scenario", "seed", "method", "n_target",
    "n_donor", "n_pre_periods", "n_post_periods")], as.character), sep = "|"))
  for (x in split(sites, key)) for (group in c("complete_pre", "partial_pre", "post_only", "PRE_observed", "ALL")) {
    take <- if (group == "ALL") rep(TRUE, nrow(x)) else if (group == "PRE_observed")
      x$obs_group != "post_only" else x$obs_group == group
    y <- x[take, , drop = FALSE]
    if (!nrow(y)) next
    info <- x[1, fields, drop = FALSE]
    eval_ids <- sort(as.character(y$point_id[y$evaluated]))
    info$obs_group <- group; info$n_sites <- nrow(y); info$n_eval_sites <- sum(y$evaluated)
    info$evaluated_population <- wd_digest(eval_ids)
    info$mean_weight_RMSE <- wd_mean(y$weight_RMSE)
    info$pooled_weight_RMSE <- sqrt(wd_mean(y$weight_RMSE^2))
    for (field in c("weight_L1", "weight_cosine", "effective_donors", "max_weight"))
      info[[paste0("mean_", field)]] <- wd_mean(y[[field]])
    index <- index + 1L; rows[[index]] <- info
  }
  do.call(rbind, rows)
}

wd_summary <- function(replications) {
  metrics <- c("mean_weight_RMSE", "pooled_weight_RMSE", "mean_weight_L1",
               "mean_weight_cosine", "mean_effective_donors", "mean_max_weight")
  fields <- c("study_id", "scenario", "design", "n_target", "n_donor", "n_pre_periods",
              "n_post_periods", "method", "obs_group", "n_sites", "n_eval_sites")
  key <- do.call(paste, c(lapply(replications[fields], as.character), sep = "|"))
  out <- list(); i <- 0L
  for (x in split(replications, key)) for (metric in metrics) {
    values <- x[[metric]]; values <- values[is.finite(values)]; n <- length(values)
    row <- x[1, fields, drop = FALSE]; row$metric <- metric
    row$n_rep <- n; row$mean <- if (n) mean(values) else NA_real_
    row$MCSE <- if (n >= 2L) stats::sd(values) / sqrt(n) else NA_real_
    i <- i + 1L; out[[i]] <- row
  }
  do.call(rbind, out)
}

wd_paired <- function(replications) {
  methods <- c("Graph_SCM", "Ordinary_SCM", "uniform_weights", "Covariate_SCM_geo_econ")
  keys <- c("study_id", "scenario", "rep", "seed", "n_target", "n_donor", "n_pre_periods", "n_post_periods", "obs_group")
  rows <- list(); k <- 0L
  for (reference in methods) {
    a <- replications[replications$method == "GeoEco_SCM", , drop = FALSE]
    b <- replications[replications$method == reference, , drop = FALSE]
    if (!nrow(a) || !nrow(b)) next
    z <- merge(a, b, by = keys, suffixes = c("_left", "_right"))
    z <- z[z$n_eval_sites_left > 0 & z$n_eval_sites_left == z$n_eval_sites_right &
      z$evaluated_population_left == z$evaluated_population_right &
      nzchar(z$data_signature_left) & z$data_signature_left == z$data_signature_right, , drop = FALSE]
    if (!nrow(z)) next
    grouping <- do.call(paste, c(lapply(z[c("study_id", "scenario", "n_target", "n_donor", "n_pre_periods", "n_post_periods", "obs_group")], as.character), sep = "|"))
    for (x in split(z, grouping)) for (metric in c("mean_weight_RMSE", "mean_weight_L1")) {
      d <- x[[paste0(metric, "_left")]] - x[[paste0(metric, "_right")]]
      d <- d[is.finite(d)]; n <- length(d)
      if (!n) next
      se <- if (n >= 2L) stats::sd(d) / sqrt(n) else NA_real_
      half <- if (n >= 2L) stats::qt(0.975, n - 1L) * se else NA_real_
      row <- x[1, c("study_id", "scenario", "n_target", "n_donor", "n_pre_periods", "n_post_periods", "obs_group"), drop = FALSE]
      row$left <- "GeoEco_SCM"; row$right <- reference; row$metric <- metric
      row$n_rep <- n; row$mean_difference <- mean(d); row$MCSE_difference <- se
      row$lower_95 <- mean(d) - half; row$upper_95 <- mean(d) + half
      k <- k + 1L; rows[[k]] <- row
    }
  }
  if (!length(rows)) return(data.frame())
  do.call(rbind, rows)
}

wd_fixed_design_variance <- function(cases, method, group = "ALL") {
  if (length(cases) < 2L) stop("At least two fixed-design noise repetitions are required.")
  cases <- lapply(cases, function(x) wd_case(x$metadata, x$truth, x$groups, x$estimates, x$design))
  ids <- vapply(cases, function(x) {
    if (!isTRUE(x$metadata$data_complete))
      stop("Fixed-design variance requires donor data and the observation mask.")
    wd_digest(list(x$truth, x$groups, x$design[setdiff(names(x$design), "observed_pre")]))
  }, character(1))
  if (length(unique(ids)) != 1L)
    stop("Truth/design differs: raw weight variation is not conditional estimator variance.")
  truth <- cases[[1]]$truth; groups <- cases[[1]]$groups
  take <- if (group == "ALL") rep(TRUE, nrow(truth)) else if (group == "PRE_observed")
    groups != "post_only" else groups == group
  if (!any(take)) stop("Empty evaluation group.")
  w <- lapply(cases, function(x) {
    if (!method %in% names(x$estimates)) stop("Method missing from a repetition.")
    x$estimates[[method]][take, , drop = FALSE]
  })
  if (any(!vapply(w, function(x) all(is.finite(x)), logical(1))))
    stop("Fixed-design variance requires the same estimable population in every repetition.")
  avg <- Reduce(`+`, w) / length(w)
  bias2 <- mean((avg - truth[take, , drop = FALSE])^2)
  variance <- mean(vapply(w, function(x) mean((x - avg)^2), numeric(1)))
  mse <- mean(vapply(w, function(x) mean((x - truth[take, , drop = FALSE])^2), numeric(1)))
  data.frame(method = method, obs_group = group, n_rep = length(w),
    empirical_squared_bias = bias2, empirical_variance = variance, mean_squared_error = mse,
    variance_sample_correction = variance * length(w) / (length(w) - 1L))
}
