# Source this file, then call run_graphscm_100(). Sourcing starts no estimation.
# D9/D10 retain the fixed 24-site and 2+2-anchor rules and share replacement seeds.
graphscm_100_case_plan <- function(project_dir) {
  catalog <- read.csv(file.path(project_dir,"replication/design_catalog.csv"),stringsAsFactors=FALSE)
  stopifnot(identical(catalog$paper_id,paste0("D",1:10)))
  plan <- do.call(rbind,lapply(seq_len(nrow(catalog)),function(i) {
    ids <- if(catalog$paper_id[i] %in% c("D9","D10")) setdiff(1:102,c(50L,70L)) else 1:100
    data.frame(design=catalog$paper_id[i],scenario=catalog$scenario[i],rep=ids,
      seed=as.integer(catalog$seed_base[i]+ids))
  }))
  stopifnot(nrow(plan)==1000L,all(table(plan$design)==100L),
    identical(plan$seed[plan$design=="D9"],plan$seed[plan$design=="D10"]))
  plan
}

graphscm_100_weight_coverage <- function(audit,plan) {
  key <- function(x) paste(x$design,x$rep,sep="|")
  expected <- key(audit) %in% key(plan)
  outside <- audit[!expected,,drop=FALSE]
  if(nrow(outside) && any(outside$status!="case_not_found"))
    stop("Saved weights outside the declared 100-case plan require review.")
  coverage <- audit[expected,,drop=FALSE]
  methods <- c("GeoEco_SCM","Graph_SCM","Ordinary_SCM","uniform_weights")
  if(nrow(coverage)!=4L*nrow(plan) || !setequal(coverage$method,methods) ||
     anyDuplicated(paste(key(coverage),coverage$method,sep="|")) ||
     !setequal(key(coverage),key(plan)) ||
     any(coverage$status %in% c("case_not_found","method_weights_not_saved")))
    stop("Expected 100-case weight coverage is incomplete; inspect weight_coverage_audit.csv.")
  list(coverage=coverage,outside=outside)
}

run_graphscm_100 <- function(project_dir=".",output_root=file.path(project_dir,"replication/output"),
                             engine="Rcpp",dry_run=FALSE) {
  project_dir <- normalizePath(project_dir,winslash="/",mustWork=TRUE)
  # Resolve before a child generator changes its working directory.
  output_root <- if(dir.exists(output_root)) normalizePath(output_root,winslash="/",mustWork=TRUE) else
    if(grepl("^([A-Za-z]:[/\\\\]|/)",output_root)) output_root else file.path(getwd(),output_root)
  if(!engine %in% c("R","Rcpp")) stop("Choose engine=R or Rcpp.")
  generator <- file.path(project_dir,"replication/original/internal/generator_local_paired_v9.R")
  if(tolower(unname(tools::md5sum(generator)))!="c61289c431802f9b15f49f16d8d1af47")
    stop("The local generator differs from the source used to certify the excluded seeds.")
  runner <- file.path(project_dir,"replication/original/R/02_run_one.R")
  if(tolower(unname(tools::md5sum(runner)))!="13033740bcb1f83dea02d9f8bac53d7c")
    stop("The runner configuration differs from the fixed design used to certify the excluded seeds.")
  plan <- graphscm_100_case_plan(project_dir)
  full <- file.path(output_root,if(engine=="Rcpp") "full_Rcpp" else "full")
  marker_paths <- function(x) file.path(full,paste0("seed_",x$seed),x$scenario,
    "results_graph_geoeco","_MC_FINISHED.txt")
  complete <- file.exists(marker_paths(plan))
  progress <- aggregate(cbind(planned=rep(1L,nrow(plan)),complete=as.integer(complete),
    remaining=as.integer(!complete))~design,plan,sum)
  progress <- progress[match(paste0("D",1:10),progress$design),]
  print(progress,row.names=FALSE)
  if(isTRUE(dry_run)) {
    cat("Plan only: 1000 cases;",sum(complete),"complete;",sum(!complete),"remaining. No fits or files changed.\n")
    return(invisible(list(plan=plan,progress=progress)))
  }
  # collect reads all completed cases, so reject unexpected completed extras first.
  existing <- if(dir.exists(full)) list.files(full,"^_MC_FINISHED[.]txt$",recursive=TRUE,full.names=TRUE) else character()
  normalized <- function(x) tolower(gsub("\\\\","/",x))
  if(length(setdiff(normalized(existing),normalized(marker_paths(plan)))))
    stop("Completed cases outside the declared study exist. Use a separate output root or inspect them first.")
  source(file.path(project_dir,"replication/run_from_RStudio.R"),local=TRUE)
  metadata <- file.path(output_root,"feasible_pair_design")
  dir.create(metadata,recursive=TRUE,showWarnings=FALSE)
  stamp <- format(Sys.time(),"%Y%m%d_%H%M%S")
  for(name in c("run_plan.csv","run_status.csv")) if(file.exists(file.path(full,name)))
    file.copy(file.path(full,name),file.path(metadata,paste0(stamp,"_before_resume_",name)),overwrite=FALSE)
  write.csv(plan,file.path(metadata,"case_plan_100_per_design.csv"),row.names=FALSE)
  exclusions <- read.csv(file.path(project_dir,"replication/plans/local_pair_infeasible_seeds.csv"),stringsAsFactors=FALSE)
  write.csv(exclusions,file.path(metadata,"excluded_generator_seeds.csv"),row.names=FALSE)
  writeLines(c("D9/D10 are evaluated conditional on feasibility of the specified observation design.",
    "Original indices 50 and 70 have maximum feasible post-only size 23; the required size remains 24.",
    "Both designs use indices 1:102 excluding 50 and 70, retaining seed=base+index.",
    "The next common seeds (indices 101 and 102) replace the infeasible draws.",
    "Rejection is based on design feasibility; outcome and estimator performance are not selection criteria.",
    "The truth-side linear Econ-X R2 diagnostic produces warnings only; orthogonalization strength remains 0.75.",
    "Completed results retain their original paths and indices."),file.path(metadata,"DESIGN_NOTE.txt"))
  legacy <- plan[!plan$design %in% c("D9","D10"),]
  if(!all(file.exists(marker_paths(legacy))))
    run_replication("full",engine=engine,designs=paste(paste0("D",1:8),collapse=","),
      reps="1:100",project_dir=project_dir,output_root=output_root)
  else cat("D1-D8 are complete; reusing all 800 cases.\n")
  pair <- plan[plan$design %in% c("D9","D10"),]
  if(!all(file.exists(marker_paths(pair))))
    run_replication("full",engine=engine,designs="D9,D10",reps=paste(unique(pair$rep),collapse=","),
      project_dir=project_dir,output_root=output_root)
  else cat("D9-D10 are complete; reusing all 200 cases.\n")
  if(!all(file.exists(marker_paths(plan)))) stop("Some planned cases remain incomplete.")
  run_replication("collect",engine=engine,project_dir=project_dir,output_root=output_root)
  run_replication("covariate",mode="full",designs="primary",reps="1:100",input_root=full,
    project_dir=project_dir,output_root=output_root)
  run_replication("weights",designs="all",reps="1:102",input_root=full,
    project_dir=project_dir,output_root=output_root)
  # Separate deliberately unrequested indices from genuinely missing weight files.
  audit_file <- file.path(output_root,"weights/weight_coverage_audit.csv")
  checked <- graphscm_100_weight_coverage(read.csv(audit_file,stringsAsFactors=FALSE),plan)
  write.csv(checked$outside,file.path(metadata,"weight_audit_outside_declared_plan.csv"),row.names=FALSE)
  write.csv(checked$coverage,audit_file,row.names=FALSE)
  cov_path <- readLines(file.path(output_root,"covariate/LATEST_SUMMARY.txt"),warn=FALSE)
  cf <- read.csv(file.path(cov_path,"covariate_CF_replications.csv"),stringsAsFactors=FALSE)
  counts <- table(unique(cf[c("scenario","seed")])$scenario)
  stopifnot(length(counts)==5L,all(counts==100L))
  progress$complete <- progress$planned; progress$remaining <- 0L
  write.csv(progress,file.path(metadata,"completion_100_per_design.csv"),row.names=FALSE)
  cat("Completed: D1-D10 each 100 cases; Cov-SCM D1-D5 each 100 cases.\n")
  cat("Graph/ST summaries:",file.path(full,"_publication_summary"),"\n")
  cat("Cov-SCM summaries:",cov_path,"\n")
  cat("Design and seed records:",metadata,"\n")
  invisible(progress)
}
