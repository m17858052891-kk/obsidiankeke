entry <- sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1])
project <- normalizePath(file.path(dirname(entry),"../.."),winslash="/",mustWork=TRUE)
source(file.path(project,"replication/run_100_replications.R"))
# The generator's SIM_LOCAL_ setting must disable truth-side diagnostic rejection.
runner <- parse(file.path(project,"replication/original/R/02_run_one.R"))
settings <- Filter(function(x)is.call(x)&&identical(x[[1]],quote(Sys.setenv)),as.list(runner))[[1L]]
stopifnot(identical(as.list(settings)[["SIM_LOCAL_DGP2_ALIGNMENT_STRICT"]],"false"),
          is.null(as.list(settings)[["MC_LOCAL_DGP2_ALIGNMENT_STRICT"]]))
fail <- function(expr) stopifnot(inherits(tryCatch({force(expr);NULL},error=identity),"error"))
plan <- graphscm_100_case_plan(project)
stopifnot(nrow(plan)==1000L,all(table(plan$design)==100L),
  identical(plan$rep[plan$design=="D9"],as.integer(setdiff(1:102,c(50,70)))),
  identical(plan$seed[plan$design=="D9"],plan$seed[plan$design=="D10"]),
  all(c(50L,70L) %in% plan$rep[plan$design=="D1"]),
  all(plan$seed[plan$design=="D9" & plan$rep %in% c(101L,102L)]==c(20261030L,20261031L)))
methods <- c("GeoEco_SCM","Graph_SCM","Ordinary_SCM","uniform_weights")
audit <- plan[rep(seq_len(nrow(plan)),each=4L),c("design","rep")]
audit$method <- rep(methods,nrow(plan));audit$status <- "complete"
audit$status[audit$method=="Ordinary_SCM"] <- "partial_scientific_coverage"
outside <- data.frame(design=c("D9","D10","D1"),rep=c(50L,70L,101L),
  method="GeoEco_SCM",status="case_not_found")
checked <- graphscm_100_weight_coverage(rbind(audit,outside),plan)
stopifnot(nrow(checked$coverage)==4000L,nrow(checked$outside)==3L)
bad <- audit;bad$status[1] <- "method_weights_not_saved"
fail(graphscm_100_weight_coverage(bad,plan))
fail(graphscm_100_weight_coverage(audit[-1,],plan))
bad <- outside;bad$status[1] <- "complete"
fail(graphscm_100_weight_coverage(rbind(audit,bad),plan))
check_dry_run <- function() {
  scratch <- tempfile("graphscm_plan_");dir.create(scratch)
  scratch <- normalizePath(scratch,winslash="/",mustWork=TRUE)
  temp_root <- paste0(normalizePath(tempdir(),winslash="/",mustWork=TRUE),"/")
  stopifnot(startsWith(paste0(scratch,"/"),temp_root))
  on.exit(unlink(scratch,recursive=TRUE),add=TRUE)
  folder <- file.path(scratch,"full_Rcpp",paste0("seed_",plan$seed[1]),plan$scenario[1],"results_graph_geoeco")
  dir.create(folder,recursive=TRUE)
  marker <- file.path(folder,"_MC_FINISHED.txt");writeLines("fixture",marker)
  before <- tools::md5sum(marker)
  result <- run_graphscm_100(project,scratch,dry_run=TRUE)
  stopifnot(sum(result$progress$complete)==1L,sum(result$progress$remaining)==999L,
    identical(before,tools::md5sum(marker)),!dir.exists(file.path(scratch,"feasible_pair_design")))
}
check_dry_run()
cat("PASS: paired 100-case plan, replacement seeds, unchanged legacy indices, missing/out-of-plan weight guards, read-only resumption plan.\n")
