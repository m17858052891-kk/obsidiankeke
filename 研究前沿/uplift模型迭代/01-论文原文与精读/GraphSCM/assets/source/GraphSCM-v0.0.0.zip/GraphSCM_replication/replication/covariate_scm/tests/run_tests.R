args <- grep("^--file=", commandArgs(FALSE), value = TRUE)
root <- normalizePath(file.path(dirname(sub("^--file=", "", args[1])), ".."))
source(file.path(root, "R", "core.R"))
source(file.path(root, "R", "data.R"))
close_to <- function(a, b, tol = 1e-7) {
  if (length(a) != length(b) || any(!is.finite(a)) ||
      max(abs(as.numeric(a) - as.numeric(b)), 0) > tol) stop("Numeric assertion failed.")
}
must_fail <- function(expr) {
  if (!inherits(tryCatch({force(expr); NULL}, error = identity), "error"))
    stop("Expected an error.")
}
# Two-donor solutions and an outside-hull target.
fit <- fit_covariate_scm(matrix(c(0.5, 3), ncol = 1),
                         matrix(c(0, 2), ncol = 1))
close_to(fit$W[1, ], c(0.75, 0.25))
close_to(fit$W[2, ], c(0, 1))
# Indistinguishable donors must be allocated equal weights by the ridge.
fit <- fit_covariate_scm(matrix(0.5, 1, 1), matrix(c(0, 0, 1, 1), 4, 1))
close_to(fit$W[1, ], rep(0.25, 4), 1e-5)
flat <- fit_covariate_scm(matrix(1, 2, 3), matrix(1, 4, 3))
close_to(flat$W, matrix(0.25, 2, 4))
# Small QP oracle: enumerate all simplex faces rather than follow the active-set path.
set.seed(17)
for (iteration in 1:15) {
  D <- matrix(rnorm(12), 4, 3)
  x <- rnorm(3)
  Q <- 2 * (tcrossprod(D) / 3 + diag(0.01, 4))
  b <- -2 * as.numeric(D %*% x) / 3
  objectives <- weights <- list()
  for (mask in 1:15) {
    ii <- which(as.logical(intToBits(mask)[1:4]))
    k <- length(ii)
    K <- rbind(cbind(Q[ii, ii, drop = FALSE], rep(1, k)), c(rep(1, k), 0))
    z <- solve(K, c(-b[ii], 1))[seq_len(k)]
    if (min(z) < -1e-10) next
    w <- numeric(4);w[ii] <- z
    weights[[length(weights) + 1]] <- w
    objectives[[length(objectives) + 1]] <- sum(w * (Q %*% w)) / 2 + sum(b * w)
  }
  expected <- weights[[which.min(unlist(objectives))]]
  solved <- cov_qp(Q, b)
  close_to(solved$w, expected)
}
must_fail(fit_covariate_scm(matrix(NA_real_, 1, 2), matrix(1, 3, 2)))
must_fail(fit_covariate_scm(matrix(1, 1, 2), matrix(1, 3, 3)))
# Hand-calculated outcome/ATT metrics; percentage transformation follows mean log effects.
dat <- list(target = data.frame(point_id = c("a", "b")),
  donor = data.frame(point_id = c("c", "d")), years = 1:2,
  pre_years = 1L, post_years = 2L, groups = c("complete_pre", "post_only"),
  donor_log = matrix(c(0, 0, 0, 2), 2, 2),
  true_cf_log = matrix(c(0, 0, 0.5, 1.5), 2, 2),
  observed_log = matrix(c(0, NA, 0.7, 1.9), 2, 2),
  tau_log = matrix(c(0, 0, 0.2, 0.4), 2, 2))
W <- matrix(c(0.75, 0.25, 0.25, 0.75), 2, 2, byrow = TRUE)
evaluation <- cov_evaluate(W, dat, "test")
close_to(evaluation$cf$CF_RMSE_log, rep(0, 3))
close_to(evaluation$att$ATT_RMSE_pp, rep(0, 3))
# Frozen generation must agree with the archive, preserve the caller RNG, and ignore external overrides.
generator <- file.path(root, "vendor", "generator_legacy8.R")
cf <- read.csv(file.path(root, "reference", "counterfactual_replications.csv"))
att <- read.csv(file.path(root, "reference", "ATT_replications.csv"))
set.seed(123);before <- .Random.seed
Sys.setenv(SIM_N_TARGET = "999")
dat <- cov_generate(generator, "smooth_geo_only", 20360923L)
stopifnot(identical(before, .Random.seed), Sys.getenv("SIM_N_TARGET") == "999")
Sys.unsetenv("SIM_N_TARGET")
audit <- cov_archive_check(dat, cf, att, "smooth_geo_only", 20360923L)
stopifnot(all(audit$max_abs_difference <= audit$tolerance))
# Read the saved original schema, aligning scrambled rows by location ID.
to_points <- function(attributes, log_prices, type) {
  z <- attributes
  z$group_type <- type
  for (t in seq_along(dat$years)) z[[paste0("price_", dat$years[t])]] <- exp(log_prices[, t])
  z
}
target_points <- to_points(dat$target, dat$observed_log, "Treatment")
donor_points <- to_points(dat$donor, dat$donor_log, "Control")
target_meta <- dat$target
target_meta$obs_group <- dat$groups
obj <- list(config = list(scenario = dat$scenario, years = dat$years,
    period_pre = dat$pre_years, period_post = dat$post_years),
  target_meta = target_meta,
  target_points = target_points[rev(seq_len(nrow(target_points))), ],
  all_points = rbind(target_points, donor_points),
  simulation_truth = list(seed = dat$seed,
    true_cf_log = dat$true_cf_log, tau_log = dat$tau_log))
saved <- tempfile(fileext = ".rds")
saveRDS(obj, saved)
read_back <- cov_read_original(saved, dat$scenario, dat$seed)
close_to(read_back$true_cf_log, dat$true_cf_log, 1e-13)
close_to(read_back$donor_log, dat$donor_log, 1e-13)
invisible(cov_archive_check(read_back, cf, att, dat$scenario, dat$seed))
must_fail(cov_read_original(saved, dat$scenario, dat$seed + 1L))
saveRDS(dat, saved)
read_back <- cov_read_original(saved, dat$scenario, dat$seed)
close_to(read_back$true_cf_log, dat$true_cf_log, 0)
unlink(saved)
# Extra repetitions must use a completed matching dataset/reference pair.
check_extended_inputs <- function() {
  fixture <- tempfile("cov_saved_reference_"); dir.create(fixture)
  temporary_root <- paste0(normalizePath(tempdir(),winslash="/"),"/")
  stopifnot(startsWith(paste0(normalizePath(fixture,winslash="/"),"/"),temporary_root))
  on.exit(unlink(fixture,recursive=TRUE),add=TRUE)
  extended <- dat; extended$seed <- 20361023L
  folder <- file.path(fixture,"seed_20361023","smooth_geo_only")
  result <- file.path(folder,"results_graph_geoeco")
  dir.create(result,recursive=TRUE)
  saveRDS(extended,file.path(folder,"M1_LP_synthetic_dataset.rds"))
  sources <- list(cf=cf,att=att)
  filenames <- c("simulation_counterfactual_method_comparison_by_group.csv",
                 "simulation_ATT_method_comparison_by_group.csv")
  for (i in seq_along(sources)) {
    x <- sources[[i]]
    x <- x[x$scenario==dat$scenario & x$seed==dat$seed,,drop=FALSE]
    x$rep <- 101L; x$seed <- extended$seed
    write.csv(x,file.path(result,filenames[i]),row.names=FALSE)
  }
  marker <- file.path(result,"_MC_FINISHED.txt")
  must_fail(cov_prepare_references(root,fixture,dat$scenario,101L))
  writeLines("completed test fixture",marker)
  reference <- cov_prepare_references(root,fixture,dat$scenario,101L)
  audit <- cov_archive_check(extended,reference$cf,reference$att,dat$scenario,extended$seed)
  stopifnot(all(audit$max_abs_difference<=audit$tolerance),nrow(reference$sources)==1L)
  wrong <- read.csv(file.path(result,filenames[1])); wrong$seed <- wrong$seed+1L
  write.csv(wrong,file.path(result,filenames[1]),row.names=FALSE)
  must_fail(cov_prepare_references(root,fixture,dat$scenario,101L))
  must_fail(cov_prepare_references(root,NULL,dat$scenario,101L))
}
check_extended_inputs()
# Features-only fitting: changing truth and POST outcomes cannot change its input or weights.
features <- cov_features()
X <- as.matrix(dat$target[, features]);D <- as.matrix(dat$donor[, features])
original <- fit_covariate_scm(X[1:4, ], D)
dat$true_cf_log[] <- 999
dat$observed_log[, match(dat$post_years, dat$years)] <- -999
again <- fit_covariate_scm(as.matrix(dat$target[1:4, features]), D)
close_to(original$W, again$W, 0)
cat("PASS: analytic QPs, global-face oracle, evaluation, archive check, original-RDS alignment, RNG isolation, information separation.\n")
