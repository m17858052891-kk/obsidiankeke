# Read-only checks; no model estimation and no package installation.
validate_public <- function(project_root) {
  root <- file.path(project_root, "replication")
  catalog <- read.csv(file.path(root, "design_catalog.csv"), stringsAsFactors = FALSE)
  stopifnot(identical(catalog$paper_id, paste0("D", 1:10)),
            identical(catalog$role, c(rep("primary", 5), rep("supplementary", 5))),
            !anyDuplicated(catalog$scenario), !anyDuplicated(catalog$legacy_id))
  cf <- read.csv(file.path(project_root, "data", "counterfactual_replications.csv"), na.strings = c("NA", ""))
  plan <- read.csv(file.path(project_root,"data/study_plan.csv"),stringsAsFactors=FALSE)
  for (i in seq_len(nrow(catalog))) {
    x <- unique(cf[cf$scenario == catalog$scenario[i], c("rep", "seed")])
    expected <- plan[plan$scenario==catalog$scenario[i],c("rep","seed")]
    stopifnot(nrow(x) == 100L, setequal(paste(x$rep,x$seed),paste(expected$rep,expected$seed)),
              all(x$seed == catalog$seed_base[i] + x$rep))
  }
  stopifnot(catalog$seed_base[9] == catalog$seed_base[10])
  for (name in c("counterfactual_replications.csv", "ATT_replications.csv")) {
    paths <- c(file.path(project_root, "data", name), file.path(root, "covariate_scm", "reference", name))
    stopifnot(length(unique(unname(tools::md5sum(paths)))) == 1L)
  }
  for (file in list.files(root, "[.]R$", recursive = TRUE, full.names = TRUE)) parse(file, keep.source = FALSE)
  full_packages <- c("pacman", "sf", "tidyverse", "data.table", "glue", "Matrix", "FNN", "scales",
    "osqp", "CVXR", "mgcv", "readr", "dplyr", "tidyr", "tibble", "ggplot2", "forcats")
  missing <- full_packages[!vapply(full_packages, requireNamespace, logical(1), quietly = TRUE)]
  cat("PASS: D1-D10 catalog, all 1000 published scenario/seed pairs, paired seeds, reference copies, and R syntax.\n")
  cat("Base-R summaries and Cov-SCM are available without extra packages.\n")
  if (length(missing)) cat("Full-estimator dependencies not installed:", paste(missing, collapse = ", "), "\n")
  else cat("All full-estimator dependencies are installed.\n")
  invisible(TRUE)
}
