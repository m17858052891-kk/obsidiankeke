entry <- sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1])
root <- dirname(dirname(normalizePath(entry,winslash="/",mustWork=TRUE)))
project <- dirname(dirname(root))
source(file.path(root,"R/backend.R"))
native <- scm_load_rcpp()
reference <- scm_reference_environment(project)
fast <- scm_accelerate_function(reference$fit_smooth_scm,native)
stop_error <- function(expr) stopifnot(inherits(tryCatch({ force(expr); NULL },error=identity),"error"))
set.seed(6106)
for (j in c(2L,24L)) {
  x <- matrix(rnorm(13*j),13,j)
  stopifnot(max(abs(native$scm_project_rows_cpp(x)-reference$project_rows_simplex(x)))<1e-12)
}
stopifnot(all(native$scm_project_rows_cpp(matrix(c(-2,0,7),3,1))==1))
stop_error(native$scm_project_rows_cpp(matrix(NA_real_,2,2)))
cases <- 0L; differences <- numeric()
for (n in c(3L,17L)) for (j in c(2L,5L)) for (lambda in c(0,.03,4)) {
  tt <- 5L
  yc <- matrix(rnorm(tt*j),tt,j)
  truth <- matrix(rexp(n*j),n,j); truth <- truth/rowSums(truth)
  yt <- truth%*%t(yc)+matrix(rnorm(n*tt,sd=.01),n,tt)
  yt[n,] <- NA_real_
  if (n>3) yt[seq(2,n-1,by=2),c(1,3)] <- NA_real_
  edges <- data.frame(i=seq_len(n-1),k=2:n,a=seq(.2,2,length.out=n-1))
  graph <- list(edges=edges,Dg=Matrix::sparseMatrix(i=rep(seq_len(nrow(edges)),each=2),
    j=as.vector(t(as.matrix(edges[c("i","k")]))),
    x=as.vector(t(cbind(sqrt(edges$a),-sqrt(edges$a)))),dims=c(n-1,n)))
  reference$target_meta <- data.frame(point_id=paste0("t",seq_len(n)))
  reference$control_df <- data.frame(point_id=paste0("c",seq_len(j)))
  for (warm in c(FALSE,TRUE)) {
    start <- if (warm) matrix(rnorm(n*j),n,j) else NULL
    before <- serialize(list(yt,yc,graph,start),NULL)
    rng_before <- .Random.seed
    args <- list(Yt_train=yt,Yc_train=yc,graph_obj=graph,lambda=lambda,rho=.001,
      W_start=start,max_iter=750L,min_iter=20L,tol=1e-8)
    a <- do.call(reference$fit_smooth_scm,args); b <- do.call(fast,args)
    delta <- max(abs(a$W-b$W))
    stopifnot(delta<1e-8,max(abs((a$W-b$W)%*%t(yc)))<1e-8,
      abs(a$value-b$value)<1e-9,identical(a$status,b$status),
      identical(a$fista_iter,b$fista_iter),identical(dimnames(a$W),dimnames(b$W)),
      min(b$W)>=-1e-14,max(abs(rowSums(b$W)-1))<1e-12,
      abs(a$projected_gradient_norm-b$projected_gradient_norm)<1e-7,
      identical(rng_before,.Random.seed),
      identical(before,serialize(list(yt,yc,graph,start),NULL)))
    cases <- cases+1L; differences <- c(differences,delta)
  }
}
# Preserve nonconvergence/stale-last-check diagnostics for an unaligned iteration cap.
args$max_iter <- 13L; args$min_iter <- 100L; args$W_start <- NULL
a <- do.call(reference$fit_smooth_scm,args); b <- do.call(fast,args)
stopifnot(a$status=="max_iter_fista",b$status==a$status,b$fista_iter==13L,
  max(abs(a$W-b$W))<1e-8,abs(a$value-b$value)<1e-9)
args$Yt_train[,] <- NA_real_
stop_error(do.call(fast,args))
# A zero-edge graph remains usable for an ordinary, unregularized fit.
reference$target_meta <- data.frame(point_id=c("x","y"))
reference$control_df <- data.frame(point_id=c("a","b"))
empty_graph <- list(edges=data.frame(a=numeric()),Dg=Matrix::sparseMatrix(
  i=integer(),j=integer(),x=numeric(),dims=c(0,2)))
a <- reference$fit_smooth_scm(matrix(1:6/10,2),matrix(1:6/9,3),empty_graph,
  lambda=0,max_iter=100L,min_iter=0L)
b <- fast(matrix(1:6/10,2),matrix(1:6/9,3),empty_graph,lambda=0,max_iter=100L,min_iter=0L)
stopifnot(max(abs(a$W-b$W))<1e-8)
# The production hook installs the accelerated function before later expressions.
fixture <- tempfile(fileext=".R")
writeLines(c("fit_smooth_scm <-",deparse(reference$fit_smooth_scm),
  "hook_was_installed <- exists('GRAPHSCM_FISTA_ENGINE', inherits=FALSE)"),fixture)
production <- new.env(parent=reference)
scm_source_estimator(fixture,production,engine="Rcpp")
stopifnot(isTRUE(production$hook_was_installed),is.function(production$fit_smooth_scm_R))
unlink(fixture)
# Explicit extra repetitions keep the archived seed mapping and are collected.
old_output <- Sys.getenv("GRAPHSCM_OUTPUT_ROOT",unset=NA_character_)
fixture_root <- tempfile("scm_extended_plan_")
Sys.setenv(GRAPHSCM_OUTPUT_ROOT=fixture_root)
config <- new.env(parent=globalenv())
source(file.path(project,"replication/original/R/00_config.R"),local=config)
stopifnot(config$N_REPS_DEFAULT==20L,config$seed_for("D1",100L)==20361022L)
for (rep in c(1L,21L,100L)) {
  folder <- config$result_dir_for(config$SCENARIOS_ALL[1],rep)
  dir.create(folder,recursive=TRUE,showWarnings=FALSE)
  writeLines("done",file.path(folder,"_MC_FINISHED.txt"))
}
dir.create(config$result_dir_for(config$SCENARIOS_ALL[1],99L),recursive=TRUE,showWarnings=FALSE)
stopifnot(identical(config$completed_reps_for("D1"),c(1L,21L,100L)))
if (is.na(old_output)) Sys.unsetenv("GRAPHSCM_OUTPUT_ROOT") else Sys.setenv(GRAPHSCM_OUTPUT_ROOT=old_output)
cat("PASS:",cases,"R/Rcpp fits; maximum weight difference",format(max(differences),digits=5),
  "; simplex projection, warm starts, missing histories, graph storage, diagnostics, immutable inputs/RNG, source hook and extended seed/collection mapping.\n")
