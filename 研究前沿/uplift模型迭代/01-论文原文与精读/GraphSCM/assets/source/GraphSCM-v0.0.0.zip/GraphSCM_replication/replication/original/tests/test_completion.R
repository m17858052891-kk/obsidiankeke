entry <- sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1])
root <- dirname(dirname(normalizePath(entry,winslash="/",mustWork=TRUE)))
source(file.path(root,"R/completion.R"))
fixture <- function() {
  folder <- file.path(tempfile("completion_fixture_"),"results_graph_geoeco")
  dir.create(folder,recursive=TRUE)
  tids <- paste0("T",1:3); dids <- paste0("C",1:2)
  donors <- matrix(c(1,2,2,3,3,5,4,6),2,dimnames=list(dids,as.character(2000:2003)))
  truth_w <- rbind(c(1,0),c(.5,.5),c(0,1)); dimnames(truth_w) <- list(tids,dids)
  fitted <- rbind(c(.8,.2),c(.4,.6),c(.1,.9)); dimnames(fitted) <- list(tids,dids)
  groups <- c("complete_pre","partial_pre","post_only")
  data <- list(config=list(scenario="unit",period_post=2002:2003),
    simulation_truth=list(seed=123L,W_true=truth_w,true_cf_log=truth_w%*%donors),
    target_meta=data.frame(point_id=tids,obs_group=groups),
    all_points=data.frame(point_id=dids,price_2002=exp(donors[,3]),price_2003=exp(donors[,4])))
  saveRDS(data,file.path(dirname(folder),"M1_LP_synthetic_dataset.rds"))
  write <- function(x,name) write.csv(x,file.path(folder,name),row.names=FALSE,na="")
  write(data.frame(point_id=tids,fitted,check.names=FALSE),"joint_scm_weights.csv")
  write(data.frame(lambda=.1,beta_econ=0),"selected_parameters.csv")
  write(data.frame(point_id=tids,model_data_identified=TRUE),"postonly_graph_anchor_diagnostics.csv")
  error <- (fitted-truth_w)%*%donors[,3:4]
  rows <- lapply(c(groups,"ALL"),function(group) {
    selected <- if (group=="ALL") rep(TRUE,3) else groups==group
    data.frame(obs_group=group,n_sites=sum(selected),n_eval_sites=sum(selected),
      CF_RMSE_log=sqrt(mean(error[selected,,drop=FALSE]^2)),
      CF_MAE_log=mean(abs(error[selected,,drop=FALSE])),CF_signed_mean_bias_log=mean(error[selected,,drop=FALSE]))
  })
  cf <- do.call(rbind,lapply(c("GeoEco_SCM","Graph_SCM","Ordinary_SCM","uniform_weights"),
    function(method) cbind(method=method,do.call(rbind,rows))))
  write(cf,"simulation_counterfactual_method_comparison_by_group.csv")
  att <- cf[c("method","obs_group","n_sites","n_eval_sites")]; att$ATT_RMSE_pp <- 0
  write(att,"simulation_ATT_method_comparison_by_group.csv")
  write(data.frame(scenario="unit",component="fit",elapsed_sec=2),"simulation_runtime_breakdown.csv")
  for (name in c("simulation_runtime_mc_projection.csv","simulation_validation_scorecard.csv","simulation_fista_fit_runtime_log.csv"))
    write(data.frame(stage="complete",value=1),name)
  folder
}
reject <- function(folder,expr) {
  error <- tryCatch({ force(expr); NULL },error=identity)
  stopifnot(inherits(error,"error"),!file.exists(file.path(folder,"_MC_FINISHED.txt")))
}
folder <- fixture()
before <- tools::md5sum(list.files(folder,full.names=TRUE))
checked <- scm_finalize_case(folder,"unit",123L,"Rcpp")
stopifnot(checked$max_CF_reconstruction_difference<1e-12,
  file.exists(file.path(folder,"_MC_FINISHED.txt")),
  identical(unname(before),unname(tools::md5sum(names(before)))))
marker_hash <- tools::md5sum(file.path(folder,"_MC_FINISHED.txt"))
scm_finalize_case(folder,"unit",123L,"Rcpp")
stopifnot(identical(marker_hash,tools::md5sum(file.path(folder,"_MC_FINISHED.txt"))))
folder <- fixture(); unlink(file.path(folder,"simulation_runtime_mc_projection.csv"))
reject(folder,scm_finalize_case(folder,"unit",123L,"Rcpp"))
folder <- fixture()
reject(folder,scm_finalize_case(folder,"unit",124L,"Rcpp"))
reject(folder,scm_finalize_case(folder,"other",123L,"Rcpp"))
weights <- read.csv(file.path(folder,"joint_scm_weights.csv")); weights$C1[1] <- 1.5
write.csv(weights,file.path(folder,"joint_scm_weights.csv"),row.names=FALSE)
reject(folder,scm_finalize_case(folder,"unit",123L,"Rcpp"))
folder <- fixture()
cf <- read.csv(file.path(folder,"simulation_counterfactual_method_comparison_by_group.csv"))
cf$CF_RMSE_log[1] <- cf$CF_RMSE_log[1]+.01
write.csv(cf,file.path(folder,"simulation_counterfactual_method_comparison_by_group.csv"),row.names=FALSE)
reject(folder,scm_finalize_case(folder,"unit",123L,"Rcpp"))
folder <- fixture()
scm_finalize_case(folder,"unit",123L,"Rcpp",origin="recovered_saved_output")
stopifnot(any(grepl("origin=recovered_saved_output",readLines(file.path(folder,"_MC_FINISHED.txt")))))
test_relative_output <- function() {
  previous <- Sys.getenv("GRAPHSCM_OUTPUT_ROOT",unset=NA_character_)
  previous_wd <- getwd()
  on.exit({setwd(previous_wd); if (is.na(previous)) Sys.unsetenv("GRAPHSCM_OUTPUT_ROOT") else Sys.setenv(GRAPHSCM_OUTPUT_ROOT=previous)},add=TRUE)
  temporary <- tempfile("relative_output_fixture_"); dir.create(temporary)
  setwd(temporary); Sys.setenv(GRAPHSCM_OUTPUT_ROOT="relative/results")
  cfg <- new.env(parent=globalenv())
  source(file.path(root,"R/00_config.R"),local=cfg)
  expected <- normalizePath("relative/results",winslash="/",mustWork=TRUE)
  stopifnot(identical(cfg$OUTPUT_ROOT,expected))
  setwd(previous_wd)
  stopifnot(startsWith(cfg$result_dir_for("smooth_geo_only",1L),paste0(expected,"/")))
}
test_relative_output()
cat("PASS: normal completion, idempotency, missing final output, wrong scenario/seed, invalid weights, mismatched CF metrics, recovery without rewriting results and relative-output anchoring.\n")
