Representative PRE-validation FISTA solves; not the full adaptive CV search or an end-to-end Monte Carlo timing.
Both engines use the same observed inputs, graph, cold start, 1500-iteration cap, minimum 100 iterations and 2e-5 tolerance.
Timing excludes compilation and data generation. Each cell is the median of the specified repeats; engine order alternates.
Geographic/economic graphs are constructed with base R for this benchmark; validation masks and candidates are deliberately small representative sets.
Uniform CF/ATT agreement verifies regenerated or saved input data against the archived experiment.
Final OSQP fits, full adaptive searches, spatio-temporal benchmarks and all-200-case timings are not measured here.
