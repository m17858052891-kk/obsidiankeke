# Scenario names and archived seed bases are independent of paper numbering.
config_sources <- unlist(lapply(sys.frames(),function(frame)
  if (exists("ofile",envir=frame,inherits=FALSE)) get("ofile",envir=frame) else NULL),use.names=FALSE)
config_source <- tail(config_sources[basename(config_sources)=="00_config.R"],1L)
if (length(config_source)!=1L) stop("Source this configuration from a replication entry point.")
R_DIR <- dirname(normalizePath(config_source, winslash = "/", mustWork = TRUE))
CODE_ROOT <- normalizePath(file.path(R_DIR, ".."), winslash = "/", mustWork = TRUE)
PROJECT_ROOT <- normalizePath(file.path(CODE_ROOT, ".."), winslash = "/", mustWork = TRUE)
INTERNAL_DIR <- file.path(CODE_ROOT, "internal")
DESIGN_CATALOG <- utils::read.csv(file.path(PROJECT_ROOT, "design_catalog.csv"), stringsAsFactors = FALSE)
SCENARIOS_ALL <- DESIGN_CATALOG$scenario
SCENARIOS_LEGACY8 <- DESIGN_CATALOG$scenario[DESIGN_CATALOG$backend == "legacy8"]
SCENARIOS_LOCAL2 <- DESIGN_CATALOG$scenario[DESIGN_CATALOG$backend == "local_pair"]
N_REPS_DEFAULT <- 20L
N_REPS_MAX <- 10000L  # Explicit extensions only; the archived default remains 20.
OUTPUT_ROOT <- Sys.getenv("GRAPHSCM_OUTPUT_ROOT", unset = file.path(CODE_ROOT, "output"))
dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)
# The generators change working directory; anchor relative output paths first.
OUTPUT_ROOT <- normalizePath(OUTPUT_ROOT,winslash="/",mustWork=TRUE)
scenario_for <- function(value) {
  matched <- match(value, DESIGN_CATALOG$paper_id)
  value[!is.na(matched)] <- DESIGN_CATALOG$scenario[matched[!is.na(matched)]]
  if (any(!value %in% SCENARIOS_ALL)) stop("Unknown design/scenario: ", paste(value, collapse = ", "))
  value
}
seed_for <- function(scenario, rep) {
  scenario <- scenario_for(scenario)
  if (length(scenario) != 1L || length(rep) != 1L || !is.finite(rep) ||
      rep != as.integer(rep) || rep < 1L || rep > N_REPS_MAX)
    stop("Select one design and an integer replication from 1 to ",N_REPS_MAX,".")
  as.integer(DESIGN_CATALOG$seed_base[match(scenario, SCENARIOS_ALL)] + rep)
}
generator_for <- function(scenario) {
  if (scenario %in% SCENARIOS_LEGACY8) return(file.path(INTERNAL_DIR, "generator_legacy8.R"))
  if (scenario %in% SCENARIOS_LOCAL2) return(file.path(INTERNAL_DIR, "generator_local_paired_v9.R"))
  stop("Unknown scenario: ", scenario)
}
estimator_for <- function(scenario) {
  if (scenario %in% SCENARIOS_LEGACY8) return(file.path(INTERNAL_DIR, "estimator_legacy8_final.R"))
  if (scenario %in% SCENARIOS_LOCAL2) return(file.path(INTERNAL_DIR, "estimator_local_paired_v9_final.R"))
  stop("Unknown scenario: ", scenario)
}
result_dir_for <- function(scenario, rep) {
  file.path(OUTPUT_ROOT, paste0("seed_", seed_for(scenario, rep)), scenario, "results_graph_geoeco")
}
completed_reps_for <- function(scenario) {
  scenario <- scenario_for(scenario)
  if (length(scenario)!=1L) stop("Select one scenario.")
  folders <- list.dirs(OUTPUT_ROOT,recursive=FALSE,full.names=TRUE)
  folders <- folders[grepl("^seed_[0-9]+$",basename(folders))]
  seeds <- suppressWarnings(as.integer(sub("^seed_","",basename(folders))))
  reps <- seeds-DESIGN_CATALOG$seed_base[match(scenario,SCENARIOS_ALL)]
  keep <- !is.na(reps) & reps>=1L & reps<=N_REPS_MAX
  folders <- folders[keep]; reps <- reps[keep]
  complete <- file.exists(file.path(folders,scenario,"results_graph_geoeco","_MC_FINISHED.txt"))
  sort(as.integer(reps[complete]))
}
required_packages <- c("pacman", "sf", "tidyverse", "data.table", "glue", "Matrix", "FNN",
  "scales", "osqp", "CVXR", "mgcv", "readr", "dplyr", "tidyr", "tibble", "ggplot2", "forcats")
