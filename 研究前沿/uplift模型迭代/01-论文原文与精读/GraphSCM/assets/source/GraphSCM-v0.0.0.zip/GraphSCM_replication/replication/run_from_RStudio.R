# Source this file from the extracted archive's top-level working directory.
# Defining this helper does not start a simulation.
run_replication <- function(task = "summary", mode = "test", designs = NULL,
                            reps = NULL, input_root = NULL, output_root = NULL,
                            dry_run = FALSE, project_dir = ".", engine = "R",
                            benchmark_repeats = 3L) {
  entry <- normalizePath(file.path(project_dir, "replication/run.R"),
    winslash = "/", mustWork = TRUE)
  rscript <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
  arguments <- c("--vanilla", shQuote(entry), paste0("--task=", task), paste0("--mode=", mode),
    shQuote(paste0("--engine=",engine)),shQuote(paste0("--benchmark-repeats=",benchmark_repeats)))
  for (key in c("designs", "reps", "input-root", "output-root")) {
    value <- switch(key, designs = designs, reps = reps, `input-root` = input_root,
                    `output-root` = output_root)
    if (!is.null(value)) arguments <- c(arguments, shQuote(paste0("--", key, "=", value)))
  }
  if (isTRUE(dry_run)) arguments <- c(arguments, "--dry-run")
  previous <- Sys.getenv("LC_ALL", unset = NA_character_)
  if (.Platform$OS.type == "windows") {
    Sys.setenv(LC_ALL = "English_United States.utf8")
    on.exit(if (is.na(previous)) Sys.unsetenv("LC_ALL") else Sys.setenv(LC_ALL = previous), add = TRUE)
  }
  status <- system2(rscript, args = arguments)
  if (status != 0L) stop("Replication task stopped with exit code ", status)
  invisible(status)
}
