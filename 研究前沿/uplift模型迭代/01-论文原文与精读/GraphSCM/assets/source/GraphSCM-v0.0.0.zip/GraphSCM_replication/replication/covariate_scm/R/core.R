# Covariate-only synthetic control. Base R and stats only.
# Fitting functions accept observed PRE attributes, never outcomes or truth.

cov_qp <- function(Q, linear, gap_tol = 1e-13, max_iter = 10000L) {
  j <- length(linear)
  stopifnot(is.matrix(Q), all(dim(Q) == c(j, j)), j > 0L,
            all(is.finite(Q)), all(is.finite(linear)))
  Q <- (Q + t(Q)) / 2
  scale <- max(abs(Q), abs(linear), 1e-12)
  H <- Q / scale
  b <- linear / scale
  tol <- min(1e-10, gap_tol / scale)
  w <- numeric(j)
  w[which.min(diag(H) / 2 + b)] <- 1
  active <- which(w > 0)
  for (iteration in seq_len(max_iter)) {
    k <- length(active)
    K <- rbind(cbind(H[active, active, drop = FALSE], rep(1, k)),
               c(rep(1, k), 0))
    sol <- solve(K, c(-b[active], 1), tol = 0)
    z <- as.numeric(sol[seq_len(k)])
    if (any(!is.finite(z))) stop("Non-finite QP face solution.")
    if (any(z < -1e-12)) {
      old <- w[active]
      blocking <- which(z < -1e-12)
      step <- min(old[blocking] / (old[blocking] - z[blocking]))
      w[active] <- old + step * (z - old)
      w[abs(w) <= 1e-12] <- 0
      if (min(w) < -1e-12) stop("QP lost simplex feasibility.")
      w <- pmax(w, 0)
      w <- w / sum(w)
      active <- which(w > 0)
      next
    }
    w[] <- 0
    w[active] <- pmax(z, 0)
    w <- w / sum(w)
    active <- which(w > 0)
    grad <- as.numeric(H %*% w + b)
    mu <- sum(w * grad)
    inactive <- setdiff(seq_len(j), active)
    reduced <- grad[inactive] - mu
    raw_grad <- as.numeric(Q %*% w + linear)
    gap <- max(0, sum(w * raw_grad) - min(raw_grad))
    if ((!length(reduced) || min(reduced) >= -tol) &&
        max(abs(grad[active] - mu)) <= max(tol, 5e-12) &&
        gap <= gap_tol) {
      raw_mu <- sum(w * raw_grad)
      return(list(w = w, iterations = iteration, duality_gap = gap,
                  kkt_residual = max(abs(raw_grad[active] - raw_mu),
                                     pmax(raw_mu - raw_grad, 0),
                                     abs(sum(w) - 1), pmax(-w, 0))))
    }
    if (length(reduced) && min(reduced) < -tol) {
      active <- sort(c(active, inactive[which.min(reduced)]))
    } else {
      stop("QP precision check failed; gap=", format(gap, digits = 6))
    }
  }
  stop("QP exceeded max_iter.")
}

fit_covariate_scm <- function(target_attributes, donor_attributes,
                              ridge = 1e-10, gap_tol = 1e-13) {
  X <- as.matrix(target_attributes)
  C <- as.matrix(donor_attributes)
  if (!is.numeric(X) || !is.numeric(C) || ncol(X) != ncol(C) ||
      nrow(X) < 1L || nrow(C) < 1L || ncol(X) < 1L ||
      any(!is.finite(X)) || any(!is.finite(C)) ||
      !is.finite(ridge) || ridge <= 0) {
    stop("Attributes must be complete numeric matrices; ridge must be positive.")
  }
  if (!is.null(colnames(X)) && !is.null(colnames(C)) &&
      !identical(colnames(X), colnames(C))) stop("Feature names/order disagree.")
  pooled <- rbind(X, C)
  center <- colMeans(pooled)
  scale <- apply(pooled, 2, stats::sd)
  retained <- is.finite(scale) & scale > 0
  if (!any(retained)) {
    W <- matrix(1 / nrow(C), nrow(X), nrow(C))
    dimnames(W) <- list(rownames(X), rownames(C))
    diagnostics <- data.frame(iterations = rep(0L, nrow(X)),
                              duality_gap = 0, kkt_residual = 0,
                              covariate_mse = 0)
    return(list(W = W, diagnostics = diagnostics, center = center,
                scale = scale, retained = retained, ridge = ridge))
  }
  Z <- sweep(sweep(X[, retained, drop = FALSE], 2, center[retained], "-"),
             2, scale[retained], "/")
  D <- sweep(sweep(C[, retained, drop = FALSE], 2, center[retained], "-"),
             2, scale[retained], "/")
  p <- ncol(D)
  Q <- 2 * (tcrossprod(D) / p + diag(ridge, nrow(D)))
  W <- matrix(NA_real_, nrow(X), nrow(C))
  diagnostics <- vector("list", nrow(X))
  for (i in seq_len(nrow(X))) {
    linear <- -2 * as.numeric(D %*% Z[i, ]) / p
    solved <- cov_qp(Q, linear, gap_tol)
    W[i, ] <- solved$w
    diagnostics[[i]] <- data.frame(
      iterations = solved$iterations, duality_gap = solved$duality_gap,
      kkt_residual = solved$kkt_residual,
      covariate_mse = mean((as.numeric(solved$w %*% D) - Z[i, ])^2))
  }
  dimnames(W) <- list(rownames(X), rownames(C))
  list(W = W, diagnostics = do.call(rbind, diagnostics), center = center,
       scale = scale, retained = retained, ridge = ridge)
}

cov_evaluate <- function(W, dat, method) {
  stopifnot(all(dim(W) == c(nrow(dat$target), nrow(dat$donor))),
            all(is.finite(W)), min(W) >= -1e-10,
            max(abs(rowSums(W) - 1)) < 1e-8)
  pp <- match(dat$post_years, dat$years)
  prediction <- W %*% dat$donor_log[, pp, drop = FALSE]
  observed <- dat$observed_log[, pp, drop = FALSE]
  truth <- dat$true_cf_log[, pp, drop = FALSE]
  tau <- dat$tau_log[, pp, drop = FALSE]
  if (any(!is.finite(c(prediction, observed, truth, tau))))
    stop("Non-finite required POST evaluation cells.")
  cf <- att <- annual <- list()
  for (g in c("complete_pre", "partial_pre", "post_only", "ALL")) {
    ii <- if (g == "ALL") seq_len(nrow(W)) else which(dat$groups == g)
    if (!length(ii)) next
    err <- prediction[ii, , drop = FALSE] - truth[ii, , drop = FALSE]
    estimate_log <- colMeans(observed[ii, , drop = FALSE] -
                              prediction[ii, , drop = FALSE])
    truth_log <- colMeans(tau[ii, , drop = FALSE])
    estimate_pct <- 100 * expm1(estimate_log)
    truth_pct <- 100 * expm1(truth_log)
    bias <- estimate_pct - truth_pct
    cf[[g]] <- data.frame(method = method, obs_group = g, n_sites = length(ii),
      n_eval_sites = length(ii), CF_RMSE_log = sqrt(mean(err^2)),
      CF_MAE_log = mean(abs(err)), CF_signed_mean_bias_log = mean(err))
    att[[g]] <- data.frame(method = method, obs_group = g, n_sites = length(ii),
      n_eval_sites = length(ii), ATT_RMSE_pp = sqrt(mean(bias^2)),
      ATT_MAE_pp = mean(abs(bias)), ATT_mean_bias_pp = mean(bias))
    annual[[g]] <- data.frame(method = method, obs_group = g,
      year = dat$post_years, true_ATT_log = truth_log,
      estimated_ATT_log = estimate_log, true_ATT_pct = truth_pct,
      estimated_ATT_pct = estimate_pct, ATT_bias_pp = bias)
  }
  bind <- function(x) { out <- do.call(rbind, x); rownames(out) <- NULL; out }
  list(cf = bind(cf), att = bind(att), annual = bind(annual),
       prediction = prediction)
}
