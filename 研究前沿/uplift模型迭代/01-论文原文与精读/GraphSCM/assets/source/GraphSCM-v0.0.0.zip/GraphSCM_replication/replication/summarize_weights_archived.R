# Reaggregate the published 1000-case weight diagnostics without refitting.
summarize_weights_archived <- function(project_root,output_root) {
  rows <- read.csv(file.path(project_root,"data/weight_diagnostics/weight_replications.csv"),
    stringsAsFactors=FALSE,na.strings=c("","NA"))
  plan <- read.csv(file.path(project_root,"data/study_plan.csv"),stringsAsFactors=FALSE)
  stopifnot(nrow(rows)==20000L,!anyDuplicated(rows[c("scenario","seed","method","obs_group")]),
    setequal(rows$method,c("Graph_SCM","GeoEco_SCM","Ordinary_SCM","uniform_weights")),
    all(rows$n_donor==24L),setequal(paste(rows$scenario,rows$seed),paste(plan$scenario,plan$seed)))
  full <- rows$method!="Ordinary_SCM"
  stopifnot(all(rows$n_sites[full]==rows$n_eval_sites[full]))
  core <- new.env(parent=globalenv())
  sys.source(file.path(project_root,"replication/weight_diagnostics/R/core.R"),envir=core)
  summary <- core$wd_summary(rows);paired <- core$wd_paired(rows)
  stopifnot(all(summary$n_rep %in% c(0L,100L)),all(paired$n_rep==100L))
  empty <- summary$n_rep==0L
  stopifnot(all(summary$method[empty]=="Ordinary_SCM"),all(summary$obs_group[empty]=="post_only"))
  dir.create(output_root,recursive=TRUE,showWarnings=FALSE)
  write.csv(summary,file.path(output_root,"weight_summary.csv"),row.names=FALSE)
  write.csv(paired,file.path(output_root,"paired_weight_differences.csv"),row.names=FALSE)
  cat("Published 100-replication weight summaries written to:",normalizePath(output_root,winslash="/"),"\n")
  invisible(list(summary=summary,paired=paired))
}
