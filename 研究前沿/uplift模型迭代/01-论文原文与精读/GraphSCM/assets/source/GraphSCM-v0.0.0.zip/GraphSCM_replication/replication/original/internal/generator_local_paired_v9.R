# =============================================================================
# M1_LP - Proposal DGP: Graph-SCM / GeoEco-SCM
# =============================================================================
# Purpose:
#   Create a small, fully known data-generating process (DGP) that mimics the
#   structure of the real M1_LP dataset but is fast enough for repeated testing.
#
#   The untreated treatment-site outcome is generated EXACTLY from a convex
#   combination of control outcomes:
#       Y0_it = sum_j w_true_ij * Yc_jt
#   with true weights w_true_i generated from TARGET latent market exposure.
#   v14 switches economic distance OFF/ON across the two main scenarios while
#   keeping donor physical nearness out of the true weight score.
#   A known post-2005 treatment effect is then added.
#
#   Three observation groups are created:
#       complete_pre : all 1994-2004 outcomes observed
#       partial_pre  : only 4-8 pre years observed
#       post_only    : no pre outcomes observed
#
#   Because W_true, Y0 and tau are saved, 02 can be evaluated against truth.
# =============================================================================


LOCAL_MISMATCH_PATCH_VERSION <- "2026-10-04-v9-paired"

DGP_SCRIPT_START <- Sys.time()

# ---- 0. Packages -------------------------------------------------------------
if (!requireNamespace("pacman", quietly = TRUE)) install.packages("pacman")
pacman::p_load(sf, tidyverse, Matrix, scales)

# ---- 1. User settings --------------------------------------------------------
WORK_DIR <- Sys.getenv(
  "M1_LP_WORK_DIR",
  unset = getwd()
)
setwd(WORK_DIR)

# Scenario can be overridden before source() with
#   Sys.setenv(SIM_SCENARIO = "smooth_geo_econ")
# v14 makes the central scientific contrast explicit:
#   smooth_geo_only : untreated outcomes/SCM representations are smooth in geography only
#   smooth_geo_econ : an additional partly non-spatial economic dimension is required
# The remaining scenarios are robustness / failure-mode checks.
SCENARIO <- Sys.getenv("SIM_SCENARIO", unset = "smooth_geo_econ")
VALID_SCENARIOS <- c(
  "smooth_geo_only",
  "smooth_geo_econ",
  "station_selected_geo_only",
  "station_selected_geo_econ",
  "station_selected_local_standard",
  "station_selected_local_mismatch",
  "smooth_geo_econ_latent_factor",
  "no_spatial",
  "spatially_separated_donors",
  "boundary"
)
if (!SCENARIO %in% VALID_SCENARIOS) {
  stop("SCENARIO must be one of: ", paste(VALID_SCENARIOS, collapse = ", "))
}

# Seed can also be overridden for later Monte Carlo experiments.
SEED <- as.integer(Sys.getenv("SIM_SEED", unset = "20260916"))
set.seed(SEED)

# Keep each scenario in a separate directory so results are never overwritten.
SIM_OUTPUT_ROOT <- Sys.getenv(
  "SIM_OUTPUT_ROOT",
  unset = file.path("output", "simulation_graph_geoeco")
)
OUTPUT_DIR <- file.path(SIM_OUTPUT_ROOT, SCENARIO)
dir.create(OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)

YEARS <- 1994:2015
PERIOD_PRE <- 1994:2004
PERIOD_POST <- 2005:2015

# Intentionally small: this should run much faster than the real dataset.
N_CONTROL <- as.integer(Sys.getenv("SIM_N_CONTROL", unset = "24"))
N_TARGET <- as.integer(Sys.getenv("SIM_N_TARGET", unset = "120"))

# Observation-pattern shares among treatment targets.
PROP_COMPLETE <- as.numeric(Sys.getenv("SIM_PROP_COMPLETE", unset = "0.50"))
PROP_PARTIAL <- as.numeric(Sys.getenv("SIM_PROP_PARTIAL", unset = "0.30"))
# Remaining 20% become post_only.

# Observation-process axis for the two station-selected scenarios.  The latent
# outcome process is held fixed relative to the matching random-entry scenario;
# only the assignment of PRE histories changes.  Post-only sites are sampled
# with fixed count but higher probability when they are (i) close to the new
# station and (ii) relatively low-priced before opening.  Because the treatment
# effect is already larger near the new station, this creates the empirically
# relevant selection problem: newly observed post-opening sites tend to have
# lower latent PRE prices and larger treatment effects.
OBSERVATION_SELECTION_MODE <- if (SCENARIO %in% c(
  "station_selected_local_standard", "station_selected_local_mismatch"
)) {
  "paired_station_selected_fixed"
} else if (SCENARIO %in% c(
  "station_selected_geo_only", "station_selected_geo_econ"
)) {
  "station_selected"
} else {
  "random"
}
STATION_SELECTION_NEAR_SCALE_M <- 3000
STATION_SELECTION_NEAR_COEF <- 1.00
STATION_SELECTION_LOW_PRICE_COEF <- 0.90
STATION_SELECTION_INTERACTION_COEF <- 0.50
STATION_SELECTION_TEMPERATURE <- 1.00

# Local socioeconomic-mismatch stress test.  v6 keeps the v5 mixed graph support
# explicit.  A mismatch target must have BOTH economically similar and dissimilar
# units among its geographic kNN.  Post-only selection is then concentrated on
# such mixed neighborhoods, while the selection algorithm guarantees that at
# least a small number of similar and dissimilar geographic neighbors remain
# PRE-observed anchors.  This matches the mechanism that GeoEco-SCM can address:
# it does not create distant edges; it downweights the wrong-regime local edges
# while retaining useful borrowing from same-regime local anchors.
LOCAL_MISMATCH_K <- as.integer(Sys.getenv("SIM_LOCAL_MISMATCH_K", unset = "10"))
LOCAL_MISMATCH_NEAR_COEF <- 0.80
LOCAL_MISMATCH_ECON_COEF <- 0.65
LOCAL_MISMATCH_MIXEDNESS_COEF <- 1.35
LOCAL_MISMATCH_LOW_PRICE_COEF <- 0.40
LOCAL_MISMATCH_INTERACTION_COEF <- 0.35
LOCAL_MIX_SIMILAR_EDGE_QUANTILE <- as.numeric(Sys.getenv(
  "SIM_LOCAL_MIX_SIMILAR_EDGE_QUANTILE", unset = "0.35"
))
LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE <- as.numeric(Sys.getenv(
  "SIM_LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE", unset = "0.65"
))
LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS <- as.integer(Sys.getenv(
  "SIM_LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS", unset = "2"
))
LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS <- as.integer(Sys.getenv(
  "SIM_LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS", unset = "2"
))
LOCAL_MISMATCH_CANDIDATE_QUANTILE <- as.numeric(Sys.getenv(
  "SIM_LOCAL_MISMATCH_CANDIDATE_QUANTILE", unset = "0.50"
))
if (!is.finite(LOCAL_MIX_SIMILAR_EDGE_QUANTILE) ||
    !is.finite(LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE) ||
    LOCAL_MIX_SIMILAR_EDGE_QUANTILE <= 0 ||
    LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE >= 1 ||
    LOCAL_MIX_SIMILAR_EDGE_QUANTILE >= LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE) {
  stop("Local mixed-neighborhood edge quantiles must satisfy 0 < similar < dissimilar < 1.")
}
if (LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS < 1L ||
    LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS < 1L) {
  stop("Local mixed-neighborhood minimum PRE-anchor counts must be >= 1.")
}
if (!is.finite(LOCAL_MISMATCH_K) || LOCAL_MISMATCH_K < 4L) {
  stop("SIM_LOCAL_MISMATCH_K must be an integer >= 4.")
}
if (!is.finite(LOCAL_MISMATCH_CANDIDATE_QUANTILE) ||
    LOCAL_MISMATCH_CANDIDATE_QUANTILE < 0 ||
    LOCAL_MISMATCH_CANDIDATE_QUANTILE >= 1) {
  stop("SIM_LOCAL_MISMATCH_CANDIDATE_QUANTILE must satisfy 0 <= q < 1.")
}

# v9 paired-local design.  The two local scenarios now share EXACTLY the same
# geography, station-selected observation pattern, treatment effect, target
# noise, donor outcomes and marginal distribution of target PRE-economic
# covariates.  The only intended contrast is the geographic ALIGNMENT of the
# target economic state.  In the mismatch scenario the complete target economic
# row vector is deterministically permuted across locations; the permutation is
# chosen using DGP diagnostics only (never estimator performance).
LOCAL_PAIRED_SCENARIO <- SCENARIO %in% c(
  "station_selected_local_standard", "station_selected_local_mismatch"
)
LOCAL_PAIRED_MISMATCH_ACTIVE <- SCENARIO == "station_selected_local_mismatch"
LOCAL_PAIRED_ECON_SPATIAL_SHARE <- as.numeric(Sys.getenv(
  "SIM_LOCAL_PAIRED_ECON_SPATIAL_SHARE", unset = "0.60"
))
LOCAL_PAIRED_INTERLEAVE_STRATA <- as.integer(strsplit(
  Sys.getenv("SIM_LOCAL_PAIRED_INTERLEAVE_STRATA", unset = "3,4,5,6"), ",",
  fixed = TRUE
)[[1]])
LOCAL_PAIRED_SELECTION_NEAR_COEF <- as.numeric(Sys.getenv(
  "SIM_LOCAL_PAIRED_SELECTION_NEAR_COEF", unset = "1.00"
))
LOCAL_PAIRED_DESIGN_MIN_MISMATCH_GAIN <- as.numeric(Sys.getenv(
  "SIM_LOCAL_PAIRED_DESIGN_MIN_MISMATCH_GAIN", unset = "0.10"
))
if (!is.finite(LOCAL_PAIRED_ECON_SPATIAL_SHARE) ||
    LOCAL_PAIRED_ECON_SPATIAL_SHARE < 0 || LOCAL_PAIRED_ECON_SPATIAL_SHARE > 1) {
  stop("SIM_LOCAL_PAIRED_ECON_SPATIAL_SHARE must be in [0,1].")
}
if (!length(LOCAL_PAIRED_INTERLEAVE_STRATA) ||
    any(!is.finite(LOCAL_PAIRED_INTERLEAVE_STRATA)) ||
    any(LOCAL_PAIRED_INTERLEAVE_STRATA < 2L)) {
  stop("SIM_LOCAL_PAIRED_INTERLEAVE_STRATA must contain integers >=2.")
}

# v6 retains the v5 modest nonlinear economic-archetype component to donor outcome
# trajectories in BOTH local scenarios.  Loadings are nonlinear functions of the
# latent economic state and are residualized against the linear span of observed
# PRE Econ-X.  Thus economic similarity can matter for donor composition without
# simply turning Econ-X into a direct linear outcome regressor.
LOCAL_ARCHETYPE_SCALE <- as.numeric(Sys.getenv(
  "SIM_LOCAL_ARCHETYPE_SCALE", unset = "0.045"
))
LOCAL_ARCHETYPE_BW <- as.numeric(Sys.getenv(
  "SIM_LOCAL_ARCHETYPE_BW", unset = "0.75"
))
LOCAL_ARCHETYPE_IDIO_SD <- as.numeric(Sys.getenv(
  "SIM_LOCAL_ARCHETYPE_IDIO_SD", unset = "0.08"
))

# Mechanism-isolation safeguard for the two local-selection scenarios.  The
# economic proxies should identify differences in the TRUE donor representation,
# rather than act as an almost-direct linear predictor of untreated outcome
# levels.  After W_true has been generated, donor outcome vectors are projected
# away from the target-level linear Econ-X direction conditional on (X,Y).
# This keeps Y0 = W_true %*% Y_control EXACT while moderating the direct
# reduced-form advantage of an outcome regression/kriging mean with Econ-X.
LOCAL_DGP2_ECON_ORTHOGONALIZE <- tolower(Sys.getenv(
  "SIM_LOCAL_DGP2_ECON_ORTHOGONALIZE", unset = "true"
)) %in% c("1", "true", "t", "yes", "y")
LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH <- as.numeric(Sys.getenv(
  "SIM_LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH", unset = "0.75"
))
LOCAL_DGP2_ECON_ORTHOGONALIZATION_RIDGE <- as.numeric(Sys.getenv(
  "SIM_LOCAL_DGP2_ECON_ORTHOGONALIZATION_RIDGE", unset = "1e-10"
))
if (!is.finite(LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH) ||
    LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH < 0 ||
    LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH > 1) {
  stop("SIM_LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH must be in [0,1].")
}

# v5: pre-specified DGP-alignment audit.  The preferred interval is a DESIGN
# diagnostic, not an estimator-tuning target: the orthogonalization strength is
# fixed before Graph/GeoEco are fitted and is never adapted to their RMSE.
LOCAL_DGP2_ALIGNMENT_STRICT <- tolower(Sys.getenv(
  "SIM_LOCAL_DGP2_ALIGNMENT_STRICT", unset = "true"
)) %in% c("1", "true", "t", "yes", "y")
LOCAL_DGP2_ALIGNMENT_PREFERRED_MIN <- as.numeric(Sys.getenv(
  "SIM_LOCAL_DGP2_ALIGNMENT_PREFERRED_MIN", unset = "0.05"
))
LOCAL_DGP2_ALIGNMENT_PREFERRED_MAX <- as.numeric(Sys.getenv(
  "SIM_LOCAL_DGP2_ALIGNMENT_PREFERRED_MAX", unset = "0.15"
))
LOCAL_DGP2_ALIGNMENT_WARN_MAX <- as.numeric(Sys.getenv(
  "SIM_LOCAL_DGP2_ALIGNMENT_WARN_MAX", unset = "0.20"
))
LOCAL_DGP2_ALIGNMENT_HARD_MAX <- as.numeric(Sys.getenv(
  "SIM_LOCAL_DGP2_ALIGNMENT_HARD_MAX", unset = "0.25"
))

# DGP controls.
TARGET_NOISE_SD <- 0.008       # log-price observation noise (~0.8%)

# The smooth/boundary scenarios deliberately use fairly concentrated true
# weights, but IMPORTANTLY they do NOT make a target prefer geographically
# nearby donors.  Instead, each target has a smoothly varying latent market
# exposure and donors form a common dictionary of market archetypes.  Nearby
# TARGETS therefore have similar donor representations, which is the actual
# identifying assumption of graph-SCM.  Donor physical location is not used in
# the smooth-weight score.
WEIGHT_LATENT_SCALE <- 0.60
WEIGHT_ACCESS_SCALE <- 0.80
WEIGHT_ACCESS_IMPORTANCE <- 0.60
BOUNDARY_BONUS <- 2.50         # used only in SCENARIO="boundary"

# Economic-distance signal used in the main geo+econ DGP.  Only a small share
# of the latent economic variation is spatially predictable.  This is deliberate:
# a spatial-only method should work in smooth_geo_only, but should be unable to
# reconstruct the full latent market state in smooth_geo_econ from coordinates
# alone.  Observed PRE economic variables are noisy proxies for this latent state.
ECON_MARKET_STRENGTH <- 0.65
ECON_SPATIAL_SHARE <- 0.20

# smooth_geo_econ_latent_factor:
# Keep the SAME geo+econ true SCM-weight field as smooth_geo_econ, but let donor
# outcomes load on several latent temporal factors with different dynamics.
# Loadings combine a genuinely spatial component with nonlinear market/economic
# components and donor-specific heterogeneity.  The target counterfactual remains
# an exact stable donor mixture, but a stationary lag-based space-time covariance
# is no longer the natural representation.  This is the proposal-positive-control
# DGP; it is intentionally not pure white noise, so flexible kriging retains some
# usable spatial signal.
LATENT_FACTOR_SCALE <- 0.060
LATENT_FACTOR_SPATIAL_SHARE <- 0.35
LATENT_FACTOR_IDIO_SD <- 0.25
LATENT_FACTOR_ECON_BASIS_BW <- 0.70
LATENT_FACTOR_AR1_PHI <- 0.88
LATENT_FACTOR_AR2_PHI <- 0.25
LATENT_FACTOR_SHOCK_YEAR <- 2001L

# spatially_separated_donors: targets occupy an inner disk while donor controls
# occupy an outer annulus, leaving a buffer with no estimation sites.  The true
# weight field remains the same geo+econ smooth representation as in
# smooth_geo_econ.  Hence this scenario isolates donor-pool spatial separation
# / outcome extrapolation from a failure of the Graph/GeoEco weight assumption.
SPATIAL_SUPPORT_CENTER <- c(10000, 10000)
SPATIAL_TARGET_RADIUS_M <- 5000
SPATIAL_BUFFER_OUTER_RADIUS_M <- 7000
SPATIAL_CONTROL_OUTER_RADIUS_M <- 13000
SPATIAL_BOX_MIN_M <- 500
SPATIAL_BOX_MAX_M <- 19500

# no_spatial: independent concentrated weights unrelated to target geography.
NO_SPATIAL_DIRICHLET_SHAPE <- 0.20

# Explicit common market factor.  Ordinary scenarios contain a shared temporal
# component with donor-specific loadings; the negative-control scenario keeps
# only a small fraction of it.  This makes the label ``weak common factor``
# literal rather than merely relying on shared sinusoidal frequencies.
COMMON_FACTOR_SCALE <- 1.00
COMMON_FACTOR_AR_PHI <- 0.70
COMMON_FACTOR_AR_SD <- 0.004

# Observed PRE economic characteristics.  They are noisy proxies for latent
# market exposure and are safe to use in the graph because they are generated
# before treatment.  The graph never uses the latent truth directly.
ECON_PROXY_NOISE_SD <- 0.18

# ---- 2. Helper functions -----------------------------------------------------
min_dist_to_points <- function(xy, pts) {
  apply(xy, 1, function(z) {
    min(sqrt((z[1] - pts[, 1])^2 + (z[2] - pts[, 2])^2))
  })
}

softmax_stable <- function(z) {
  zz <- z - max(z)
  ez <- exp(zz)
  ez / sum(ez)
}

make_ar1 <- function(n, phi = 0.55, sd = 0.008) {
  e <- rnorm(n, 0, sd)
  out <- numeric(n)
  out[1] <- e[1]
  if (n >= 2) {
    for (tt in 2:n) out[tt] <- phi * out[tt - 1] + e[tt]
  }
  out
}

zscore_vec <- function(x) {
  sx <- stats::sd(x)
  if (!is.finite(sx) || sx <= 0) return(x - mean(x))
  (x - mean(x)) / sx
}

sample_uniform_disk <- function(n, center, radius) {
  theta <- runif(n, 0, 2 * pi)
  rr <- radius * sqrt(runif(n))
  cbind(
    X_m = center[1] + rr * cos(theta),
    Y_m = center[2] + rr * sin(theta)
  )
}

sample_uniform_annulus_in_box <- function(n, center, r_min, r_max, box_min, box_max) {
  out <- matrix(NA_real_, nrow = n, ncol = 2,
                dimnames = list(NULL, c("X_m", "Y_m")))
  filled <- 0L
  while (filled < n) {
    batch_n <- max(200L, 8L * (n - filled))
    cand <- cbind(
      X_m = runif(batch_n, box_min, box_max),
      Y_m = runif(batch_n, box_min, box_max)
    )
    rr <- sqrt((cand[, 1] - center[1])^2 + (cand[, 2] - center[2])^2)
    ok <- which(rr >= r_min & rr <= r_max)
    if (!length(ok)) next
    take_n <- min(length(ok), n - filled)
    out[(filled + 1L):(filled + take_n), ] <- cand[ok[seq_len(take_n)], , drop = FALSE]
    filled <- filled + take_n
  }
  out
}

# ---- 3. Synthetic geography -------------------------------------------------
# 20 km x 20 km rectangular market.  Main scenarios use overlapping spatial
# support.  The spatially_separated_donors stress scenario instead places
# targets inside a 5-km disk and controls outside a 7-km buffer.
if (SCENARIO == "spatially_separated_donors") {
  target_xy <- sample_uniform_disk(
    N_TARGET, SPATIAL_SUPPORT_CENTER, SPATIAL_TARGET_RADIUS_M
  )
  control_xy <- sample_uniform_annulus_in_box(
    N_CONTROL, SPATIAL_SUPPORT_CENTER,
    SPATIAL_BUFFER_OUTER_RADIUS_M, SPATIAL_CONTROL_OUTER_RADIUS_M,
    SPATIAL_BOX_MIN_M, SPATIAL_BOX_MAX_M
  )
} else {
  control_xy <- cbind(
    X_m = runif(N_CONTROL, 500, 19500),
    Y_m = runif(N_CONTROL, 500, 19500)
  )
  target_xy <- cbind(
    X_m = runif(N_TARGET, 500, 19500),
    Y_m = runif(N_TARGET, 500, 19500)
  )
}

spatial_center_distance_control <- sqrt(
  (control_xy[, 1] - SPATIAL_SUPPORT_CENTER[1])^2 +
    (control_xy[, 2] - SPATIAL_SUPPORT_CENTER[2])^2
)
spatial_center_distance_target <- sqrt(
  (target_xy[, 1] - SPATIAL_SUPPORT_CENTER[1])^2 +
    (target_xy[, 2] - SPATIAL_SUPPORT_CENTER[2])^2
)

# Two stations already available before treatment. This is a PRE-treatment
# accessibility measure and is therefore safe for graph construction.
pre_stations <- rbind(
  c(4500, 5500),
  c(15500, 14000)
)

# One synthetic "new" station whose opening in 2005 creates the treatment
# effect. Distance to this station affects tau but is NOT needed by the SCM.
new_station <- matrix(c(10500, 9500), nrow = 1)

control_pre_station_dist <- min_dist_to_points(control_xy, pre_stations)
target_pre_station_dist <- min_dist_to_points(target_xy, pre_stations)
target_new_station_dist <- min_dist_to_points(target_xy, new_station)

control_ids <- sprintf("C_%03d", seq_len(N_CONTROL))
target_ids <- sprintf("T_%03d", seq_len(N_TARGET))

# ---- 3b. Latent market + observed PRE economic characteristics ----------------
# v14 DGP principle:
#   * smooth_geo_only: true market exposure is a smooth function of geography;
#   * smooth_geo_econ: true market exposure additionally depends on an economic
#     latent state that is only weakly predictable from coordinates;
#   * the observed PRE economic variables are noisy proxies for that state;
#   * target-donor PHYSICAL distance never directly enters the true SCM score.
#
# The main comparison therefore changes whether ECONOMIC DISTANCE is part of
# the truth, while Gneiting/spCF remain outcome-side estimators in 04b.
# Importantly, the same seed and random innovations are used in the two main
# scenarios, so their difference is not driven by a different random draw.
target_x_scaled <- (target_xy[, 1] - 10000) / 9500
target_y_scaled <- (target_xy[, 2] - 10000) / 9500
control_x_scaled <- (control_xy[, 1] - 10000) / 9500
control_y_scaled <- (control_xy[, 2] - 10000) / 9500

# Smooth broad geographic component, defined identically for controls/targets.
target_geo_z1 <- 0.70 * target_x_scaled + 0.20 * sin(pi * target_y_scaled)
target_geo_z2 <- 0.65 * target_y_scaled + 0.18 * cos(pi * target_x_scaled)
control_geo_z1 <- 0.70 * control_x_scaled + 0.20 * sin(pi * control_y_scaled)
control_geo_z2 <- 0.65 * control_y_scaled + 0.18 * cos(pi * control_x_scaled)

# Latent economics.  For the new paired-local scenarios we deliberately start
# from a MORE geographically aligned economic field than the generic 20% case;
# this makes the standard member a genuine aligned baseline.  The mismatch
# member uses the EXACT SAME economic rows but permutes them across target
# locations, so marginal economics are identical by construction.
econ_spatial_share_now <- if (LOCAL_PAIRED_SCENARIO) {
  LOCAL_PAIRED_ECON_SPATIAL_SHARE
} else {
  ECON_SPATIAL_SHARE
}

all_xy <- rbind(control_xy, target_xy)
n_all <- nrow(all_xy)

econ_spatial1 <- zscore_vec(
  sin(2 * pi * all_xy[, 1] / 8500) * cos(2 * pi * all_xy[, 2] / 11000)
)
econ_spatial2 <- zscore_vec(
  cos(2 * pi * all_xy[, 1] / 10500 + all_xy[, 2] / 6000)
)
econ_idio1 <- zscore_vec(rnorm(n_all))
econ_idio2 <- zscore_vec(rnorm(n_all))

econ_latent1_all_base <- zscore_vec(
  sqrt(econ_spatial_share_now) * econ_spatial1 +
    sqrt(1 - econ_spatial_share_now) * econ_idio1
)
econ_latent2_all_base <- zscore_vec(
  sqrt(econ_spatial_share_now) * econ_spatial2 +
    sqrt(1 - econ_spatial_share_now) * econ_idio2
)

control_econ_latent1 <- econ_latent1_all_base[seq_len(N_CONTROL)]
control_econ_latent2 <- econ_latent2_all_base[seq_len(N_CONTROL)]
target_econ_latent1_base <- econ_latent1_all_base[N_CONTROL + seq_len(N_TARGET)]
target_econ_latent2_base <- econ_latent2_all_base[N_CONTROL + seq_len(N_TARGET)]

# Generate the PRE-economic proxy innovations ONCE.  The target economic row
# package (latent state + all proxy values) will later be permuted jointly,
# preserving its empirical joint distribution exactly across the paired DGPs.
proxy_emp_all_base <- zscore_vec(
  0.85 * econ_latent1_all_base + rnorm(n_all, 0, ECON_PROXY_NOISE_SD)
)
proxy_com_all_base <- zscore_vec(
  -0.25 * econ_latent1_all_base + 0.85 * econ_latent2_all_base +
    rnorm(n_all, 0, ECON_PROXY_NOISE_SD)
)
proxy_inc_all_base <- zscore_vec(
  0.55 * econ_latent1_all_base - 0.35 * econ_latent2_all_base +
    rnorm(n_all, 0, ECON_PROXY_NOISE_SD)
)

control_pre_employment_density_z <- proxy_emp_all_base[seq_len(N_CONTROL)]
control_pre_commercial_share_z <- proxy_com_all_base[seq_len(N_CONTROL)]
control_pre_income_z <- proxy_inc_all_base[seq_len(N_CONTROL)]
target_pre_employment_density_z_base <- proxy_emp_all_base[N_CONTROL + seq_len(N_TARGET)]
target_pre_commercial_share_z_base <- proxy_com_all_base[N_CONTROL + seq_len(N_TARGET)]
target_pre_income_z_base <- proxy_inc_all_base[N_CONTROL + seq_len(N_TARGET)]

target_pairwise_geo_dist <- as.matrix(stats::dist(target_xy))
diag(target_pairwise_geo_dist) <- Inf
k_mismatch <- min(LOCAL_MISMATCH_K, N_TARGET - 1L)
geo_knn_index <- t(vapply(seq_len(N_TARGET), function(i) {
  order(target_pairwise_geo_dist[i, ])[seq_len(k_mismatch)]
}, integer(k_mismatch)))

calc_local_econ_metrics <- function(proxy_mat) {
  dd_mat <- matrix(NA_real_, nrow = N_TARGET, ncol = k_mismatch)
  for (i in seq_len(N_TARGET)) {
    nn <- geo_knn_index[i, ]
    dd <- sweep(proxy_mat[nn, , drop = FALSE], 2, proxy_mat[i, ], FUN = "-")
    dd_mat[i, ] <- sqrt(rowSums(dd^2))
  }
  edge <- as.numeric(dd_mat)
  qlo <- as.numeric(stats::quantile(
    edge, LOCAL_MIX_SIMILAR_EDGE_QUANTILE, na.rm = TRUE, names = FALSE
  ))
  qhi <- as.numeric(stats::quantile(
    edge, LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE, na.rm = TRUE, names = FALSE
  ))
  sim_n <- rowSums(dd_mat <= qlo, na.rm = TRUE)
  dis_n <- rowSums(dd_mat >= qhi, na.rm = TRUE)
  mixed <- sim_n >= LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS &
    dis_n >= LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS
  mismatch <- rowMeans(dd_mat)
  balance <- pmin(sim_n, dis_n)
  separation <- vapply(seq_len(N_TARGET), function(i) {
    x <- dd_mat[i, ]
    lo <- x[x <= qlo]
    hi <- x[x >= qhi]
    if (!length(lo) || !length(hi)) return(0)
    mean(hi) - mean(lo)
  }, numeric(1))
  mixed_score <- zscore_vec(as.numeric(balance) + 0.50 * zscore_vec(separation))
  list(
    distance = dd_mat, similar_threshold = qlo, dissimilar_threshold = qhi,
    similar_count = sim_n, dissimilar_count = dis_n, mixed_eligible = mixed,
    mismatch_score = mismatch, mismatch_z = zscore_vec(mismatch),
    mixed_score = mixed_score
  )
}

# Standard target economic row package.
target_econ_package_base <- cbind(
  econ_latent1 = target_econ_latent1_base,
  econ_latent2 = target_econ_latent2_base,
  pre_employment_density_z = target_pre_employment_density_z_base,
  pre_commercial_share_z = target_pre_commercial_share_z_base,
  pre_income_z = target_pre_income_z_base
)
paired_standard_metrics <- calc_local_econ_metrics(
  target_econ_package_base[, 3:5, drop = FALSE]
)

# Deterministic spatial-interleaving permutations.  Economic rows are sorted by
# a fixed 2-D score and distributed across nearby locations in alternating
# strata.  We pre-specify a finite candidate family and select the member that
# maximizes LOCAL economic mismatch / mixed support only.  No fitted estimator,
# RMSE, W_true, Y0 or treatment effect enters this choice.
make_interleaved_row_order <- function(econ_order, n_strata, phase = 0L, flip = FALSE) {
  n <- length(econ_order)
  grp_id <- cut(seq_len(n), breaks = n_strata, labels = FALSE)
  groups <- split(econ_order, grp_id)
  if (flip) {
    for (g in seq_along(groups)) if (g %% 2L == 0L) groups[[g]] <- rev(groups[[g]])
  }
  gseq <- seq_len(n_strata)
  if (phase > 0L) {
    phase <- phase %% n_strata
    gseq <- c(gseq[(phase + 1L):n_strata], if (phase > 0L) gseq[seq_len(phase)] else integer(0))
  }
  out <- integer(0)
  m <- max(lengths(groups))
  for (k in seq_len(m)) {
    for (g in gseq) if (k <= length(groups[[g]])) out <- c(out, groups[[g]][k])
  }
  out[seq_len(n)]
}

paired_econ_permutation <- seq_len(N_TARGET)
paired_permutation_candidate_table <- tibble::tibble()
if (LOCAL_PAIRED_SCENARIO) {
  econ_score_base <- zscore_vec(target_econ_latent1_base) +
    0.35 * zscore_vec(target_econ_latent2_base)
  econ_order <- order(econ_score_base, target_econ_latent2_base)
  hc <- stats::hclust(stats::dist(target_xy), method = "ward.D2")
  spatial_orders <- list(
    hclust = hc$order,
    hclust_reverse = rev(hc$order),
    diag_plus = order(target_xy[, 1] + target_xy[, 2], target_xy[, 1]),
    diag_minus = order(target_xy[, 1] - target_xy[, 2], target_xy[, 1])
  )
  cand_rows <- list()
  cc <- 0L
  best_score <- -Inf
  best_perm <- NULL
  best_meta <- NULL
  std_mean_mismatch <- mean(paired_standard_metrics$mismatch_score)
  for (ord_name in names(spatial_orders)) {
    spatial_order <- spatial_orders[[ord_name]]
    for (ns in LOCAL_PAIRED_INTERLEAVE_STRATA) {
      for (ph in 0:(ns - 1L)) {
        for (flip in c(FALSE, TRUE)) {
          econ_interleaved <- make_interleaved_row_order(econ_order, ns, ph, flip)
          perm <- integer(N_TARGET)
          perm[spatial_order] <- econ_interleaved
          proxy_cand <- target_econ_package_base[perm, 3:5, drop = FALSE]
          met <- calc_local_econ_metrics(proxy_cand)
          gain <- mean(met$mismatch_score) - std_mean_mismatch
          mixed_frac <- mean(met$mixed_eligible)
          mean_balance <- mean(pmin(met$similar_count, met$dissimilar_count))
          # Strong priority to actual mismatch gain; mixed support is a secondary
          # feasibility property, not an estimator-performance target.
          design_score <- gain + 0.20 * mixed_frac + 0.02 * mean_balance
          cc <- cc + 1L
          cand_rows[[cc]] <- tibble::tibble(
            spatial_order = ord_name, n_strata = ns, phase = ph, flip = flip,
            mismatch_gain = gain, mixed_eligible_fraction = mixed_frac,
            mean_mixed_balance = mean_balance, design_score = design_score
          )
          if (is.finite(design_score) && design_score > best_score) {
            best_score <- design_score
            best_perm <- perm
            best_meta <- cand_rows[[cc]]
          }
        }
      }
    }
  }
  paired_permutation_candidate_table <- dplyr::bind_rows(cand_rows) |>
    dplyr::arrange(dplyr::desc(design_score))
  paired_econ_permutation <- best_perm
  if (is.null(paired_econ_permutation) ||
      !setequal(paired_econ_permutation, seq_len(N_TARGET))) {
    stop("Internal v9 paired-DGP error: economic permutation is invalid.")
  }
}

target_econ_package_mismatch <- target_econ_package_base[paired_econ_permutation, , drop = FALSE]
paired_mismatch_metrics <- calc_local_econ_metrics(
  target_econ_package_mismatch[, 3:5, drop = FALSE]
)
paired_mean_mismatch_gain <- mean(paired_mismatch_metrics$mismatch_score) -
  mean(paired_standard_metrics$mismatch_score)
if (LOCAL_PAIRED_SCENARIO &&
    (!is.finite(paired_mean_mismatch_gain) ||
     paired_mean_mismatch_gain < LOCAL_PAIRED_DESIGN_MIN_MISMATCH_GAIN)) {
  stop(
    "Paired local mismatch construction did not achieve the pre-specified DGP diagnostic gain. ",
    "Observed mean mismatch gain=", signif(paired_mean_mismatch_gain, 4),
    "; required >=", LOCAL_PAIRED_DESIGN_MIN_MISMATCH_GAIN,
    ". This check uses DGP covariates only, never estimator performance."
  )
}

# Activate either the aligned or permuted economic row package.
target_econ_package_actual <- if (LOCAL_PAIRED_MISMATCH_ACTIVE) {
  target_econ_package_mismatch
} else {
  target_econ_package_base
}
target_econ_latent1 <- target_econ_package_actual[, "econ_latent1"]
target_econ_latent2 <- target_econ_package_actual[, "econ_latent2"]
target_pre_employment_density_z <- target_econ_package_actual[, "pre_employment_density_z"]
target_pre_commercial_share_z <- target_econ_package_actual[, "pre_commercial_share_z"]
target_pre_income_z <- target_econ_package_actual[, "pre_income_z"]

# Economic distance is TRUE in the local pair and the established geo+econ DGPs.
ECONOMIC_DISTANCE_ACTIVE <- SCENARIO %in% c(
  "smooth_geo_econ", "station_selected_geo_econ",
  "station_selected_local_standard", "station_selected_local_mismatch",
  "smooth_geo_econ_latent_factor", "spatially_separated_donors", "boundary"
)

# Use the STANDARD member to set the market normalization for BOTH paired DGPs.
# Donor market coordinates are therefore identical across the pair; only target
# economic-geographic alignment is changed in the mismatch member.
donor_market_raw1 <- if (ECONOMIC_DISTANCE_ACTIVE) {
  control_geo_z1 + ECON_MARKET_STRENGTH * control_econ_latent1
} else control_geo_z1
donor_market_raw2 <- if (ECONOMIC_DISTANCE_ACTIVE) {
  control_geo_z2 + ECON_MARKET_STRENGTH * control_econ_latent2
} else control_geo_z2

target_market_raw1_standard <- if (ECONOMIC_DISTANCE_ACTIVE) {
  target_geo_z1 + ECON_MARKET_STRENGTH * target_econ_latent1_base
} else target_geo_z1
target_market_raw2_standard <- if (ECONOMIC_DISTANCE_ACTIVE) {
  target_geo_z2 + ECON_MARKET_STRENGTH * target_econ_latent2_base
} else target_geo_z2
target_market_raw1_actual <- if (ECONOMIC_DISTANCE_ACTIVE) {
  target_geo_z1 + ECON_MARKET_STRENGTH * target_econ_latent1
} else target_geo_z1
target_market_raw2_actual <- if (ECONOMIC_DISTANCE_ACTIVE) {
  target_geo_z2 + ECON_MARKET_STRENGTH * target_econ_latent2
} else target_geo_z2

market1_ref <- c(donor_market_raw1, target_market_raw1_standard)
market2_ref <- c(donor_market_raw2, target_market_raw2_standard)
market1_mu <- mean(market1_ref); market1_sd <- stats::sd(market1_ref)
market2_mu <- mean(market2_ref); market2_sd <- stats::sd(market2_ref)
if (!is.finite(market1_sd) || market1_sd <= 0) market1_sd <- 1
if (!is.finite(market2_sd) || market2_sd <= 0) market2_sd <- 1
std_ref <- function(x, mu, sig) (x - mu) / sig

donor_market_z1 <- std_ref(donor_market_raw1, market1_mu, market1_sd)
donor_market_z2 <- std_ref(donor_market_raw2, market2_mu, market2_sd)
target_market_z1_standard <- std_ref(target_market_raw1_standard, market1_mu, market1_sd)
target_market_z2_standard <- std_ref(target_market_raw2_standard, market2_mu, market2_sd)
target_market_z1 <- std_ref(target_market_raw1_actual, market1_mu, market1_sd)
target_market_z2 <- std_ref(target_market_raw2_actual, market2_mu, market2_sd)

all_pre_station_dist <- c(control_pre_station_dist, target_pre_station_dist)
access_mean <- mean(all_pre_station_dist)
access_sd <- stats::sd(all_pre_station_dist)
if (!is.finite(access_sd) || access_sd <= 0) access_sd <- 1
control_access_z <- -(control_pre_station_dist - access_mean) / access_sd
target_access_z <- -(target_pre_station_dist - access_mean) / access_sd

# Actual-scenario local economic diagnostics, plus both members' diagnostics for
# the paired audit and common observation-pattern construction.
actual_proxy_mat <- cbind(
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z
)
actual_local_metrics <- calc_local_econ_metrics(actual_proxy_mat)
local_econ_mismatch_score <- actual_local_metrics$mismatch_score
local_econ_mismatch_z <- actual_local_metrics$mismatch_z
geo_knn_econ_dist <- actual_local_metrics$distance
local_similar_edge_threshold <- actual_local_metrics$similar_threshold
local_dissimilar_edge_threshold <- actual_local_metrics$dissimilar_threshold
local_similar_neighbor_count <- actual_local_metrics$similar_count
local_dissimilar_neighbor_count <- actual_local_metrics$dissimilar_count
local_mixed_neighbor_eligible <- actual_local_metrics$mixed_eligible
local_mixed_neighbor_score <- actual_local_metrics$mixed_score

# Common paired post-only candidate set is defined using the mismatch alignment
# only and then reused verbatim in BOTH scenarios.  This isolates alignment from
# sample composition.
paired_local_mismatch_score <- paired_mismatch_metrics$mismatch_score
if (!any(paired_mismatch_metrics$mixed_eligible)) {
  stop("Paired mismatch construction produced no mixed-neighborhood-eligible targets.")
}
paired_local_mismatch_threshold <- as.numeric(stats::quantile(
  paired_local_mismatch_score[paired_mismatch_metrics$mixed_eligible],
  probs = LOCAL_MISMATCH_CANDIDATE_QUANTILE, na.rm = TRUE, names = FALSE
))
paired_local_mismatch_candidate_eligible <-
  paired_mismatch_metrics$mixed_eligible &
  paired_local_mismatch_score >= paired_local_mismatch_threshold

# Preserve the legacy variable names for validator compatibility.  In the actual
# mismatch member these are identical to the paired design values; in the
# standard member a highly aligned field may have no 2+2 mixed neighborhoods,
# which is allowed because selection is fixed from the paired mismatch design.
if (any(local_mixed_neighbor_eligible)) {
  local_mismatch_candidate_threshold <- as.numeric(stats::quantile(
    local_econ_mismatch_score[local_mixed_neighbor_eligible],
    probs = LOCAL_MISMATCH_CANDIDATE_QUANTILE, na.rm = TRUE, names = FALSE
  ))
  local_mismatch_candidate_eligible <- local_mixed_neighbor_eligible &
    local_econ_mismatch_score >= local_mismatch_candidate_threshold
} else {
  local_mismatch_candidate_threshold <- NA_real_
  local_mismatch_candidate_eligible <- rep(FALSE, N_TARGET)
}

# PRE-access and observed economic features used by downstream estimators.
target_market_features <- tibble::tibble(
  point_id = target_ids,
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  market_z1 = target_market_z1,
  market_z2 = target_market_z2,
  econ_latent1 = target_econ_latent1,
  econ_latent2 = target_econ_latent2,
  economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
  pre_access_z = target_access_z,
  pre_station_distance_m = target_pre_station_dist,
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z
)

donor_market_features <- tibble::tibble(
  point_id = control_ids,
  X_m = control_xy[, 1],
  Y_m = control_xy[, 2],
  market_z1 = donor_market_z1,
  market_z2 = donor_market_z2,
  econ_latent1 = control_econ_latent1,
  econ_latent2 = control_econ_latent2,
  economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
  pre_access_z = control_access_z,
  pre_station_distance_m = control_pre_station_dist,
  pre_employment_density_z = control_pre_employment_density_z,
  pre_commercial_share_z = control_pre_commercial_share_z,
  pre_income_z = control_pre_income_z
)

# Paired-alignment audit written for every local run.  The target economic rows
# are exactly the same multiset across standard/mismatch; only location changes.
paired_alignment_diagnostics <- tibble::tibble(
  point_id = target_ids,
  economic_row_source_index = paired_econ_permutation,
  standard_local_mismatch_score = paired_standard_metrics$mismatch_score,
  mismatch_local_mismatch_score = paired_mismatch_metrics$mismatch_score,
  mismatch_minus_standard = paired_mismatch_metrics$mismatch_score -
    paired_standard_metrics$mismatch_score,
  standard_mixed_eligible = paired_standard_metrics$mixed_eligible,
  mismatch_mixed_eligible = paired_mismatch_metrics$mixed_eligible
)
readr::write_csv(
  paired_alignment_diagnostics,
  file.path(OUTPUT_DIR, "simulation_paired_alignment_diagnostics.csv")
)
if (LOCAL_PAIRED_SCENARIO) {
  readr::write_csv(
    paired_permutation_candidate_table,
    file.path(OUTPUT_DIR, "simulation_paired_permutation_candidates.csv")
  )
}
# Boundary stress test: target market membership jumps at x=10 km.  Donor
# regime is defined by latent market type, not by physical distance to targets.
latent_regime_score <- donor_market_z1 + 0.30 * donor_market_z2
donor_market_regime <- ifelse(
  latent_regime_score >= stats::median(latent_regime_score),
  "east_type", "west_type"
)

target_market_features <- tibble::tibble(
  point_id = target_ids,
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  market_z1 = target_market_z1,
  market_z2 = target_market_z2,
  econ_latent1 = target_econ_latent1,
  econ_latent2 = target_econ_latent2,
  economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
  pre_access_z = target_access_z,
  pre_station_distance_m = target_pre_station_dist,
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z
)

donor_market_features <- tibble::tibble(
  point_id = control_ids,
  X_m = control_xy[, 1],
  Y_m = control_xy[, 2],
  market_z1 = donor_market_z1,
  market_z2 = donor_market_z2,
  econ_latent1 = control_econ_latent1,
  econ_latent2 = control_econ_latent2,
  economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
  pre_access_z = control_access_z,
  pre_station_distance_m = control_pre_station_dist,
  pre_employment_density_z = control_pre_employment_density_z,
  pre_commercial_share_z = control_pre_commercial_share_z,
  pre_income_z = control_pre_income_z,
  latent_market_regime = donor_market_regime
)

# ---- 4. Complete control outcome trajectories --------------------------------
# Controls are fully observed and untreated.  Most scenarios retain the original
# coherent market surface in which donor outcome coefficients depend on latent
# market characteristics.  Two proposal-focused DGPs instead use a DGP2 outcome
# architecture: donor levels/trends/cycles retain genuine geographic structure
# but have no direct linear dependence on the observed/latent economic proxies.
# Economic information can therefore remain highly informative about W_true
# without automatically becoming a strong linear outcome-mean predictor.
#
# IMPORTANT: spatially_separated_donors shares only this DGP2 BASE outcome
# architecture.  It does NOT receive the extra latent temporal factors used by
# smooth_geo_econ_latent_factor, so its distinctive stress remains spatial donor
# separation/extrapolation rather than a second simultaneous DGP change.
DGP2_OUTCOME_ARCHITECTURE <- SCENARIO %in% c(
  "smooth_geo_econ_latent_factor", "spatially_separated_donors",
  "station_selected_local_standard", "station_selected_local_mismatch"
)
Tn <- length(YEARS)
time_index <- YEARS - min(YEARS)

common_factor_raw <-
  0.012 * sin(time_index / 3.1) +
  0.008 * cos(time_index / 5.0) +
  make_ar1(Tn, phi = COMMON_FACTOR_AR_PHI, sd = COMMON_FACTOR_AR_SD)
common_factor_raw <- common_factor_raw - mean(common_factor_raw)
if (DGP2_OUTCOME_ARCHITECTURE) {
  # In the DGP2 outcome architecture, keep a real geographic outcome signal for
  # kriging, but avoid giving Econ-X a direct linear market-loading advantage.
  common_factor_loading <- 1 + 0.12 * zscore_vec(
    sin(pi * control_xy[, 1] / 10000) +
      0.6 * cos(pi * control_xy[, 2] / 12000)
  ) + rnorm(N_CONTROL, 0, 0.10)
} else {
  common_factor_loading <- 1 + 0.18 * donor_market_z1 - 0.10 * donor_market_z2 +
    rnorm(N_CONTROL, 0, 0.10)
}

control_log <- matrix(NA_real_, nrow = N_CONTROL, ncol = Tn,
                      dimnames = list(control_ids, YEARS))

# Spatial bases used by the DGP2 outcome architecture. They leave
# genuine geographic structure for Gneiting kriging without making the safe
# economic proxies linear outcome-level regressors.
lf_base_spatial <- zscore_vec(
  sin(pi * control_xy[, 1] / 9000) + 0.7 * cos(pi * control_xy[, 2] / 11000)
)
lf_slope_spatial <- zscore_vec(
  cos(pi * (control_xy[, 1] + control_xy[, 2]) / 17000)
)
lf_cycle_spatial <- zscore_vec(
  sin(2 * pi * control_xy[, 1] / 20000) * cos(pi * control_xy[, 2] / 20000)
)

for (j in seq_len(N_CONTROL)) {
  if (DGP2_OUTCOME_ARCHITECTURE) {
    # Baseline donor trajectories are geographically structured but have no
    # direct linear dependence on the economic latent variables. Economic
    # information affects the target counterfactual mainly through donor
    # composition and the nonlinear factor loadings added below.
    base_j <- log(220000) + 0.10 * lf_base_spatial[j] + rnorm(1, 0, 0.10)
  } else {
    # Ordinary scenarios retain the original coherent market surface.
    base_j <- log(220000) +
      0.18 * donor_market_z1[j] - 0.10 * donor_market_z2[j] + rnorm(1, 0, 0.10)
  }

  if (DGP2_OUTCOME_ARCHITECTURE) {
    slope_j <- 0.004 + 0.0020 * lf_slope_spatial[j] + rnorm(1, 0, 0.0045)
    curve_j <- -0.00005 + rnorm(1, 0, 0.00008)
    cyc1_j <- 0.008 * lf_cycle_spatial[j] + rnorm(1, 0, 0.012)
    cyc2_j <- -0.006 * lf_base_spatial[j] + rnorm(1, 0, 0.010)
    local_cycle <- cyc1_j * sin(time_index / 2.8) + cyc2_j * cos(time_index / 4.2)
    ar_part <- make_ar1(Tn, phi = 0.55, sd = 0.006)
    common_part <- COMMON_FACTOR_SCALE * common_factor_loading[j] * common_factor_raw
    control_log[j, ] <- base_j + slope_j * time_index +
      curve_j * time_index^2 + local_cycle + common_part + ar_part
  } else {
    slope_j <- 0.004 + 0.0030 * donor_market_z1[j] +
      0.0015 * donor_market_z2[j] + rnorm(1, 0, 0.0045)
    curve_j <- -0.00005 + 0.00003 * donor_market_z2[j] + rnorm(1, 0, 0.00008)
    cyc1_j <- 0.010 * donor_market_z1[j] + rnorm(1, 0, 0.014)
    cyc2_j <- -0.008 * donor_market_z2[j] + rnorm(1, 0, 0.011)
    local_cycle <- cyc1_j * sin(time_index / 2.8) + cyc2_j * cos(time_index / 4.2)
    ar_part <- make_ar1(Tn, phi = 0.55, sd = 0.006)
    common_part <- COMMON_FACTOR_SCALE * common_factor_loading[j] * common_factor_raw
    control_log[j, ] <- base_j + slope_j * time_index +
      curve_j * time_index^2 + local_cycle + common_part + ar_part
  }
}

# ---- 4b. Local nonlinear economic-archetype outcome component ----------------
# The two local scenarios share this exact donor component.  In v9 donor outcomes
# are held fixed across the pair; target counterfactuals differ only because the
# target economic-to-location alignment changes W_true. Each loading is
# nonlinear in latent economics but residualized on the observed PRE Econ-X
# levels; this is intended to make donor-mixture differences consequential while
# keeping the direct linear Econ-X mean advantage modest.
local_archetype_component <- NULL
local_archetype_loadings <- NULL
local_archetype_series <- NULL
if (SCENARIO %in% c("station_selected_local_standard", "station_selected_local_mismatch")) {
  econ_proxy_control_local <- cbind(
    control_pre_employment_density_z,
    control_pre_commercial_share_z,
    control_pre_income_z
  )
  residualize_local_proxy <- function(v) {
    X <- cbind(1, econ_proxy_control_local)
    fit <- stats::lm.fit(x = X, y = as.numeric(v))
    zscore_vec(as.numeric(fit$residuals))
  }
  local_econ_rbf <- function(c1, c2, bw = LOCAL_ARCHETYPE_BW) {
    exp(-((control_econ_latent1 - c1)^2 +
            (control_econ_latent2 - c2)^2) / (2 * bw^2))
  }
  local_basis1 <- residualize_local_proxy(
    local_econ_rbf(-0.9, -0.4) - local_econ_rbf(0.8, 0.5)
  )
  local_basis2 <- residualize_local_proxy(
    local_econ_rbf(0.8, -0.8) - local_econ_rbf(-0.5, 0.9)
  )
  local_basis3 <- residualize_local_proxy(
    sin(1.5 * control_econ_latent1) * cos(1.3 * control_econ_latent2)
  )
  local_loading1 <- zscore_vec(local_basis1 + rnorm(N_CONTROL, 0, LOCAL_ARCHETYPE_IDIO_SD))
  local_loading2 <- zscore_vec(local_basis2 + rnorm(N_CONTROL, 0, LOCAL_ARCHETYPE_IDIO_SD))
  local_loading3 <- zscore_vec(local_basis3 + rnorm(N_CONTROL, 0, LOCAL_ARCHETYPE_IDIO_SD))

  local_factor1 <- zscore_vec(
    0.65 * sin(time_index / 2.1) + make_ar1(Tn, phi = 0.75, sd = 0.012)
  )
  local_factor2 <- zscore_vec(
    0.55 * cos(time_index / 3.0) + make_ar1(Tn, phi = 0.55, sd = 0.012)
  )
  local_factor3 <- zscore_vec(
    0.45 * sin(time_index / 4.0 + 0.7) +
      0.30 * cos(time_index / 1.8) + make_ar1(Tn, phi = 0.65, sd = 0.010)
  )
  local_archetype_loadings <- cbind(
    archetype1_loading = local_loading1,
    archetype2_loading = local_loading2,
    archetype3_loading = local_loading3
  )
  rownames(local_archetype_loadings) <- control_ids
  local_archetype_series <- cbind(
    archetype1 = local_factor1,
    archetype2 = local_factor2,
    archetype3 = local_factor3
  )
  rownames(local_archetype_series) <- YEARS
  local_archetype_component <- LOCAL_ARCHETYPE_SCALE * (
    outer(local_loading1, local_factor1) +
      outer(local_loading2, local_factor2) +
      outer(local_loading3, local_factor3)
  ) / sqrt(3)
  control_log <- control_log + local_archetype_component
}

latent_factor_component <- NULL
latent_factor_loadings <- NULL
latent_factor_series <- NULL

# Proposal-positive-control DGP: stable geo+econ donor weights, but outcome
# dependence is driven by several latent temporal factors rather than by a
# single stationary space-time covariance surface.  Factor loadings retain a
# meaningful geographic component so this is not an artificial anti-kriging
# construction; the remaining signal is nonlinear in latent market/economic
# state and partly donor-specific.
if (SCENARIO == "smooth_geo_econ_latent_factor") {
  lf_spatial1 <- zscore_vec(
    sin(2 * pi * control_xy[, 1] / 20000) * cos(pi * control_xy[, 2] / 20000)
  )
  lf_spatial2 <- zscore_vec(
    cos(pi * control_xy[, 1] / 10000 + control_xy[, 2] / 14000)
  )
  lf_spatial3 <- zscore_vec(
    sin(pi * (control_xy[, 1] + control_xy[, 2]) / 18000)
  )

  # The observed economic variables are useful as a DISTANCE metric but should
  # not become strong linear outcome-level regressors. Build nonlinear local
  # economic archetypes and remove only their linear projection on the three
  # observed proxy levels. Nearby economic states remain similar, which is what
  # GeoEco-SCM exploits through Mahalanobis edge distance.
  econ_proxy_control <- cbind(
    control_pre_employment_density_z,
    control_pre_commercial_share_z,
    control_pre_income_z
  )
  residualize_linear_proxy <- function(v) {
    X <- cbind(1, econ_proxy_control)
    fit <- stats::lm.fit(x = X, y = as.numeric(v))
    zscore_vec(as.numeric(fit$residuals))
  }
  econ_rbf <- function(c1, c2, bw = LATENT_FACTOR_ECON_BASIS_BW) {
    exp(-((control_econ_latent1 - c1)^2 +
            (control_econ_latent2 - c2)^2) / (2 * bw^2))
  }

  econ_basis1 <- residualize_linear_proxy(
    econ_rbf(-0.9, -0.5) - econ_rbf(0.8, 0.4)
  )
  econ_basis2 <- residualize_linear_proxy(
    econ_rbf(0.9, -0.7) - econ_rbf(-0.4, 0.9)
  )
  econ_basis3 <- residualize_linear_proxy(
    sin(1.6 * control_econ_latent1) * cos(1.4 * control_econ_latent2)
  )

  make_loading <- function(spatial_part, econ_part) {
    zscore_vec(
      sqrt(LATENT_FACTOR_SPATIAL_SHARE) * spatial_part +
        sqrt(1 - LATENT_FACTOR_SPATIAL_SHARE) * econ_part +
        rnorm(N_CONTROL, 0, LATENT_FACTOR_IDIO_SD)
    )
  }

  loading1 <- make_loading(lf_spatial1, econ_basis1)
  loading2 <- make_loading(lf_spatial2, econ_basis2)
  loading3 <- make_loading(lf_spatial3, econ_basis3)

  factor1 <- zscore_vec(make_ar1(Tn, phi = LATENT_FACTOR_AR1_PHI, sd = 0.018))
  factor2 <- zscore_vec(
    make_ar1(Tn, phi = LATENT_FACTOR_AR2_PHI, sd = 0.018) +
      0.60 * sin(time_index / 1.9)
  )
  factor3 <- zscore_vec(
    0.55 * cos(time_index / 3.1) +
      0.45 * as.numeric(YEARS >= LATENT_FACTOR_SHOCK_YEAR) +
      make_ar1(Tn, phi = 0.55, sd = 0.010)
  )

  latent_factor_loadings <- cbind(
    factor1_loading = loading1,
    factor2_loading = loading2,
    factor3_loading = loading3
  )
  rownames(latent_factor_loadings) <- control_ids
  latent_factor_series <- cbind(factor1 = factor1, factor2 = factor2, factor3 = factor3)
  rownames(latent_factor_series) <- YEARS

  latent_factor_component <- LATENT_FACTOR_SCALE * (
    outer(loading1, factor1) +
      outer(loading2, factor2) +
      outer(loading3, factor3)
  ) / sqrt(3)

  control_log <- control_log + latent_factor_component
}

# ---- 5. Known spatially varying SCM weights ---------------------------------
# The smooth scenarios impose smoothness on the TARGET representation, not on
# target-donor geographic distance.  A target is matched to donor locations
# with similar latent market exposures and PRE-treatment accessibility.
#
# score_ij = -1/2 [ ((z1_i-b1_j)/h_z)^2 + ((z2_i-b2_j)/h_z)^2
#                  + a_access ((A_i-A_j)/h_A)^2 ]
# w_true_ij = softmax_j(score_ij).
#
# In smooth_geo_only, z_i is geographic only.  In smooth_geo_econ and the
# derived stress scenarios, z_i also contains the partly non-spatial economic
# latent state.  A donor does NOT receive a direct bonus merely because it is
# physically near the target.
W_true <- matrix(NA_real_, nrow = N_TARGET, ncol = N_CONTROL,
                 dimnames = list(target_ids, control_ids))

for (i in seq_len(N_TARGET)) {
  if (SCENARIO == "no_spatial") {
    # Deliberately violate the core spatial-smoothness assumption: each target
    # gets an independent concentrated simplex weight vector.
    z <- stats::rgamma(N_CONTROL, shape = NO_SPATIAL_DIRICHLET_SHAPE, rate = 1)
    W_true[i, ] <- z / sum(z)
  } else {
    latent_d1 <- (donor_market_z1 - target_market_z1[i]) / WEIGHT_LATENT_SCALE
    latent_d2 <- (donor_market_z2 - target_market_z2[i]) / WEIGHT_LATENT_SCALE
    access_d <- (control_access_z - target_access_z[i]) / WEIGHT_ACCESS_SCALE

    score <- -0.5 * (
      latent_d1^2 +
        latent_d2^2 +
        WEIGHT_ACCESS_IMPORTANCE * access_d^2
    )

    if (SCENARIO == "boundary") {
      # Abrupt latent-market boundary at x = 10 km.  Target market type jumps
      # across the boundary, while donor regime labels remain unrelated to
      # donor physical location.  This isolates oversmoothing across a target
      # market boundary from any target-donor-nearness assumption.
      target_regime <- if (target_xy[i, 1] >= 10000) "east_type" else "west_type"
      score <- score + BOUNDARY_BONUS *
        as.numeric(donor_market_regime == target_regime)
    }

    W_true[i, ] <- softmax_stable(score)
  }
}

stopifnot(max(abs(rowSums(W_true) - 1)) < 1e-10)
stopifnot(min(W_true) >= 0)

# Scenario-invariant STANDARD reference weights for the paired orthogonalization.
# This keeps donor outcome trajectories identical across standard/mismatch; the
# final pair differs through target economic-geographic alignment and hence its
# actual W_true only.
W_true_pair_reference <- W_true
if (LOCAL_PAIRED_SCENARIO) {
  W_true_pair_reference <- matrix(NA_real_, nrow = N_TARGET, ncol = N_CONTROL,
                                  dimnames = list(target_ids, control_ids))
  for (i in seq_len(N_TARGET)) {
    latent_d1 <- (donor_market_z1 - target_market_z1_standard[i]) / WEIGHT_LATENT_SCALE
    latent_d2 <- (donor_market_z2 - target_market_z2_standard[i]) / WEIGHT_LATENT_SCALE
    access_d <- (control_access_z - target_access_z[i]) / WEIGHT_ACCESS_SCALE
    score_ref <- -0.5 * (latent_d1^2 + latent_d2^2 +
                           WEIGHT_ACCESS_IMPORTANCE * access_d^2)
    W_true_pair_reference[i, ] <- softmax_stable(score_ref)
  }
  stopifnot(max(abs(rowSums(W_true_pair_reference) - 1)) < 1e-10)
}

# ---- 5b. Local-DGP2 Econ-X orthogonalization --------------------------------
# For the local-standard/local-mismatch pair only, isolate the scientific
# mechanism of interest while keeping donor outcomes exactly common across the
# pair. The projection is therefore defined from the STANDARD reference economic
# alignment and W_true_pair_reference in both scenarios. Let E_res be standard
# PRE economic proxies residualized on [1,X,Y]. For each donor outcome vector c_t,
# remove its component in A = E_res' W_true_pair_reference. Then
#     E_res' W_true_pair_reference c_t(new) ~= 0,
# while the exact SCM identity Y0_t = W_true c_t(new) is preserved.  This is a
# truth-side DGP construction only; estimators never see W_true or this projection.
LOCAL_DGP2_PAIR <- SCENARIO %in% c(
  "station_selected_local_standard", "station_selected_local_mismatch"
)
local_dgp2_orthogonalization_active <-
  LOCAL_DGP2_PAIR && LOCAL_DGP2_ECON_ORTHOGONALIZE
local_dgp2_control_log_before <- NULL
local_dgp2_true_cf_before <- NULL
local_dgp2_orthogonalization_relative_adjustment <- 0
local_dgp2_orthogonality_max_abs_moment_before <- NA_real_
local_dgp2_orthogonality_max_abs_moment_after <- NA_real_

if (local_dgp2_orthogonalization_active) {
  local_dgp2_control_log_before <- control_log
  local_dgp2_true_cf_before <- W_true_pair_reference %*% control_log

  G_target <- cbind(
    intercept = 1,
    X_km = target_xy[, 1] / 1000,
    Y_km = target_xy[, 2] / 1000
  )
  # Use the STANDARD economic alignment as a scenario-invariant reference.
  E_target <- cbind(
    pre_employment_density_z = target_pre_employment_density_z_base,
    pre_commercial_share_z = target_pre_commercial_share_z_base,
    pre_income_z = target_pre_income_z_base
  )
  E_res <- apply(E_target, 2, function(v) {
    fit <- stats::lm.fit(x = G_target, y = as.numeric(v))
    as.numeric(fit$residuals)
  })
  if (is.null(dim(E_res))) E_res <- matrix(E_res, ncol = 1)

  A_econ <- crossprod(E_res, W_true_pair_reference)  # p_econ x n_control
  AAt <- A_econ %*% t(A_econ)
  ridge_scale <- max(mean(diag(AAt)), 1)
  M_econ <- AAt + diag(
    LOCAL_DGP2_ECON_ORTHOGONALIZATION_RIDGE * ridge_scale,
    nrow(AAt)
  )

  for (tt in seq_len(ncol(control_log))) {
    v <- control_log[, tt]
    rhs <- A_econ %*% v
    coef_adj <- tryCatch(
      solve(M_econ, rhs),
      error = function(e) qr.solve(M_econ, rhs, tol = 1e-12)
    )
    projection <- as.numeric(t(A_econ) %*% coef_adj)
    control_log[, tt] <- v -
      LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH * projection
  }

  local_dgp2_true_cf_after <- W_true_pair_reference %*% control_log
  moment_before <- crossprod(E_res, local_dgp2_true_cf_before) / nrow(E_res)
  moment_after <- crossprod(E_res, local_dgp2_true_cf_after) / nrow(E_res)
  local_dgp2_orthogonality_max_abs_moment_before <- max(abs(moment_before))
  local_dgp2_orthogonality_max_abs_moment_after <- max(abs(moment_after))
  local_dgp2_orthogonalization_relative_adjustment <-
    sqrt(sum((control_log - local_dgp2_control_log_before)^2)) /
    max(sqrt(sum(local_dgp2_control_log_before^2)), 1e-12)
}

# ---- 6. True untreated treatment outcomes -----------------------------------
# This is the exact SCM counterfactual before observation noise.
true_cf_log <- W_true %*% control_log
rownames(true_cf_log) <- target_ids
colnames(true_cf_log) <- YEARS

# ---- 7. Known treatment effect ----------------------------------------------
# Treatment starts in 2005 and gradually ramps up. The long-run log effect is
# larger near the synthetic new station. This lets us assess ATT recovery.
tau_log <- matrix(0, nrow = N_TARGET, ncol = Tn,
                  dimnames = list(target_ids, YEARS))

site_longrun_tau <- 0.015 + 0.105 * exp(-target_new_station_dist / 5000)
for (tt in seq_along(YEARS)) {
  yy <- YEARS[tt]
  if (yy >= 2005) {
    ramp <- min(1, (yy - 2004) / 5)
    tau_log[, tt] <- site_longrun_tau * ramp
  }
}

# Observed treatment outcomes = untreated CF + known treatment effect + noise.
target_noise <- matrix(
  rnorm(N_TARGET * Tn, 0, TARGET_NOISE_SD),
  nrow = N_TARGET, ncol = Tn,
  dimnames = list(target_ids, YEARS)
)
target_log_complete <- true_cf_log + tau_log + target_noise

# ---- 8. Create missing PRE histories ----------------------------------------
n_complete <- round(N_TARGET * PROP_COMPLETE)
n_partial <- round(N_TARGET * PROP_PARTIAL)
n_postonly <- N_TARGET - n_complete - n_partial

pre_pos <- match(PERIOD_PRE, YEARS)
post_pos <- match(PERIOD_POST, YEARS)

# Truth-side quantities used ONLY to generate/diagnose the observation process.
# Estimators never receive latent PRE prices at post-only sites.
pre_cf_mean_log <- rowMeans(true_cf_log[, pre_pos, drop = FALSE])
low_pre_price_z <- -zscore_vec(pre_cf_mean_log)
near_new_station_raw <- exp(-target_new_station_dist / STATION_SELECTION_NEAR_SCALE_M)
near_new_station_z <- zscore_vec(near_new_station_raw)
station_selection_score_standard <-
  STATION_SELECTION_NEAR_COEF * near_new_station_z +
  STATION_SELECTION_LOW_PRICE_COEF * low_pre_price_z +
  STATION_SELECTION_INTERACTION_COEF * near_new_station_z * low_pre_price_z

station_selection_score_local_mismatch <-
  LOCAL_MISMATCH_NEAR_COEF * near_new_station_z +
  LOCAL_MISMATCH_ECON_COEF * local_econ_mismatch_z +
  LOCAL_MISMATCH_MIXEDNESS_COEF * local_mixed_neighbor_score +
  LOCAL_MISMATCH_LOW_PRICE_COEF * low_pre_price_z +
  LOCAL_MISMATCH_INTERACTION_COEF * near_new_station_z * local_mixed_neighbor_score

# v9 PAIRING RULE: local-standard and local-mismatch use the SAME selection
# score and the SAME candidate set.  The score uses geography/station proximity
# only; the candidate set is the pre-specified mixed-support set under the
# mismatch alignment.  Thus post-only membership cannot change between the two.
station_selection_score <- if (LOCAL_PAIRED_SCENARIO) {
  LOCAL_PAIRED_SELECTION_NEAR_COEF * near_new_station_z
} else if (OBSERVATION_SELECTION_MODE == "station_selected_local_mismatch") {
  station_selection_score_local_mismatch
} else {
  station_selection_score_standard
}

# Select post-only sites.  In the local-mismatch scenario v8 first constructs
# a COMPLETE feasible post-only set before accepting the observation pattern.
# This avoids the v7 failure mode in which a myopic sequential draw could enter
# a dead end even when another size-n_postonly feasible subset exists.
#
# Candidate ranking is stochastic but uses only the pre-specified observation-
# selection probabilities (a weighted random permutation / exponential race).
# A greedy pass is attempted first.  If it cannot reach n_postonly, a bounded
# include/exclude backtracking search uses the same ex-ante ranking.  At no point
# are W_true, Y0, treatment effects, or estimator performance used.  The DGP
# stops rather than relaxing the 2+2 PRE-anchor constraints.
local_selection_constraint_used <- FALSE
local_selection_search_method <- "not_used"
local_selection_search_nodes <- NA_integer_
local_selection_search_max_nodes <- as.integer(Sys.getenv(
  "SIM_LOCAL_FEASIBLE_SEARCH_MAX_NODES", unset = "10000000"
))
local_selection_search_aborted <- FALSE
local_selection_candidate_count <- NA_integer_
if (!is.finite(local_selection_search_max_nodes) || local_selection_search_max_nodes < 1000L) {
  stop("SIM_LOCAL_FEASIBLE_SEARCH_MAX_NODES must be an integer >= 1000.")
}

if (LOCAL_PAIRED_SCENARIO) {
  local_selection_constraint_used <- TRUE
  local_selection_candidate_count <- sum(paired_local_mismatch_candidate_eligible)
  if (local_selection_candidate_count < n_postonly) {
    stop(
      "Local mismatch DGP has only ", local_selection_candidate_count,
      " candidate targets after the mixed-neighborhood + observed-mismatch threshold for ",
      n_postonly, " post-only slots. Lower SIM_LOCAL_MISMATCH_CANDIDATE_QUANTILE ",
      "or increase N_TARGET; no result-dependent relaxation is applied."
    )
  }
  station_selection_prob <- rep(0, N_TARGET)
  base_prob <- softmax_stable(station_selection_score / STATION_SELECTION_TEMPERATURE)
  station_selection_prob[paired_local_mismatch_candidate_eligible] <-
    base_prob[paired_local_mismatch_candidate_eligible] /
    sum(base_prob[paired_local_mismatch_candidate_eligible])

  similar_neighbor_list <- lapply(seq_len(N_TARGET), function(i) {
    nn <- geo_knn_index[i, ]
    nn[paired_mismatch_metrics$distance[i, ] <= paired_mismatch_metrics$similar_threshold]
  })
  dissimilar_neighbor_list <- lapply(seq_len(N_TARGET), function(i) {
    nn <- geo_knn_index[i, ]
    nn[paired_mismatch_metrics$distance[i, ] >= paired_mismatch_metrics$dissimilar_threshold]
  })
  feasible_postonly_set <- function(sel) {
    if (!length(sel)) return(TRUE)
    all(vapply(sel, function(i) {
      sum(!(similar_neighbor_list[[i]] %in% sel)) >= LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS &&
        sum(!(dissimilar_neighbor_list[[i]] %in% sel)) >= LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS
    }, logical(1)))
  }

  # Ex-ante weighted random priority.  For positive weights, sorting
  # -log(U)/w is a weighted random permutation without replacement.
  candidate_ids <- which(paired_local_mismatch_candidate_eligible)
  priority_w <- station_selection_prob[candidate_ids]
  if (!all(is.finite(priority_w)) || sum(priority_w) <= 0) {
    priority_w <- rep(1 / length(candidate_ids), length(candidate_ids))
  }
  priority_w <- pmax(priority_w, .Machine$double.xmin)
  priority_key <- -log(stats::runif(length(candidate_ids))) / priority_w
  candidate_order <- candidate_ids[order(priority_key)]

  # Fast feasible greedy construction first.
  greedy_sel <- integer(0)
  for (j in candidate_order) {
    if (length(greedy_sel) >= n_postonly) break
    trial <- c(greedy_sel, j)
    if (feasible_postonly_set(trial)) greedy_sel <- trial
  }

  if (length(greedy_sel) >= n_postonly) {
    idx_postonly <- greedy_sel[seq_len(n_postonly)]
    local_selection_search_method <- "weighted_greedy_feasible_set"
    local_selection_search_nodes <- 0L
  } else {
    # Backtracking search over the same pre-specified stochastic ranking.
    # The search returns the first complete feasible set of the requested size.
    # Because current selections are always feasible, infeasible branches can be
    # pruned immediately.  The large safety cap prevents pathological runtimes;
    # if hit, the generator stops and reports the cap rather than relaxing rules.
    search_nodes <- 0L
    search_aborted <- FALSE
    best_size <- 0L
    n_order <- length(candidate_order)

    search_feasible_set <- function(pos, sel) {
      search_nodes <<- search_nodes + 1L
      if (search_nodes > local_selection_search_max_nodes) {
        search_aborted <<- TRUE
        return(NULL)
      }
      if (length(sel) > best_size) best_size <<- length(sel)
      if (length(sel) == n_postonly) return(sel)
      if (pos > n_order) return(NULL)
      if (length(sel) + (n_order - pos + 1L) < n_postonly) return(NULL)

      j <- candidate_order[pos]
      trial <- c(sel, j)
      if (feasible_postonly_set(trial)) {
        ans <- search_feasible_set(pos + 1L, trial)
        if (!is.null(ans)) return(ans)
      }
      search_feasible_set(pos + 1L, sel)
    }

    idx_postonly <- search_feasible_set(1L, integer(0))
    local_selection_search_nodes <- search_nodes
    local_selection_search_aborted <- search_aborted
    local_selection_search_method <- "weighted_priority_backtracking"

    if (is.null(idx_postonly)) {
      reason <- if (search_aborted) {
        paste0(
          "search reached SIM_LOCAL_FEASIBLE_SEARCH_MAX_NODES=",
          local_selection_search_max_nodes,
          " (best feasible partial size=", best_size, ")"
        )
      } else {
        paste0(
          "candidate set was exhaustively searched with no feasible size-",
          n_postonly, " subset (best feasible partial size=", best_size, ")"
        )
      }
      stop(
        "Local mixed-neighborhood v8 could not construct the required complete feasible post-only set: ",
        reason,
        ". Candidate quantile is fixed ex ante; no result-dependent relaxation is applied."
      )
    }
  }

  if (length(idx_postonly) != n_postonly || !feasible_postonly_set(idx_postonly)) {
    stop("Internal v8 DGP error: completed local-mismatch post-only set is not feasible.")
  }
} else if (OBSERVATION_SELECTION_MODE == "station_selected") {
  station_selection_prob <- softmax_stable(
    station_selection_score / STATION_SELECTION_TEMPERATURE
  )
  idx_postonly <- sample(
    seq_len(N_TARGET), size = n_postonly, replace = FALSE,
    prob = station_selection_prob
  )
} else {
  station_selection_prob <- rep(1 / N_TARGET, N_TARGET)
  idx_postonly <- sample(seq_len(N_TARGET), size = n_postonly, replace = FALSE)
}

remaining_after_post <- setdiff(seq_len(N_TARGET), idx_postonly)
idx_partial <- sample(remaining_after_post, size = n_partial, replace = FALSE)
idx_complete <- setdiff(remaining_after_post, idx_partial)
stopifnot(length(idx_complete) == n_complete, length(idx_partial) == n_partial,
          length(idx_postonly) == n_postonly)

obs_group <- rep(NA_character_, N_TARGET)
obs_group[idx_complete] <- "complete_pre"
obs_group[idx_partial] <- "partial_pre"
obs_group[idx_postonly] <- "post_only"

target_log_observed <- target_log_complete

# Partial-pre: randomly retain only 4-8 pre-treatment observations.
for (i in idx_partial) {
  n_keep <- sample(4:8, 1)
  keep_years <- sample(PERIOD_PRE, n_keep, replace = FALSE)
  drop_pos <- pre_pos[!(PERIOD_PRE %in% keep_years)]
  target_log_observed[i, drop_pos] <- NA_real_
}

# Post-only: hide every pre-treatment outcome.
target_log_observed[idx_postonly, pre_pos] <- NA_real_

# Keep all post-treatment observations in the first validation experiment so
# treatment-effect recovery can be evaluated cleanly.

observation_selection <- tibble::tibble(
  point_id = target_ids,
  obs_group = obs_group,
  selection_mode = OBSERVATION_SELECTION_MODE,
  new_station_distance_m = target_new_station_dist,
  near_new_station_raw = near_new_station_raw,
  near_new_station_z = near_new_station_z,
  latent_pre_cf_mean_log = pre_cf_mean_log,
  low_pre_price_z = low_pre_price_z,
  local_econ_mismatch_score = local_econ_mismatch_score,
  local_econ_mismatch_z = local_econ_mismatch_z,
  local_similar_neighbor_count = local_similar_neighbor_count,
  local_dissimilar_neighbor_count = local_dissimilar_neighbor_count,
  local_mixed_neighbor_eligible = local_mixed_neighbor_eligible,
  local_mismatch_candidate_eligible = local_mismatch_candidate_eligible,
  local_mismatch_candidate_threshold = local_mismatch_candidate_threshold,
  local_mixed_neighbor_score = local_mixed_neighbor_score,
  selection_score = station_selection_score,
  sampling_probability = station_selection_prob,
  true_longrun_tau_log = site_longrun_tau,
  true_longrun_tau_pct = (exp(site_longrun_tau) - 1) * 100
)

# ---- 8b. Local mismatch diagnostics -----------------------------------------
# Truth is used only for diagnostics below, never for tuning or estimation.
row_cosine <- function(a, b) {
  den <- sqrt(sum(a^2)) * sqrt(sum(b^2))
  if (!is.finite(den) || den <= 0) return(NA_real_)
  sum(a * b) / den
}
local_true_weight_dissimilarity <- vapply(seq_len(N_TARGET), function(i) {
  nn <- order(target_pairwise_geo_dist[i, ])[seq_len(k_mismatch)]
  1 - mean(vapply(nn, function(k) row_cosine(W_true[i, ], W_true[k, ]), numeric(1)),
           na.rm = TRUE)
}, numeric(1))
q_obs <- stats::quantile(local_econ_mismatch_score, 0.75, na.rm = TRUE)
q_true <- stats::quantile(local_true_weight_dissimilarity, 0.75, na.rm = TRUE)
# Count the local PRE-observed support that actually remains after post-only
# assignment.  These are the key v8 design diagnostics.
local_similar_pre_anchor_count <- vapply(seq_len(N_TARGET), function(i) {
  nn <- geo_knn_index[i, ]
  keep <- geo_knn_econ_dist[i, ] <= local_similar_edge_threshold
  sum(obs_group[nn[keep]] != "post_only")
}, integer(1))
local_dissimilar_pre_anchor_count <- vapply(seq_len(N_TARGET), function(i) {
  nn <- geo_knn_index[i, ]
  keep <- geo_knn_econ_dist[i, ] >= local_dissimilar_edge_threshold
  sum(obs_group[nn[keep]] != "post_only")
}, integer(1))
local_mixed_pre_anchor_support <-
  local_similar_pre_anchor_count >= LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS &
  local_dissimilar_pre_anchor_count >= LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS

# Paired-design support diagnostics use the mismatch alignment irrespective of
# which member is currently being generated.
paired_similar_pre_anchor_count <- vapply(seq_len(N_TARGET), function(i) {
  nn <- geo_knn_index[i, ]
  keep <- paired_mismatch_metrics$distance[i, ] <= paired_mismatch_metrics$similar_threshold
  sum(obs_group[nn[keep]] != "post_only")
}, integer(1))
paired_dissimilar_pre_anchor_count <- vapply(seq_len(N_TARGET), function(i) {
  nn <- geo_knn_index[i, ]
  keep <- paired_mismatch_metrics$distance[i, ] >= paired_mismatch_metrics$dissimilar_threshold
  sum(obs_group[nn[keep]] != "post_only")
}, integer(1))
paired_mixed_pre_anchor_support <-
  paired_similar_pre_anchor_count >= LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS &
  paired_dissimilar_pre_anchor_count >= LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS
if (LOCAL_PAIRED_SCENARIO && any(!paired_mixed_pre_anchor_support[idx_postonly])) {
  stop("Internal v9 paired-DGP error: a fixed post-only target lost required mismatch mixed PRE-anchor support.")
}
if (LOCAL_PAIRED_SCENARIO &&
    any(!paired_local_mismatch_candidate_eligible[idx_postonly])) {
  stop("Internal v9 paired-DGP error: a fixed post-only target fell outside the pre-specified mismatch candidate set.")
}

local_mismatch_diagnostics <- tibble::tibble(
  point_id = target_ids,
  obs_group = obs_group,
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  new_station_distance_m = target_new_station_dist,
  local_econ_mismatch_score = local_econ_mismatch_score,
  local_econ_mismatch_z = local_econ_mismatch_z,
  local_similar_neighbor_count = local_similar_neighbor_count,
  local_dissimilar_neighbor_count = local_dissimilar_neighbor_count,
  local_mixed_neighbor_eligible = local_mixed_neighbor_eligible,
  local_mismatch_candidate_eligible = local_mismatch_candidate_eligible,
  local_mismatch_candidate_threshold = local_mismatch_candidate_threshold,
  local_mixed_neighbor_score = local_mixed_neighbor_score,
  local_similar_pre_anchor_count = local_similar_pre_anchor_count,
  local_dissimilar_pre_anchor_count = local_dissimilar_pre_anchor_count,
  local_mixed_pre_anchor_support = local_mixed_pre_anchor_support,
  paired_standard_local_mismatch_score = paired_standard_metrics$mismatch_score,
  paired_mismatch_local_mismatch_score = paired_mismatch_metrics$mismatch_score,
  paired_mismatch_minus_standard = paired_mismatch_metrics$mismatch_score -
    paired_standard_metrics$mismatch_score,
  paired_mismatch_candidate_eligible = paired_local_mismatch_candidate_eligible,
  paired_similar_pre_anchor_count = paired_similar_pre_anchor_count,
  paired_dissimilar_pre_anchor_count = paired_dissimilar_pre_anchor_count,
  paired_mixed_pre_anchor_support = paired_mixed_pre_anchor_support,
  local_true_weight_dissimilarity = local_true_weight_dissimilarity,
  high_observed_econ_mismatch = local_econ_mismatch_score >= q_obs,
  high_true_weight_mismatch = local_true_weight_dissimilarity >= q_true
)
readr::write_csv(
  local_mismatch_diagnostics,
  file.path(OUTPUT_DIR, "simulation_local_mismatch_diagnostics.csv")
)

# ---- 9. Convert to the same RDS schema used by 02 ----------------------------
price_cols <- paste0("price_", YEARS)

control_df <- tibble::tibble(
  point_id = control_ids,
  original_id = paste0("SIM_CONTROL_", seq_len(N_CONTROL)),
  group_type = "Control",
  X_m = control_xy[, 1],
  Y_m = control_xy[, 2],
  pre_station_distance_m = control_pre_station_dist,
  pre_access_z = control_access_z,
  pre_employment_density_z = control_pre_employment_density_z,
  pre_commercial_share_z = control_pre_commercial_share_z,
  pre_income_z = control_pre_income_z
)
for (tt in seq_along(YEARS)) {
  control_df[[price_cols[tt]]] <- exp(control_log[, tt])
}

# Treatment data retain NAs exactly where outcomes are intentionally hidden.
target_df <- tibble::tibble(
  point_id = target_ids,
  original_id = paste0("SIM_TREAT_", seq_len(N_TARGET)),
  group_type = "Treatment",
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  pre_station_distance_m = target_pre_station_dist,
  pre_access_z = target_access_z,
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z
)
for (tt in seq_along(YEARS)) {
  vv <- target_log_observed[, tt]
  target_df[[price_cols[tt]]] <- ifelse(is.finite(vv), exp(vv), NA_real_)
}

control_sf <- sf::st_as_sf(control_df, coords = c("X_m", "Y_m"),
                           crs = 6691, remove = FALSE)
target_sf <- sf::st_as_sf(target_df, coords = c("X_m", "Y_m"),
                          crs = 6691, remove = FALSE)
all_points <- rbind(control_sf, target_sf)
target_points <- target_sf

n_pre_obs <- rowSums(is.finite(target_log_observed[, pre_pos, drop = FALSE]))
n_post_obs <- rowSums(is.finite(target_log_observed[, post_pos, drop = FALSE]))

last_year <- apply(is.finite(target_log_observed), 1, function(z) {
  max(YEARS[z])
})

target_meta <- tibble::tibble(
  point_id = target_ids,
  original_id = target_df$original_id,
  obs_group = obs_group,
  n_pre_obs = n_pre_obs,
  n_post_obs = n_post_obs,
  last_year = last_year,
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  pre_station_distance_m = target_pre_station_dist,
  pre_access_z = target_access_z,
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z,
  # Included only because 02 currently carries this field into the output table.
  # In the simulation it is the SAME safe pre-treatment distance.
  StationDistance = target_pre_station_dist,
  true_new_station_distance_m = target_new_station_dist
)

# Simple bounding polygon; 02 does not use it in estimation, but it keeps the
# synthetic object structurally similar to the real prepared dataset.
poly_xy <- matrix(
  c(0, 0,
    20000, 0,
    20000, 20000,
    0, 20000,
    0, 0),
  ncol = 2, byrow = TRUE
)
study_area <- sf::st_sf(
  area_name = "synthetic_market",
  geometry = sf::st_sfc(sf::st_polygon(list(poly_xy)), crs = 6691)
)

simulation_truth <- list(
  scenario = SCENARIO,
  seed = SEED,
  W_true = W_true,
  true_cf_log = true_cf_log,
  tau_log = tau_log,
  control_log = control_log,
  target_noise = target_noise,
  control_ids = control_ids,
  target_ids = target_ids,
  pre_stations = pre_stations,
  new_station = new_station,
  target_market_features = target_market_features,
  donor_market_features = donor_market_features,
  common_market_factor = stats::setNames(common_factor_raw, YEARS),
  common_factor_loading = stats::setNames(common_factor_loading, control_ids),
  latent_factor_loadings = latent_factor_loadings,
  latent_factor_series = latent_factor_series,
  latent_factor_component = latent_factor_component,
  local_archetype_loadings = local_archetype_loadings,
  local_archetype_series = local_archetype_series,
  local_archetype_component = local_archetype_component,
  observation_selection = observation_selection,
  local_mismatch_diagnostics = local_mismatch_diagnostics,
  paired_alignment_diagnostics = paired_alignment_diagnostics,
  paired_econ_permutation = paired_econ_permutation,
  W_true_pair_reference = W_true_pair_reference,
  parameters = list(
    target_noise_sd = TARGET_NOISE_SD,
    weight_latent_scale = WEIGHT_LATENT_SCALE,
    weight_access_scale = WEIGHT_ACCESS_SCALE,
    weight_access_importance = WEIGHT_ACCESS_IMPORTANCE,
    economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
    econ_market_strength = ECON_MARKET_STRENGTH,
    econ_spatial_share = econ_spatial_share_now,
    local_paired_design = LOCAL_PAIRED_SCENARIO,
    local_paired_mismatch_active = LOCAL_PAIRED_MISMATCH_ACTIVE,
    local_paired_econ_spatial_share = LOCAL_PAIRED_ECON_SPATIAL_SHARE,
    local_paired_mean_mismatch_gain = paired_mean_mismatch_gain,
    local_paired_selection_near_coef = LOCAL_PAIRED_SELECTION_NEAR_COEF,
    local_paired_design_min_mismatch_gain = LOCAL_PAIRED_DESIGN_MIN_MISMATCH_GAIN,
    direct_target_donor_geographic_distance_in_weight_score = FALSE,
    boundary_bonus = BOUNDARY_BONUS,
    latent_factor_scale = LATENT_FACTOR_SCALE,
    latent_factor_spatial_share = LATENT_FACTOR_SPATIAL_SHARE,
    latent_factor_idio_sd = LATENT_FACTOR_IDIO_SD,
    latent_factor_econ_basis_bw = LATENT_FACTOR_ECON_BASIS_BW,
    latent_factor_ar1_phi = LATENT_FACTOR_AR1_PHI,
    latent_factor_ar2_phi = LATENT_FACTOR_AR2_PHI,
    latent_factor_shock_year = LATENT_FACTOR_SHOCK_YEAR,
    spatial_support_center = SPATIAL_SUPPORT_CENTER,
    spatial_target_radius_m = SPATIAL_TARGET_RADIUS_M,
    spatial_buffer_outer_radius_m = SPATIAL_BUFFER_OUTER_RADIUS_M,
    spatial_control_outer_radius_m = SPATIAL_CONTROL_OUTER_RADIUS_M,
    no_spatial_dirichlet_shape = NO_SPATIAL_DIRICHLET_SHAPE,
    econ_proxy_noise_sd = ECON_PROXY_NOISE_SD,
    observation_selection_mode = OBSERVATION_SELECTION_MODE,
    station_selection_near_scale_m = STATION_SELECTION_NEAR_SCALE_M,
    station_selection_near_coef = STATION_SELECTION_NEAR_COEF,
    station_selection_low_price_coef = STATION_SELECTION_LOW_PRICE_COEF,
    station_selection_interaction_coef = STATION_SELECTION_INTERACTION_COEF,
    station_selection_temperature = STATION_SELECTION_TEMPERATURE,
    local_mismatch_k = LOCAL_MISMATCH_K,
    local_mismatch_near_coef = LOCAL_MISMATCH_NEAR_COEF,
    local_mismatch_econ_coef = LOCAL_MISMATCH_ECON_COEF,
    local_mismatch_mixedness_coef = LOCAL_MISMATCH_MIXEDNESS_COEF,
    local_mismatch_low_price_coef = LOCAL_MISMATCH_LOW_PRICE_COEF,
    local_mismatch_interaction_coef = LOCAL_MISMATCH_INTERACTION_COEF,
    local_mix_similar_edge_quantile = LOCAL_MIX_SIMILAR_EDGE_QUANTILE,
    local_mix_dissimilar_edge_quantile = LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE,
    local_mix_similar_edge_threshold = local_similar_edge_threshold,
    local_mix_dissimilar_edge_threshold = local_dissimilar_edge_threshold,
    local_mix_min_similar_pre_anchors = LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS,
    local_mix_min_dissimilar_pre_anchors = LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS,
    local_selection_constraint_used = local_selection_constraint_used,
    local_archetype_scale = LOCAL_ARCHETYPE_SCALE,
    local_archetype_bw = LOCAL_ARCHETYPE_BW,
    local_archetype_idio_sd = LOCAL_ARCHETYPE_IDIO_SD,
    local_dgp2_econ_orthogonalization_active = local_dgp2_orthogonalization_active,
    local_dgp2_econ_orthogonalization_strength = LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH,
    local_dgp2_econ_orthogonalization_ridge = LOCAL_DGP2_ECON_ORTHOGONALIZATION_RIDGE,
    local_dgp2_orthogonalization_relative_adjustment = local_dgp2_orthogonalization_relative_adjustment,
    common_factor_scale = COMMON_FACTOR_SCALE,
    common_factor_ar_phi = COMMON_FACTOR_AR_PHI,
    common_factor_ar_sd = COMMON_FACTOR_AR_SD
  )
)

dataset <- list(
  schema_version = "M1_LP_spatial_scm_dataset_v1",
  config = list(
    years = YEARS,
    period_pre = PERIOD_PRE,
    period_post = PERIOD_POST,
    synthetic = TRUE,
    scenario = SCENARIO
  ),
  study_area = study_area,
  all_points = all_points,
  target_points = target_points,
  target_meta = target_meta,
  simulation_truth = simulation_truth
)

rds_path <- file.path(OUTPUT_DIR, "M1_LP_synthetic_dataset.rds")
saveRDS(dataset, rds_path)

# ---- 10. Human-readable truth files -----------------------------------------
weights_truth <- as.data.frame(W_true, check.names = FALSE) %>%
  tibble::rownames_to_column("point_id")
readr::write_csv(weights_truth, file.path(OUTPUT_DIR, "truth_weights.csv"))

readr::write_csv(target_market_features,
                 file.path(OUTPUT_DIR, "truth_and_observed_target_market_features.csv"))
readr::write_csv(donor_market_features,
                 file.path(OUTPUT_DIR, "truth_and_observed_donor_market_features.csv"))
readr::write_csv(
  target_market_features,
  file.path(OUTPUT_DIR, "truth_target_latent_market_features.csv")
)
readr::write_csv(
  donor_market_features,
  file.path(OUTPUT_DIR, "truth_donor_latent_market_features.csv")
)

readr::write_csv(
  observation_selection,
  file.path(OUTPUT_DIR, "truth_observation_selection_by_site.csv")
)
observation_selection_summary <- observation_selection %>%
  dplyr::group_by(obs_group) %>%
  dplyr::summarise(
    n = dplyr::n(),
    mean_new_station_distance_m = mean(new_station_distance_m),
    mean_latent_pre_cf_log = mean(latent_pre_cf_mean_log),
    mean_low_pre_price_z = mean(low_pre_price_z),
    mean_true_longrun_tau_pct = mean(true_longrun_tau_pct),
    mean_selection_score = mean(selection_score),
    .groups = "drop"
  )
readr::write_csv(
  observation_selection_summary,
  file.path(OUTPUT_DIR, "simulation_observation_selection_diagnostics.csv")
)

# How concentrated are the true weights? This is a key diagnostic because a
# diffuse W_true makes uniform weights an unrealistically strong benchmark.
truth_weight_concentration <- tibble::tibble(
  point_id = target_ids,
  obs_group = obs_group,
  max_true_weight = apply(W_true, 1, max),
  true_effective_donors = 1 / rowSums(W_true^2),
  true_weight_entropy = -rowSums(ifelse(W_true > 0, W_true * log(W_true), 0))
)
readr::write_csv(
  truth_weight_concentration,
  file.path(OUTPUT_DIR, "truth_weight_concentration_by_site.csv")
)
truth_weight_concentration_summary <- truth_weight_concentration %>%
  dplyr::summarise(
    mean_effective_donors = mean(true_effective_donors),
    median_effective_donors = median(true_effective_donors),
    p10_effective_donors = quantile(true_effective_donors, 0.10),
    p90_effective_donors = quantile(true_effective_donors, 0.90),
    mean_max_true_weight = mean(max_true_weight)
  )
readr::write_csv(
  truth_weight_concentration_summary,
  file.path(OUTPUT_DIR, "truth_weight_concentration_summary.csv")
)

truth_cf_long <- as.data.frame(true_cf_log) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "true_cf_log") %>%
  dplyr::mutate(year = as.integer(year), true_cf_yen = exp(true_cf_log))
readr::write_csv(truth_cf_long, file.path(OUTPUT_DIR, "truth_counterfactual_long.csv"))

truth_tau_long <- as.data.frame(tau_log) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "true_tau_log") %>%
  dplyr::mutate(
    year = as.integer(year),
    true_tau_pct = (exp(true_tau_log) - 1) * 100
  )
readr::write_csv(truth_tau_long, file.path(OUTPUT_DIR, "truth_treatment_effect_long.csv"))

true_att <- truth_tau_long %>%
  dplyr::filter(year %in% PERIOD_POST) %>%
  dplyr::group_by(year) %>%
  dplyr::summarise(
    true_ATT_log = mean(true_tau_log),
    true_ATT_pct = (exp(true_ATT_log) - 1) * 100,
    .groups = "drop"
  )
readr::write_csv(true_att, file.path(OUTPUT_DIR, "truth_ATT_by_year.csv"))

# Truth-only ATT populations.  The gap between PRE_OBSERVED and ALL is the pure
# observation-selection component that ordinary site-specific SCM cannot remove.
att_population_index <- list(
  ALL = seq_len(N_TARGET),
  PRE_OBSERVED = which(obs_group != "post_only"),
  POST_ONLY = which(obs_group == "post_only"),
  COMPLETE_PRE = which(obs_group == "complete_pre"),
  PARTIAL_PRE = which(obs_group == "partial_pre")
)
true_att_by_population <- dplyr::bind_rows(lapply(names(att_population_index), function(pop) {
  ii <- att_population_index[[pop]]
  dplyr::bind_rows(lapply(PERIOD_POST, function(yy) {
    tt <- match(yy, YEARS)
    mlog <- mean(tau_log[ii, tt])
    tibble::tibble(
      population = pop, year = yy, n_sites = length(ii),
      true_ATT_log = mlog, true_ATT_pct = (exp(mlog) - 1) * 100
    )
  }))
}))
readr::write_csv(
  true_att_by_population,
  file.path(OUTPUT_DIR, "truth_ATT_by_observation_population.csv")
)

true_weight_model_label <- dplyr::case_when(
  SCENARIO == "smooth_geo_only" ~
    "concentrated weights from geographic latent market similarity + spatial PRE accessibility; economic proxies are irrelevant nuisance variables",
  SCENARIO == "smooth_geo_econ" ~
    "concentrated weights from geographic + partly non-spatial latent economic similarity + spatial PRE accessibility; observed PRE economics are noisy proxies",
  SCENARIO == "station_selected_geo_only" ~
    "same geographic-only outcome/weight DGP as smooth_geo_only; post-only membership selected toward low-PRE-price sites near the new station",
  SCENARIO == "station_selected_geo_econ" ~
    "same geo+econ outcome/weight DGP as smooth_geo_econ; post-only membership selected toward low-PRE-price sites near the new station",
  SCENARIO == "station_selected_local_standard" ~
    "v9 paired local baseline: common fixed observation pattern, geographically aligned target economic rows, and shared geography/treatment/noise/donor outcomes with paired mismatch",
  SCENARIO == "station_selected_local_mismatch" ~
    "v9 paired local stress: identical observation pattern/geography/treatment/noise/donor outcomes and identical target economic-row distribution; only target economic rows are spatially interleaved to create local economic mismatch",
  SCENARIO == "smooth_geo_econ_latent_factor" ~
    "same geo+econ smooth weights as smooth_geo_econ; donor outcomes combine genuine geographic signal with nonlinear local economic-archetype factor loadings whose linear projection on observed Econ-X proxies is removed",
  SCENARIO == "no_spatial" ~
    "independent concentrated Dirichlet weights unrelated to target geography/economics",
  SCENARIO == "spatially_separated_donors" ~
    "same geo+econ smooth weights as smooth_geo_econ; targets lie within 5 km and donor controls outside a 7 km buffer; donor outcome levels/trends/cycles retain geographic structure but exclude direct linear economic-market loading (DGP2 outcome architecture)",
  SCENARIO == "boundary" ~
    "geo+econ latent-exposure weights with an abrupt x=10km target-market boundary",
  TRUE ~ SCENARIO
)

sim_design <- tibble::tibble(
  item = c(
    "scenario", "seed", "years", "pre_period", "post_period",
    "n_control", "n_target", "complete_pre", "partial_pre", "post_only",
    "target_noise_sd", "weight_latent_scale", "weight_access_scale",
    "weight_access_importance",
    "economic_distance_active", "econ_market_strength", "econ_spatial_share",
    "direct_target_donor_geographic_distance_in_weight_score",
    "boundary_bonus",
    "latent_factor_scale", "latent_factor_spatial_share",
    "latent_factor_idio_sd", "latent_factor_econ_basis_bw", "latent_factor_ar1_phi",
    "latent_factor_ar2_phi", "latent_factor_shock_year",
    "no_spatial_dirichlet_shape", "econ_proxy_noise_sd",
    "observation_selection_mode", "station_selection_near_scale_m",
    "station_selection_near_coef", "station_selection_low_price_coef",
    "station_selection_interaction_coef", "station_selection_temperature",
    "spatial_target_radius_m", "spatial_buffer_outer_radius_m",
    "spatial_control_outer_radius_m", "common_factor_scale",
    "common_factor_ar_phi", "common_factor_ar_sd",
    "mean_true_effective_donors", "median_true_effective_donors",
    "true_weight_model"
  ),
  value = c(
    SCENARIO, as.character(SEED), paste0(min(YEARS), "-", max(YEARS)),
    paste0(min(PERIOD_PRE), "-", max(PERIOD_PRE)),
    paste0(min(PERIOD_POST), "-", max(PERIOD_POST)),
    N_CONTROL, N_TARGET,
    sum(obs_group == "complete_pre"), sum(obs_group == "partial_pre"),
    sum(obs_group == "post_only"), TARGET_NOISE_SD,
    WEIGHT_LATENT_SCALE, WEIGHT_ACCESS_SCALE, WEIGHT_ACCESS_IMPORTANCE,
    ECONOMIC_DISTANCE_ACTIVE, ECON_MARKET_STRENGTH, econ_spatial_share_now,
    FALSE, BOUNDARY_BONUS, LATENT_FACTOR_SCALE, LATENT_FACTOR_SPATIAL_SHARE,
    LATENT_FACTOR_IDIO_SD, LATENT_FACTOR_ECON_BASIS_BW, LATENT_FACTOR_AR1_PHI, LATENT_FACTOR_AR2_PHI,
    LATENT_FACTOR_SHOCK_YEAR,
    NO_SPATIAL_DIRICHLET_SHAPE, ECON_PROXY_NOISE_SD,
    OBSERVATION_SELECTION_MODE, STATION_SELECTION_NEAR_SCALE_M,
    STATION_SELECTION_NEAR_COEF, STATION_SELECTION_LOW_PRICE_COEF,
    STATION_SELECTION_INTERACTION_COEF, STATION_SELECTION_TEMPERATURE,
    SPATIAL_TARGET_RADIUS_M, SPATIAL_BUFFER_OUTER_RADIUS_M,
    SPATIAL_CONTROL_OUTER_RADIUS_M, COMMON_FACTOR_SCALE,
    COMMON_FACTOR_AR_PHI, COMMON_FACTOR_AR_SD,
    truth_weight_concentration_summary$mean_effective_donors,
    truth_weight_concentration_summary$median_effective_donors,
    true_weight_model_label
  )
)
readr::write_csv(sim_design, file.path(OUTPUT_DIR, "simulation_design.csv"))

local_mismatch_design <- tibble::tibble(
  scenario = SCENARIO,
  active = LOCAL_PAIRED_SCENARIO,
  k_geographic_neighbors = LOCAL_MISMATCH_K,
  near_station_coef = LOCAL_MISMATCH_NEAR_COEF,
  local_economic_mismatch_coef = LOCAL_MISMATCH_ECON_COEF,
  local_mixedness_coef = LOCAL_MISMATCH_MIXEDNESS_COEF,
  low_pre_price_coef = LOCAL_MISMATCH_LOW_PRICE_COEF,
  near_x_mismatch_interaction_coef = LOCAL_MISMATCH_INTERACTION_COEF,
  similar_edge_quantile = LOCAL_MIX_SIMILAR_EDGE_QUANTILE,
  dissimilar_edge_quantile = LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE,
  similar_edge_threshold = local_similar_edge_threshold,
  dissimilar_edge_threshold = local_dissimilar_edge_threshold,
  min_similar_pre_anchors = LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS,
  min_dissimilar_pre_anchors = LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS,
  mismatch_candidate_quantile = LOCAL_MISMATCH_CANDIDATE_QUANTILE,
  mismatch_candidate_threshold = local_mismatch_candidate_threshold,
  n_mixed_eligible = sum(local_mixed_neighbor_eligible),
  n_mismatch_candidate_eligible = sum(local_mismatch_candidate_eligible),
  local_selection_search_method = local_selection_search_method,
  local_selection_search_nodes = local_selection_search_nodes,
  local_selection_search_max_nodes = local_selection_search_max_nodes,
  local_selection_search_aborted = local_selection_search_aborted,
  local_selection_candidate_count = local_selection_candidate_count,
  fraction_targets_mixed_eligible = mean(local_mixed_neighbor_eligible),
  fraction_targets_mismatch_candidate_eligible = mean(local_mismatch_candidate_eligible),
  fraction_postonly_mixed_eligible = mean(local_mixed_neighbor_eligible[obs_group == "post_only"]),
  fraction_postonly_mismatch_candidate_eligible =
    mean(local_mismatch_candidate_eligible[obs_group == "post_only"]),
  fraction_postonly_with_required_mixed_pre_support =
    mean(local_mixed_pre_anchor_support[obs_group == "post_only"]),
  paired_mismatch_candidate_threshold = paired_local_mismatch_threshold,
  paired_n_mismatch_candidate_eligible = sum(paired_local_mismatch_candidate_eligible),
  paired_fraction_postonly_with_required_mixed_pre_support =
    mean(paired_mixed_pre_anchor_support[obs_group == "post_only"]),
  paired_mean_standard_mismatch_all = mean(paired_standard_metrics$mismatch_score),
  paired_mean_mismatch_all = mean(paired_mismatch_metrics$mismatch_score),
  paired_mean_mismatch_gain_all = paired_mean_mismatch_gain,
  paired_mean_mismatch_gain_postonly = mean(
    paired_mismatch_metrics$mismatch_score[obs_group == "post_only"] -
      paired_standard_metrics$mismatch_score[obs_group == "post_only"]
  ),
  mean_similar_pre_anchor_count_post_only =
    mean(local_similar_pre_anchor_count[obs_group == "post_only"]),
  mean_dissimilar_pre_anchor_count_post_only =
    mean(local_dissimilar_pre_anchor_count[obs_group == "post_only"]),
  local_archetype_scale = LOCAL_ARCHETYPE_SCALE,
  local_archetype_bw = LOCAL_ARCHETYPE_BW,
  dgp2_econ_orthogonalization_active = local_dgp2_orthogonalization_active,
  dgp2_econ_orthogonalization_strength =
    LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH,
  dgp2_relative_control_adjustment = local_dgp2_orthogonalization_relative_adjustment,
  mean_mismatch_score_all = mean(local_econ_mismatch_score),
  mean_mismatch_score_post_only = mean(local_econ_mismatch_score[obs_group == "post_only"]),
  mean_mismatch_score_pre_observed = mean(local_econ_mismatch_score[obs_group != "post_only"]),
  observed_mismatch_mean_gap_postonly_minus_pre =
    mean(local_econ_mismatch_score[obs_group == "post_only"]) -
    mean(local_econ_mismatch_score[obs_group != "post_only"]),
  mean_true_weight_dissimilarity_post_only = mean(local_true_weight_dissimilarity[obs_group == "post_only"]),
  mean_true_weight_dissimilarity_pre_observed = mean(local_true_weight_dissimilarity[obs_group != "post_only"])
)
readr::write_csv(
  local_mismatch_design,
  file.path(OUTPUT_DIR, "simulation_local_mismatch_design.csv")
)

paired_design_summary <- tibble::tibble(
  scenario = SCENARIO,
  seed = SEED,
  paired_design = LOCAL_PAIRED_SCENARIO,
  mismatch_active = LOCAL_PAIRED_MISMATCH_ACTIVE,
  target_econ_spatial_share = econ_spatial_share_now,
  n_target = N_TARGET,
  n_post_only = sum(obs_group == "post_only"),
  n_partial_pre = sum(obs_group == "partial_pre"),
  n_complete_pre = sum(obs_group == "complete_pre"),
  mean_standard_local_mismatch = mean(paired_standard_metrics$mismatch_score),
  mean_mismatch_local_mismatch = mean(paired_mismatch_metrics$mismatch_score),
  mean_mismatch_gain = paired_mean_mismatch_gain,
  postonly_mean_standard_local_mismatch = mean(paired_standard_metrics$mismatch_score[idx_postonly]),
  postonly_mean_mismatch_local_mismatch = mean(paired_mismatch_metrics$mismatch_score[idx_postonly]),
  postonly_mean_mismatch_gain = mean(
    paired_mismatch_metrics$mismatch_score[idx_postonly] -
      paired_standard_metrics$mismatch_score[idx_postonly]
  ),
  all_postonly_have_mismatch_mixed_pre_support = all(paired_mixed_pre_anchor_support[idx_postonly]),
  target_economic_row_distribution_preserved = TRUE,
  observation_pattern_is_pair_fixed = TRUE,
  target_noise_is_pair_fixed_by_seed = TRUE,
  treatment_effect_is_pair_fixed_by_geography = TRUE
)
readr::write_csv(
  paired_design_summary,
  file.path(OUTPUT_DIR, "simulation_paired_design_summary.csv")
)

# ---- 10a2. Spatial-support diagnostics --------------------------------------
# These files document whether estimation is interpolation (overlapping support)
# or extrapolation across a donor-free buffer. They are descriptive only.
spatial_support_diag <- tibble::tibble(
  scenario = SCENARIO,
  support_mode = ifelse(
    SCENARIO == "spatially_separated_donors",
    "targets_inner_disk_controls_outer_annulus",
    "overlapping_uniform_support"
  ),
  target_max_center_distance_m = max(spatial_center_distance_target),
  target_mean_center_distance_m = mean(spatial_center_distance_target),
  control_min_center_distance_m = min(spatial_center_distance_control),
  control_mean_center_distance_m = mean(spatial_center_distance_control),
  nominal_target_radius_m = ifelse(SCENARIO == "spatially_separated_donors",
                                   SPATIAL_TARGET_RADIUS_M, NA_real_),
  nominal_buffer_outer_radius_m = ifelse(SCENARIO == "spatially_separated_donors",
                                         SPATIAL_BUFFER_OUTER_RADIUS_M, NA_real_),
  nominal_control_outer_radius_m = ifelse(SCENARIO == "spatially_separated_donors",
                                          SPATIAL_CONTROL_OUTER_RADIUS_M, NA_real_),
  realized_min_gap_m = min(spatial_center_distance_control) -
    max(spatial_center_distance_target)
)
readr::write_csv(
  spatial_support_diag,
  file.path(OUTPUT_DIR, "simulation_spatial_support_diagnostics.csv")
)

spatial_map_df <- dplyr::bind_rows(
  tibble::tibble(
    point_id = control_ids, group = "Control donor",
    X_m = control_xy[, 1], Y_m = control_xy[, 2]
  ),
  tibble::tibble(
    point_id = target_ids, group = "Treatment target",
    X_m = target_xy[, 1], Y_m = target_xy[, 2]
  )
)
p_support <- ggplot2::ggplot(
  spatial_map_df, ggplot2::aes(X_m / 1000, Y_m / 1000, shape = group)
) +
  ggplot2::geom_point(size = 2.1, alpha = 0.75) +
  ggplot2::geom_point(
    data = tibble::tibble(X_m = new_station[, 1], Y_m = new_station[, 2]),
    ggplot2::aes(X_m / 1000, Y_m / 1000), inherit.aes = FALSE,
    shape = 8, size = 4
  ) +
  ggplot2::coord_equal(xlim = c(0, 20), ylim = c(0, 20)) +
  ggplot2::labs(
    title = "Synthetic target and donor spatial support",
    subtitle = paste("Scenario:", SCENARIO, "| star = synthetic new station"),
    x = "X (km)", y = "Y (km)", shape = "Sample"
  ) +
  ggplot2::theme_minimal()

if (SCENARIO == "spatially_separated_donors") {
  theta_ring <- seq(0, 2 * pi, length.out = 361)
  ring_lines <- dplyr::bind_rows(
    tibble::tibble(
      X_km = (SPATIAL_SUPPORT_CENTER[1] + SPATIAL_TARGET_RADIUS_M * cos(theta_ring)) / 1000,
      Y_km = (SPATIAL_SUPPORT_CENTER[2] + SPATIAL_TARGET_RADIUS_M * sin(theta_ring)) / 1000,
      ring = "target edge (5 km)"
    ),
    tibble::tibble(
      X_km = (SPATIAL_SUPPORT_CENTER[1] + SPATIAL_BUFFER_OUTER_RADIUS_M * cos(theta_ring)) / 1000,
      Y_km = (SPATIAL_SUPPORT_CENTER[2] + SPATIAL_BUFFER_OUTER_RADIUS_M * sin(theta_ring)) / 1000,
      ring = "donor inner edge (7 km)"
    )
  )
  p_support <- p_support +
    ggplot2::geom_path(
      data = ring_lines,
      ggplot2::aes(X_km, Y_km, group = ring, linetype = ring),
      inherit.aes = FALSE, linewidth = 0.6
    ) +
    ggplot2::labs(linetype = "Support boundary")
}

ggplot2::ggsave(
  file.path(OUTPUT_DIR, "simulation_map_target_control_support.png"),
  p_support, width = 8, height = 6, dpi = 180, bg = "white"
)

# ---- 10b. DGP roughness diagnostics -----------------------------------------
# These descriptive quantities make the latent-factor/weak-temporal scenarios interpretable.  They
# are not used for tuning.  Lower lag-1 correlation / larger first differences
# mean that a smooth separable space-time kriging model faces a harder problem.
control_diff <- control_log[, -1, drop = FALSE] - control_log[, -ncol(control_log), drop = FALSE]
control_lag1 <- vapply(seq_len(N_CONTROL), function(j) {
  suppressWarnings(stats::cor(control_log[j, -Tn], control_log[j, -1]))
}, numeric(1))
true_cf_diff <- true_cf_log[, -1, drop = FALSE] - true_cf_log[, -ncol(true_cf_log), drop = FALSE]
true_cf_lag1 <- vapply(seq_len(N_TARGET), function(i) {
  suppressWarnings(stats::cor(true_cf_log[i, -Tn], true_cf_log[i, -1]))
}, numeric(1))

roughness_diag <- tibble::tibble(
  scenario = SCENARIO,
  control_mean_lag1 = mean(control_lag1, na.rm = TRUE),
  control_sd_first_difference = stats::sd(as.vector(control_diff), na.rm = TRUE),
  target_cf_mean_lag1 = mean(true_cf_lag1, na.rm = TRUE),
  target_cf_sd_first_difference = stats::sd(as.vector(true_cf_diff), na.rm = TRUE)
)
readr::write_csv(
  roughness_diag,
  file.path(OUTPUT_DIR, "simulation_outcome_roughness_diagnostics.csv")
)

# ---- 10c. DGP alignment diagnostics -----------------------------------------
# Mirror the Gneiting universal-kriging mean specification on the TRUE PRE
# counterfactual.  The key positive-control diagnostic is the incremental R^2
# from adding linear Econ-X proxies after year FE + geography.  In the revised
# latent-factor DGP this should be modest even though economic DISTANCE remains
# informative about W_true. These quantities are truth-only diagnostics and are
# never used by the estimators or tuning.  For spatially_separated_donors this
# specifically audits that ring separation does not accidentally turn Econ-X
# into a near-direct linear predictor of the target counterfactual.
pre_cf_long_diag <- as.data.frame(true_cf_log[, pre_pos, drop = FALSE]) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "true_cf_log") %>%
  dplyr::mutate(year = as.integer(year)) %>%
  dplyr::left_join(
    target_meta %>% dplyr::select(
      point_id, X_m, Y_m, pre_employment_density_z,
      pre_commercial_share_z, pre_income_z
    ),
    by = "point_id"
  ) %>%
  dplyr::mutate(X_km = X_m / 1000, Y_km = Y_m / 1000)

fit_geo_time_diag <- stats::lm(
  true_cf_log ~ factor(year) + X_km + Y_km,
  data = pre_cf_long_diag
)
fit_geo_time_econ_diag <- stats::lm(
  true_cf_log ~ factor(year) + X_km + Y_km +
    pre_employment_density_z + pre_commercial_share_z + pre_income_z,
  data = pre_cf_long_diag
)
r2_geo_time <- summary(fit_geo_time_diag)$r.squared
r2_geo_time_econ <- summary(fit_geo_time_econ_diag)$r.squared

loading_r2_mean <- NA_real_
local_archetype_loading_r2_mean <- NA_real_
if (!is.null(local_archetype_loadings)) {
  donor_local_diag <- data.frame(
    local_archetype_loadings,
    pre_employment_density_z = control_pre_employment_density_z,
    pre_commercial_share_z = control_pre_commercial_share_z,
    pre_income_z = control_pre_income_z
  )
  local_loading_r2 <- vapply(colnames(local_archetype_loadings), function(nm) {
    f <- stats::as.formula(paste0(
      nm, " ~ pre_employment_density_z + pre_commercial_share_z + pre_income_z"
    ))
    summary(stats::lm(f, data = donor_local_diag))$r.squared
  }, numeric(1))
  local_archetype_loading_r2_mean <- mean(local_loading_r2)
}
if (!is.null(latent_factor_loadings)) {
  donor_diag <- data.frame(
    latent_factor_loadings,
    pre_employment_density_z = control_pre_employment_density_z,
    pre_commercial_share_z = control_pre_commercial_share_z,
    pre_income_z = control_pre_income_z
  )
  loading_r2 <- vapply(colnames(latent_factor_loadings), function(nm) {
    f <- stats::as.formula(paste0(
      nm, " ~ pre_employment_density_z + pre_commercial_share_z + pre_income_z"
    ))
    summary(stats::lm(f, data = donor_diag))$r.squared
  }, numeric(1))
  loading_r2_mean <- mean(loading_r2)
}

# For the local DGP pair, also report what the direct Econ-X signal would have
# been before the orthogonalization.  This makes the design intervention fully
# auditable rather than hiding it inside the generator.
pre_orthog_incremental_r2 <- NA_real_
if (!is.null(local_dgp2_true_cf_before)) {
  pre_before_long <- as.data.frame(local_dgp2_true_cf_before[, pre_pos, drop = FALSE]) %>%
    tibble::rownames_to_column("point_id") %>%
    tidyr::pivot_longer(-point_id, names_to = "year", values_to = "true_cf_log") %>%
    dplyr::mutate(year = as.integer(year)) %>%
    dplyr::left_join(
      target_meta %>% dplyr::select(
        point_id, X_m, Y_m, pre_employment_density_z,
        pre_commercial_share_z, pre_income_z
      ),
      by = "point_id"
    ) %>%
    dplyr::mutate(X_km = X_m / 1000, Y_km = Y_m / 1000)
  fit_before_geo <- stats::lm(
    true_cf_log ~ factor(year) + X_km + Y_km, data = pre_before_long
  )
  fit_before_econ <- stats::lm(
    true_cf_log ~ factor(year) + X_km + Y_km +
      pre_employment_density_z + pre_commercial_share_z + pre_income_z,
    data = pre_before_long
  )
  pre_orthog_incremental_r2 <-
    summary(fit_before_econ)$r.squared - summary(fit_before_geo)$r.squared
}

dgp_alignment_diag <- tibble::tibble(
  scenario = SCENARIO,
  pre_true_cf_R2_geo_time = r2_geo_time,
  pre_true_cf_R2_geo_time_econ = r2_geo_time_econ,
  pre_true_cf_incremental_R2_linear_econ = r2_geo_time_econ - r2_geo_time,
  pre_orthogonalization_incremental_R2_linear_econ = pre_orthog_incremental_r2,
  local_dgp2_econ_orthogonalization_active = local_dgp2_orthogonalization_active,
  local_dgp2_econ_orthogonalization_strength =
    LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH,
  local_dgp2_relative_control_adjustment =
    local_dgp2_orthogonalization_relative_adjustment,
  local_dgp2_max_abs_econ_moment_before =
    local_dgp2_orthogonality_max_abs_moment_before,
  local_dgp2_max_abs_econ_moment_after =
    local_dgp2_orthogonality_max_abs_moment_after,
  alignment_preferred_min = LOCAL_DGP2_ALIGNMENT_PREFERRED_MIN,
  alignment_preferred_max = LOCAL_DGP2_ALIGNMENT_PREFERRED_MAX,
  alignment_warn_max = LOCAL_DGP2_ALIGNMENT_WARN_MAX,
  alignment_hard_max = LOCAL_DGP2_ALIGNMENT_HARD_MAX,
  alignment_strict = LOCAL_DGP2_ALIGNMENT_STRICT,
  mean_latent_factor_loading_R2_linear_econ = loading_r2_mean,
  mean_local_archetype_loading_R2_linear_econ = local_archetype_loading_r2_mean,
  local_archetype_scale = LOCAL_ARCHETYPE_SCALE
)
readr::write_csv(
  dgp_alignment_diag,
  file.path(OUTPUT_DIR, "simulation_dgp_alignment_diagnostics.csv")
)

# Guardrail for the local socioeconomic-mismatch mechanism DGP.  v8 retains
# PARTIAL (default 0.75) orthogonalization plus nonlinear economic archetypes.  The preferred
# incremental-R2 band is 0.05--0.15: enough outcome relevance for donor-weight
# differences to matter, but not enough for Econ-X to become an almost-direct
# outcome predictor.  Crucially, the strength is fixed ex ante and is NOT tuned
# to Graph/GeoEco performance.  For Monte Carlo, strict stopping can be disabled
# so replications are never selected on this truth-side diagnostic.
if (LOCAL_DGP2_PAIR) {
  delta_r2_now <- r2_geo_time_econ - r2_geo_time
  if (is.finite(delta_r2_now) &&
      (delta_r2_now < LOCAL_DGP2_ALIGNMENT_PREFERRED_MIN ||
       delta_r2_now > LOCAL_DGP2_ALIGNMENT_PREFERRED_MAX)) {
    warning(sprintf(
      paste0(
        "Local DGP direct linear Econ-X incremental R2 is %.3f; preferred design band is [%.2f, %.2f]. ",
        "Do not retune the orthogonalization strength using Graph/GeoEco RMSE."
      ),
      delta_r2_now, LOCAL_DGP2_ALIGNMENT_PREFERRED_MIN, LOCAL_DGP2_ALIGNMENT_PREFERRED_MAX
    ))
  }
  if (is.finite(delta_r2_now) && delta_r2_now > LOCAL_DGP2_ALIGNMENT_WARN_MAX) {
    warning(sprintf(
      "Local DGP direct linear Econ-X incremental R2 is %.3f (>%.2f warning threshold).",
      delta_r2_now, LOCAL_DGP2_ALIGNMENT_WARN_MAX
    ))
  }
  if (LOCAL_DGP2_ALIGNMENT_STRICT && is.finite(delta_r2_now) &&
      delta_r2_now > LOCAL_DGP2_ALIGNMENT_HARD_MAX) {
    stop(sprintf(
      "Local DGP failed mechanism-isolation guardrail: incremental linear Econ-X R2 = %.3f (>%.2f).",
      delta_r2_now, LOCAL_DGP2_ALIGNMENT_HARD_MAX
    ))
  }
}

# ---- 11. Quick plots of the known DGP ---------------------------------------
plot_meta <- target_meta %>%
  dplyr::mutate(
    true_longrun_tau_pct = (exp(site_longrun_tau) - 1) * 100
  )

p_map <- ggplot(plot_meta, aes(X_m / 1000, Y_m / 1000,
                              color = true_longrun_tau_pct,
                              shape = obs_group)) +
  geom_point(size = 2.2) +
  geom_point(
    data = tibble::tibble(X_m = new_station[, 1], Y_m = new_station[, 2]),
    aes(X_m / 1000, Y_m / 1000), inherit.aes = FALSE,
    shape = 8, size = 4
  ) +
  coord_equal() +
  labs(
    title = "Synthetic treatment sites and known long-run effect",
    subtitle = paste("Scenario:", SCENARIO, "| star = synthetic new station"),
    x = "X (km)", y = "Y (km)", color = "True effect (%)", shape = "Observation group"
  ) +
  theme_minimal()
ggsave(file.path(OUTPUT_DIR, "simulation_map_true_effect.png"), p_map,
       width = 8, height = 6, dpi = 180, bg = "white")

p_att <- ggplot(true_att, aes(year, true_ATT_pct)) +
  geom_hline(yintercept = 0, color = "grey70") +
  geom_line(linewidth = 1) + geom_point() +
  labs(title = "Known ATT in the synthetic DGP", x = NULL, y = "True ATT (%)") +
  theme_minimal()
ggsave(file.path(OUTPUT_DIR, "simulation_true_ATT.png"), p_att,
       width = 7, height = 4.5, dpi = 180, bg = "white")

cat("\n============================================================\n")
cat("Synthetic M1_LP dataset created.\n")
cat("Scenario:", SCENARIO, "\n")
cat("RDS:", rds_path, "\n")
cat("Controls:", N_CONTROL, " Targets:", N_TARGET, "\n")
if (SCENARIO == "spatially_separated_donors") {
  cat(sprintf(
    "Spatial support: target radius <= %.1f km | donor radius >= %.1f km | realized gap %.2f km\n",
    SPATIAL_TARGET_RADIUS_M / 1000,
    SPATIAL_BUFFER_OUTER_RADIUS_M / 1000,
    (min(spatial_center_distance_control) - max(spatial_center_distance_target)) / 1000
  ))
}
cat(sprintf("True effective donors: mean %.2f, median %.2f\n",
            truth_weight_concentration_summary$mean_effective_donors,
            truth_weight_concentration_summary$median_effective_donors))
cat("Observation groups:\n")
print(table(obs_group))
cat("Known post-treatment ATT range (%): ",
    sprintf("%.2f to %.2f", min(true_att$true_ATT_pct), max(true_att$true_ATT_pct)), "\n", sep = "")
cat("Next: run 04b_validate_graph_geoeco_simulation.R\n")

# v14 runtime profiling: total generator wall time.  04b reads this file and
# includes it in the per-scenario runtime breakdown used for Monte Carlo planning.
dgp_elapsed_sec <- as.numeric(difftime(Sys.time(), DGP_SCRIPT_START, units = "secs"))
dgp_runtime <- tibble::tibble(
  scenario = SCENARIO,
  component = "DGP_generation_04a",
  elapsed_sec = dgp_elapsed_sec,
  elapsed_min = dgp_elapsed_sec / 60,
  n_fits = 1L,
  component_class = "data_generation",
  estimator_required = TRUE,
  mc_default = "keep"
)
readr::write_csv(dgp_runtime, file.path(OUTPUT_DIR, "simulation_dgp_runtime.csv"))
cat(sprintf("DGP generation elapsed: %.2f min\n", dgp_elapsed_sec / 60))
cat("============================================================\n")
