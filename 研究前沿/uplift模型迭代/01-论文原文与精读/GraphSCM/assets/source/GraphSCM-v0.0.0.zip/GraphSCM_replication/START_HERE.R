# Quick reproduction of the supplied 100-replication results.
# Open GraphSCM_replication.Rproj in RStudio first, then source this file.
# Only base/recommended R is required. No Monte Carlo models are fitted.
if (!file.exists("replication/run_from_RStudio.R")) {
  stop("Open GraphSCM_replication.Rproj or set the working directory to the extracted project root.")
}
source("replication/run_from_RStudio.R")
run_replication("check")
run_replication("summary")
cat("\nResults: replication/output/archived_summary/\n")
cat("Weight summaries: replication/output/archived_summary/weight_diagnostics/\n")
