@echo off
setlocal
cd /d "%~dp0"
Rscript run_all.R
pause
