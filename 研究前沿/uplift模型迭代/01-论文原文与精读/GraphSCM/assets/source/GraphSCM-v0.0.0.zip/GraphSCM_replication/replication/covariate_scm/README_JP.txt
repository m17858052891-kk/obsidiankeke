共変量だけで重みを決めるSCM：追加比較用Rコード
============================================

1. 何を追加するコードか
---------------------
地理座標2変数とPRE経済共変量3変数を合わせる、独立したCovariate-SCMです。
各targetについて、donorの凸結合がこれらの属性を近似するように重みを求めます。
targetのPRE/POSTアウトカムも、真の重み・反実仮想・処置効果も、重み推定には使いません。
推定後の反実仮想は、求めた重みとdonorのPOSTアウトカムから計算します。
Graph-SCM等の既存推定器を再実行するコードではありません。

比較の中心は、PREアウトカムを持たないpost-only地点です。
complete/partial地点にも同じ共変量のみの方法を適用し、別々に評価します。
この比較は、グラフを介してPRE情報を借りることの有用性を調べるためのものです。
地理座標と経済共変量を両方使う比較なので、経済項だけの寄与を切り分ける実験とは異なります。

2. 実行方法（Windows）
----------------------
ZIPを展開し、まずrun_test.batをダブルクリックしてください。
D1–D5について各1反復だけ計算します。
その後run_all_20rep.batを実行すると、同じ5 DGPの各20反復、計100ケースを計算します。
正常終了済みの同じケースは再利用します。

Windows用の起動ファイルはR 4.2以降を想定しています。追加Rパッケージは不要です。
ネットワーク接続やパッケージのインストール処理は含みません。
Rscript.exeが自動検出されない場合は、PowerShellで次のようにパスを指定できます。

  .\run_windows.ps1 -Mode test -RscriptPath "C:/Program Files/R/R-4.6.0/bin/x64/Rscript.exe"

RStudioで実行する場合は、run_covariate_scm.Rのあるフォルダを作業フォルダにして、

  source("run_covariate_scm.R")
  run_covariate_benchmark(mode = "test")
  run_covariate_benchmark(mode = "full")

としてください。sourceだけでは計算を開始しません。

コマンドラインの例：

  Rscript --vanilla run_covariate_scm.R --mode=full
  Rscript --vanilla run_covariate_scm.R --mode=test --scenarios=D1,D3 --reps=1:2

既定値は本文候補の5 DGPです。D1-D8も指定できます。D9-D10は本コードの対象外です。
既存の本文や表からDGPを削除・移動する変更は、このコードでは行いません。

3. 重みの定義
-------------
使用する観測済みPRE属性：
  X_m, Y_m,
  pre_employment_density_z, pre_commercial_share_z, pre_income_z

targetとdonorを合わせた属性データで、各列を共通の平均・標本標準偏差で標準化します。
一定の値しか持たない列は除きます。標準化後のtarget属性をz_i、
donor属性行列をZ_D、残った列数をpとすると、

  minimize  mean((z_i - w_i %*% Z_D)^2) + 1e-10 * sum(w_i^2)
  subject to w_ij >= 0 and sum(w_i) = 1.

共変量間の重みは固定で等しく、アウトカムを使ったチューニングは行いません。
微小なridgeは、ほぼ同じ属性を再現する複数の重みの選択と数値計算のために入れています。
独自のactive-set二次計画ソルバーを使い、双対ギャップとKKT残差を保存します。
全列が一定なら、ridge最小化により一様重みになります。

既定の方法名はCovariate_SCM_geo_econです。
feature_set = "econ"なら経済3変数だけ、"geo"なら座標2変数だけも指定できます。
これらは必要な場合の追加仕様です。POST成績を見て最良仕様だけを選ぶ処理はありません。

  run_covariate_benchmark(mode = "full", feature_set = "econ")

4. データと既存結果との対応
-------------------------
既存のデータRDSがなくても実行できます。凍結した元の生成器の数値計算部分だけを
実行し、同じシナリオ・seed・donor/target数・欠測設定でデータを再生成します。
図作成、sfオブジェクト化、元の推定器の実行は省くため、追加計算だけで済みます。
元の生成器はvendor/に変更せず保存しています。ファイルの照合に失敗したら停止します。

各ケースについて、Uniform法のCF/ATT指標を全4群で再計算し、同梱した既存の
反復別評価CSVと照合します。許容誤差はlog指標1e-9、ATT指標1e-7 percentage pointsです。
不一致なら、そのまま比較を続けず停止します。
この照合はデータの対応確認であり、新しい推定方法の評価結果を調整する操作ではありません。

元のM1_LP_synthetic_dataset.rdsを使う場合：

  run_covariate_benchmark(mode = "full", input_root = "H:/path/to/simulation_results")

次の場所を順に探します。
  input_root/seed_<seed>/<scenario>/M1_LP_synthetic_dataset.rds
  input_root/<scenario>/M1_LP_synthetic_dataset.rds
該当ファイルがないケースは数値生成器で再生成します。
RDSが存在しても、seed・シナリオ・ID・既存評価との対応が不一致なら停止します。

5. 出力
-------
output/Covariate_SCM_geo_econ_<設定の照合値>/以下に保存します。
元の評価CSVやLaTeXには書き込みません。仕様やソースを変えると別フォルダになります。
各seedフォルダには重み、ソルバー診断、標準化情報、完了マーカーを保存します。
summary_*フォルダには、今回要求したDGP・反復だけの集計を出力します。

  covariate_CF_replications.csv   反復別の反実仮想誤差
  covariate_ATT_replications.csv  反復別のATT誤差
  covariate_ATT_by_year.csv       年別の推定ATTと真値
  covariate_summary.csv           平均RMSE・平均ATT biasとMC標準誤差
  paired_CF_RMSE.csv              既存7法との差とMC標準誤差・95%区間
  paired_ATT_RMSE.csv             同じ反復でのATT RMSE差と区間
  uniform_data_audit.csv          データ照合の結果
  runtime.csv                    生成・推定の実測時間
  RUN_INFO.txt                   実行条件・集計範囲

差は「Covariate-SCM - 比較法」なので、RMSE差が負ならCovariate-SCMの方が小さい値です。
比較は同じDGP・seed・観測群・評価地点数で行います。
Ordinary SCMはpost-onlyに使えず、ALLの評価母集団も異なるため、この比較には含めません。
CFは潜在的な無処置signalとのlog誤差です。
ATTは群の平均log効果を100*expm1(...)で変換し、その誤差をpercentage pointsで評価します。
区間はシミュレーションの平均性能差に対するMC区間で、因果効果の信頼区間ではありません。
各1反復のtest出力ではMC標準誤差と区間を空欄にします。full結果と混同しないでください。

6. 動作確認
-----------
tests/run_tests.Rに、解析的に解ける例、全ての面を探索した独立の最適解との照合、
手計算のCF/ATT、元RDS形式のID整列、既存Uniform評価との照合、乱数状態の保全、
推定に真値・targetアウトカムが混入しないことの確認を含めています。

  Rscript --vanilla tests/run_tests.R

少量のデータで再開機能・比較表・MC区間・D1-D8の生成と推定を確認する場合：

  Rscript --vanilla tests/run_integration_tests.R

この確認用の出力は一時フォルダに作成し、終了後に削除します。

実施済みの範囲はvalidation/TEST_REPORT.txtを参照してください。
初回コード配布時は小規模な動作確認までを実施しました。
その後、ユーザー実行の全5 DGP×20反復を検証し、プロジェクトのdata/covariate_scm/と論文に反映しています。
本フォルダのvalidation/TEST_REPORT.txtは初回のコード確認範囲を記録したものです。
公開版では番号とパスの変更後に共変量SCMの100ケースを再計算し、旧評価値との一致を確認しています。Graph・時空間法の全再推定は実行していません。
