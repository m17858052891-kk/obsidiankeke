# Run one scenario/replication in a fresh R session.
args_all <- commandArgs(trailingOnly = FALSE)
file_arg <- grep('^--file=', args_all, value = TRUE)
R_DIR <- if (length(file_arg)) normalizePath(dirname(sub('^--file=', '', file_arg[1])), winslash='/', mustWork=TRUE) else normalizePath(getwd(), winslash='/', mustWork=TRUE)
source(file.path(R_DIR, '00_config.R'))
source(file.path(R_DIR, 'completion.R'))

args <- commandArgs(trailingOnly=TRUE)
if (length(args) < 2) stop('Usage: Rscript 02_run_one.R <scenario> <rep>')
scenario <- args[1]
rep <- as.integer(args[2])
if (!scenario %in% SCENARIOS_ALL) stop('Unknown scenario: ', scenario)
if (!is.finite(rep) || rep < 1) stop('rep must be a positive integer')
seed <- seed_for(scenario, rep)
engine <- Sys.getenv("GRAPHSCM_ENGINE",unset="R")
if (!engine %in% c("R","Rcpp")) stop("Choose GRAPHSCM_ENGINE=R or Rcpp.")
seed_root <- file.path(OUTPUT_ROOT, paste0('seed_', seed))
result_dir <- file.path(seed_root, scenario, 'results_graph_geoeco')
marker <- file.path(result_dir, '_MC_FINISHED.txt')
if (file.exists(marker)) {
  cat('SKIP completed:', scenario, 'rep', rep, 'seed', seed, '\n')
  quit(status=0)
}

dir.create(seed_root, recursive=TRUE, showWarnings=FALSE)

# One publication configuration for every scenario. The two DGP backends are
# frozen separately only to preserve the exact validated truth used in the paper.
inherited <- names(Sys.getenv())
Sys.unsetenv(inherited[grepl("^(SIM_|MC_LOCAL_|M1_LP_)", inherited)])
RNGkind("Mersenne-Twister", "Inversion", "Rejection")
Sys.setenv(
  M1_LP_WORK_DIR = CODE_ROOT,
  SIM_OUTPUT_ROOT = seed_root,
  SIM_SCENARIO = scenario,
  SIM_SEED = as.character(seed),
  SIM_N_CONTROL = '24',
  SIM_N_TARGET = '120',
  SIM_PROP_COMPLETE = '0.50',
  SIM_PROP_PARTIAL = '0.30',
  SIM_FAST_MC_TUNING = 'true',
  SIM_RUN_BLOCK_STRESS = 'false',
  SIM_FAST_LAMBDA_TAIL_MAX_STEPS = '11',
  SIM_FAST_LAMBDA_TAIL_MAX_MULTIPLIER = '531441',
  SIM_FAST_LAMBDA_TAIL_EXTRA_BETA_MAX = '8',
  SIM_FAST_BETA_TAIL_MAX_STEPS = '3',
  SIM_FAST_BETA_TAIL_MAX = '32',
  SIM_FAST_FINAL_3FOLD_CONFIRM = 'true',
  SIM_FAST_FINAL_CONFIRM_FOLDS = '3',
  SIM_FAST_FINAL_CONFIRM_TOP_N = '3',
  SIM_FAST_FINAL_CONFIRM_SITES_PER_FOLD = '8',
  SIM_FISTA_MAX_ITER_FINAL = '20000',
  SIM_USE_NATIVE_OSQP_FINAL = 'true',
  SIM_RUN_EXACT_QP = 'false',
  SIM_RUN_GNEITING_SCM = 'true',
  SIM_RUN_DIRECT_GNEITING = 'true',
  SIM_RUN_ECON_X = 'true',
  SIM_RUN_SPCF_SCM = 'false',
  SIM_RUN_DIRECT_SPCF = 'false',
  SIM_RUN_RHO_STABILITY = 'false',
  SIM_RUN_INIT_STABILITY = 'false',
  SIM_RUN_BOUNDARY_FORCED = 'false',
  SIM_FISTA_VERBOSE = 'false',
  # Paired-v9 local DGP settings; harmless for legacy-eight scenarios.
  MC_LOCAL_DGP2_ECON_ORTHOGONALIZE = 'true',
  MC_LOCAL_DGP2_ECON_ORTHOGONALIZATION_STRENGTH = '0.75',
  # This is a truth-side diagnostic, not a Monte Carlo acceptance rule.
  # The generator reads SIM_LOCAL_, so MC_LOCAL_ would leave strict=TRUE.
  SIM_LOCAL_DGP2_ALIGNMENT_STRICT = 'false',
  MC_LOCAL_ARCHETYPE_SCALE = '0.045',
  MC_LOCAL_ARCHETYPE_BW = '0.75',
  MC_LOCAL_ARCHETYPE_IDIO_SD = '0.08',
  MC_LOCAL_MISMATCH_K = '10',
  MC_LOCAL_MIX_SIMILAR_EDGE_QUANTILE = '0.35',
  MC_LOCAL_MIX_DISSIMILAR_EDGE_QUANTILE = '0.65',
  MC_LOCAL_MIX_MIN_SIMILAR_PRE_ANCHORS = '2',
  MC_LOCAL_MIX_MIN_DISSIMILAR_PRE_ANCHORS = '2',
  MC_LOCAL_MISMATCH_CANDIDATE_QUANTILE = '0.50',
  MC_LOCAL_FEASIBLE_SEARCH_MAX_NODES = '10000000',
  SIM_LOCAL_PAIRED_ECON_SPATIAL_SHARE = '0.60',
  SIM_LOCAL_PAIRED_INTERLEAVE_STRATA = '3,4,5,6',
  SIM_LOCAL_PAIRED_SELECTION_NEAR_COEF = '1.00',
  SIM_LOCAL_PAIRED_DESIGN_MIN_MISMATCH_GAIN = '0.10'
)

cat('RUN:', scenario, 'rep', rep, 'seed', seed, '\n')
acceleration <- new.env(parent=globalenv())
source(file.path(PROJECT_ROOT,"acceleration/R/backend.R"),local=acceleration)
if (engine=="Rcpp") acceleration$scm_load_rcpp()
source(generator_for(scenario), local=new.env(parent=globalenv()))
fit_environment <- new.env(parent = globalenv())
acceleration$scm_source_estimator(estimator_for(scenario),envir=fit_environment,engine=engine)
scm_finalize_case(result_dir,scenario,seed,engine)
# Export already-computed fits; this block performs no optimization or tuning.
# Keep scientific estimation completion separate from diagnostic completion.
tryCatch({
  weight_root <- normalizePath(file.path(CODE_ROOT, '..', 'weight_diagnostics'), winslash='/', mustWork=TRUE)
  source(file.path(weight_root, 'R', 'core.R'))
  source(file.path(weight_root, 'R', 'io.R'))
  wd_export_environment(fit_environment, DESIGN_CATALOG, result_dir)
  writeLines('Saved Graph/GeoEco/ordinary/uniform weight diagnostics.', file.path(result_dir, '_WEIGHTS_FINISHED.txt'))
}, error = function(e) {
  writeLines(conditionMessage(e), file.path(result_dir, 'weight_export_error.txt'))
  warning('Scientific fits completed, but weight export failed: ', conditionMessage(e))
})
cat('DONE:', scenario, 'rep', rep, 'seed', seed, '\n')
