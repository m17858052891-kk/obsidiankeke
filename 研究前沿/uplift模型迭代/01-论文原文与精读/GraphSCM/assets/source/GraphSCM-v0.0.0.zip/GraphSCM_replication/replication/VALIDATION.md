# Replication validation

## Public release 0.0.0

This is the public version number selected for the Zenodo deposit. Older version labels below refer to internal development snapshots, not separate public releases. The public archive retains the 100-replication study and the latest table-layout corrections. All 25 tables have unchanged numerical entries; the table-generation scripts preserve the corrected layouts. The numerical generators and estimators are unchanged. Japanese top-level instructions and deposit-preparation notes are intentionally omitted from this archive.

## Internal packaging checks, 2026-11-08

This release adds the authors' MIT license, a portable RStudio project, quick-result and full-study entry scripts, and publication instructions. Numerical generators, estimators and the supplied 100-replication evaluations are unchanged from 1.5.0. No full simulation was rerun for this documentation release. The quick entry checks and summarizes the supplied results; the full-study entry runs only a dry-run plan until explicitly enabled.

## Internal 100-replication validation, 2026-11-08

The supplied evaluations now contain 1,000 full-estimator cases and 500 primary Cov-SCM cases. All saved full-estimator outputs passed scenario/seed, simplex and reconstructed GeoEco CF checks, all 100 local-pair invariants passed, and all 500 Cov-SCM Uniform data audits passed. Published R and Python summaries use 100 cases and t(99) intervals. Graph and ordinary-SCM weight snapshots are now included as aggregated diagnostics. Raw case matrices remain in the run output, outside the publication archive. Three beta-screening flags are retained and reported. The manuscript uses the user-completed runs; small software-validation fits use temporary outputs. The shorter-spatial-range check remains an earlier 20-replication sensitivity subset.

The dated sections below describe earlier development checks and historical release sizes; they do not describe the current data row counts.

# Release validation: 2026-11-05

## Truth-side diagnostic setting: release 1.4.4, 2026-11-08

The runner intended to set local-pair alignment strictness to false, but used `MC_LOCAL_DGP2_ALIGNMENT_STRICT`; the generator reads `SIM_LOCAL_DGP2_ALIGNMENT_STRICT`. Thus its default true flag stopped D10 index 80 at incremental PRE R-squared 0.32402455. The corrected runner passes the intended `SIM_LOCAL_` name. No seed is rejected on this truth-side diagnostic, and the orthogonalization strength remains 0.75. This corrects diagnostic stopping; no generator or estimator expressions change.

Earlier preflight validation reached post-only selection and did not execute the later alignment diagnostic. The new check executes the original complete generator through its final statements for every remaining D10 index 80–102, using a separate output directory and no model fitting. Index 80 completes and its entire saved scientific RDS is identical to the previous stopped-run RDS, including truth, observed outcomes, covariates and observation groups.

## Feasible local-pair extension: release 1.4.3, 2026-11-08

D9/D10 original indices 50 and 70 (seeds 20260979 and 20260999) admit at most 23 post-only locations under the fixed candidate and two-similar/two-dissimilar PRE-neighbor rules. A pruned exact search and an independent HiGHS integer program agreed; both integer optima were 23 with zero gap. The exact-search implementation matched the original first-solution order in 300 small independent checks. Preflight of indices 50–105 verified that the other draws are feasible and that both paired members have identical selection inputs and RNG state. For the two feasible draws requiring backtracking, indices 64 and 84, the original traversal also found the same sets within its original node limit (80,082 and 1,876 nodes).

The accepted 100-case extension excludes indices 50 and 70 for both members and adds indices 101 and 102 (seeds 20261030 and 20261031). The original generator, estimator, candidate threshold and anchor constraints are unchanged. The new orchestration helper records this conditioning and the plan, reuses completed results, and distinguishes deliberately excluded indices from missing weight files. No 100-case results replace the archived 20-case evaluation CSVs in this release.

## Cov-SCM additional repetitions: release 1.4.2, 2026-11-07

Cov-SCM accepts explicit repetitions through 10,000 while retaining the 20-repetition default. Additional cases require completed full-estimator references and the matching saved input dataset. A 500-case primary-design dry run validated reference coverage without fitting. A small integration check fitted D1 repetitions 1, 21 and 100 using their actual saved inputs, checked paired summaries, and resumed all three without changing completion markers. Repetition 1 reproduced archived Cov-SCM CF RMSE within 4.45e-16. Unit checks reject missing completion and mismatched reference seeds. Contiguous repetition ranges use short summary-directory names to avoid Windows component-length limits. This release validation did not execute the full 500-case Cov-SCM study or the supplementary 500-case full-estimator study.

## Completion recording: release 1.4.1, 2026-11-06

The original runner incorrectly expected the frozen estimator to write `_MC_FINISHED.txt`, although it writes numerical results only. The runner now checks the final files, scenario/seed, donor-weight feasibility and the agreement of reconstructed GeoEco CF metrics before atomically recording completion. Relative output roots are made absolute before the generators change working directory. The completion tests reject missing final outputs, wrong scenario/seed, invalid weights and inconsistent CF metrics, and verify idempotency and preservation of result files.

The user's already finished D1/rep1 outputs were validated and their completion record recovered without rewriting the numerical results. A separate full Rcpp run of the same D1/rep1 completed normally, including all-method weight snapshots and completion markers. Input arrays, selected parameters and main weight CSVs agreed exactly, and all CF/ATT metric differences were zero. Missing post-estimation diagnostics were restored from that verified run. The saved runtime ledger was 74.76 seconds for the user's case and 71.30 seconds for the final independent case. These are individual Rcpp cases, not an end-to-end R-versus-Rcpp speed comparison or an all-design runtime estimate. See `acceleration/validation/completion_integration.csv`.

## Rcpp FISTA extension: release 1.4.0, 2026-11-06

The optional Rcpp engine compiled and ran on Windows x64, R 4.6.0, Rcpp 1.1.2 and GCC 14.3.0. The original five numerical backend files remain unchanged. A source hook replaces only the FISTA loop and projected-gradient calculation in a separate execution environment; original preprocessing, candidate generation, graph construction, stopping rules, output assembly and final OSQP code are retained. The default engine is still R.

Independent tests passed 24 numerical conditions plus projection, nonconvergence, zero-edge graphs, source-hook installation, input/RNG immutability and extended-seed/collection checks. The maximum unit-test weight discrepancy was 2.72e-14.

Two original numerical DGPs were regenerated for D1 and D3 at replication 1, with archived Uniform CF/ATT alignment verified. Sixteen representative temporal/pseudo-post-only validation problems were solved with both engines, each timed three times in alternating order. The sum of cell medians was 53.16 seconds for R and 1.12 seconds for Rcpp, a factor of 47.46 in this FISTA benchmark. Maximum weight and PRE-prediction differences were 3.71e-13 and 4.02e-13. All iteration counts and choices from the small representative candidate set agreed.

This does not validate or time the complete adaptive CV search, final OSQP fits, spatio-temporal benchmarks or end-to-end Monte Carlo. No full original-estimator case or new 200-case study was run in this extension. Detailed measurements and code hashes are in `acceleration/validation/`. Rcpp compilation and data generation are excluded from the benchmark times.

Explicit extra repetitions are now supported for the original full workflow and saved-weight assessment; defaults remain 20. A 100-repetition dry-run plan passed without fitting models. Collection scans completed repetitions instead of truncating at 20. Archived summaries and the Cov-SCM adapter retain their original scope. No parallel-execution feature was added.

The v1.4.0 ZIP was extracted into a fresh path containing Japanese characters and spaces. Rcpp compiled again from that extracted source using a fresh cache, and all numerical tests passed. Archived weight tests, public checks, RStudio summaries, the unchanged 200-case original plan, the explicit 100-case Rcpp plan and benchmark dry-run behavior passed. R/Python weight statistics agreed and all 25 manuscript tables regenerated identically. No full original model was fitted during the extracted-archive checks.

## Weight-diagnostic extension: 2026-11-06

Release 1.3.0 additionally includes the original experiment's saved-weight evaluations for all 200 cases (D1–D10, 20 replications each). Original RDS truth and weight CSVs agreed; recalculated site-level errors matched saved diagnostics to a maximum absolute difference of 5.11e-15. GeoEco CF RMSE/MAE/signed-bias values matched current publication inputs across 200 datasets and four groups to 2.78e-17. The user-completed assessment agreed with the independently verified assessment to 1.04e-13 across the six replication-level metrics. These checks were evaluations of saved output, with no new original-estimator fitting or tuning.

The new `summary` branch reads included replication-level weight diagnostics, so this reproduction needs no private drive. Graph-SCM-only and ordinary-SCM matrices were not saved in the original outputs and are not represented as available weight comparisons. A portable RStudio helper exposes the same CLI tasks. Target-count and PRE-length sensitivity experiments were not run.

The v1.3.0 public ZIP was extracted to a fresh Japanese/space-containing path. Its checksums, independent weight tests, catalog checks, RStudio `summary` workflow and original 200-case dry-run plan passed. R and Python agreed on every post-only weight-table mean, MCSE and paired interval to less than 1e-12. The extracted Python scripts reproduced all 25 supplied LaTeX tables byte for byte.

The saved-output assessment task and post-estimation weight export were added without changing the five frozen numeric backend copies. The extension was tested with hand-calculated recovery errors, shuffled/missing IDs, invalid simplex weights, support masks, ordinary-SCM post-only exclusion, resumption, paired dataset intervals, fixed-design empirical MSE decomposition, rejected changing designs, legacy inputs, duplicate/conflicting copies, input-file immutability, Unicode/space paths and the Windows launcher. Tests used Windows x64 and R 4.6.0, with base/recommended R only.

The extension's unit tests used small, controlled fixtures. No new heavy Monte Carlo estimation was executed, and original CF/ATT publication evaluation CSVs were not changed. Recomputing site-level errors from original weights requires the original saved output directory; reaggregating the included replication-level weight diagnostics does not. Summary inputs cannot reconstruct missing method weights. See `weight_diagnostics/README_JP.md` and the module's test report for the added workflow.

Verified on Windows x64 with R 4.6.0. The summary and Cov-SCM workflows use only base/recommended R packages. Python table generation uses the standard library.

## Scientific inputs and numbering

- D1–D5 are primary; D6–D10 are supplementary. `design_catalog.csv` records the legacy-to-paper mapping.
- All 200 original scenario/replication/seed assignments were checked. D9 and D10 retain their common paired seeds.
- Original CF/ATT evaluations and the user-completed 100-case Cov-SCM evaluations are unchanged.
- Parsed scientific R expressions in the four original numerical backends and the Cov-SCM vendor generator were compared with the pre-release sources. They are identical after excluding the single work-directory default assignment, which was made portable. Wrapper changes provide the catalog, explicit seeds, paths, and published settings.

## Tests actually run

- Catalog, reference-copy and R syntax checks: passed.
- Base-R reconstruction of archived CF/ATT means, MCSEs and paired intervals: passed. Primary-cell means and MCSEs agree with the Python manuscript-table summaries to less than 1e-10.
- Cov-SCM unit tests: passed, including analytic quadratic-program checks, independent face-enumeration checks, archive alignment, and separation of outcome/truth inputs from weight fitting.
- Cov-SCM integration tests: passed, including the default five designs, resumption, two-replication paired intervals, all eight supported numeric DGPs at replication 20, and optional attribute specifications.
- **All 100 primary Cov-SCM cases were recomputed** with the publication catalog. CF RMSE/MAE/signed bias and ATT RMSE/MAE/signed bias match the archived metrics exactly at the stored numerical precision (maximum absolute difference 0).
- The full original-estimator dry run produces the correct 200-case seed plan.
- The archived GeoEco-versus-Graph plot was regenerated in sequential DGP order using base R.

The accompanying manuscript and Online Appendix are checked separately with the desktop application's built-in LaTeX compiler. Detailed manuscript checks are retained in the Overleaf archive's `validation/` directory.

## Scope

The full Graph-SCM/GeoEco-SCM and spatio-temporal estimators were **not** refitted across all 200 datasets during this release validation. Their supplied evaluations are used for the paper tables. The full workflow is included with its dependency checks and publication settings; its original package environment was not version-locked in the development archive. A fresh heavy-workflow run therefore requires the listed packages and should retain its own `sessionInfo()`.

Monte Carlo intervals describe uncertainty in mean simulated performance, rather than treatment-effect inference. The DGP-label update adds no new simulation design and changes no underlying archived result.

## Extracted delivery archive

The public ZIP was extracted to a directory containing Japanese characters and spaces. The Windows PowerShell launcher passed catalog checks, archived summary/plot generation, the five-design Cov-SCM smoke run, and the 200-case full-workflow dry run. Rebuilding the LaTeX tables with the extracted Python scripts reproduced every supplied table byte for byte. ZIP integrity and every file checksum were checked before execution. No heavy original estimator was run in this extraction check.

## Archived Cov-SCM input and optimization checks

The original numeric generator was re-executed with each primary-design seed without refitting the original estimators. Source and feature-fitting fingerprints were checked. Uniform CF/ATT metrics were recomputed for the same four target groups before Cov-SCM fitting: the maximum discrepancy was zero for CF metrics and approximately 1.25e-14 percentage points for ATT metrics. The accompanying provenance records retain the source archive and file hashes.

The supplied 100-case run contains 12,000 target-weight fits. The maximum duality gap and KKT residual were approximately 9.93e-14; the maximum row-sum error was 1.78e-15 and no weight was negative. The solver checks simplex feasibility, complementary optimality conditions and an absolute duality gap no greater than 1e-13.

The exploratory shorter-range spatio-temporal grid check preceded the Cov-SCM addition and covers the original seven full-coverage methods. It is separate from the later data-alignment and release-validation checks.
