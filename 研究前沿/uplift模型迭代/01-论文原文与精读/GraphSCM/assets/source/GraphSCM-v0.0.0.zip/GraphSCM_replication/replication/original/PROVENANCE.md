# Code provenance

The public interface was created after the final 10-DGP analysis was frozen.

Two DGP generators are intentionally retained:

- `internal/generator_legacy8.R`: the frozen generator used for the eight established DGPs.
- `internal/generator_local_paired_v9.R`: the finalized paired local-standard/local-mismatch generator.

Two compatible estimator backends are retained because the paired-v9 estimator expects local diagnostic objects that are absent from the historical eight-DGP RDS schema. The Graph-SCM / GeoEco-SCM objective, PRE-only calibration logic, final OSQP exact solve, and Gneiting benchmark are common in scientific content.

For publication, the legacy estimator copy uses the final saturated Gneiting parameter grid established by the sensitivity analysis. The public runner also permits the expanded lambda upper tail globally; this only removes the single archived boundary diagnostic and does not alter its selected lambda, beta, RMSE, or signed bias.

The paper's archived final QA reports:

- 10 scenarios, 20 replications each
- exact QP success 200/200
- OSQP solved 200/200
- remaining lambda boundaries 0
- remaining beta boundaries 0
- paired-v9 invariant audit passed for all 20 seed pairs
