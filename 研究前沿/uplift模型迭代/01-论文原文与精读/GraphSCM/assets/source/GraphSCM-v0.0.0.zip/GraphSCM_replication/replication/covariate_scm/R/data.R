# Original-RDS reader and a dependency-free adapter for the frozen legacy DGP.
# The adapter executes the original numeric expressions, not a rewritten DGP.

cov_source_files <- unlist(lapply(sys.frames(), function(frame) {
  if (exists("ofile", envir = frame, inherits = FALSE)) get("ofile", envir = frame) else NULL
}), use.names = FALSE)
cov_source_file <- tail(cov_source_files[basename(cov_source_files) == "data.R"], 1L)
if (length(cov_source_file) != 1L) stop("Source R/data.R from its saved file.")
cov_catalog_path <- file.path(dirname(normalizePath(cov_source_file,
    winslash = "/")), "..", "..", "design_catalog.csv")
cov_catalog <- utils::read.csv(cov_catalog_path, stringsAsFactors = FALSE)
cov_catalog <- cov_catalog[cov_catalog$backend == "legacy8",
    c("paper_id", "scenario", "seed_base", "legacy_index")]
names(cov_catalog)[1] <- "code"

cov_features <- function(feature_set = "geo_econ") {
  econ <- c("pre_employment_density_z", "pre_commercial_share_z", "pre_income_z")
  switch(feature_set, geo_econ = c("X_m", "Y_m", econ), econ = econ,
         geo = c("X_m", "Y_m"), stop("Unknown feature-set: ", feature_set))
}

cov_attributes <- function(x, ids = NULL) {
  columns <- c("point_id", cov_features())
  if (!all(columns %in% names(x))) stop("Missing required observed attributes.")
  ans <- as.data.frame(setNames(lapply(columns, function(nm) x[[nm]]), columns),
                       stringsAsFactors = FALSE)
  if (anyNA(ans$point_id) || anyDuplicated(ans$point_id) ||
      any(!nzchar(as.character(ans$point_id)))) stop("Invalid location IDs.")
  ans$point_id <- as.character(ans$point_id)
  if (!is.null(ids)) {
    if (!all(ids %in% ans$point_id)) stop("Attribute IDs do not cover required IDs.")
    ans <- ans[match(ids, ans$point_id), , drop = FALSE]
  }
  ans
}

cov_validate_data <- function(dat, scenario, seed) {
  if (!identical(as.character(dat$scenario), scenario) ||
      as.integer(dat$seed) != as.integer(seed)) stop("Dataset scenario/seed mismatch.")
  n <- nrow(dat$target); j <- nrow(dat$donor); tt <- length(dat$years)
  if (anyDuplicated(dat$years) || anyNA(dat$years) ||
      !setequal(dat$years, c(dat$pre_years, dat$post_years)) ||
      length(intersect(dat$pre_years, dat$post_years)) ||
      max(dat$pre_years) >= min(dat$post_years)) stop("Invalid time partition.")
  if (!all(dim(dat$donor_log) == c(j, tt)) ||
      !all(dim(dat$observed_log) == c(n, tt)) ||
      !all(dim(dat$true_cf_log) == c(n, tt)) ||
      !all(dim(dat$tau_log) == c(n, tt))) stop("Dataset matrix dimensions disagree.")
  if (any(!is.finite(dat$donor_log)) ||
      any(!is.finite(dat$true_cf_log)) ||
      any(!is.finite(dat$tau_log))) stop("Incomplete donor/truth arrays.")
  pre <- dat$observed_log[, match(dat$pre_years, dat$years), drop = FALSE]
  count <- rowSums(is.finite(pre))
  groups <- ifelse(count == 0, "post_only",
                   ifelse(count == ncol(pre), "complete_pre", "partial_pre"))
  if (!identical(as.character(dat$groups), as.character(groups)))
    stop("Observation groups disagree with observed PRE outcomes.")
  for (nm in cov_features()) {
    if (!is.numeric(dat$target[[nm]]) || !is.numeric(dat$donor[[nm]]) ||
        any(!is.finite(c(dat$target[[nm]], dat$donor[[nm]]))))
      stop("Invalid observed attribute: ", nm)
  }
  dat
}

cov_read_original <- function(path, scenario, seed) {
  obj <- readRDS(path)
  if (identical(obj$schema, "covariate_scm_input_v1"))
    return(cov_validate_data(obj, scenario, seed))
  needed <- c("config", "target_meta", "target_points", "all_points",
              "simulation_truth")
  if (!all(needed %in% names(obj))) stop("Unsupported original RDS schema.")
  tr <- obj$simulation_truth
  target <- cov_attributes(obj$target_meta)
  tids <- target$point_id
  if (anyDuplicated(obj$target_points[["point_id"]])) stop("Duplicate target IDs.")
  ti <- match(tids, as.character(obj$target_points[["point_id"]]))
  if (anyNA(ti)) stop("Target metadata and outcome IDs disagree.")
  years <- as.integer(obj$config$years)
  prices <- paste0("price_", years)
  matrix_cols <- function(x) {
    if (!all(prices %in% names(x))) stop("Missing price-year columns.")
    as.matrix(as.data.frame(setNames(lapply(prices, function(nm) x[[nm]]), prices)))
  }
  observed <- matrix_cols(obj$target_points)[ti, , drop = FALSE]
  if (any(!is.na(observed) & (!is.finite(observed) | observed <= 0)))
    stop("Observed target prices must be positive.")
  raw <- matrix_cols(obj$all_points)
  controls <- grepl("Control", as.character(obj$all_points[["group_type"]]),
                    fixed = TRUE)
  eligible <- controls & apply(raw, 1, function(z) all(is.finite(z) & z > 0))
  prepos <- match(obj$config$period_pre, years)
  eligible[eligible] <- apply(log(raw[eligible, prepos, drop = FALSE]), 1,
                              function(z) stats::sd(z) > 0)
  dids <- as.character(obj$all_points[["point_id"]])[eligible]
  if (!length(dids) || length(dids) > 40L)
    stop("This add-on expects the fixed simulation donor pool (at most 40 donors).")
  donor <- cov_attributes(obj$all_points, dids)
  truth_matrix <- function(z) {
    if (!is.matrix(z) || is.null(rownames(z)) || is.null(colnames(z)) ||
        !all(tids %in% rownames(z)) ||
        !all(as.character(years) %in% colnames(z))) stop("Truth IDs/years mismatch.")
    z[tids, as.character(years), drop = FALSE]
  }
  dat <- list(schema = "covariate_scm_input_v1", scenario = obj$config$scenario,
    seed = tr$seed, years = years, pre_years = as.integer(obj$config$period_pre),
    post_years = as.integer(obj$config$period_post), target = target, donor = donor,
    groups = as.character(obj$target_meta[["obs_group"]]),
    observed_log = log(observed), donor_log = log(raw[eligible, , drop = FALSE]),
    true_cf_log = truth_matrix(tr$true_cf_log), tau_log = truth_matrix(tr$tau_log))
  cov_validate_data(dat, scenario, seed)
}

cov_generate <- function(generator, scenario, seed) {
  expected <- "dc7c30b52a3adc1aecbc7d0bcd089ce1"
  if (unname(tools::md5sum(generator)) != expected)
    stop("Frozen generator checksum differs; use an original saved RDS instead.")
  expressions <- parse(generator, keep.source = FALSE)
  assigned <- function(x) {
    if (is.call(x) && identical(x[[1]], as.name("<-")) && is.symbol(x[[2]]))
      as.character(x[[2]]) else ""
  }
  names <- vapply(expressions, assigned, character(1))
  first <- which(names == "SCENARIO")
  last <- which(names == "observation_selection")
  stopifnot(length(first) == 1L, length(last) == 1L, first < last)
  # Isolate environment overrides, seed and RNG kind from the caller.
  text <- readLines(generator, warn = FALSE)
  matches <- regmatches(paste(text, collapse = "\n"),
                        gregexpr('Sys.getenv\\(\\s*"[^"]+"',
                                 paste(text, collapse = "\n"), perl = TRUE))[[1]]
  vars <- unique(sub('.*"([^"]+)"$', "\\1", matches))
  old_env <- Sys.getenv(vars, unset = NA_character_)
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    Sys.unsetenv(vars)
    present <- !is.na(old_env)
    if (any(present)) do.call(Sys.setenv, as.list(old_env[present]))
    do.call(RNGkind, as.list(old_kind))
    if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  Sys.unsetenv(vars)
  Sys.setenv(SIM_SCENARIO = scenario, SIM_SEED = as.character(seed),
             SIM_N_CONTROL = "24", SIM_N_TARGET = "120",
             SIM_PROP_COMPLETE = "0.50", SIM_PROP_PARTIAL = "0.30")
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  env <- new.env(parent = asNamespace("stats"))
  omitted <- c("SIM_OUTPUT_ROOT", "OUTPUT_DIR",
               "target_market_features", "donor_market_features")
  for (k in seq.int(first, last - 1L)) {
    e <- expressions[[k]]
    if (names[k] %in% omitted) next
    if (is.call(e) && identical(e[[1]], as.name("dir.create"))) next
    eval(e, env)
  }
  attr_frame <- function(which) {
    is_target <- which == "target"
    xy <- if (is_target) env$target_xy else env$control_xy
    ids <- if (is_target) env$target_ids else env$control_ids
    prefix <- if (is_target) "target_" else "control_"
    data.frame(point_id = ids, X_m = xy[, 1], Y_m = xy[, 2],
      pre_employment_density_z = get(paste0(prefix, "pre_employment_density_z"), env),
      pre_commercial_share_z = get(paste0(prefix, "pre_commercial_share_z"), env),
      pre_income_z = get(paste0(prefix, "pre_income_z"), env),
      stringsAsFactors = FALSE)
  }
  dat <- list(schema = "covariate_scm_input_v1", scenario = scenario, seed = seed,
    years = env$YEARS, pre_years = env$PERIOD_PRE, post_years = env$PERIOD_POST,
    target = attr_frame("target"), donor = attr_frame("control"),
    groups = env$obs_group, observed_log = env$target_log_observed,
    donor_log = env$control_log, true_cf_log = env$true_cf_log, tau_log = env$tau_log)
  cov_validate_data(dat, scenario, seed)
}

cov_archive_check <- function(dat, cf_ref, att_ref, scenario, seed) {
  result <- cov_evaluate(matrix(1 / nrow(dat$donor), nrow(dat$target),
                                nrow(dat$donor)), dat, "uniform_weights")
  checks <- list()
  for (kind in c("cf", "att")) {
    ref <- if (kind == "cf") cf_ref else att_ref
    ref <- ref[ref$scenario == scenario & ref$seed == seed &
                 ref$method == "uniform_weights", , drop = FALSE]
    got <- result[[kind]]
    if (nrow(ref) != nrow(got) || anyDuplicated(ref$obs_group) ||
        !setequal(ref$obs_group, got$obs_group)) stop("Missing Uniform archive rows.")
    ref <- ref[match(got$obs_group, ref$obs_group), , drop = FALSE]
    fields <- if (kind == "cf") c("CF_RMSE_log", "CF_MAE_log",
                                  "CF_signed_mean_bias_log") else
      c("ATT_RMSE_pp", "ATT_MAE_pp", "ATT_mean_bias_pp")
    for (field in fields) {
      difference <- max(abs(got[[field]] - ref[[field]]))
      tolerance <- if (kind == "cf") 1e-9 else 1e-7
      if (!is.finite(difference) || difference > tolerance ||
          any(got$n_sites != ref$n_sites) ||
          any(got$n_eval_sites != ref$n_eval_sites))
        stop("Generated/saved data disagree with archive: ", field,
             "; maximum discrepancy=", format(difference, digits = 8))
      checks[[length(checks) + 1L]] <- data.frame(
        metric = field, max_abs_difference = difference, tolerance = tolerance)
    }
  }
  do.call(rbind, checks)
}

# Extra repetitions use the actual saved datasets and their comparator results.
# The bundled 100-repetition archive remains the default reference.
cov_prepare_references <- function(root, input_root, scenarios, reps) {
  paths <- file.path(root,"reference",c("counterfactual_replications.csv","ATT_replications.csv"))
  reference <- lapply(paths,utils::read.csv,stringsAsFactors=FALSE)
  names(reference) <- c("cf","att")
  replacements <- list(cf=list(),att=list()); sources <- list(); replaced <- character()
  if (!is.null(input_root)) input_root <- normalizePath(input_root,winslash="/",mustWork=TRUE)
  for (scenario in scenarios) for (rep in reps) {
    seed <- as.integer(cov_catalog$seed_base[match(scenario,cov_catalog$scenario)]+rep)
    key <- paste(scenario,seed,sep="|")
    folder <- if (is.null(input_root)) "" else file.path(input_root,paste0("seed_",seed),scenario)
    files <- file.path(folder,"results_graph_geoeco",c(
      "simulation_counterfactual_method_comparison_by_group.csv",
      "simulation_ATT_method_comparison_by_group.csv"))
    use_saved <- !is.null(input_root) && any(file.exists(files))
    if (use_saved) {
      if (!all(file.exists(files))) stop("Incomplete saved CF/ATT reference: ",folder)
      if (rep>100L && !file.exists(file.path(folder,"results_graph_geoeco","_MC_FINISHED.txt")))
        stop("Saved full-estimator case is not marked complete: ",folder)
      for (i in seq_along(files)) {
        x <- utils::read.csv(files[i],stringsAsFactors=FALSE)
        for (nm in c("scenario","rep","seed")) {
          expected <- switch(nm,scenario=scenario,rep=rep,seed=seed)
          if (nm %in% names(x) && any(is.na(x[[nm]]) | x[[nm]]!=expected))
            stop("Saved reference metadata disagree: ",files[i])
          x[[nm]] <- expected
        }
        if (!all(names(reference[[i]]) %in% names(x)) ||
            anyDuplicated(paste(x$method,x$obs_group,sep="|")))
          stop("Invalid saved reference schema or duplicate method/group: ",files[i])
        replacements[[i]][[length(replacements[[i]])+1L]] <- x[,names(reference[[i]]),drop=FALSE]
      }
      replaced <- c(replaced,key)
    } else {
      for (x in reference) if (!any(x$scenario==scenario & x$rep==rep & x$seed==seed))
        stop("Replication ",rep," is outside the bundled reference. Supply input_root pointing to completed full/full_Rcpp output.")
    }
    if (rep>100L && (is.null(input_root) || !any(file.exists(c(
        file.path(folder,"M1_LP_synthetic_dataset.rds"),
        file.path(input_root,scenario,"M1_LP_synthetic_dataset.rds"))))))
      stop("Extra repetitions require the saved simulation dataset: ",scenario," rep ",rep)
    sources[[length(sources)+1L]] <- data.frame(scenario=scenario,rep=rep,seed=seed,
      reference_source=if (use_saved) folder else "bundled_100_replication_archive",
      CF_md5=unname(tools::md5sum(if(use_saved) files[1] else paths[1])),
      ATT_md5=unname(tools::md5sum(if(use_saved) files[2] else paths[2])))
  }
  for (i in seq_along(reference)) if (length(replacements[[i]])) {
    x <- reference[[i]]
    reference[[i]] <- rbind(x[!paste(x$scenario,x$seed,sep="|") %in% replaced,,drop=FALSE],
      do.call(rbind,replacements[[i]]))
  }
  list(cf=reference$cf,att=reference$att,sources=do.call(rbind,sources))
}
