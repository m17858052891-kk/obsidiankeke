# Original generation and estimation backends

Use the unified entry point and [publication README](../../README_R.md).
These backends retain the validated scientific expressions for D1–D10. Private WORK_DIR fallbacks were replaced by getwd(); see ../publication_source_changes.json. The public catalog supplies the current paper labels and unchanged seed bases.

`run_all.R --dry-run` prints the plan without fitting. `--test` still refits every requested method for one seed per design, so it is not a lightweight dependency test. The unified archive-summary workflow requires no extra packages.
