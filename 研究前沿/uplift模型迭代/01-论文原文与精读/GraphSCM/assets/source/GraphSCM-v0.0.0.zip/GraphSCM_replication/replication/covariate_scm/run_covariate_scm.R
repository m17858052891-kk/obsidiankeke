# Run with Rscript --vanilla run_covariate_scm.R --mode=test or --mode=full.
args_file <- grep("^--file=", commandArgs(FALSE), value = TRUE)
source_file <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
COV_ROOT <- if (!is.null(source_file)) {
  dirname(normalizePath(source_file, winslash = "/"))
} else if (length(args_file)) {
  dirname(normalizePath(sub("^--file=", "", args_file[1]), winslash = "/"))
} else {
  getwd()
}
source(file.path(COV_ROOT, "R", "core.R"))
source(file.path(COV_ROOT, "R", "data.R"))

cov_write_csv <- function(x, file) {
  utils::write.csv(x, file, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}

cov_summary <- function(cf, att) {
  keys <- unique(cf[, c("scenario", "method", "obs_group")])
  rows <- vector("list", nrow(keys))
  for (i in seq_len(nrow(keys))) {
    k <- keys[i, ]
    a <- cf[cf$scenario == k$scenario & cf$method == k$method &
              cf$obs_group == k$obs_group, ]
    b <- att[att$scenario == k$scenario & att$method == k$method &
               att$obs_group == k$obs_group, ]
    if (nrow(a) != nrow(b) || !setequal(a$seed, b$seed))
      stop("CF and ATT replication sets disagree.")
    out <- k
    out$n_replications <- nrow(a)
    for (metric in c("CF_RMSE_log", "ATT_RMSE_pp", "ATT_mean_bias_pp")) {
      v <- if (metric %in% names(a)) a[[metric]] else b[[metric]]
      out[[paste0(metric, "_mean")]] <- mean(v)
      out[[paste0(metric, "_MCSE")]] <-
        if (length(v) > 1) stats::sd(v) / sqrt(length(v)) else NA_real_
    }
    rows[[i]] <- out
  }
  do.call(rbind, rows)
}

cov_pairs <- function(new, reference, metric) {
  methods <- c("Graph_SCM", "GeoEco_SCM", "uniform_weights",
    "Gneiting_kriging_then_SCM", "Gneiting_kriging_EconX_then_SCM",
    "direct_Gneiting_kriging", "direct_Gneiting_kriging_EconX")
  rows <- list()
  for (scenario in unique(new$scenario)) for (g in unique(new$obs_group)) {
    x <- new[new$scenario == scenario & new$obs_group == g, ]
    for (method in methods) {
      y <- reference[reference$scenario == scenario &
                       reference$obs_group == g & reference$method == method, ]
      y <- y[match(x$seed, y$seed), , drop = FALSE]
      if (anyNA(y$seed) || any(x$n_sites != y$n_sites) ||
          any(x$n_eval_sites != x$n_sites) || any(y$n_eval_sites != y$n_sites))
        stop("Comparison population/replications disagree: ", scenario, "/", g, "/", method)
      d <- x[[metric]] - y[[metric]]
      n <- length(d)
      se <- if (n > 1) stats::sd(d) / sqrt(n) else NA_real_
      margin <- if (n > 1) stats::qt(0.975, n - 1) * se else NA_real_
      rows[[length(rows) + 1L]] <- data.frame(
        scenario = scenario, obs_group = g, metric = metric,
        new_method = unique(x$method), reference_method = method, n = n,
        new_mean = mean(x[[metric]]), reference_mean = mean(y[[metric]]),
        mean_difference = mean(d), MCSE_difference = se,
        lower_95 = mean(d) - margin, upper_95 = mean(d) + margin)
    }
  }
  do.call(rbind, rows)
}

cov_replication_label <- function(reps) {
  if (length(reps)>1L && all(diff(reps)==1L)) return(paste0(reps[1],"to",tail(reps,1)))
  label <- paste(reps,collapse="-")
  if (nchar(label)<=100L) return(label)
  file <- tempfile(); on.exit(unlink(file),add=TRUE)
  saveRDS(reps,file,version=2)
  paste0("selected",length(reps),"_",substr(unname(tools::md5sum(file)),1,12))
}

run_covariate_benchmark <- function(mode = "test", scenarios = NULL,
    reps = NULL, feature_set = "geo_econ", input_root = NULL,
    output_root = file.path(COV_ROOT, "output"), root = COV_ROOT, dry_run = FALSE) {
  stopifnot(mode %in% c("test", "full"))
  features <- cov_features(feature_set)
  if (is.null(scenarios)) scenarios <- paste0("D", 1:5)
  aliases <- match(scenarios, cov_catalog$code)
  scenarios[!is.na(aliases)] <- cov_catalog$scenario[aliases[!is.na(aliases)]]
  if (!length(scenarios) || anyDuplicated(scenarios) ||
      any(!scenarios %in% cov_catalog$scenario)) stop("Choose D1-D8 or their scenario names.")
  if (is.null(reps)) reps <- if (mode == "test") 1L else 1:100
  if (!length(reps) || anyNA(reps) || anyDuplicated(reps) ||
      any(reps != as.integer(reps)) || any(reps < 1 | reps > 10000))
    stop("Replication IDs must be unique integers from 1 to 10000; published defaults are 1-100.")
  reps <- sort(as.integer(reps))
  if (!is.null(input_root)) input_root <- normalizePath(input_root,winslash="/",mustWork=TRUE)
  generator <- file.path(root, "vendor", "generator_legacy8.R")
  reference <- cov_prepare_references(root,input_root,scenarios,reps)
  cf_ref <- reference$cf; att_ref <- reference$att
  if (isTRUE(dry_run)) {
    cat("Cov-SCM plan:",length(scenarios)*length(reps),"cases; saved references validated. No model was fitted.\n")
    return(invisible(reference$sources))
  }
  method <- paste0("Covariate_SCM_", feature_set)
  files <- c(file.path(root, "R", c("core.R", "data.R")),
             file.path(root, "run_covariate_scm.R"),
             file.path(root, "..", "design_catalog.csv"), generator,
             file.path(root, "reference",
                       c("counterfactual_replications.csv", "ATT_replications.csv")))
  config <- list(version = 3L, features = features, feature_set = feature_set,
    standardization = "pooled target and donor PRE attributes; sample SD",
    objective = "mean squared standardized covariate imbalance + ridge * sum(w^2)",
    ridge = 1e-10, gap_tolerance = 1e-13,
    source_md5 = unname(tools::md5sum(files)))
  hash_file <- tempfile()
  saveRDS(config, hash_file, version = 2)
  run_id <- substr(unname(tools::md5sum(hash_file)), 1, 12)
  unlink(hash_file)
  out <- file.path(output_root, paste0(method, "_", run_id))
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  out <- normalizePath(out,winslash="/",mustWork=TRUE)
  saveRDS(config, file.path(out, "config.rds"))
  # Test and full runs use the same configuration directory, enabling resumption.
  results <- audits <- runtime <- list()
  for (scenario in scenarios) for (rep in reps) {
    dgp <- match(scenario, cov_catalog$scenario)
    seed <- as.integer(cov_catalog$seed_base[dgp] + rep)
    expected <- unique(cf_ref$seed[cf_ref$scenario == scenario & cf_ref$rep == rep])
    if (!identical(as.integer(expected), seed)) stop("Seed mapping disagrees with archive.")
    case_dir <- file.path(out, paste0("seed_", seed), scenario)
    dir.create(case_dir, recursive = TRUE, showWarnings = FALSE)
    marker <- file.path(case_dir, "completed.rds")
    input <- NULL
    if (!is.null(input_root)) {
      candidates <- c(
        file.path(input_root, paste0("seed_", seed), scenario, "M1_LP_synthetic_dataset.rds"),
        file.path(input_root, scenario, "M1_LP_synthetic_dataset.rds"))
      found <- candidates[file.exists(candidates)]
      if (length(found)) input <- normalizePath(found[1], winslash = "/")
    }
    input_md5 <- if (is.null(input)) "frozen_generator" else unname(tools::md5sum(input))
    if (file.exists(marker)) {
      one <- readRDS(marker)
      if (!identical(one$run_id, run_id) || !identical(one$input_md5, input_md5))
        stop("A completed run has incompatible provenance: ", marker)
      cat("RESUME: ", cov_catalog$code[dgp], " rep ", rep, "\n", sep = "")
    } else {
      cat("RUN: ", cov_catalog$code[dgp], " rep ", rep, " seed ", seed, "\n", sep = "")
      began <- proc.time()[["elapsed"]]
      dat <- if (is.null(input)) cov_generate(generator, scenario, seed) else
        cov_read_original(input, scenario, seed)
      generated_sec <- proc.time()[["elapsed"]] - began
      audit <- cov_archive_check(dat, cf_ref, att_ref, scenario, seed)
      # Only these two attribute matrices enter the fitting function.
      X <- as.matrix(dat$target[, features, drop = FALSE])
      C <- as.matrix(dat$donor[, features, drop = FALSE])
      rownames(X) <- dat$target$point_id
      rownames(C) <- dat$donor$point_id
      fit_start <- proc.time()[["elapsed"]]
      fit <- fit_covariate_scm(X, C, ridge = config$ridge,
                               gap_tol = config$gap_tolerance)
      fit_sec <- proc.time()[["elapsed"]] - fit_start
      evaluated <- cov_evaluate(fit$W, dat, method)
      tag <- function(x) cbind(data.frame(scenario = scenario, rep = rep, seed = seed), x)
      diag <- cbind(point_id = dat$target$point_id, obs_group = dat$groups,
                    fit$diagnostics)
      weight_table <- data.frame(point_id = dat$target$point_id, fit$W, check.names = FALSE)
      cov_write_csv(weight_table, file.path(case_dir, "covariate_weights.csv"))
      cov_write_csv(diag, file.path(case_dir, "solver_diagnostics.csv"))
      saveRDS(list(center = fit$center, scale = fit$scale, retained = fit$retained,
                   features = features), file.path(case_dir, "standardization.rds"))
      one <- list(run_id = run_id, input_md5 = input_md5,
        cf = tag(evaluated$cf), att = tag(evaluated$att),
        annual = tag(evaluated$annual), audit = tag(audit),
        runtime = data.frame(scenario = scenario, rep = rep, seed = seed,
          input_source = if (is.null(input)) "frozen_numeric_generator" else input,
          generation_or_read_sec = generated_sec, fitting_sec = fit_sec,
          total_sec = proc.time()[["elapsed"]] - began,
          max_duality_gap = max(fit$diagnostics$duality_gap),
          max_kkt_residual = max(fit$diagnostics$kkt_residual)))
      temporary <- paste0(marker, ".tmp")
      saveRDS(one, temporary)
      if (!file.rename(temporary, marker)) stop("Cannot finalize completion marker.")
    }
    key <- paste(scenario, rep)
    results[[key]] <- one
    audits[[key]] <- one$audit
    runtime[[key]] <- one$runtime
  }
  bind <- function(field) {
    ans <- do.call(rbind, lapply(results, function(z) z[[field]]))
    rownames(ans) <- NULL
    ans
  }
  cf <- bind("cf"); att <- bind("att")
  # Restrict collection to the requested cases, even if other cases are cached.
  summary_dir <- file.path(out, paste0("summary_", mode, "_",
    paste(cov_catalog$code[match(scenarios, cov_catalog$scenario)], collapse = "-"),
    "_reps_", cov_replication_label(reps)))
  dir.create(summary_dir, recursive = TRUE, showWarnings = FALSE)
  cov_write_csv(cf, file.path(summary_dir, "covariate_CF_replications.csv"))
  cov_write_csv(att, file.path(summary_dir, "covariate_ATT_replications.csv"))
  cov_write_csv(bind("annual"), file.path(summary_dir, "covariate_ATT_by_year.csv"))
  cov_write_csv(cov_summary(cf, att), file.path(summary_dir, "covariate_summary.csv"))
  cov_write_csv(cov_pairs(cf, cf_ref, "CF_RMSE_log"),
                file.path(summary_dir, "paired_CF_RMSE.csv"))
  cov_write_csv(cov_pairs(att, att_ref, "ATT_RMSE_pp"),
                file.path(summary_dir, "paired_ATT_RMSE.csv"))
  cov_write_csv(do.call(rbind, audits), file.path(summary_dir, "uniform_data_audit.csv"))
  cov_write_csv(do.call(rbind, runtime), file.path(summary_dir, "runtime.csv"))
  cov_write_csv(reference$sources,file.path(summary_dir,"reference_sources.csv"))
  writeLines(c(paste("Mode:", mode), paste("Cases:", length(results)),
    paste("Feature set:", feature_set), paste("R:", R.version.string),
    "Paired differences are Covariate-SCM minus the reference method.",
    "Negative RMSE differences favor Covariate-SCM.",
    "Intervals are Monte Carlo performance intervals, not ATT confidence intervals.",
    if (mode == "test") "TEST OUTPUT: one replication per DGP by default; not full Monte Carlo results."
    else paste("Full mode; requested repetitions per DGP:",length(reps)),
    "Full mode uses 100 repetitions; additional repetitions beyond the supplied references require saved inputs."),
    file.path(summary_dir, "RUN_INFO.txt"))
  writeLines(normalizePath(summary_dir,winslash="/"),file.path(output_root,"LATEST_SUMMARY.txt"))
  cat("Completed ", length(results), " requested case(s).\nOutput: ",
      normalizePath(summary_dir, winslash = "/"), "\n", sep = "")
  invisible(list(summary_dir = summary_dir, cf = cf, att = att))
}

if (sys.nframe() == 0L) {
  opts <- list()
  for (arg in commandArgs(TRUE)) {
    if (arg=="--dry-run") { opts$dry_run <- TRUE; next }
    if (!grepl("^--[a-z-]+=", arg)) stop("Use --option=value arguments: ", arg)
    split <- regexpr("=", arg, fixed = TRUE)[1]
    key <- substring(arg, 3, split - 1L)
    if (!key %in% c("mode", "scenarios", "reps", "feature-set", "input-root", "output-root"))
      stop("Unknown option: ", key)
    opts[[key]] <- substring(arg, split + 1L)
  }
  get_opt <- function(name, default = NULL) if (is.null(opts[[name]])) default else opts[[name]]
  rep_text <- get_opt("reps")
  reps <- if (is.null(rep_text)) NULL else if (grepl("^[0-9]+:[0-9]+$", rep_text)) {
    endpoints <- as.integer(strsplit(rep_text, ":", fixed = TRUE)[[1]])
    if (anyNA(endpoints) || any(endpoints<1L | endpoints>10000L)) stop("Replication range must be within 1-10000.")
    seq.int(endpoints[1], endpoints[2])
  } else as.integer(strsplit(rep_text, ",", fixed = TRUE)[[1]])
  scenes <- get_opt("scenarios")
  run_covariate_benchmark(mode = get_opt("mode", "test"),
    scenarios = if (is.null(scenes)) NULL else strsplit(scenes, ",", fixed = TRUE)[[1]],
    reps = reps, feature_set = get_opt("feature-set", "geo_econ"),
    input_root = get_opt("input-root"),
    dry_run = isTRUE(opts$dry_run),
    output_root = get_opt("output-root", file.path(COV_ROOT, "output")))
}
