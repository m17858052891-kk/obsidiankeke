# Graph-SCM and GeoEco-SCM: publication replication materials

Release **0.0.0 (2026-11-09)** contains 100 replications for each of D1–D10 (1,000 datasets) and Cov-SCM on the same 500 primary datasets, D1–D5. Supplementary designs are D6–D10. The authoritative scenario mapping is `replication/design_catalog.csv`; actual indices and seeds are in `data/study_plan.csv`.

## Start here in RStudio

1. Extract the whole ZIP; do not open individual R files inside the ZIP.
2. Open `GraphSCM_replication.Rproj` in RStudio. This sets the working directory.
3. Open `START_HERE.R` and click **Source**, or enter `source("START_HERE.R")`.
4. Read the outputs in `replication/output/archived_summary/`.

This first route checks the files and reaggregates supplied results. It does not fit the Monte Carlo models. Rcpp and a C++ compiler are unnecessary for this route. This release consists of R replication scripts, not an installable R package.

For complete model refitting, use `RUN_FULL_STUDY.R`. It initially prints only the plan. Its commented last line starts the expensive calculation after the packages and compiler described below have been installed.

## Start with the supplied results

Unzip the entire archive. Set the working directory to the top-level folder containing `replication` and `data`.

```r
source("replication/run_from_RStudio.R")
run_replication("check")
run_replication("summary")
```

These commands need only base/recommended R. They reproduce published means, MCSEs, paired 95% Monte Carlo intervals and a scientific figure without refitting or accessing the original output drive. Results go to `replication/output/archived_summary/`, with donor-weight summaries in its `weight_diagnostics/` subfolder. Despite the directory name, the supplied archive now contains the current 100-replication study.

Rebuild the 25 LaTeX tables with Python 3.10+ and its standard library:

```sh
python analysis/rebuild_tables.py
```

Windows users can also double-click `replication/check_and_summarize.bat`, or use:

```sh
Rscript --vanilla replication/run.R --task=check
Rscript --vanilla replication/run.R --task=summary
```

## Included data

- `data/counterfactual_replications.csv`: 32,000 evaluation rows for the original eight methods, including nonestimable ordinary-SCM rows.
- `data/ATT_replications.csv`: 31,000 finite ATT rows; ordinary-SCM post-only rows are omitted.
- `data/covariate_scm/`: 500 Cov-SCM datasets, 2,000 CF and ATT rows each, Uniform alignment audits and paired comparisons.
- `data/weight_diagnostics/`: 20,000 replication/group/method records for Graph-SCM, GeoEco-SCM, ordinary SCM and Uniform, from 1,000 saved weight snapshots.
- `data/study_plan.csv`: all 1,000 design/index/seed combinations.
- `data/selected_parameters.csv` and `data/solver_search_audit.csv`: tuning and numerical diagnostics.

All inputs are synthetic. Raw panels and complete weight matrices are not bundled because of their size; the generators and estimators regenerate them. Ordinary SCM is unavailable for post-only targets; its ALL evaluation covers the 96 PRE-observed targets. The full-coverage methods use the same indicated target group.

## Refit the exact 100-case-per-design study

Full estimation is computationally expensive. Inspect the plan first:

```r
source("replication/run_100_replications.R")
out <- "D:/GraphSCM_100rep" # choose your output directory
run_graphscm_100(output_root=out, engine="Rcpp", dry_run=TRUE)
run_graphscm_100(output_root=out, engine="Rcpp")
```

The last line fits the graph/spatio-temporal methods, runs Cov-SCM, and collects outcomes and weight diagnostics. Completed cases at the same root are reused. Graph results are in `full_Rcpp/`, their summaries in `full_Rcpp/_publication_summary/`, weights in `weights/`, and `covariate/LATEST_SUMMARY.txt` records the Cov-SCM summary directory.

The Rcpp engine needs Rcpp and a compatible C++ compiler (Rtools on Windows); RcppArmadillo is unnecessary. Full-estimator dependencies include:

```r
install.packages(c("Rcpp", "pacman", "sf", "tidyverse", "data.table", "glue",
  "Matrix", "FNN", "scales", "osqp", "CVXR", "mgcv"))
```

Use `engine="R"` for the original R FISTA loop. Its output is separated in `full/`. Published evaluations use the Rcpp engine. Different package environments or floating-point CV/QP calculations can produce small numerical differences; the supplied evaluation CSVs reproduce the reported statistics directly. The code was checked on Windows x64 with R 4.6.0. No full package environment is claimed to be version-locked.

### Seed plan and local-pair feasibility

D1–D8 use original indices 1–100. D9/D10 share indices 1–102 excluding 50 and 70. Those two draws admit at most 23 post-only locations under the fixed candidate and two-similar/two-dissimilar PRE-neighbor constraints, while 24 are required. The next common seeds, indices 101 and 102, replace them. This is an experiment conditional on observation-design feasibility; thresholds and support conditions are retained. The plan and exclusions are saved in `feasible_pair_design/`.

The truth-side incremental PRE R-squared from economic proxies is a warning diagnostic, not a replication acceptance criterion. Orthogonalization strength is fixed at 0.75. Index 80 is retained despite its large diagnostic. The generator and estimator numerical expressions are preserved; the runner passes the warning-only flag correctly.

### Recompute Cov-SCM alone

```r
source("replication/run_from_RStudio.R")
run_replication("covariate", mode="test") # one case per primary design
run_replication("covariate", mode="full") # 100 cases per primary design
```

This comparator requires only base R. The adapter executes the original numeric generation expressions, verifies Uniform CF/ATT against the supplied 100-case references, and fits simplex weights from two coordinates and three PRE economic proxies only. Coordinates are balanced as donor-weighted means; donors need not share the target location. Target outcomes and truth do not enter the weight-fitting function. The adapter supports D1–D8; the paper uses D1–D5, and D9/D10 use a different generator. Beyond the supplied seed references, provide completed datasets and comparator outputs with `input_root`.

## Other entry points

| Task | Purpose |
|---|---|
| `check` | Verify the published 1,000-case catalog, seed plan, references and R syntax |
| `summary` | Reaggregate the supplied 100-replication evaluations |
| `collect` | Aggregate completed graph/spatio-temporal output from your own run |
| `weights` | Evaluate your own saved weight snapshots without fitting |
| `benchmark` | Compare representative small R/Rcpp FISTA problems |
| `full` | Low-level original-estimator launcher with explicit design and index selection |

For backward compatibility, the low-level `full` and `weights` interfaces retain a 20-index default when no indices are supplied. Use `run_graphscm_100()` for the complete published study, including its common local-pair seed replacements. Use explicit indices for custom weight assessments. `summary` always reads the currently supplied 100-replication data.

## Statistical and numerical interpretation

MCSEs use 100 independent datasets per design; paired intervals use Student t with 99 degrees of freedom. ATT transforms the mean log effect into a percentage for each POST year before evaluating errors. Weight RMSE and counterfactual RMSE are distinct targets; effective donor counts measure concentration, not fixed-design sampling variance.

All 1,000 final QPs were solved. Adaptive beta-screening flags remain for D4/index 99, D8/index 87 and D10/index 23; final confirmed beta values are 8, 0 and 16. No invariance to further search expansion is claimed. The shorter-range sensitivity check used the earlier 20-replication subset; the 100-replication study uses the resulting expanded covariance grid. Current checks and dated development history are in `replication/VALIDATION.md`.

Please cite the accompanying paper; author metadata are in `CITATION.cff`.

## License and release links

The authors' original replication code and accompanying materials are released under the MIT license; see `LICENSE`. Required external R packages retain their own licenses. They are installed separately.

Author and software-version metadata are in `CITATION.cff`. The Zenodo record supplies the software DOI; use its version-specific DOI when citing the calculations in the paper. The paper's arXiv link can be added to the Zenodo record after announcement. The arXiv paper license is selected separately from the software license.
