args_all <- commandArgs(trailingOnly = FALSE)
file_arg <- grep('^--file=', args_all, value = TRUE)
R_DIR <- if (length(file_arg)) normalizePath(dirname(sub('^--file=', '', file_arg[1])), winslash='/', mustWork=TRUE) else normalizePath(getwd(), winslash='/', mustWork=TRUE)
source(file.path(R_DIR, '00_config.R'))
for (p in c('dplyr','readr','tibble')) if (!requireNamespace(p, quietly=TRUE)) stop('Package required: ',p)

scenario_std <- 'station_selected_local_standard'
scenario_mis <- 'station_selected_local_mismatch'
seed_dirs <- list.dirs(OUTPUT_ROOT, recursive=FALSE, full.names=TRUE)
seed_dirs <- seed_dirs[grepl('seed_[0-9]+$', basename(seed_dirs))]
max_abs_diff <- function(a,b) { z <- abs(as.numeric(a)-as.numeric(b)); z <- z[is.finite(z)]; if (!length(z)) 0 else max(z) }
sorted_econ_rows <- function(tf) {
  x <- as.data.frame(tf[,c('pre_employment_density_z','pre_commercial_share_z','pre_income_z')])
  x[do.call(order,x),,drop=FALSE]
}
rows <- list()
for (sd in seed_dirs) {
  f1 <- file.path(sd,scenario_std,'M1_LP_synthetic_dataset.rds')
  f2 <- file.path(sd,scenario_mis,'M1_LP_synthetic_dataset.rds')
  if (!file.exists(f1) || !file.exists(f2)) next
  a <- readRDS(f1); b <- readRDS(f2); ta <- a$simulation_truth; tb <- b$simulation_truth
  ma <- as.data.frame(a$target_meta); mb <- as.data.frame(b$target_meta)
  ea <- sorted_econ_rows(ta$target_market_features); eb <- sorted_econ_rows(tb$target_market_features)
  da <- as.data.frame(ta$local_mismatch_diagnostics)
  rows[[length(rows)+1L]] <- tibble::tibble(
    seed=ta$seed,
    same_target_ids=identical(as.character(ta$target_ids),as.character(tb$target_ids)),
    max_xy_diff=max(max_abs_diff(ma$X_m,mb$X_m),max_abs_diff(ma$Y_m,mb$Y_m)),
    same_obs_group=identical(as.character(ma$obs_group),as.character(mb$obs_group)),
    same_n_pre_obs=identical(as.integer(ma$n_pre_obs),as.integer(mb$n_pre_obs)),
    max_tau_diff=max_abs_diff(ta$tau_log,tb$tau_log),
    max_target_noise_diff=max_abs_diff(ta$target_noise,tb$target_noise),
    max_control_log_diff=max_abs_diff(ta$control_log,tb$control_log),
    max_sorted_econ_distribution_diff=max_abs_diff(as.matrix(ea),as.matrix(eb)),
    mean_mismatch_gain=mean(da$paired_mismatch_minus_standard),
    postonly_mismatch_gain=mean(da$paired_mismatch_minus_standard[da$obs_group=='post_only']),
    all_postonly_have_mixed_support=all(da$paired_mixed_pre_anchor_support[da$obs_group=='post_only']),
    w_true_changed=max_abs_diff(ta$W_true,tb$W_true)>1e-10,
    true_cf_changed=max_abs_diff(ta$true_cf_log,tb$true_cf_log)>1e-10
  )
}
if (!length(rows)) {
  cat('No completed D9-D10 pair found; paired audit was not run.\n')
  quit(status=0)
}
out <- dplyr::bind_rows(rows) |>
  dplyr::mutate(invariants_pass=same_target_ids & max_xy_diff<1e-12 & same_obs_group & same_n_pre_obs &
    max_tau_diff<1e-12 & max_target_noise_diff<1e-12 & max_control_log_diff<1e-12 &
    max_sorted_econ_distribution_diff<1e-12 & all_postonly_have_mixed_support &
    mean_mismatch_gain>=0.10 & w_true_changed & true_cf_changed)
dir.create(file.path(OUTPUT_ROOT,'_paired_audit'),recursive=TRUE,showWarnings=FALSE)
readr::write_csv(out,file.path(OUTPUT_ROOT,'_paired_audit','pair_invariants_by_rep.csv'))
summary <- tibble::tibble(n_pairs=nrow(out),n_pass=sum(out$invariants_pass),all_pass=all(out$invariants_pass),
  mean_mismatch_gain=mean(out$mean_mismatch_gain),mean_postonly_mismatch_gain=mean(out$postonly_mismatch_gain))
readr::write_csv(summary,file.path(OUTPUT_ROOT,'_paired_audit','pair_invariants_summary.csv'))
print(summary)
if (!all(out$invariants_pass)) stop('Paired invariants failed.')
