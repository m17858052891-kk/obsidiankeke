# Completion belongs to the runner: the frozen estimator writes results, not markers.
scm_validate_case_outputs <- function(result_dir,scenario,seed,tolerance=1e-8) {
  result_dir <- normalizePath(result_dir,winslash="/",mustWork=TRUE)
  required <- c("selected_parameters.csv","joint_scm_weights.csv",
    "simulation_counterfactual_method_comparison_by_group.csv",
    "simulation_ATT_method_comparison_by_group.csv","simulation_runtime_breakdown.csv",
    "simulation_runtime_mc_projection.csv","simulation_validation_scorecard.csv",
    "simulation_fista_fit_runtime_log.csv","postonly_graph_anchor_diagnostics.csv")
  paths <- file.path(result_dir,required)
  if (any(!file.exists(paths)) || any(file.info(paths)$size<=0))
    stop("Estimator outputs are incomplete; completion was not recorded.")
  read <- function(name) utils::read.csv(file.path(result_dir,name),stringsAsFactors=FALSE,
    check.names=FALSE,na.strings=c("","NA"))
  original <- file.path(dirname(result_dir),"M1_LP_synthetic_dataset.rds")
  if (!file.exists(original)) stop("Missing original input RDS; completion was not recorded.")
  dataset <- readRDS(original)
  truth <- dataset$simulation_truth
  if (!identical(as.character(dataset$config$scenario),as.character(scenario)) ||
      length(truth$seed)!=1L || is.na(truth$seed) || as.integer(truth$seed)!=as.integer(seed))
    stop("Scenario/seed mismatch; completion was not recorded.")
  weights <- read("joint_scm_weights.csv")
  if (!"point_id" %in% names(weights) || anyNA(weights$point_id) ||
      anyDuplicated(weights$point_id) || !setequal(weights$point_id,rownames(truth$W_true)))
    stop("Invalid saved weight target IDs.")
  donor_ids <- setdiff(names(weights),"point_id")
  if (!setequal(donor_ids,colnames(truth$W_true))) stop("Invalid saved donor IDs.")
  w <- as.matrix(weights[donor_ids]); rownames(w) <- weights$point_id
  if (!is.numeric(w) || any(!is.finite(w)) || min(w) < -tolerance ||
      max(abs(rowSums(w)-1))>tolerance) stop("Saved weights fail simplex checks.")
  parameters <- read("selected_parameters.csv")
  if (nrow(parameters)!=1L || !all(c("lambda","beta_econ") %in% names(parameters)) ||
      any(!is.finite(unlist(parameters[c("lambda","beta_econ")])))) stop("Invalid selected parameters.")
  cf <- read("simulation_counterfactual_method_comparison_by_group.csv")
  att <- read("simulation_ATT_method_comparison_by_group.csv")
  check_metrics <- function(value,metric) {
    fields <- c("method","obs_group","n_sites","n_eval_sites",metric)
    if (!all(fields %in% names(value)) || !nrow(value) ||
        anyDuplicated(value[c("method","obs_group")]) || anyNA(value[fields[1:4]]) ||
        any(value$n_eval_sites<0 | value$n_eval_sites>value$n_sites) ||
        any(!is.finite(value[[metric]][value$n_eval_sites>0]))) stop("Incomplete metric output: ",metric)
    for (method in c("GeoEco_SCM","Graph_SCM","Ordinary_SCM","uniform_weights"))
      if (!setequal(value$obs_group[value$method==method],c("complete_pre","partial_pre","post_only","ALL")))
        stop("Missing method/group output: ",method)
  }
  check_metrics(cf,"CF_RMSE_log"); check_metrics(att,"ATT_RMSE_pp")
  support <- read("postonly_graph_anchor_diagnostics.csv")
  if (!all(c("point_id","model_data_identified") %in% names(support)) ||
      anyDuplicated(support$point_id) || !setequal(support$point_id,rownames(w))) stop("Invalid support diagnostics.")
  keep <- as.logical(support$model_data_identified[match(rownames(w),support$point_id)])
  if (anyNA(keep)) stop("Incomplete support diagnostics.")
  ids <- as.character(dataset$all_points[["point_id"]])
  pos <- match(donor_ids,ids)
  post <- as.character(dataset$config$period_post)
  if (anyNA(pos) || !length(post) || !all(paste0("price_",post) %in% names(dataset$all_points)))
    stop("Missing donor POST observations.")
  donor_post <- vapply(paste0("price_",post),function(field)
    as.numeric(dataset$all_points[[field]])[pos],numeric(length(pos)))
  if (any(!is.finite(donor_post) | donor_post<=0)) stop("Invalid donor POST observations.")
  mu <- as.matrix(truth$true_cf_log)[rownames(w),post,drop=FALSE]
  error <- w%*%log(donor_post)-mu
  if (any(!is.finite(error))) stop("Invalid counterfactual reconstruction.")
  target_ids <- as.character(dataset$target_meta[["point_id"]])
  groups <- as.character(dataset$target_meta[["obs_group"]])[match(rownames(w),target_ids)]
  if (anyNA(groups)) stop("Invalid target groups.")
  max_metric_error <- 0
  for (group in c("complete_pre","partial_pre","post_only","ALL")) {
    take <- if (group=="ALL") rep(TRUE,nrow(w)) else groups==group
    row <- cf[cf$method=="GeoEco_SCM" & cf$obs_group==group,,drop=FALSE]
    selected <- take&keep
    if (row$n_sites!=sum(take) || row$n_eval_sites!=sum(selected)) stop("Saved evaluation population differs.")
    if (any(selected)) {
      expected <- c(CF_RMSE_log=sqrt(mean(error[selected,,drop=FALSE]^2)),
        CF_MAE_log=mean(abs(error[selected,,drop=FALSE])),
        CF_signed_mean_bias_log=mean(error[selected,,drop=FALSE]))
      if (!all(names(expected) %in% names(row))) stop("Missing CF diagnostic columns.")
      difference <- max(abs(as.numeric(unlist(row[1,names(expected)],use.names=FALSE))-expected))
      if (!is.finite(difference) || difference>tolerance) stop("Saved weights and CF evaluations disagree.")
      max_metric_error <- max(max_metric_error,difference)
    }
  }
  runtime <- read("simulation_runtime_breakdown.csv")
  if (!all(c("scenario","component","elapsed_sec") %in% names(runtime)) ||
      any(runtime$scenario!=scenario) || any(!is.finite(runtime$elapsed_sec) | runtime$elapsed_sec<0))
    stop("Invalid final runtime ledger.")
  list(files=data.frame(file=required,bytes=file.info(paths)$size,
      md5=unname(tools::md5sum(paths)),stringsAsFactors=FALSE),
    max_CF_reconstruction_difference=max_metric_error,
    profiled_elapsed_sec=sum(runtime$elapsed_sec),n_targets=nrow(w),n_donors=ncol(w))
}

scm_finalize_case <- function(result_dir,scenario,seed,engine,origin="normal_estimator_return") {
  if (!engine %in% c("R","Rcpp")) stop("Unknown execution engine.")
  checked <- scm_validate_case_outputs(result_dir,scenario,seed)
  marker <- file.path(result_dir,"_MC_FINISHED.txt")
  utils::write.csv(checked$files,file.path(result_dir,"completion_output_audit.csv"),row.names=FALSE)
  writeLines(c(paste0("FISTA engine: ",engine),paste0("R version: ",R.version.string),
    "Original objective, candidate grids, stopping criteria and final OSQP solver retained.",
    paste0("Completion origin: ",origin)),file.path(result_dir,"fista_execution_engine.txt"))
  if (!file.exists(marker)) {
    temporary <- tempfile("completion_",tmpdir=result_dir,fileext=".txt")
    on.exit(if (file.exists(temporary)) unlink(temporary),add=TRUE)
    writeLines(c("Validated simulation outputs completed.",paste0("scenario=",scenario),
      paste0("seed=",seed),paste0("engine=",engine),paste0("origin=",origin),
      paste0("max_CF_reconstruction_difference=",format(checked$max_CF_reconstruction_difference,digits=16))),temporary)
    if (!file.rename(temporary,marker)) stop("Could not commit the completion marker.")
  }
  invisible(checked)
}
