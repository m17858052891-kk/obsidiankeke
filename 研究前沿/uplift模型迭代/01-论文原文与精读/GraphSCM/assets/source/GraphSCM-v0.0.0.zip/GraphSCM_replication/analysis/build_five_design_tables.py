"""Add five-design tables from archived results; never refit an estimator."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from format_tables import format_table_tex
from collections import defaultdict
import csv
import json
import math
import statistics as st

P = Path(__file__).resolve().parents[1]
with (P / 'replication/design_catalog.csv').open(encoding='utf-8', newline='') as stream:
    CATALOG = list(csv.DictReader(stream))
SC = [r['scenario'] for r in CATALOG if r['role'] == 'primary']
CODES = {r['scenario']:r['paper_id'] for r in CATALOG if r['role'] == 'primary'}
COV = 'Covariate_SCM_geo_econ'
METHODS = ['Graph_SCM', 'GeoEco_SCM', COV, 'uniform_weights',
           'Gneiting_kriging_then_SCM', 'Gneiting_kriging_EconX_then_SCM',
           'direct_Gneiting_kriging', 'direct_Gneiting_kriging_EconX']
NAMES = dict(zip(METHODS, ['Graph', 'GeoEco', 'Cov-SCM', 'Uniform', 'STI', 'STI-X', 'STD', 'STD-X']))
GROUPS = ['complete_pre', 'partial_pre', 'post_only', 'ALL']
T99 = 1.9842169515086827

def read(name):
    with (P / 'data' / name).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def write(name, lines):
    (P / 'tables' / name).write_text(format_table_tex('\n'.join(lines) + '\n'), encoding='utf-8')

def csv_out(name, rows):
    with (P / 'data' / name).open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

cf = [r for r in read('counterfactual_replications.csv') if r['scenario'] in SC and r['method'] in METHODS]
att = [r for r in read('ATT_replications.csv') if r['scenario'] in SC and r['method'] in METHODS]
new_cf = read('covariate_scm/covariate_CF_replications.csv')
new_att = read('covariate_scm/covariate_ATT_replications.csv')
assert len(new_cf) == len(new_att) == 2000
cf += new_cf; att += new_att

def aggregate(rows, metric):
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row['scenario'], row['method'], row['obs_group'])].append(float(row[metric]))
    result = {}
    for key, values in grouped.items():
        assert len(values) == 100 and all(math.isfinite(v) for v in values)
        result[key] = (st.mean(values), st.stdev(values) / math.sqrt(100))
    assert len(result) == 5 * 8 * 4
    return result

cs = aggregate(cf, 'CF_RMSE_log')
ar = aggregate(att, 'ATT_RMSE_pp')
ab = aggregate(att, 'ATT_mean_bias_pp')
csv_out('primary_CF_summary.csv', [dict(scenario=k[0], design=CODES[k[0]], method=k[1], obs_group=k[2], mean=v[0], mcse=v[1], n=100) for k, v in cs.items()])
csv_out('primary_ATT_summary.csv', [dict(scenario=k[0], design=CODES[k[0]], method=k[1], obs_group=k[2], mean_RMSE=v[0], mcse_RMSE=v[1], mean_bias=ab[k][0], mcse_bias=ab[k][1], n=100) for k, v in ar.items()])
legend = ('Graph/GeoEco: graph estimators; Cov-SCM: coordinate and PRE economic-covariate balancing; '
          'Uniform: equal donor weights; STI: spatio-temporal PRE imputation followed by SCM; '
          'STD: direct spatio-temporal prediction; -X: economic covariates in the outcome mean model.')

def table_begin(caption, label, cols, placement='!t'):
    return [r'\begin{table}[' + placement + r']\centering',
            r'\caption{' + caption + r'}\label{' + label + '}',
            r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{3pt}',
            r'\begin{tabular}{@{}' + cols + r'@{}}\toprule']

def table_end(note):
    return [r'\bottomrule\end{tabular}',
            r'\begin{tablenotes}[flushleft]\scriptsize\item ' + note,
            r'\end{tablenotes}\end{threeparttable}\end{table}']

def rmse_table(name, group, caption, label, placement):
    lines = table_begin(caption, label, 'l' + 'r' * 8, placement)
    lines += ['DGP & ' + ' & '.join(NAMES[m] for m in METHODS) + r' \\\midrule']
    for scenario in SC:
        values = [r'\shortstack[r]{%.4f\\(%.4f)}' % cs[(scenario, method, group)] for method in METHODS]
        lines.append(CODES[scenario] + ' & ' + ' & '.join(values) + r' \\')
    lines += table_end('Means of replication-specific latent-signal RMSEs on the log scale over 100 replications. Parentheses contain Monte Carlo standard errors; lower is better. All methods evaluate the same target group. ' + legend)
    write(name, lines)

rmse_table('postonly_primary.tex', 'post_only', 'Post-only counterfactual signal RMSE: five primary designs.', 'tab:postonly-primary', '!t')
rmse_table('all_primary.tex', 'ALL', 'All-target counterfactual signal RMSE: five primary designs.', 'tab:all-primary', 'H')

original_pairs = read('paired_CF_differences.csv')
lines = table_begin('Paired post-only signal-RMSE differences for the graph estimators.', 'tab:paired-primary', 'lrrrr')
lines += [r' & \multicolumn{2}{c}{GeoEco $-$ Graph} & \multicolumn{2}{c}{GeoEco $-$ STI-X} \\',
          r'DGP & Difference & 95\% MC interval & Difference & 95\% MC interval \\\midrule']
for scenario in SC:
    values = []
    for right in ['Graph_SCM', 'Gneiting_kriging_EconX_then_SCM']:
        row = next(r for r in original_pairs if r['scenario'] == scenario and r['obs_group'] == 'post_only' and r['right'] == right)
        values += [f"{float(row['mean_diff']):.4f}", f"[{float(row['ci_lo']):.4f}, {float(row['ci_hi']):.4f}]"]
    lines.append(CODES[scenario] + ' & ' + ' & '.join(values) + r' \\')
lines += table_end('Negative differences favor GeoEco. Intervals are unadjusted paired $t_{99}$ Monte Carlo intervals over the same 100 datasets.')
write('paired_primary.tex', lines)

paired = {}
for metric, records, source in [('CF_RMSE_log', cf, 'paired_CF_RMSE.csv'), ('ATT_RMSE_pp', att, 'paired_ATT_RMSE.csv')]:
    lookup = {(r['scenario'], r['method'], r['obs_group'], int(r['seed'])): r for r in records}
    for row in read('covariate_scm/' + source):
        scenario = row['scenario']; group = row['obs_group']; method = row['reference_method']
        seeds = sorted(int(r['seed']) for r in records if r['scenario'] == scenario and r['obs_group'] == group and r['method'] == COV)
        assert len(seeds) == 100 and int(row['n']) == 100
        differences = [float(lookup[(scenario, COV, group, seed)][metric]) - float(lookup[(scenario, method, group, seed)][metric]) for seed in seeds]
        mean = st.mean(differences); se = st.stdev(differences) / math.sqrt(100)
        for field, expected in [('mean_difference', mean), ('MCSE_difference', se), ('lower_95', mean - T99 * se), ('upper_95', mean + T99 * se)]:
            assert abs(float(row[field]) - expected) < 1e-10
        paired[(metric, scenario, group, method)] = (mean, se, mean - T99 * se, mean + T99 * se)

lines = table_begin('Cov-SCM minus GeoEco: paired post-only performance differences.', 'tab:covariate-pairs-primary', 'lrrrr')
lines += [r' & \multicolumn{2}{c}{Signal RMSE (log)} & \multicolumn{2}{c}{ATT RMSE (pp)} \\',
          r'DGP & Difference & 95\% MC interval & Difference & 95\% MC interval \\\midrule']
for scenario in SC:
    values = []
    for metric, digits in [('CF_RMSE_log', 5), ('ATT_RMSE_pp', 3)]:
        mean, se, low, high = paired[(metric, scenario, 'post_only', 'GeoEco_SCM')]
        values += [f'{mean:.{digits}f}', f'[{low:.{digits}f}, {high:.{digits}f}]']
    lines.append(CODES[scenario] + ' & ' + ' & '.join(values) + r' \\')
lines += table_end('Differences are Cov-SCM minus GeoEco, paired by dataset. Negative values favor Cov-SCM. Intervals quantify Monte Carlo uncertainty in mean performance differences. Each design has 100 replications.')
write('covariate_pairs_primary.tex', lines)

for metric, suffix, units, digits in [('CF_RMSE_log', 'cf', 'log', 5), ('ATT_RMSE_pp', 'att', 'pp', 3)]:
    lines = table_begin('Cov-SCM paired comparisons: post-only ' + ('signal RMSE' if suffix == 'cf' else 'ATT RMSE') + '.', 'tab:covariate-pairs-' + suffix, 'llrrr', 'H')
    lines += [r'DGP & Reference & Difference (' + units + r') & MCSE & 95\% MC interval \\\midrule']
    for scenario in SC:
        for method in ['Graph_SCM', 'GeoEco_SCM', 'uniform_weights', 'Gneiting_kriging_EconX_then_SCM']:
            mean, se, low, high = paired[(metric, scenario, 'post_only', method)]
            lines.append(CODES[scenario] + ' & ' + NAMES[method] + f' & {mean:.{digits}f} & {se:.{digits}f} & [{low:.{digits}f}, {high:.{digits}f}]' + r' \\')
    lines += table_end('Cov-SCM minus reference; negative differences favor Cov-SCM. Paired $t_{99}$ Monte Carlo intervals use 100 replications.')
    write('covariate_pairs_' + suffix + '_supp.tex', lines)

def att_table(name, group, label, placement):
    lines = [r'\begin{table}[' + placement + r']\centering',
             r'\caption{ATT recovery: ' + ('post-only targets' if group == 'post_only' else 'all targets') + r', five primary designs.}\label{' + label + '}',
             r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{3pt}']
    for title, methods in [('A. Graph, covariate, and uniform-weight methods', METHODS[:4]), ('B. Spatio-temporal methods', METHODS[4:])]:
        lines += [r'\begin{tabular}{@{}lrrrrrrrr@{}}\toprule',
                  r'\multicolumn{9}{@{}l}{\textit{' + title + r'}}\\',
                  'DGP & ' + ' & '.join(r'\multicolumn{2}{c}{' + NAMES[m] + '}' for m in methods) + r' \\',
                  ' & ' + ' & '.join(['RMSE & Bias'] * 4) + r' \\\midrule']
        for scenario in SC:
            values = []
            for method in methods:
                k = scenario, method, group
                values += [f'{ar[k][0]:.3f}', f'{ab[k][0]:.3f}']
            lines.append(CODES[scenario] + ' & ' + ' & '.join(values) + r' \\')
        lines += [r'\bottomrule\end{tabular}\par\medskip']
    lines += [r'\begin{tablenotes}[flushleft]\scriptsize\item Percentage points, averaged over 100 replication-specific annual errors. ATT is $100\{\exp(\overline\tau_t)-1\}$, the percentage transformation of the mean log effect. Bias is estimated minus true ATT. All methods evaluate the same indicated population. Monte Carlo standard errors are reported in the Online Appendix. ' + legend,
              r'\end{tablenotes}\end{threeparttable}\end{table}']
    write(name, lines)

att_table('att_primary.tex', 'post_only', 'tab:att-primary', '!t')
att_table('att_all_primary.tex', 'ALL', 'tab:att-all-primary', 'H')

lines = table_begin('Cov-SCM performance by observation group in the five primary designs.', 'tab:covariate-groups', 'llrrr', 'H')
lines += [r'DGP & Group & Signal RMSE (log) & ATT RMSE (pp) & ATT bias (pp) \\\midrule']
for scenario in SC:
    for group in GROUPS:
        k = scenario, COV, group
        group_name = {'complete_pre': 'complete PRE', 'partial_pre': 'partial PRE', 'post_only': 'post-only', 'ALL': 'all targets'}[group]
        values = [r'\shortstack[r]{%.4f\\(%.4f)}' % cs[k],
                  r'\shortstack[r]{%.3f\\(%.3f)}' % ar[k],
                  r'\shortstack[r]{%.3f\\(%.3f)}' % ab[k]]
        lines.append(CODES[scenario] + ' & ' + group_name + ' & ' + ' & '.join(values) + r' \\')
lines += table_end('Means over 100 replications; parentheses contain Monte Carlo standard errors. The covariate-fitting rule is identical in all groups and uses no target outcomes. Population sizes are 60 complete-PRE, 36 partial-PRE, 24 post-only, and 120 all-target sites per replication.')
write('covariate_groups.tex', lines)

lines = [r'\begin{table}[H]\centering\caption{ATT RMSE and Monte Carlo standard errors in the primary designs.}\label{tab:att-mcse-primary}',
         r'\begin{threeparttable}\footnotesize\setlength{\tabcolsep}{3pt}']
for group, title in [('post_only', 'A. Post-only targets'), ('ALL', 'B. All targets')]:
    lines += [r'\begin{tabular}{@{}lrrrrrrrr@{}}\toprule', r'\multicolumn{9}{@{}l}{\textit{' + title + r'}}\\',
              'DGP & ' + ' & '.join(NAMES[m] for m in METHODS) + r' \\\midrule']
    for scenario in SC:
        values = [r'\shortstack[r]{%.3f\\(%.3f)}' % ar[(scenario, method, group)] for method in METHODS]
        lines.append(CODES[scenario] + ' & ' + ' & '.join(values) + r' \\')
    lines += [r'\bottomrule\end{tabular}\par\medskip']
lines += [r'\begin{tablenotes}[flushleft]\scriptsize\item Percentage points. Parentheses contain Monte Carlo standard errors across 100 replication-specific annual ATT RMSEs; these are not treatment-effect standard errors. ' + legend,
          r'\end{tablenotes}\end{threeparttable}\end{table}']
write('att_mcse_primary.tex', lines)

audit = dict(primary_designs=CODES, primary_datasets=500, supplementary_datasets=500,
             full_coverage_methods=METHODS, primary_CF_rows=len(cf), primary_ATT_rows=len(att),
             primary_CF_cells=len(cs), replications_per_cell=100,
             covariate_source_rows=2000, covariate_paired_comparisons=len(paired),
             estimation_executed=False, added_results='user-provided completed 500-case Cov-SCM run')
(P / 'data' / 'primary_build_audit.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
print(json.dumps(audit))
