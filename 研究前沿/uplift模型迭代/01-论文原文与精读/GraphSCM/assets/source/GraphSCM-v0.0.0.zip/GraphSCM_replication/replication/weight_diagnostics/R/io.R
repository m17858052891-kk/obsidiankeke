wd_read_csv <- function(path) utils::read.csv(path, check.names = FALSE,
  stringsAsFactors = FALSE, na.strings = c("NA", ""))

wd_weight_csv <- function(path) {
  x <- wd_read_csv(path)
  if (!"point_id" %in% names(x) || ncol(x) < 2L) stop("Weight CSV needs point_id and donor columns.")
  ids <- wd_ids(x$point_id, "CSV target IDs")
  value <- as.matrix(x[, setdiff(names(x), "point_id"), drop = FALSE])
  storage.mode(value) <- "double"; rownames(value) <- ids
  value
}

wd_legacy_mask <- function(result_dir, ids) {
  support <- file.path(result_dir, "postonly_graph_anchor_diagnostics.csv")
  cf_site <- file.path(result_dir, "simulation_counterfactual_recovery_by_site.csv")
  if (file.exists(support)) {
    z <- wd_read_csv(support)
    if (!all(c("point_id", "model_data_identified") %in% names(z))) stop("Invalid support diagnostics.")
    wd_ids(z$point_id, "support target IDs")
    keep <- as.logical(z$model_data_identified)[match(ids, z$point_id)]
    if (anyNA(keep)) stop("Support diagnostics do not cover the weight rows.")
  } else if (file.exists(cf_site)) {
    z <- wd_read_csv(cf_site)
    wd_ids(z$point_id, "CF diagnostic target IDs")
    if (!"post_CF_RMSE_log" %in% names(z)) stop("Missing scientific CF coverage field.")
    pos <- match(ids, z$point_id)
    if (anyNA(pos)) stop("CF diagnostic target IDs disagree.")
    keep <- is.finite(z$post_CF_RMSE_log[pos])
  } else stop("Saved weights/diagnostics lack a scientific support mask; retain the original support or CF-by-site CSV.")
  keep
}

wd_case_metadata <- function(scenario, seed, catalog) {
  row <- catalog[match(scenario, catalog$scenario), , drop = FALSE]
  if (nrow(row) != 1L || is.na(row$scenario)) stop("Unknown scenario: ", scenario)
  rep <- as.integer(seed) - row$seed_base
  if (!is.finite(rep) || rep < 1 || rep > 10000) stop("Seed is outside this design's supported replication range.")
  list(study_id = "publication", paper_id = row$paper_id, scenario = scenario,
    seed = as.integer(seed), rep = as.integer(rep))
}

wd_original_data <- function(obj) {
  if (!all(c("config", "simulation_truth", "target_meta", "target_points", "all_points") %in% names(obj)))
    stop("Unsupported original dataset RDS schema.")
  tr <- obj$simulation_truth
  truth <- as.matrix(tr$W_true)
  tids <- sort(wd_ids(rownames(truth), "original target IDs"))
  dids <- sort(wd_ids(colnames(truth), "original donor IDs"))
  meta_ids <- as.character(obj$target_meta[["point_id"]])
  if (anyDuplicated(meta_ids) || !setequal(meta_ids, tids)) stop("Dataset target metadata IDs disagree.")
  groups <- as.character(obj$target_meta[["obs_group"]])[match(tids, meta_ids)]
  names(groups) <- tids
  fields <- c("X_m", "Y_m", "pre_employment_density_z", "pre_commercial_share_z", "pre_income_z")
  attrs <- function(x, ids) {
    loc <- as.character(x[["point_id"]])
    if (anyDuplicated(loc) || !all(ids %in% loc) || !all(fields %in% names(x)))
      stop("Observed attribute IDs or fields are missing.")
    value <- as.data.frame(setNames(lapply(fields, function(nm) as.numeric(x[[nm]])[match(ids, loc)]), fields))
    rownames(value) <- ids; value
  }
  years <- as.integer(obj$config$years); pre <- as.integer(obj$config$period_pre)
  post <- as.integer(obj$config$period_post)
  locations <- as.character(obj$target_points[["point_id"]])
  if (anyDuplicated(locations) || !all(tids %in% locations)) stop("Observed outcome IDs disagree.")
  cols <- paste0("price_", pre)
  if (!all(cols %in% names(obj$target_points))) stop("Missing observed PRE price columns.")
  observed <- as.matrix(as.data.frame(setNames(lapply(cols, function(nm) {
    value <- as.numeric(obj$target_points[[nm]])[match(tids, locations)]
    if (length(value) != length(tids) || any(!is.na(value) & (!is.finite(value) | value <= 0)))
      stop("Invalid observed PRE price column: ", nm)
    log(value)
  }), as.character(pre)), optional = TRUE))
  rownames(observed) <- tids
  count <- rowSums(is.finite(observed))
  expected <- ifelse(count == 0, "post_only", ifelse(count == length(pre), "complete_pre", "partial_pre"))
  if (!identical(unname(groups), unname(expected))) stop("Observation groups and PRE masks disagree.")
  if (is.null(rownames(tr$control_log)) || is.null(colnames(tr$control_log)) ||
      !all(dids %in% rownames(tr$control_log)) || !all(as.character(pre) %in% colnames(tr$control_log)))
    stop("Donor PRE matrix IDs or years disagree.")
  if (!all(cols %in% names(obj$all_points))) stop("Missing observed donor PRE price columns.")
  all_ids <- as.character(obj$all_points[["point_id"]])
  if (anyDuplicated(all_ids) || !all(dids %in% all_ids)) stop("Observed donor IDs disagree.")
  donor_pre <- as.matrix(as.data.frame(setNames(lapply(cols, function(nm) {
    value <- as.numeric(obj$all_points[[nm]])[match(dids, all_ids)]
    if (any(!is.finite(value) | value <= 0)) stop("Invalid donor PRE prices.")
    log(value)
  }), as.character(pre)), optional = TRUE))
  rownames(donor_pre) <- dids
  if (max(abs(donor_pre - tr$control_log[dids, as.character(pre), drop = FALSE])) > 1e-10)
    stop("Observed donor PRE prices and simulation truth disagree.")
  design <- list(years = years, pre_years = pre, post_years = post,
    donor_pre = donor_pre,
    observed_pre = observed, observation_mask = is.finite(observed),
    target_attributes = attrs(obj$target_meta, tids), donor_attributes = attrs(obj$all_points, dids))
  list(truth = truth[tids, dids, drop = FALSE], groups = groups, design = design,
       scenario = as.character(tr$scenario), seed = as.integer(tr$seed),
       n_pre_periods = length(pre), n_post_periods = length(post))
}

wd_metadata_from_path <- function(case_dir, catalog) {
  scenario <- basename(case_dir)
  seed_text <- basename(dirname(case_dir))
  if (!grepl("^seed_[0-9]+$", seed_text)) stop("Cannot infer seed: use the original seed_<seed>/<scenario> directory structure.")
  wd_case_metadata(scenario, as.integer(sub("^seed_", "", seed_text)), catalog)
}

wd_read_legacy <- function(result_dir, catalog) {
  case_dir <- dirname(result_dir)
  data_file <- file.path(case_dir, "M1_LP_synthetic_dataset.rds")
  data <- if (file.exists(data_file)) wd_original_data(readRDS(data_file)) else NULL
  metadata <- if (!is.null(data)) wd_case_metadata(data$scenario, data$seed, catalog) else
    wd_metadata_from_path(case_dir, catalog)
  if (!is.null(data)) {
    metadata$n_pre_periods <- data$n_pre_periods
    metadata$n_post_periods <- data$n_post_periods
  }
  diagnostic <- file.path(result_dir, "simulation_weight_recovery_by_site.csv")
  diag <- if (file.exists(diagnostic)) wd_read_csv(diagnostic) else NULL
  truth_file <- file.path(case_dir, "truth_weights.csv")
  truth <- if (!is.null(data)) data$truth else if (file.exists(truth_file)) wd_weight_csv(truth_file) else NULL
  if (!is.null(data) && file.exists(truth_file)) {
    other <- wd_align(wd_weight_csv(truth_file), rownames(truth), colnames(truth), "Truth CSV")
    if (max(abs(other - truth)) > 1e-12) stop("Truth CSV and original RDS disagree.")
  }
  groups <- if (!is.null(data)) data$groups else if (!is.null(diag)) {
    wd_ids(diag$point_id, "diagnostic target IDs")
    stats::setNames(as.character(diag$obs_group), diag$point_id)
  } else {
    grouping_file <- file.path(case_dir, "truth_observation_selection_by_site.csv")
    if (!file.exists(grouping_file)) stop("Cannot determine observation groups.")
    z <- wd_read_csv(grouping_file)
    wd_ids(z$point_id, "selection target IDs")
    if (!"obs_group" %in% names(z)) stop("Selection CSV lacks obs_group.")
    stats::setNames(as.character(z$obs_group), z$point_id)
  }
  weight_file <- file.path(result_dir, "joint_scm_weights.csv")
  if (!is.null(truth) && file.exists(weight_file)) {
    estimates <- list(GeoEco_SCM = wd_weight_csv(weight_file))
    # Respect the scientific prediction mask, not a solver's numerical continuation.
    keep <- wd_legacy_mask(result_dir, rownames(estimates[[1]]))
    estimates[[1]][!keep, ] <- NA_real_
    estimates$uniform_weights <- matrix(1 / ncol(truth), nrow(truth), ncol(truth), dimnames = dimnames(truth))
    case <- wd_case(metadata, truth, groups, estimates, if (is.null(data)) list() else data$design)
    return(list(sites = wd_evaluate(case), kind = "legacy_weights", methods = names(estimates)))
  }
  if (is.null(diag)) stop("No recoverable weights or weight diagnostic CSV.")
  needed <- c("point_id", "obs_group", "weight_RMSE", "weight_L1", "weight_cosine")
  if (!all(needed %in% names(diag)) || anyNA(diag[needed]) ||
      any(!is.finite(as.matrix(diag[c("weight_RMSE", "weight_L1", "weight_cosine")]))))
    stop("Invalid legacy weight diagnostics.")
  if (any(!diag$obs_group %in% c("complete_pre", "partial_pre", "post_only")) ||
      any(diag$weight_RMSE < 0) || any(diag$weight_L1 < 0)) stop("Invalid diagnostic values.")
  keep <- wd_legacy_mask(result_dir, as.character(diag$point_id))
  diag[!keep, c("weight_RMSE", "weight_L1", "weight_cosine")] <- NA_real_
  # Diagnostic-only rows cannot establish matching data versions across methods.
  sites <- data.frame(study_id = metadata$study_id, scenario = metadata$scenario,
    design = metadata$paper_id, rep = metadata$rep, seed = metadata$seed,
    n_target = nrow(diag), n_donor = if (!is.null(truth)) ncol(truth) else NA_integer_,
    n_pre_periods = if (!is.null(data)) data$n_pre_periods else NA_integer_,
    n_post_periods = if (!is.null(data)) data$n_post_periods else NA_integer_,
    method = "GeoEco_SCM", point_id = as.character(diag$point_id), obs_group = diag$obs_group,
    evaluated = keep, weight_RMSE = diag$weight_RMSE, weight_L1 = diag$weight_L1,
    weight_cosine = diag$weight_cosine, effective_donors = NA_real_, max_weight = NA_real_,
    data_signature = "", fixed_design_signature = "", input_kind = "legacy_diagnostic_only",
    stringsAsFactors = FALSE)
  list(sites = sites, kind = "legacy_diagnostic_only", methods = "GeoEco_SCM")
}

wd_export_environment <- function(env, catalog, destination) {
  get_local <- function(name) if (exists(name, envir = env, inherits = FALSE)) get(name, envir = env) else NULL
  obj <- get_local("dataset")
  if (is.null(obj)) stop("The estimator environment has no original dataset.")
  data <- wd_original_data(obj)
  metadata <- wd_case_metadata(data$scenario, data$seed, catalog)
  metadata$n_pre_periods <- data$n_pre_periods; metadata$n_post_periods <- data$n_post_periods
  original_tids <- as.character(get_local("target_meta")[["point_id"]])
  original_dids <- as.character(get_local("control_df")[["point_id"]])
  if (!setequal(original_tids, rownames(data$truth)) || !setequal(original_dids, colnames(data$truth)))
    stop("Live estimator IDs and original truth differ.")
  post <- as.integer(get_local("post_pos_truth"))
  if (!length(post)) stop("Missing scientific POST evaluation indices.")
  add_method <- function(w, predictions, label) {
    if (is.null(w) || is.null(predictions)) return(NULL)
    w <- as.matrix(w); predictions <- as.matrix(predictions)
    if (!identical(dim(w), c(length(original_tids), length(original_dids))) ||
        nrow(predictions) != nrow(w) || max(post) > ncol(predictions)) stop("Live dimensions disagree: ", label)
    if (!is.null(rownames(w)) && !identical(rownames(w), original_tids)) stop("Live weight target order differs: ", label)
    if (!is.null(colnames(w)) && !identical(colnames(w), original_dids)) stop("Live weight donor order differs: ", label)
    dimnames(w) <- list(original_tids, original_dids)
    keep <- rowSums(is.finite(predictions[, post, drop = FALSE])) == length(post)
    w[!keep, ] <- NA_real_; w
  }
  geo <- get_local("geo_only_fit"); ordinary <- get_local("fit_lambda0")
  estimates <- list(GeoEco_SCM = add_method(get_local("W_hat"), get_local("Y0_raw"), "GeoEco_SCM"),
    Graph_SCM = add_method(if (is.null(geo)) NULL else geo$W, get_local("Y0_geo_only"), "Graph_SCM"),
    Ordinary_SCM = add_method(if (is.null(ordinary)) NULL else ordinary$W, get_local("Y0_lambda0"), "Ordinary_SCM"))
  available <- !vapply(estimates, is.null, logical(1))
  audit <- data.frame(method = names(estimates), exported = available,
    status = ifelse(available, "available", "fit_or_scientific_predictions_missing"))
  estimates <- estimates[available]
  estimates$uniform_weights <- matrix(1 / ncol(data$truth), nrow(data$truth), ncol(data$truth), dimnames = dimnames(data$truth))
  metadata$lambda <- get_local("best_lambda")
  metadata$beta <- get_local("best_beta")
  if (is.null(metadata$beta)) metadata$beta <- get_local("best_beta_econ")
  case <- wd_case(metadata, data$truth, data$groups, estimates, data$design)
  dir.create(destination, recursive = TRUE, showWarnings = FALSE)
  path <- file.path(destination, "weight_assessment.rds")
  if (file.exists(path) && !identical(readRDS(path), case))
    stop("Existing weight snapshot differs; use a fresh output root rather than overwrite it.")
  if (!file.exists(path)) {
    temporary <- tempfile("weight_assessment_", tmpdir = destination, fileext = ".rds")
    on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
    saveRDS(case, temporary, version = 2)
    if (!file.rename(temporary, path)) stop("Cannot commit weight snapshot.")
  }
  utils::write.csv(wd_evaluate(case), file.path(destination, "weight_assessment_by_site.csv"), row.names = FALSE, na = "")
  utils::write.csv(audit, file.path(destination, "weight_method_export_audit.csv"), row.names = FALSE)
  invisible(path)
}
