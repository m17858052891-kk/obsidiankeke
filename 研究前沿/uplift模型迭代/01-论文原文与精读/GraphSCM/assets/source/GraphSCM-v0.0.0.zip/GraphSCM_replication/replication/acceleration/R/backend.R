# Optional Rcpp execution of the original FISTA loop. Source backends stay frozen.
scm_acceleration_root <- function() {
  locations <- unlist(lapply(sys.frames(), function(frame)
    if (exists("ofile", envir=frame, inherits=FALSE)) get("ofile", envir=frame) else NULL), use.names=FALSE)
  own <- tail(locations[basename(locations)=="backend.R"],1L)
  if (length(own)!=1L) stop("Source acceleration/R/backend.R from its saved file.")
  dirname(dirname(normalizePath(own,winslash="/",mustWork=TRUE)))
}
SCM_ACCELERATION_ROOT <- scm_acceleration_root()

scm_load_rcpp <- local({
  compiled <- NULL
  function(cache_dir=Sys.getenv("GRAPHSCM_RCPP_CACHE", unset=tools::R_user_dir("GraphSCM","cache"))) {
    if (!is.null(compiled)) return(compiled)
    if (!requireNamespace("Rcpp",quietly=TRUE))
      stop("Rcpp is required for engine=Rcpp. Install it with install.packages('Rcpp'); see acceleration/README_JP.md.")
    dir.create(cache_dir,recursive=TRUE,showWarnings=FALSE)
    if (!dir.exists(cache_dir)) stop("Cannot create Rcpp compilation cache: ",cache_dir)
    target <- new.env(parent=globalenv())
    Rcpp::registerPlugin("graphscm_blas",function(...) list(env=list(
      PKG_LIBS=paste(Sys.getenv("PKG_LIBS"),"$(BLAS_LIBS) $(FLIBS)"))))
    Rcpp::sourceCpp(file.path(SCM_ACCELERATION_ROOT,"src/fista.cpp"),env=target,
      cacheDir=cache_dir,rebuild=FALSE,showOutput=FALSE,verbose=FALSE)
    stopifnot(is.function(target$scm_fista_cpp),is.function(target$scm_project_rows_cpp))
    compiled <<- target
    compiled
  }
})

scm_sparse_payload <- function(value) {
  # Matrix::crossprod may return symmetric storage containing only one triangle.
  # Expand that representation before handing its CSC entries to C++.
  value <- methods::as(methods::as(Matrix::Matrix(value,sparse=TRUE),"generalMatrix"),"CsparseMatrix")
  list(nrow=nrow(value),ncol=ncol(value),p=value@p,i=value@i,x=as.numeric(value@x))
}

scm_is_assignment <- function(expr,name) is.call(expr) &&
  identical(expr[[1L]],as.name("<-")) && identical(expr[[2L]],as.name(name))

scm_accelerate_function <- function(original,native=scm_load_rcpp()) {
  if (!is.function(original)) stop("Expected the original FISTA function.")
  statements <- as.list(body(original))[-1L]
  loop <- which(vapply(statements,function(x) is.call(x) &&
    identical(x[[1L]],as.name("for")) && identical(x[[2L]],as.name("iter")),logical(1)))
  mapping <- which(vapply(statements,function(x) scm_is_assignment(x,"grad_final") ||
    scm_is_assignment(x,"W_pg") || scm_is_assignment(x,"pg_norm"),logical(1)))
  if (length(loop)!=1L || length(mapping)!=3L || any(mapping<loop))
    stop("The original FISTA structure changed; refusing an unchecked replacement.")
  required <- c("step","Lg","sum_a","Yobs","mask","last_obj","last_check_pred")
  for (name in required)
    if (!any(vapply(statements,function(x) scm_is_assignment(x,name),logical(1))))
      stop("Missing original FISTA binding: ",name)
  injected <- parse(text=paste(
    ".scm_cpp_result <- .scm_native_kernel(Yobs, mask, Yc_train,",
    " .scm_sparse_payload(Lg), .scm_sparse_payload(graph_obj$Dg),",
    " sum_a, lambda, rho + NUMERICAL_RIDGE, step, W, as.integer(max_iter), tol,",
    " as.integer(min_iter), as.integer(FISTA_CHECK_EVERY), verbose || FISTA_VERBOSE,",
    " as.integer(progress_every), as.character(fit_label))",
    "W <- .scm_cpp_result$W", "last_obj <- .scm_cpp_result$last_obj",
    "iter_used <- .scm_cpp_result$iterations", "converged <- .scm_cpp_result$converged",
    "rel_change <- .scm_cpp_result$rel_change", "obj_rel_change <- .scm_cpp_result$obj_rel_change",
    "pred_rel_change <- .scm_cpp_result$pred_rel_change", "pg_norm <- .scm_cpp_result$pg_norm",
    sep="\n"))
  replacement <- list()
  for (i in seq_along(statements)) {
    if (i==loop) replacement <- c(replacement,as.list(injected))
    else if (!i %in% mapping) replacement[[length(replacement)+1L]] <- statements[[i]]
  }
  result <- original
  body(result) <- as.call(c(list(as.name("{")),replacement))
  # Add private helpers through a child environment; data bindings remain visible
  # in the original estimator environment, including counters used with <<-.
  helpers <- new.env(parent=environment(original))
  helpers$.scm_native_kernel <- native$scm_fista_cpp
  helpers$.scm_sparse_payload <- scm_sparse_payload
  environment(result) <- helpers
  result
}

scm_source_estimator <- function(file,envir,engine="R") {
  if (!engine %in% c("R","Rcpp")) stop("Choose engine=R or Rcpp.")
  if (engine=="R") return(source(file,local=envir))
  native <- scm_load_rcpp()  # Fail before starting the costly estimator if compilation fails.
  expressions <- parse(file,keep.source=TRUE)
  installed <- 0L
  for (expr in expressions) {
    eval(expr,envir=envir)
    if (scm_is_assignment(expr,"fit_smooth_scm")) {
      envir$fit_smooth_scm_R <- envir$fit_smooth_scm
      envir$fit_smooth_scm <- scm_accelerate_function(envir$fit_smooth_scm,native)
      installed <- installed+1L
      envir$GRAPHSCM_FISTA_ENGINE <- "Rcpp"
    }
  }
  if (installed!=1L) stop("Expected exactly one original FISTA definition.")
  invisible(envir)
}

# Extract only numerical functions for independent tests and saved-data benchmarks.
# Replace the timing-log constructor with base data.frame; no fit expression changes.
scm_reference_environment <- function(project_root) {
  file <- file.path(project_root,"replication/original/internal/estimator_legacy8_final.R")
  env <- new.env(parent=globalenv())
  wanted <- c("calc_losses_from_W","project_simplex_vec","project_rows_simplex","fit_smooth_scm")
  for (expr in parse(file,keep.source=FALSE)) {
    if (any(vapply(wanted,function(name) scm_is_assignment(expr,name),logical(1)))) eval(expr,env)
  }
  b <- as.list(body(env$fit_smooth_scm))
  log_index <- which(vapply(b,function(x) is.call(x) && identical(x[[1L]],as.name("<<-")) &&
    is.call(x[[3L]]) && identical(x[[3L]][[1L]],quote(tibble::tibble)),logical(1)))
  if (length(log_index)!=1L) stop("Expected one timing-log constructor.")
  b[[log_index]][[3L]][[1L]] <- as.name("data.frame")
  body(env$fit_smooth_scm) <- as.call(b)
  env$NUMERICAL_RIDGE <- 1e-10
  env$FISTA_MAX_ITER_CV <- 1500L; env$FISTA_TOL_CV <- 2e-5; env$FISTA_MIN_ITER_CV <- 100L
  env$FISTA_CHECK_EVERY <- 25L; env$FISTA_PROGRESS_EVERY <- 100L; env$FISTA_VERBOSE <- FALSE
  env$runtime_fit_log <- list(); env$runtime_fit_counter <- 0L
  env
}
