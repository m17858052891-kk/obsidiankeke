# Replication entry point

Start with [English instructions](../README_R.md).
Use `Rscript --vanilla replication/run.R --task=check` from the top-level project directory.
The paper IDs and fixed seed bases are in `design_catalog.csv`.
