@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_windows.ps1" -Mode full
set "COV_EXIT=%ERRORLEVEL%"
pause
exit /b %COV_EXIT%
