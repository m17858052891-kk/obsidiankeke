# Small integration checks only: no full 20-replication Monte Carlo run.
args <- grep("^--file=", commandArgs(FALSE), value = TRUE)
root <- normalizePath(file.path(dirname(sub("^--file=", "", args[1])), ".."))
source(file.path(root, "run_covariate_scm.R"))
stopifnot(identical(cov_replication_label(1:100),"1to100"),
          nchar(cov_replication_label(seq(1L,9999L,by=2L)))<100L)
check_pipeline <- function() {
  scratch <- tempfile("covariate_integration_")
  dir.create(scratch)
  scratch <- normalizePath(scratch, winslash = "/", mustWork = TRUE)
  temporary_root <- paste0(normalizePath(tempdir(), winslash = "/", mustWork = TRUE), "/")
  stopifnot(startsWith(paste0(scratch, "/"), temporary_root))
  on.exit(unlink(scratch, recursive = TRUE), add = TRUE)
  # Run the exact default five-DGP entry point, then resume the same cases.
  first <- run_covariate_benchmark(mode = "test", output_root = scratch)
  markers <- list.files(scratch, "^completed[.]rds$", recursive = TRUE, full.names = TRUE)
  hashes <- tools::md5sum(markers)
  second <- run_covariate_benchmark(mode = "test", output_root = scratch)
  stopifnot(identical(first$summary_dir, second$summary_dir),
            identical(hashes, tools::md5sum(markers)), length(markers) == 5L,
            nrow(first$cf) == 20L, nrow(first$att) == 20L,
            all(first$cf$n_sites == first$cf$n_eval_sites))
  paired <- read.csv(file.path(first$summary_dir, "paired_CF_RMSE.csv"))
  stopifnot(nrow(paired) == 5L * 4L * 7L, all(paired$n == 1L),
            all(is.na(paired$MCSE_difference)), all(is.na(paired$lower_95)))
  # Two-replication subset must produce finite MCSEs and t intervals.
  subset <- run_covariate_benchmark(mode = "test", scenarios = "D1", reps = 1:2,
                                    output_root = scratch)
  pair_two <- read.csv(file.path(subset$summary_dir, "paired_ATT_RMSE.csv"))
  stopifnot(all(pair_two$n == 2L), all(is.finite(pair_two$MCSE_difference)),
            all(pair_two$lower_95 <= pair_two$mean_difference),
            all(pair_two$upper_95 >= pair_two$mean_difference))
  # Coverage of the last published seed for all eight supported scenarios.
  cf <- read.csv(file.path(root, "reference", "counterfactual_replications.csv"))
  att <- read.csv(file.path(root, "reference", "ATT_replications.csv"))
  generator <- file.path(root, "vendor", "generator_legacy8.R")
  for (i in seq_len(nrow(cov_catalog))) {
    scenario <- cov_catalog$scenario[i]
    seed <- as.integer(cov_catalog$seed_base[i] + 100)
    dat <- cov_generate(generator, scenario, seed)
    audit <- cov_archive_check(dat, cf, att, scenario, seed)
    stopifnot(all(audit$max_abs_difference <= audit$tolerance))
    features <- cov_features()
    fit <- fit_covariate_scm(as.matrix(dat$target[, features]),
                            as.matrix(dat$donor[, features]))
    stopifnot(max(fit$diagnostics$duality_gap) <= 1e-13)
    cat("PASS: ", cov_catalog$code[i], " rep 100, archive and solver.\n", sep = "")
  }
  # Optional attribute specifications have their own output directories.
  econ <- run_covariate_benchmark(scenarios = "D1", feature_set = "econ",
                                  output_root = scratch)
  geo <- run_covariate_benchmark(scenarios = "D1", feature_set = "geo",
                                 output_root = scratch)
  stopifnot(econ$summary_dir != geo$summary_dir,
            all(econ$cf$method == "Covariate_SCM_econ"),
            all(geo$cf$method == "Covariate_SCM_geo"))
  cat("PASS: integration, resumption, output populations, paired intervals, D1-D8 coverage, optional features.\n")
}
check_pipeline()
