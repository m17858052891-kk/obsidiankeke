# Optional Rcpp FISTA engine

This extension executes the original FISTA iterations in C++. It retains the original objective, input preprocessing, graph construction, tuning candidates, adaptive restart, stopping criteria, diagnostics and final OSQP estimator. The default engine remains `R`; select `Rcpp` explicitly. The five frozen numeric backend files are unchanged.

## Start with a small benchmark

Install `Rcpp` in your R library. Windows also requires [Rtools](https://cran.r-project.org/bin/windows/Rtools/) compatible with your R installation. RcppArmadillo is not required. Compilation happens on first use and is cached in the user cache directory; `GRAPHSCM_RCPP_CACHE` overrides that path.

From the extracted archive root, in RStudio:

```r
install.packages("Rcpp")
source("replication/run_from_RStudio.R")
run_replication("benchmark", designs="D1", reps="1")
```

This needs only Rcpp and Matrix. It regenerates the original numerical DGP and checks Uniform CF/ATT alignment with the archive. It then compares the R and C++ engines on the same representative temporal and pseudo-post-only PRE-validation problems. Results are written to `replication/output/acceleration_benchmark/`. Read `speed_summary.csv`, `fit_comparisons.csv` and `candidate_choices.csv`.

Each timing cell uses three repeats, alternating engine order. Compilation and data generation are excluded. The candidate set and masks are deliberately small; this does **not** time or validate the complete adaptive CV search, final OSQP fit, spatio-temporal benchmarks or end-to-end Monte Carlo. D1–D8 can be regenerated; D9–D10 require `input_root` pointing to original saved datasets.

## Use the accelerated engine for estimation

Full estimation still needs the original dependencies listed in the main README. Start with one case:

```r
run_replication("full", engine="Rcpp", designs="D1", reps="1",
  output_root="D:/GraphSCM_fast_check")
```

Results go to `D:/GraphSCM_fast_check/full_Rcpp/`. The corresponding `engine="R"` run uses `full/`, so the two do not share completion markers. `fista_execution_engine.txt` records the engine. A requested Rcpp engine fails on missing dependencies or compilation errors instead of silently reverting to R. Completed cases remain resumable. Compare selected parameters and final predictions on your first full run; floating-point differences can affect numerical decisions.

The low-level launchers retain a 20-index compatibility default; the published study uses the 100-case workflow in the top-level README. Explicit additional repetitions are supported for the original graph/spatio-temporal workflow:

```r
run_replication("full", engine="Rcpp", designs="primary", reps="1:100",
  dry_run=TRUE, output_root="D:/GraphSCM_100rep")
```

After inspecting the plan, remove `dry_run=TRUE` to execute it. Primary means five DGPs, so 100 repetitions mean 500 cases. The seed rule is extended without changing the first 20 seeds. `collect` scans completed repetitions instead of truncating at 20. Pass `reps="1:100"` when assessing their saved weights. Published `summary` now reads all 100 repetitions per design. Release 1.4.2 adds explicit Cov-SCM repetitions using `input_root` pointing to the completed `full_Rcpp` directory; run that comparator separately with `task="covariate"`. See the top-level README for the combined workflow.

CLI equivalents:

```sh
Rscript --vanilla replication/run.R --task=benchmark --designs=D1 --reps=1
Rscript --vanilla replication/run.R --task=full --engine=Rcpp --designs=D1 --reps=1
Rscript --vanilla replication/run.R --task=full --engine=Rcpp --designs=primary --reps=1:100 --dry-run
```

## Validation and scope

Release 1.4.1 fixes a runner error that demanded a completion marker the frozen estimator never writes. The runner now validates final outputs, scenario/seed, simplex weights and CF errors reconstructed from saved weights before atomically committing completion. Relative output roots are anchored before generators change working directory. Numerical estimation is unchanged.

A full D1/rep1 Rcpp case completed normally with all-method weight export, and completed-case resumption was checked. The previously finished case and the verified rerun had identical input arrays, selected parameters and main-weight CSVs, with zero CF/ATT metric differences. See `validation/completion_integration.csv`.

The included benchmark used D1 and D3, one dataset each, with 16 representative problems and three timing repeats per cell. Sums of cell medians were 53.16 seconds for R and 1.12 seconds for C++, a factor of 47.5 for these FISTA solves. Maximum weight and PRE-prediction differences were about 4e-13; iteration counts and choices from the small candidate set matched. This is not an end-to-end Monte Carlo speedup estimate.

Run `Rscript --vanilla replication/acceleration/tests/run_tests.R`. Tests cover projection, graph storage, missing histories, warm starts, convergence/nonconvergence, diagnostics, immutable inputs and installation of the source hook. The independent R reference retains all numerical expressions; only its timing-log constructor uses base `data.frame` instead of `tibble`.

Validation results are in `validation/`. Speed measurements concern the tested FISTA problems and hardware, not full-study speed. Matrix products use R's BLAS. The accelerated loop is installed in a separate execution environment when the original function is defined; source files and final OSQP code remain unchanged. No full 200-case refit, parallel-execution extension or change to reported manuscript results is included.
