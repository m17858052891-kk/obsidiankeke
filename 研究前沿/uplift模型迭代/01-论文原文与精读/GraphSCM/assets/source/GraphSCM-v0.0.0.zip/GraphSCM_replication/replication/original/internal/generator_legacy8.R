# =============================================================================
# M1_LP - Proposal DGP: Graph-SCM / GeoEco-SCM
# =============================================================================
# Purpose:
#   Create a small, fully known data-generating process (DGP) that mimics the
#   structure of the real M1_LP dataset but is fast enough for repeated testing.
#
#   The untreated treatment-site outcome is generated EXACTLY from a convex
#   combination of control outcomes:
#       Y0_it = sum_j w_true_ij * Yc_jt
#   with true weights w_true_i generated from TARGET latent market exposure.
#   v14 switches economic distance OFF/ON across the two main scenarios while
#   keeping donor physical nearness out of the true weight score.
#   A known post-2005 treatment effect is then added.
#
#   Three observation groups are created:
#       complete_pre : all 1994-2004 outcomes observed
#       partial_pre  : only 4-8 pre years observed
#       post_only    : no pre outcomes observed
#
#   Because W_true, Y0 and tau are saved, 02 can be evaluated against truth.
# =============================================================================

DGP_SCRIPT_START <- Sys.time()

# ---- 0. Packages -------------------------------------------------------------
if (!requireNamespace("pacman", quietly = TRUE)) install.packages("pacman")
pacman::p_load(sf, tidyverse, Matrix, scales)

# ---- 1. User settings --------------------------------------------------------
WORK_DIR <- Sys.getenv(
  "M1_LP_WORK_DIR",
  unset = getwd()
)
setwd(WORK_DIR)

# Scenario can be overridden before source() with
#   Sys.setenv(SIM_SCENARIO = "smooth_geo_econ")
# v14 makes the central scientific contrast explicit:
#   smooth_geo_only : untreated outcomes/SCM representations are smooth in geography only
#   smooth_geo_econ : an additional partly non-spatial economic dimension is required
# The remaining scenarios are robustness / failure-mode checks.
SCENARIO <- Sys.getenv("SIM_SCENARIO", unset = "smooth_geo_econ")
VALID_SCENARIOS <- c(
  "smooth_geo_only",
  "smooth_geo_econ",
  "station_selected_geo_only",
  "station_selected_geo_econ",
  "smooth_geo_econ_latent_factor",
  "no_spatial",
  "spatially_separated_donors",
  "boundary"
)
if (!SCENARIO %in% VALID_SCENARIOS) {
  stop("SCENARIO must be one of: ", paste(VALID_SCENARIOS, collapse = ", "))
}

# Seed can also be overridden for later Monte Carlo experiments.
SEED <- as.integer(Sys.getenv("SIM_SEED", unset = "20260916"))
set.seed(SEED)

# Keep each scenario in a separate directory so results are never overwritten.
SIM_OUTPUT_ROOT <- Sys.getenv(
  "SIM_OUTPUT_ROOT",
  unset = file.path("output", "simulation_graph_geoeco")
)
OUTPUT_DIR <- file.path(SIM_OUTPUT_ROOT, SCENARIO)
dir.create(OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)

YEARS <- 1994:2015
PERIOD_PRE <- 1994:2004
PERIOD_POST <- 2005:2015

# Intentionally small: this should run much faster than the real dataset.
N_CONTROL <- as.integer(Sys.getenv("SIM_N_CONTROL", unset = "24"))
N_TARGET <- as.integer(Sys.getenv("SIM_N_TARGET", unset = "120"))

# Observation-pattern shares among treatment targets.
PROP_COMPLETE <- as.numeric(Sys.getenv("SIM_PROP_COMPLETE", unset = "0.50"))
PROP_PARTIAL <- as.numeric(Sys.getenv("SIM_PROP_PARTIAL", unset = "0.30"))
# Remaining 20% become post_only.

# Observation-process axis for the two station-selected scenarios.  The latent
# outcome process is held fixed relative to the matching random-entry scenario;
# only the assignment of PRE histories changes.  Post-only sites are sampled
# with fixed count but higher probability when they are (i) close to the new
# station and (ii) relatively low-priced before opening.  Because the treatment
# effect is already larger near the new station, this creates the empirically
# relevant selection problem: newly observed post-opening sites tend to have
# lower latent PRE prices and larger treatment effects.
OBSERVATION_SELECTION_MODE <- if (SCENARIO %in% c(
  "station_selected_geo_only", "station_selected_geo_econ"
)) "station_selected" else "random"
STATION_SELECTION_NEAR_SCALE_M <- 3000
STATION_SELECTION_NEAR_COEF <- 1.00
STATION_SELECTION_LOW_PRICE_COEF <- 0.90
STATION_SELECTION_INTERACTION_COEF <- 0.50
STATION_SELECTION_TEMPERATURE <- 1.00

# DGP controls.
TARGET_NOISE_SD <- 0.008       # log-price observation noise (~0.8%)

# The smooth/boundary scenarios deliberately use fairly concentrated true
# weights, but IMPORTANTLY they do NOT make a target prefer geographically
# nearby donors.  Instead, each target has a smoothly varying latent market
# exposure and donors form a common dictionary of market archetypes.  Nearby
# TARGETS therefore have similar donor representations, which is the actual
# identifying assumption of graph-SCM.  Donor physical location is not used in
# the smooth-weight score.
WEIGHT_LATENT_SCALE <- 0.60
WEIGHT_ACCESS_SCALE <- 0.80
WEIGHT_ACCESS_IMPORTANCE <- 0.60
BOUNDARY_BONUS <- 2.50         # used only in SCENARIO="boundary"

# Economic-distance signal used in the main geo+econ DGP.  Only a small share
# of the latent economic variation is spatially predictable.  This is deliberate:
# a spatial-only method should work in smooth_geo_only, but should be unable to
# reconstruct the full latent market state in smooth_geo_econ from coordinates
# alone.  Observed PRE economic variables are noisy proxies for this latent state.
ECON_MARKET_STRENGTH <- 0.65
ECON_SPATIAL_SHARE <- 0.20

# smooth_geo_econ_latent_factor:
# Keep the SAME geo+econ true SCM-weight field as smooth_geo_econ, but let donor
# outcomes load on several latent temporal factors with different dynamics.
# Loadings combine a genuinely spatial component with nonlinear market/economic
# components and donor-specific heterogeneity.  The target counterfactual remains
# an exact stable donor mixture, but a stationary lag-based space-time covariance
# is no longer the natural representation.  This is the proposal-positive-control
# DGP; it is intentionally not pure white noise, so flexible kriging retains some
# usable spatial signal.
LATENT_FACTOR_SCALE <- 0.060
LATENT_FACTOR_SPATIAL_SHARE <- 0.35
LATENT_FACTOR_IDIO_SD <- 0.25
LATENT_FACTOR_ECON_BASIS_BW <- 0.70
LATENT_FACTOR_AR1_PHI <- 0.88
LATENT_FACTOR_AR2_PHI <- 0.25
LATENT_FACTOR_SHOCK_YEAR <- 2001L

# spatially_separated_donors: targets occupy an inner disk while donor controls
# occupy an outer annulus, leaving a buffer with no estimation sites.  The true
# weight field remains the same geo+econ smooth representation as in
# smooth_geo_econ.  Hence this scenario isolates donor-pool spatial separation
# / outcome extrapolation from a failure of the Graph/GeoEco weight assumption.
SPATIAL_SUPPORT_CENTER <- c(10000, 10000)
SPATIAL_TARGET_RADIUS_M <- 5000
SPATIAL_BUFFER_OUTER_RADIUS_M <- 7000
SPATIAL_CONTROL_OUTER_RADIUS_M <- 13000
SPATIAL_BOX_MIN_M <- 500
SPATIAL_BOX_MAX_M <- 19500

# no_spatial: independent concentrated weights unrelated to target geography.
NO_SPATIAL_DIRICHLET_SHAPE <- 0.20

# Explicit common market factor.  Ordinary scenarios contain a shared temporal
# component with donor-specific loadings; the negative-control scenario keeps
# only a small fraction of it.  This makes the label ``weak common factor``
# literal rather than merely relying on shared sinusoidal frequencies.
COMMON_FACTOR_SCALE <- 1.00
COMMON_FACTOR_AR_PHI <- 0.70
COMMON_FACTOR_AR_SD <- 0.004

# Observed PRE economic characteristics.  They are noisy proxies for latent
# market exposure and are safe to use in the graph because they are generated
# before treatment.  The graph never uses the latent truth directly.
ECON_PROXY_NOISE_SD <- 0.18

# ---- 2. Helper functions -----------------------------------------------------
min_dist_to_points <- function(xy, pts) {
  apply(xy, 1, function(z) {
    min(sqrt((z[1] - pts[, 1])^2 + (z[2] - pts[, 2])^2))
  })
}

softmax_stable <- function(z) {
  zz <- z - max(z)
  ez <- exp(zz)
  ez / sum(ez)
}

make_ar1 <- function(n, phi = 0.55, sd = 0.008) {
  e <- rnorm(n, 0, sd)
  out <- numeric(n)
  out[1] <- e[1]
  if (n >= 2) {
    for (tt in 2:n) out[tt] <- phi * out[tt - 1] + e[tt]
  }
  out
}

zscore_vec <- function(x) {
  sx <- stats::sd(x)
  if (!is.finite(sx) || sx <= 0) return(x - mean(x))
  (x - mean(x)) / sx
}

sample_uniform_disk <- function(n, center, radius) {
  theta <- runif(n, 0, 2 * pi)
  rr <- radius * sqrt(runif(n))
  cbind(
    X_m = center[1] + rr * cos(theta),
    Y_m = center[2] + rr * sin(theta)
  )
}

sample_uniform_annulus_in_box <- function(n, center, r_min, r_max, box_min, box_max) {
  out <- matrix(NA_real_, nrow = n, ncol = 2,
                dimnames = list(NULL, c("X_m", "Y_m")))
  filled <- 0L
  while (filled < n) {
    batch_n <- max(200L, 8L * (n - filled))
    cand <- cbind(
      X_m = runif(batch_n, box_min, box_max),
      Y_m = runif(batch_n, box_min, box_max)
    )
    rr <- sqrt((cand[, 1] - center[1])^2 + (cand[, 2] - center[2])^2)
    ok <- which(rr >= r_min & rr <= r_max)
    if (!length(ok)) next
    take_n <- min(length(ok), n - filled)
    out[(filled + 1L):(filled + take_n), ] <- cand[ok[seq_len(take_n)], , drop = FALSE]
    filled <- filled + take_n
  }
  out
}

# ---- 3. Synthetic geography -------------------------------------------------
# 20 km x 20 km rectangular market.  Main scenarios use overlapping spatial
# support.  The spatially_separated_donors stress scenario instead places
# targets inside a 5-km disk and controls outside a 7-km buffer.
if (SCENARIO == "spatially_separated_donors") {
  target_xy <- sample_uniform_disk(
    N_TARGET, SPATIAL_SUPPORT_CENTER, SPATIAL_TARGET_RADIUS_M
  )
  control_xy <- sample_uniform_annulus_in_box(
    N_CONTROL, SPATIAL_SUPPORT_CENTER,
    SPATIAL_BUFFER_OUTER_RADIUS_M, SPATIAL_CONTROL_OUTER_RADIUS_M,
    SPATIAL_BOX_MIN_M, SPATIAL_BOX_MAX_M
  )
} else {
  control_xy <- cbind(
    X_m = runif(N_CONTROL, 500, 19500),
    Y_m = runif(N_CONTROL, 500, 19500)
  )
  target_xy <- cbind(
    X_m = runif(N_TARGET, 500, 19500),
    Y_m = runif(N_TARGET, 500, 19500)
  )
}

spatial_center_distance_control <- sqrt(
  (control_xy[, 1] - SPATIAL_SUPPORT_CENTER[1])^2 +
    (control_xy[, 2] - SPATIAL_SUPPORT_CENTER[2])^2
)
spatial_center_distance_target <- sqrt(
  (target_xy[, 1] - SPATIAL_SUPPORT_CENTER[1])^2 +
    (target_xy[, 2] - SPATIAL_SUPPORT_CENTER[2])^2
)

# Two stations already available before treatment. This is a PRE-treatment
# accessibility measure and is therefore safe for graph construction.
pre_stations <- rbind(
  c(4500, 5500),
  c(15500, 14000)
)

# One synthetic "new" station whose opening in 2005 creates the treatment
# effect. Distance to this station affects tau but is NOT needed by the SCM.
new_station <- matrix(c(10500, 9500), nrow = 1)

control_pre_station_dist <- min_dist_to_points(control_xy, pre_stations)
target_pre_station_dist <- min_dist_to_points(target_xy, pre_stations)
target_new_station_dist <- min_dist_to_points(target_xy, new_station)

control_ids <- sprintf("C_%03d", seq_len(N_CONTROL))
target_ids <- sprintf("T_%03d", seq_len(N_TARGET))

# ---- 3b. Latent market + observed PRE economic characteristics ----------------
# v14 DGP principle:
#   * smooth_geo_only: true market exposure is a smooth function of geography;
#   * smooth_geo_econ: true market exposure additionally depends on an economic
#     latent state that is only weakly predictable from coordinates;
#   * the observed PRE economic variables are noisy proxies for that state;
#   * target-donor PHYSICAL distance never directly enters the true SCM score.
#
# The main comparison therefore changes whether ECONOMIC DISTANCE is part of
# the truth, while Gneiting/spCF remain outcome-side estimators in 04b.
# Importantly, the same seed and random innovations are used in the two main
# scenarios, so their difference is not driven by a different random draw.
target_x_scaled <- (target_xy[, 1] - 10000) / 9500
target_y_scaled <- (target_xy[, 2] - 10000) / 9500
control_x_scaled <- (control_xy[, 1] - 10000) / 9500
control_y_scaled <- (control_xy[, 2] - 10000) / 9500

# Smooth broad geographic component, defined identically for controls/targets.
target_geo_z1 <- 0.70 * target_x_scaled + 0.20 * sin(pi * target_y_scaled)
target_geo_z2 <- 0.65 * target_y_scaled + 0.18 * cos(pi * target_x_scaled)
control_geo_z1 <- 0.70 * control_x_scaled + 0.20 * sin(pi * control_y_scaled)
control_geo_z2 <- 0.65 * control_y_scaled + 0.18 * cos(pi * control_x_scaled)

# Latent economics: 20% spatially patterned + 80% location-specific variation.
# The latter is the key omitted dimension for spatial-only ST methods.  Generate
# controls and targets jointly so the latent scale is identical across groups.
all_xy <- rbind(control_xy, target_xy)
n_all <- nrow(all_xy)

econ_spatial1 <- zscore_vec(
  sin(2 * pi * all_xy[, 1] / 8500) * cos(2 * pi * all_xy[, 2] / 11000)
)
econ_spatial2 <- zscore_vec(
  cos(2 * pi * all_xy[, 1] / 10500 + all_xy[, 2] / 6000)
)
econ_idio1 <- zscore_vec(rnorm(n_all))
econ_idio2 <- zscore_vec(rnorm(n_all))

econ_latent1_all <- zscore_vec(
  sqrt(ECON_SPATIAL_SHARE) * econ_spatial1 +
    sqrt(1 - ECON_SPATIAL_SHARE) * econ_idio1
)
econ_latent2_all <- zscore_vec(
  sqrt(ECON_SPATIAL_SHARE) * econ_spatial2 +
    sqrt(1 - ECON_SPATIAL_SHARE) * econ_idio2
)

control_econ_latent1 <- econ_latent1_all[seq_len(N_CONTROL)]
control_econ_latent2 <- econ_latent2_all[seq_len(N_CONTROL)]
target_econ_latent1 <- econ_latent1_all[N_CONTROL + seq_len(N_TARGET)]
target_econ_latent2 <- econ_latent2_all[N_CONTROL + seq_len(N_TARGET)]

# Economic distance is TRUE only in the geo+econ main DGP and stress scenarios
# derived from it.  It is deliberately absent in smooth_geo_only.  The two
# no_spatial scenarios have independent W_true, so economic-distance smoothing
# is not part of their truth either.
ECONOMIC_DISTANCE_ACTIVE <- SCENARIO %in% c(
  "smooth_geo_econ", "station_selected_geo_econ",
  "smooth_geo_econ_latent_factor", "spatially_separated_donors", "boundary"
)

if (ECONOMIC_DISTANCE_ACTIVE) {
  target_market_raw1 <- target_geo_z1 + ECON_MARKET_STRENGTH * target_econ_latent1
  target_market_raw2 <- target_geo_z2 + ECON_MARKET_STRENGTH * target_econ_latent2
  donor_market_raw1 <- control_geo_z1 + ECON_MARKET_STRENGTH * control_econ_latent1
  donor_market_raw2 <- control_geo_z2 + ECON_MARKET_STRENGTH * control_econ_latent2
} else {
  target_market_raw1 <- target_geo_z1
  target_market_raw2 <- target_geo_z2
  donor_market_raw1 <- control_geo_z1
  donor_market_raw2 <- control_geo_z2
}

# Standardize the latent market dimensions jointly over controls+targets in each
# scenario.  This keeps the overall market-distance scale, and therefore true
# weight concentration, comparable between smooth_geo_only and smooth_geo_econ.
# Without this normalization the added economic dimension would mechanically
# spread market_z and create more concentrated W_true, confounding the comparison.
market1_all <- zscore_vec(c(donor_market_raw1, target_market_raw1))
market2_all <- zscore_vec(c(donor_market_raw2, target_market_raw2))
donor_market_z1 <- market1_all[seq_len(N_CONTROL)]
donor_market_z2 <- market2_all[seq_len(N_CONTROL)]
target_market_z1 <- market1_all[N_CONTROL + seq_len(N_TARGET)]
target_market_z2 <- market2_all[N_CONTROL + seq_len(N_TARGET)]

all_pre_station_dist <- c(control_pre_station_dist, target_pre_station_dist)
access_mean <- mean(all_pre_station_dist)
access_sd <- stats::sd(all_pre_station_dist)
if (!is.finite(access_sd) || access_sd <= 0) access_sd <- 1

# Higher z_access means better PRE-treatment station accessibility.  It is a
# deterministic function of geography and remains available descriptively, but
# v14 does NOT include it in the economic Mahalanobis metric in 04b.
control_access_z <- -(control_pre_station_dist - access_mean) / access_sd
target_access_z <- -(target_pre_station_dist - access_mean) / access_sd

# PRE economic proxy variables.  They depend ONLY on latent economics (plus
# measurement noise), not directly on geographic coordinates.  Consequently,
# they are irrelevant nuisance variables in smooth_geo_only but informative in
# smooth_geo_econ.  Standardize controls+targets jointly to retain a common scale.
proxy_emp_all <- zscore_vec(
  0.85 * econ_latent1_all + rnorm(n_all, 0, ECON_PROXY_NOISE_SD)
)
proxy_com_all <- zscore_vec(
  -0.25 * econ_latent1_all + 0.85 * econ_latent2_all +
    rnorm(n_all, 0, ECON_PROXY_NOISE_SD)
)
proxy_inc_all <- zscore_vec(
  0.55 * econ_latent1_all - 0.35 * econ_latent2_all +
    rnorm(n_all, 0, ECON_PROXY_NOISE_SD)
)

control_pre_employment_density_z <- proxy_emp_all[seq_len(N_CONTROL)]
control_pre_commercial_share_z <- proxy_com_all[seq_len(N_CONTROL)]
control_pre_income_z <- proxy_inc_all[seq_len(N_CONTROL)]
target_pre_employment_density_z <- proxy_emp_all[N_CONTROL + seq_len(N_TARGET)]
target_pre_commercial_share_z <- proxy_com_all[N_CONTROL + seq_len(N_TARGET)]
target_pre_income_z <- proxy_inc_all[N_CONTROL + seq_len(N_TARGET)]

# Boundary stress test: target market membership jumps at x=10 km.  Donor
# regime is defined by latent market type, not by physical distance to targets.
latent_regime_score <- donor_market_z1 + 0.30 * donor_market_z2
donor_market_regime <- ifelse(
  latent_regime_score >= stats::median(latent_regime_score),
  "east_type", "west_type"
)

target_market_features <- tibble::tibble(
  point_id = target_ids,
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  market_z1 = target_market_z1,
  market_z2 = target_market_z2,
  econ_latent1 = target_econ_latent1,
  econ_latent2 = target_econ_latent2,
  economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
  pre_access_z = target_access_z,
  pre_station_distance_m = target_pre_station_dist,
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z
)

donor_market_features <- tibble::tibble(
  point_id = control_ids,
  X_m = control_xy[, 1],
  Y_m = control_xy[, 2],
  market_z1 = donor_market_z1,
  market_z2 = donor_market_z2,
  econ_latent1 = control_econ_latent1,
  econ_latent2 = control_econ_latent2,
  economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
  pre_access_z = control_access_z,
  pre_station_distance_m = control_pre_station_dist,
  pre_employment_density_z = control_pre_employment_density_z,
  pre_commercial_share_z = control_pre_commercial_share_z,
  pre_income_z = control_pre_income_z,
  latent_market_regime = donor_market_regime
)

# ---- 4. Complete control outcome trajectories --------------------------------
# Controls are fully observed and untreated.  Most scenarios retain the original
# coherent market surface in which donor outcome coefficients depend on latent
# market characteristics.  Two proposal-focused DGPs instead use a DGP2 outcome
# architecture: donor levels/trends/cycles retain genuine geographic structure
# but have no direct linear dependence on the observed/latent economic proxies.
# Economic information can therefore remain highly informative about W_true
# without automatically becoming a strong linear outcome-mean predictor.
#
# IMPORTANT: spatially_separated_donors shares only this DGP2 BASE outcome
# architecture.  It does NOT receive the extra latent temporal factors used by
# smooth_geo_econ_latent_factor, so its distinctive stress remains spatial donor
# separation/extrapolation rather than a second simultaneous DGP change.
DGP2_OUTCOME_ARCHITECTURE <- SCENARIO %in% c(
  "smooth_geo_econ_latent_factor", "spatially_separated_donors"
)
Tn <- length(YEARS)
time_index <- YEARS - min(YEARS)

common_factor_raw <-
  0.012 * sin(time_index / 3.1) +
  0.008 * cos(time_index / 5.0) +
  make_ar1(Tn, phi = COMMON_FACTOR_AR_PHI, sd = COMMON_FACTOR_AR_SD)
common_factor_raw <- common_factor_raw - mean(common_factor_raw)
if (DGP2_OUTCOME_ARCHITECTURE) {
  # In the DGP2 outcome architecture, keep a real geographic outcome signal for
  # kriging, but avoid giving Econ-X a direct linear market-loading advantage.
  common_factor_loading <- 1 + 0.12 * zscore_vec(
    sin(pi * control_xy[, 1] / 10000) +
      0.6 * cos(pi * control_xy[, 2] / 12000)
  ) + rnorm(N_CONTROL, 0, 0.10)
} else {
  common_factor_loading <- 1 + 0.18 * donor_market_z1 - 0.10 * donor_market_z2 +
    rnorm(N_CONTROL, 0, 0.10)
}

control_log <- matrix(NA_real_, nrow = N_CONTROL, ncol = Tn,
                      dimnames = list(control_ids, YEARS))

# Spatial bases used by the DGP2 outcome architecture. They leave
# genuine geographic structure for Gneiting kriging without making the safe
# economic proxies linear outcome-level regressors.
lf_base_spatial <- zscore_vec(
  sin(pi * control_xy[, 1] / 9000) + 0.7 * cos(pi * control_xy[, 2] / 11000)
)
lf_slope_spatial <- zscore_vec(
  cos(pi * (control_xy[, 1] + control_xy[, 2]) / 17000)
)
lf_cycle_spatial <- zscore_vec(
  sin(2 * pi * control_xy[, 1] / 20000) * cos(pi * control_xy[, 2] / 20000)
)

for (j in seq_len(N_CONTROL)) {
  if (DGP2_OUTCOME_ARCHITECTURE) {
    # Baseline donor trajectories are geographically structured but have no
    # direct linear dependence on the economic latent variables. Economic
    # information affects the target counterfactual mainly through donor
    # composition and the nonlinear factor loadings added below.
    base_j <- log(220000) + 0.10 * lf_base_spatial[j] + rnorm(1, 0, 0.10)
  } else {
    # Ordinary scenarios retain the original coherent market surface.
    base_j <- log(220000) +
      0.18 * donor_market_z1[j] - 0.10 * donor_market_z2[j] + rnorm(1, 0, 0.10)
  }

  if (DGP2_OUTCOME_ARCHITECTURE) {
    slope_j <- 0.004 + 0.0020 * lf_slope_spatial[j] + rnorm(1, 0, 0.0045)
    curve_j <- -0.00005 + rnorm(1, 0, 0.00008)
    cyc1_j <- 0.008 * lf_cycle_spatial[j] + rnorm(1, 0, 0.012)
    cyc2_j <- -0.006 * lf_base_spatial[j] + rnorm(1, 0, 0.010)
    local_cycle <- cyc1_j * sin(time_index / 2.8) + cyc2_j * cos(time_index / 4.2)
    ar_part <- make_ar1(Tn, phi = 0.55, sd = 0.006)
    common_part <- COMMON_FACTOR_SCALE * common_factor_loading[j] * common_factor_raw
    control_log[j, ] <- base_j + slope_j * time_index +
      curve_j * time_index^2 + local_cycle + common_part + ar_part
  } else {
    slope_j <- 0.004 + 0.0030 * donor_market_z1[j] +
      0.0015 * donor_market_z2[j] + rnorm(1, 0, 0.0045)
    curve_j <- -0.00005 + 0.00003 * donor_market_z2[j] + rnorm(1, 0, 0.00008)
    cyc1_j <- 0.010 * donor_market_z1[j] + rnorm(1, 0, 0.014)
    cyc2_j <- -0.008 * donor_market_z2[j] + rnorm(1, 0, 0.011)
    local_cycle <- cyc1_j * sin(time_index / 2.8) + cyc2_j * cos(time_index / 4.2)
    ar_part <- make_ar1(Tn, phi = 0.55, sd = 0.006)
    common_part <- COMMON_FACTOR_SCALE * common_factor_loading[j] * common_factor_raw
    control_log[j, ] <- base_j + slope_j * time_index +
      curve_j * time_index^2 + local_cycle + common_part + ar_part
  }
}

latent_factor_component <- NULL
latent_factor_loadings <- NULL
latent_factor_series <- NULL

# Proposal-positive-control DGP: stable geo+econ donor weights, but outcome
# dependence is driven by several latent temporal factors rather than by a
# single stationary space-time covariance surface.  Factor loadings retain a
# meaningful geographic component so this is not an artificial anti-kriging
# construction; the remaining signal is nonlinear in latent market/economic
# state and partly donor-specific.
if (SCENARIO == "smooth_geo_econ_latent_factor") {
  lf_spatial1 <- zscore_vec(
    sin(2 * pi * control_xy[, 1] / 20000) * cos(pi * control_xy[, 2] / 20000)
  )
  lf_spatial2 <- zscore_vec(
    cos(pi * control_xy[, 1] / 10000 + control_xy[, 2] / 14000)
  )
  lf_spatial3 <- zscore_vec(
    sin(pi * (control_xy[, 1] + control_xy[, 2]) / 18000)
  )

  # The observed economic variables are useful as a DISTANCE metric but should
  # not become strong linear outcome-level regressors. Build nonlinear local
  # economic archetypes and remove only their linear projection on the three
  # observed proxy levels. Nearby economic states remain similar, which is what
  # GeoEco-SCM exploits through Mahalanobis edge distance.
  econ_proxy_control <- cbind(
    control_pre_employment_density_z,
    control_pre_commercial_share_z,
    control_pre_income_z
  )
  residualize_linear_proxy <- function(v) {
    X <- cbind(1, econ_proxy_control)
    fit <- stats::lm.fit(x = X, y = as.numeric(v))
    zscore_vec(as.numeric(fit$residuals))
  }
  econ_rbf <- function(c1, c2, bw = LATENT_FACTOR_ECON_BASIS_BW) {
    exp(-((control_econ_latent1 - c1)^2 +
            (control_econ_latent2 - c2)^2) / (2 * bw^2))
  }

  econ_basis1 <- residualize_linear_proxy(
    econ_rbf(-0.9, -0.5) - econ_rbf(0.8, 0.4)
  )
  econ_basis2 <- residualize_linear_proxy(
    econ_rbf(0.9, -0.7) - econ_rbf(-0.4, 0.9)
  )
  econ_basis3 <- residualize_linear_proxy(
    sin(1.6 * control_econ_latent1) * cos(1.4 * control_econ_latent2)
  )

  make_loading <- function(spatial_part, econ_part) {
    zscore_vec(
      sqrt(LATENT_FACTOR_SPATIAL_SHARE) * spatial_part +
        sqrt(1 - LATENT_FACTOR_SPATIAL_SHARE) * econ_part +
        rnorm(N_CONTROL, 0, LATENT_FACTOR_IDIO_SD)
    )
  }

  loading1 <- make_loading(lf_spatial1, econ_basis1)
  loading2 <- make_loading(lf_spatial2, econ_basis2)
  loading3 <- make_loading(lf_spatial3, econ_basis3)

  factor1 <- zscore_vec(make_ar1(Tn, phi = LATENT_FACTOR_AR1_PHI, sd = 0.018))
  factor2 <- zscore_vec(
    make_ar1(Tn, phi = LATENT_FACTOR_AR2_PHI, sd = 0.018) +
      0.60 * sin(time_index / 1.9)
  )
  factor3 <- zscore_vec(
    0.55 * cos(time_index / 3.1) +
      0.45 * as.numeric(YEARS >= LATENT_FACTOR_SHOCK_YEAR) +
      make_ar1(Tn, phi = 0.55, sd = 0.010)
  )

  latent_factor_loadings <- cbind(
    factor1_loading = loading1,
    factor2_loading = loading2,
    factor3_loading = loading3
  )
  rownames(latent_factor_loadings) <- control_ids
  latent_factor_series <- cbind(factor1 = factor1, factor2 = factor2, factor3 = factor3)
  rownames(latent_factor_series) <- YEARS

  latent_factor_component <- LATENT_FACTOR_SCALE * (
    outer(loading1, factor1) +
      outer(loading2, factor2) +
      outer(loading3, factor3)
  ) / sqrt(3)

  control_log <- control_log + latent_factor_component
}

# ---- 5. Known spatially varying SCM weights ---------------------------------
# The smooth scenarios impose smoothness on the TARGET representation, not on
# target-donor geographic distance.  A target is matched to donor locations
# with similar latent market exposures and PRE-treatment accessibility.
#
# score_ij = -1/2 [ ((z1_i-b1_j)/h_z)^2 + ((z2_i-b2_j)/h_z)^2
#                  + a_access ((A_i-A_j)/h_A)^2 ]
# w_true_ij = softmax_j(score_ij).
#
# In smooth_geo_only, z_i is geographic only.  In smooth_geo_econ and the
# derived stress scenarios, z_i also contains the partly non-spatial economic
# latent state.  A donor does NOT receive a direct bonus merely because it is
# physically near the target.
W_true <- matrix(NA_real_, nrow = N_TARGET, ncol = N_CONTROL,
                 dimnames = list(target_ids, control_ids))

for (i in seq_len(N_TARGET)) {
  if (SCENARIO == "no_spatial") {
    # Deliberately violate the core spatial-smoothness assumption: each target
    # gets an independent concentrated simplex weight vector.
    z <- stats::rgamma(N_CONTROL, shape = NO_SPATIAL_DIRICHLET_SHAPE, rate = 1)
    W_true[i, ] <- z / sum(z)
  } else {
    latent_d1 <- (donor_market_z1 - target_market_z1[i]) / WEIGHT_LATENT_SCALE
    latent_d2 <- (donor_market_z2 - target_market_z2[i]) / WEIGHT_LATENT_SCALE
    access_d <- (control_access_z - target_access_z[i]) / WEIGHT_ACCESS_SCALE

    score <- -0.5 * (
      latent_d1^2 +
        latent_d2^2 +
        WEIGHT_ACCESS_IMPORTANCE * access_d^2
    )

    if (SCENARIO == "boundary") {
      # Abrupt latent-market boundary at x = 10 km.  Target market type jumps
      # across the boundary, while donor regime labels remain unrelated to
      # donor physical location.  This isolates oversmoothing across a target
      # market boundary from any target-donor-nearness assumption.
      target_regime <- if (target_xy[i, 1] >= 10000) "east_type" else "west_type"
      score <- score + BOUNDARY_BONUS *
        as.numeric(donor_market_regime == target_regime)
    }

    W_true[i, ] <- softmax_stable(score)
  }
}

stopifnot(max(abs(rowSums(W_true) - 1)) < 1e-10)
stopifnot(min(W_true) >= 0)

# ---- 6. True untreated treatment outcomes -----------------------------------
# This is the exact SCM counterfactual before observation noise.
true_cf_log <- W_true %*% control_log
rownames(true_cf_log) <- target_ids
colnames(true_cf_log) <- YEARS

# ---- 7. Known treatment effect ----------------------------------------------
# Treatment starts in 2005 and gradually ramps up. The long-run log effect is
# larger near the synthetic new station. This lets us assess ATT recovery.
tau_log <- matrix(0, nrow = N_TARGET, ncol = Tn,
                  dimnames = list(target_ids, YEARS))

site_longrun_tau <- 0.015 + 0.105 * exp(-target_new_station_dist / 5000)
for (tt in seq_along(YEARS)) {
  yy <- YEARS[tt]
  if (yy >= 2005) {
    ramp <- min(1, (yy - 2004) / 5)
    tau_log[, tt] <- site_longrun_tau * ramp
  }
}

# Observed treatment outcomes = untreated CF + known treatment effect + noise.
target_noise <- matrix(
  rnorm(N_TARGET * Tn, 0, TARGET_NOISE_SD),
  nrow = N_TARGET, ncol = Tn,
  dimnames = list(target_ids, YEARS)
)
target_log_complete <- true_cf_log + tau_log + target_noise

# ---- 8. Create missing PRE histories ----------------------------------------
n_complete <- round(N_TARGET * PROP_COMPLETE)
n_partial <- round(N_TARGET * PROP_PARTIAL)
n_postonly <- N_TARGET - n_complete - n_partial

pre_pos <- match(PERIOD_PRE, YEARS)
post_pos <- match(PERIOD_POST, YEARS)

# Truth-side quantities used ONLY to generate/diagnose the observation process.
# Estimators never receive latent PRE prices at post-only sites.
pre_cf_mean_log <- rowMeans(true_cf_log[, pre_pos, drop = FALSE])
low_pre_price_z <- -zscore_vec(pre_cf_mean_log)
near_new_station_raw <- exp(-target_new_station_dist / STATION_SELECTION_NEAR_SCALE_M)
near_new_station_z <- zscore_vec(near_new_station_raw)
station_selection_score <-
  STATION_SELECTION_NEAR_COEF * near_new_station_z +
  STATION_SELECTION_LOW_PRICE_COEF * low_pre_price_z +
  STATION_SELECTION_INTERACTION_COEF * near_new_station_z * low_pre_price_z

if (OBSERVATION_SELECTION_MODE == "station_selected") {
  station_selection_prob <- softmax_stable(
    station_selection_score / STATION_SELECTION_TEMPERATURE
  )
  # Fixed post-only count keeps scenario comparisons focused on selection rather
  # than changing the amount of missingness.
  idx_postonly <- sample(
    seq_len(N_TARGET), size = n_postonly, replace = FALSE,
    prob = station_selection_prob
  )
} else {
  station_selection_prob <- rep(1 / N_TARGET, N_TARGET)
  idx_postonly <- sample(seq_len(N_TARGET), size = n_postonly, replace = FALSE)
}

remaining_after_post <- setdiff(seq_len(N_TARGET), idx_postonly)
idx_partial <- sample(remaining_after_post, size = n_partial, replace = FALSE)
idx_complete <- setdiff(remaining_after_post, idx_partial)
stopifnot(length(idx_complete) == n_complete, length(idx_partial) == n_partial,
          length(idx_postonly) == n_postonly)

obs_group <- rep(NA_character_, N_TARGET)
obs_group[idx_complete] <- "complete_pre"
obs_group[idx_partial] <- "partial_pre"
obs_group[idx_postonly] <- "post_only"

target_log_observed <- target_log_complete

# Partial-pre: randomly retain only 4-8 pre-treatment observations.
for (i in idx_partial) {
  n_keep <- sample(4:8, 1)
  keep_years <- sample(PERIOD_PRE, n_keep, replace = FALSE)
  drop_pos <- pre_pos[!(PERIOD_PRE %in% keep_years)]
  target_log_observed[i, drop_pos] <- NA_real_
}

# Post-only: hide every pre-treatment outcome.
target_log_observed[idx_postonly, pre_pos] <- NA_real_

# Keep all post-treatment observations in the first validation experiment so
# treatment-effect recovery can be evaluated cleanly.

observation_selection <- tibble::tibble(
  point_id = target_ids,
  obs_group = obs_group,
  selection_mode = OBSERVATION_SELECTION_MODE,
  new_station_distance_m = target_new_station_dist,
  near_new_station_raw = near_new_station_raw,
  near_new_station_z = near_new_station_z,
  latent_pre_cf_mean_log = pre_cf_mean_log,
  low_pre_price_z = low_pre_price_z,
  selection_score = station_selection_score,
  sampling_probability = station_selection_prob,
  true_longrun_tau_log = site_longrun_tau,
  true_longrun_tau_pct = (exp(site_longrun_tau) - 1) * 100
)

# ---- 9. Convert to the same RDS schema used by 02 ----------------------------
price_cols <- paste0("price_", YEARS)

control_df <- tibble::tibble(
  point_id = control_ids,
  original_id = paste0("SIM_CONTROL_", seq_len(N_CONTROL)),
  group_type = "Control",
  X_m = control_xy[, 1],
  Y_m = control_xy[, 2],
  pre_station_distance_m = control_pre_station_dist,
  pre_access_z = control_access_z,
  pre_employment_density_z = control_pre_employment_density_z,
  pre_commercial_share_z = control_pre_commercial_share_z,
  pre_income_z = control_pre_income_z
)
for (tt in seq_along(YEARS)) {
  control_df[[price_cols[tt]]] <- exp(control_log[, tt])
}

# Treatment data retain NAs exactly where outcomes are intentionally hidden.
target_df <- tibble::tibble(
  point_id = target_ids,
  original_id = paste0("SIM_TREAT_", seq_len(N_TARGET)),
  group_type = "Treatment",
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  pre_station_distance_m = target_pre_station_dist,
  pre_access_z = target_access_z,
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z
)
for (tt in seq_along(YEARS)) {
  vv <- target_log_observed[, tt]
  target_df[[price_cols[tt]]] <- ifelse(is.finite(vv), exp(vv), NA_real_)
}

control_sf <- sf::st_as_sf(control_df, coords = c("X_m", "Y_m"),
                           crs = 6691, remove = FALSE)
target_sf <- sf::st_as_sf(target_df, coords = c("X_m", "Y_m"),
                          crs = 6691, remove = FALSE)
all_points <- rbind(control_sf, target_sf)
target_points <- target_sf

n_pre_obs <- rowSums(is.finite(target_log_observed[, pre_pos, drop = FALSE]))
n_post_obs <- rowSums(is.finite(target_log_observed[, post_pos, drop = FALSE]))

last_year <- apply(is.finite(target_log_observed), 1, function(z) {
  max(YEARS[z])
})

target_meta <- tibble::tibble(
  point_id = target_ids,
  original_id = target_df$original_id,
  obs_group = obs_group,
  n_pre_obs = n_pre_obs,
  n_post_obs = n_post_obs,
  last_year = last_year,
  X_m = target_xy[, 1],
  Y_m = target_xy[, 2],
  pre_station_distance_m = target_pre_station_dist,
  pre_access_z = target_access_z,
  pre_employment_density_z = target_pre_employment_density_z,
  pre_commercial_share_z = target_pre_commercial_share_z,
  pre_income_z = target_pre_income_z,
  # Included only because 02 currently carries this field into the output table.
  # In the simulation it is the SAME safe pre-treatment distance.
  StationDistance = target_pre_station_dist,
  true_new_station_distance_m = target_new_station_dist
)

# Simple bounding polygon; 02 does not use it in estimation, but it keeps the
# synthetic object structurally similar to the real prepared dataset.
poly_xy <- matrix(
  c(0, 0,
    20000, 0,
    20000, 20000,
    0, 20000,
    0, 0),
  ncol = 2, byrow = TRUE
)
study_area <- sf::st_sf(
  area_name = "synthetic_market",
  geometry = sf::st_sfc(sf::st_polygon(list(poly_xy)), crs = 6691)
)

simulation_truth <- list(
  scenario = SCENARIO,
  seed = SEED,
  W_true = W_true,
  true_cf_log = true_cf_log,
  tau_log = tau_log,
  control_log = control_log,
  target_noise = target_noise,
  control_ids = control_ids,
  target_ids = target_ids,
  pre_stations = pre_stations,
  new_station = new_station,
  target_market_features = target_market_features,
  donor_market_features = donor_market_features,
  common_market_factor = stats::setNames(common_factor_raw, YEARS),
  common_factor_loading = stats::setNames(common_factor_loading, control_ids),
  latent_factor_loadings = latent_factor_loadings,
  latent_factor_series = latent_factor_series,
  latent_factor_component = latent_factor_component,
  observation_selection = observation_selection,
  parameters = list(
    target_noise_sd = TARGET_NOISE_SD,
    weight_latent_scale = WEIGHT_LATENT_SCALE,
    weight_access_scale = WEIGHT_ACCESS_SCALE,
    weight_access_importance = WEIGHT_ACCESS_IMPORTANCE,
    economic_distance_active = ECONOMIC_DISTANCE_ACTIVE,
    econ_market_strength = ECON_MARKET_STRENGTH,
    econ_spatial_share = ECON_SPATIAL_SHARE,
    direct_target_donor_geographic_distance_in_weight_score = FALSE,
    boundary_bonus = BOUNDARY_BONUS,
    latent_factor_scale = LATENT_FACTOR_SCALE,
    latent_factor_spatial_share = LATENT_FACTOR_SPATIAL_SHARE,
    latent_factor_idio_sd = LATENT_FACTOR_IDIO_SD,
    latent_factor_econ_basis_bw = LATENT_FACTOR_ECON_BASIS_BW,
    latent_factor_ar1_phi = LATENT_FACTOR_AR1_PHI,
    latent_factor_ar2_phi = LATENT_FACTOR_AR2_PHI,
    latent_factor_shock_year = LATENT_FACTOR_SHOCK_YEAR,
    spatial_support_center = SPATIAL_SUPPORT_CENTER,
    spatial_target_radius_m = SPATIAL_TARGET_RADIUS_M,
    spatial_buffer_outer_radius_m = SPATIAL_BUFFER_OUTER_RADIUS_M,
    spatial_control_outer_radius_m = SPATIAL_CONTROL_OUTER_RADIUS_M,
    no_spatial_dirichlet_shape = NO_SPATIAL_DIRICHLET_SHAPE,
    econ_proxy_noise_sd = ECON_PROXY_NOISE_SD,
    observation_selection_mode = OBSERVATION_SELECTION_MODE,
    station_selection_near_scale_m = STATION_SELECTION_NEAR_SCALE_M,
    station_selection_near_coef = STATION_SELECTION_NEAR_COEF,
    station_selection_low_price_coef = STATION_SELECTION_LOW_PRICE_COEF,
    station_selection_interaction_coef = STATION_SELECTION_INTERACTION_COEF,
    station_selection_temperature = STATION_SELECTION_TEMPERATURE,
    common_factor_scale = COMMON_FACTOR_SCALE,
    common_factor_ar_phi = COMMON_FACTOR_AR_PHI,
    common_factor_ar_sd = COMMON_FACTOR_AR_SD
  )
)

dataset <- list(
  schema_version = "M1_LP_spatial_scm_dataset_v1",
  config = list(
    years = YEARS,
    period_pre = PERIOD_PRE,
    period_post = PERIOD_POST,
    synthetic = TRUE,
    scenario = SCENARIO
  ),
  study_area = study_area,
  all_points = all_points,
  target_points = target_points,
  target_meta = target_meta,
  simulation_truth = simulation_truth
)

rds_path <- file.path(OUTPUT_DIR, "M1_LP_synthetic_dataset.rds")
saveRDS(dataset, rds_path)

# ---- 10. Human-readable truth files -----------------------------------------
weights_truth <- as.data.frame(W_true, check.names = FALSE) %>%
  tibble::rownames_to_column("point_id")
readr::write_csv(weights_truth, file.path(OUTPUT_DIR, "truth_weights.csv"))

readr::write_csv(target_market_features,
                 file.path(OUTPUT_DIR, "truth_and_observed_target_market_features.csv"))
readr::write_csv(donor_market_features,
                 file.path(OUTPUT_DIR, "truth_and_observed_donor_market_features.csv"))
readr::write_csv(
  target_market_features,
  file.path(OUTPUT_DIR, "truth_target_latent_market_features.csv")
)
readr::write_csv(
  donor_market_features,
  file.path(OUTPUT_DIR, "truth_donor_latent_market_features.csv")
)

readr::write_csv(
  observation_selection,
  file.path(OUTPUT_DIR, "truth_observation_selection_by_site.csv")
)
observation_selection_summary <- observation_selection %>%
  dplyr::group_by(obs_group) %>%
  dplyr::summarise(
    n = dplyr::n(),
    mean_new_station_distance_m = mean(new_station_distance_m),
    mean_latent_pre_cf_log = mean(latent_pre_cf_mean_log),
    mean_low_pre_price_z = mean(low_pre_price_z),
    mean_true_longrun_tau_pct = mean(true_longrun_tau_pct),
    mean_selection_score = mean(selection_score),
    .groups = "drop"
  )
readr::write_csv(
  observation_selection_summary,
  file.path(OUTPUT_DIR, "simulation_observation_selection_diagnostics.csv")
)

# How concentrated are the true weights? This is a key diagnostic because a
# diffuse W_true makes uniform weights an unrealistically strong benchmark.
truth_weight_concentration <- tibble::tibble(
  point_id = target_ids,
  obs_group = obs_group,
  max_true_weight = apply(W_true, 1, max),
  true_effective_donors = 1 / rowSums(W_true^2),
  true_weight_entropy = -rowSums(ifelse(W_true > 0, W_true * log(W_true), 0))
)
readr::write_csv(
  truth_weight_concentration,
  file.path(OUTPUT_DIR, "truth_weight_concentration_by_site.csv")
)
truth_weight_concentration_summary <- truth_weight_concentration %>%
  dplyr::summarise(
    mean_effective_donors = mean(true_effective_donors),
    median_effective_donors = median(true_effective_donors),
    p10_effective_donors = quantile(true_effective_donors, 0.10),
    p90_effective_donors = quantile(true_effective_donors, 0.90),
    mean_max_true_weight = mean(max_true_weight)
  )
readr::write_csv(
  truth_weight_concentration_summary,
  file.path(OUTPUT_DIR, "truth_weight_concentration_summary.csv")
)

truth_cf_long <- as.data.frame(true_cf_log) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "true_cf_log") %>%
  dplyr::mutate(year = as.integer(year), true_cf_yen = exp(true_cf_log))
readr::write_csv(truth_cf_long, file.path(OUTPUT_DIR, "truth_counterfactual_long.csv"))

truth_tau_long <- as.data.frame(tau_log) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "true_tau_log") %>%
  dplyr::mutate(
    year = as.integer(year),
    true_tau_pct = (exp(true_tau_log) - 1) * 100
  )
readr::write_csv(truth_tau_long, file.path(OUTPUT_DIR, "truth_treatment_effect_long.csv"))

true_att <- truth_tau_long %>%
  dplyr::filter(year %in% PERIOD_POST) %>%
  dplyr::group_by(year) %>%
  dplyr::summarise(
    true_ATT_log = mean(true_tau_log),
    true_ATT_pct = (exp(true_ATT_log) - 1) * 100,
    .groups = "drop"
  )
readr::write_csv(true_att, file.path(OUTPUT_DIR, "truth_ATT_by_year.csv"))

# Truth-only ATT populations.  The gap between PRE_OBSERVED and ALL is the pure
# observation-selection component that ordinary site-specific SCM cannot remove.
att_population_index <- list(
  ALL = seq_len(N_TARGET),
  PRE_OBSERVED = which(obs_group != "post_only"),
  POST_ONLY = which(obs_group == "post_only"),
  COMPLETE_PRE = which(obs_group == "complete_pre"),
  PARTIAL_PRE = which(obs_group == "partial_pre")
)
true_att_by_population <- dplyr::bind_rows(lapply(names(att_population_index), function(pop) {
  ii <- att_population_index[[pop]]
  dplyr::bind_rows(lapply(PERIOD_POST, function(yy) {
    tt <- match(yy, YEARS)
    mlog <- mean(tau_log[ii, tt])
    tibble::tibble(
      population = pop, year = yy, n_sites = length(ii),
      true_ATT_log = mlog, true_ATT_pct = (exp(mlog) - 1) * 100
    )
  }))
}))
readr::write_csv(
  true_att_by_population,
  file.path(OUTPUT_DIR, "truth_ATT_by_observation_population.csv")
)

true_weight_model_label <- dplyr::case_when(
  SCENARIO == "smooth_geo_only" ~
    "concentrated weights from geographic latent market similarity + spatial PRE accessibility; economic proxies are irrelevant nuisance variables",
  SCENARIO == "smooth_geo_econ" ~
    "concentrated weights from geographic + partly non-spatial latent economic similarity + spatial PRE accessibility; observed PRE economics are noisy proxies",
  SCENARIO == "station_selected_geo_only" ~
    "same geographic-only outcome/weight DGP as smooth_geo_only; post-only membership selected toward low-PRE-price sites near the new station",
  SCENARIO == "station_selected_geo_econ" ~
    "same geo+econ outcome/weight DGP as smooth_geo_econ; post-only membership selected toward low-PRE-price sites near the new station",
  SCENARIO == "smooth_geo_econ_latent_factor" ~
    "same geo+econ smooth weights as smooth_geo_econ; donor outcomes combine genuine geographic signal with nonlinear local economic-archetype factor loadings whose linear projection on observed Econ-X proxies is removed",
  SCENARIO == "no_spatial" ~
    "independent concentrated Dirichlet weights unrelated to target geography/economics",
  SCENARIO == "spatially_separated_donors" ~
    "same geo+econ smooth weights as smooth_geo_econ; targets lie within 5 km and donor controls outside a 7 km buffer; donor outcome levels/trends/cycles retain geographic structure but exclude direct linear economic-market loading (DGP2 outcome architecture)",
  SCENARIO == "boundary" ~
    "geo+econ latent-exposure weights with an abrupt x=10km target-market boundary",
  TRUE ~ SCENARIO
)

sim_design <- tibble::tibble(
  item = c(
    "scenario", "seed", "years", "pre_period", "post_period",
    "n_control", "n_target", "complete_pre", "partial_pre", "post_only",
    "target_noise_sd", "weight_latent_scale", "weight_access_scale",
    "weight_access_importance",
    "economic_distance_active", "econ_market_strength", "econ_spatial_share",
    "direct_target_donor_geographic_distance_in_weight_score",
    "boundary_bonus",
    "latent_factor_scale", "latent_factor_spatial_share",
    "latent_factor_idio_sd", "latent_factor_econ_basis_bw", "latent_factor_ar1_phi",
    "latent_factor_ar2_phi", "latent_factor_shock_year",
    "no_spatial_dirichlet_shape", "econ_proxy_noise_sd",
    "observation_selection_mode", "station_selection_near_scale_m",
    "station_selection_near_coef", "station_selection_low_price_coef",
    "station_selection_interaction_coef", "station_selection_temperature",
    "spatial_target_radius_m", "spatial_buffer_outer_radius_m",
    "spatial_control_outer_radius_m", "common_factor_scale",
    "common_factor_ar_phi", "common_factor_ar_sd",
    "mean_true_effective_donors", "median_true_effective_donors",
    "true_weight_model"
  ),
  value = c(
    SCENARIO, as.character(SEED), paste0(min(YEARS), "-", max(YEARS)),
    paste0(min(PERIOD_PRE), "-", max(PERIOD_PRE)),
    paste0(min(PERIOD_POST), "-", max(PERIOD_POST)),
    N_CONTROL, N_TARGET,
    sum(obs_group == "complete_pre"), sum(obs_group == "partial_pre"),
    sum(obs_group == "post_only"), TARGET_NOISE_SD,
    WEIGHT_LATENT_SCALE, WEIGHT_ACCESS_SCALE, WEIGHT_ACCESS_IMPORTANCE,
    ECONOMIC_DISTANCE_ACTIVE, ECON_MARKET_STRENGTH, ECON_SPATIAL_SHARE,
    FALSE, BOUNDARY_BONUS, LATENT_FACTOR_SCALE, LATENT_FACTOR_SPATIAL_SHARE,
    LATENT_FACTOR_IDIO_SD, LATENT_FACTOR_ECON_BASIS_BW, LATENT_FACTOR_AR1_PHI, LATENT_FACTOR_AR2_PHI,
    LATENT_FACTOR_SHOCK_YEAR,
    NO_SPATIAL_DIRICHLET_SHAPE, ECON_PROXY_NOISE_SD,
    OBSERVATION_SELECTION_MODE, STATION_SELECTION_NEAR_SCALE_M,
    STATION_SELECTION_NEAR_COEF, STATION_SELECTION_LOW_PRICE_COEF,
    STATION_SELECTION_INTERACTION_COEF, STATION_SELECTION_TEMPERATURE,
    SPATIAL_TARGET_RADIUS_M, SPATIAL_BUFFER_OUTER_RADIUS_M,
    SPATIAL_CONTROL_OUTER_RADIUS_M, COMMON_FACTOR_SCALE,
    COMMON_FACTOR_AR_PHI, COMMON_FACTOR_AR_SD,
    truth_weight_concentration_summary$mean_effective_donors,
    truth_weight_concentration_summary$median_effective_donors,
    true_weight_model_label
  )
)
readr::write_csv(sim_design, file.path(OUTPUT_DIR, "simulation_design.csv"))

# ---- 10a2. Spatial-support diagnostics --------------------------------------
# These files document whether estimation is interpolation (overlapping support)
# or extrapolation across a donor-free buffer. They are descriptive only.
spatial_support_diag <- tibble::tibble(
  scenario = SCENARIO,
  support_mode = ifelse(
    SCENARIO == "spatially_separated_donors",
    "targets_inner_disk_controls_outer_annulus",
    "overlapping_uniform_support"
  ),
  target_max_center_distance_m = max(spatial_center_distance_target),
  target_mean_center_distance_m = mean(spatial_center_distance_target),
  control_min_center_distance_m = min(spatial_center_distance_control),
  control_mean_center_distance_m = mean(spatial_center_distance_control),
  nominal_target_radius_m = ifelse(SCENARIO == "spatially_separated_donors",
                                   SPATIAL_TARGET_RADIUS_M, NA_real_),
  nominal_buffer_outer_radius_m = ifelse(SCENARIO == "spatially_separated_donors",
                                         SPATIAL_BUFFER_OUTER_RADIUS_M, NA_real_),
  nominal_control_outer_radius_m = ifelse(SCENARIO == "spatially_separated_donors",
                                          SPATIAL_CONTROL_OUTER_RADIUS_M, NA_real_),
  realized_min_gap_m = min(spatial_center_distance_control) -
    max(spatial_center_distance_target)
)
readr::write_csv(
  spatial_support_diag,
  file.path(OUTPUT_DIR, "simulation_spatial_support_diagnostics.csv")
)

spatial_map_df <- dplyr::bind_rows(
  tibble::tibble(
    point_id = control_ids, group = "Control donor",
    X_m = control_xy[, 1], Y_m = control_xy[, 2]
  ),
  tibble::tibble(
    point_id = target_ids, group = "Treatment target",
    X_m = target_xy[, 1], Y_m = target_xy[, 2]
  )
)
p_support <- ggplot2::ggplot(
  spatial_map_df, ggplot2::aes(X_m / 1000, Y_m / 1000, shape = group)
) +
  ggplot2::geom_point(size = 2.1, alpha = 0.75) +
  ggplot2::geom_point(
    data = tibble::tibble(X_m = new_station[, 1], Y_m = new_station[, 2]),
    ggplot2::aes(X_m / 1000, Y_m / 1000), inherit.aes = FALSE,
    shape = 8, size = 4
  ) +
  ggplot2::coord_equal(xlim = c(0, 20), ylim = c(0, 20)) +
  ggplot2::labs(
    title = "Synthetic target and donor spatial support",
    subtitle = paste("Scenario:", SCENARIO, "| star = synthetic new station"),
    x = "X (km)", y = "Y (km)", shape = "Sample"
  ) +
  ggplot2::theme_minimal()

if (SCENARIO == "spatially_separated_donors") {
  theta_ring <- seq(0, 2 * pi, length.out = 361)
  ring_lines <- dplyr::bind_rows(
    tibble::tibble(
      X_km = (SPATIAL_SUPPORT_CENTER[1] + SPATIAL_TARGET_RADIUS_M * cos(theta_ring)) / 1000,
      Y_km = (SPATIAL_SUPPORT_CENTER[2] + SPATIAL_TARGET_RADIUS_M * sin(theta_ring)) / 1000,
      ring = "target edge (5 km)"
    ),
    tibble::tibble(
      X_km = (SPATIAL_SUPPORT_CENTER[1] + SPATIAL_BUFFER_OUTER_RADIUS_M * cos(theta_ring)) / 1000,
      Y_km = (SPATIAL_SUPPORT_CENTER[2] + SPATIAL_BUFFER_OUTER_RADIUS_M * sin(theta_ring)) / 1000,
      ring = "donor inner edge (7 km)"
    )
  )
  p_support <- p_support +
    ggplot2::geom_path(
      data = ring_lines,
      ggplot2::aes(X_km, Y_km, group = ring, linetype = ring),
      inherit.aes = FALSE, linewidth = 0.6
    ) +
    ggplot2::labs(linetype = "Support boundary")
}

ggplot2::ggsave(
  file.path(OUTPUT_DIR, "simulation_map_target_control_support.png"),
  p_support, width = 8, height = 6, dpi = 180, bg = "white"
)

# ---- 10b. DGP roughness diagnostics -----------------------------------------
# These descriptive quantities make the latent-factor/weak-temporal scenarios interpretable.  They
# are not used for tuning.  Lower lag-1 correlation / larger first differences
# mean that a smooth separable space-time kriging model faces a harder problem.
control_diff <- control_log[, -1, drop = FALSE] - control_log[, -ncol(control_log), drop = FALSE]
control_lag1 <- vapply(seq_len(N_CONTROL), function(j) {
  suppressWarnings(stats::cor(control_log[j, -Tn], control_log[j, -1]))
}, numeric(1))
true_cf_diff <- true_cf_log[, -1, drop = FALSE] - true_cf_log[, -ncol(true_cf_log), drop = FALSE]
true_cf_lag1 <- vapply(seq_len(N_TARGET), function(i) {
  suppressWarnings(stats::cor(true_cf_log[i, -Tn], true_cf_log[i, -1]))
}, numeric(1))

roughness_diag <- tibble::tibble(
  scenario = SCENARIO,
  control_mean_lag1 = mean(control_lag1, na.rm = TRUE),
  control_sd_first_difference = stats::sd(as.vector(control_diff), na.rm = TRUE),
  target_cf_mean_lag1 = mean(true_cf_lag1, na.rm = TRUE),
  target_cf_sd_first_difference = stats::sd(as.vector(true_cf_diff), na.rm = TRUE)
)
readr::write_csv(
  roughness_diag,
  file.path(OUTPUT_DIR, "simulation_outcome_roughness_diagnostics.csv")
)

# ---- 10c. DGP alignment diagnostics -----------------------------------------
# Mirror the Gneiting universal-kriging mean specification on the TRUE PRE
# counterfactual.  The key positive-control diagnostic is the incremental R^2
# from adding linear Econ-X proxies after year FE + geography.  In the revised
# latent-factor DGP this should be modest even though economic DISTANCE remains
# informative about W_true. These quantities are truth-only diagnostics and are
# never used by the estimators or tuning.  For spatially_separated_donors this
# specifically audits that ring separation does not accidentally turn Econ-X
# into a near-direct linear predictor of the target counterfactual.
pre_cf_long_diag <- as.data.frame(true_cf_log[, pre_pos, drop = FALSE]) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "true_cf_log") %>%
  dplyr::mutate(year = as.integer(year)) %>%
  dplyr::left_join(
    target_meta %>% dplyr::select(
      point_id, X_m, Y_m, pre_employment_density_z,
      pre_commercial_share_z, pre_income_z
    ),
    by = "point_id"
  ) %>%
  dplyr::mutate(X_km = X_m / 1000, Y_km = Y_m / 1000)

fit_geo_time_diag <- stats::lm(
  true_cf_log ~ factor(year) + X_km + Y_km,
  data = pre_cf_long_diag
)
fit_geo_time_econ_diag <- stats::lm(
  true_cf_log ~ factor(year) + X_km + Y_km +
    pre_employment_density_z + pre_commercial_share_z + pre_income_z,
  data = pre_cf_long_diag
)
r2_geo_time <- summary(fit_geo_time_diag)$r.squared
r2_geo_time_econ <- summary(fit_geo_time_econ_diag)$r.squared

loading_r2_mean <- NA_real_
if (!is.null(latent_factor_loadings)) {
  donor_diag <- data.frame(
    latent_factor_loadings,
    pre_employment_density_z = control_pre_employment_density_z,
    pre_commercial_share_z = control_pre_commercial_share_z,
    pre_income_z = control_pre_income_z
  )
  loading_r2 <- vapply(colnames(latent_factor_loadings), function(nm) {
    f <- stats::as.formula(paste0(
      nm, " ~ pre_employment_density_z + pre_commercial_share_z + pre_income_z"
    ))
    summary(stats::lm(f, data = donor_diag))$r.squared
  }, numeric(1))
  loading_r2_mean <- mean(loading_r2)
}

dgp_alignment_diag <- tibble::tibble(
  scenario = SCENARIO,
  pre_true_cf_R2_geo_time = r2_geo_time,
  pre_true_cf_R2_geo_time_econ = r2_geo_time_econ,
  pre_true_cf_incremental_R2_linear_econ = r2_geo_time_econ - r2_geo_time,
  mean_latent_factor_loading_R2_linear_econ = loading_r2_mean
)
readr::write_csv(
  dgp_alignment_diag,
  file.path(OUTPUT_DIR, "simulation_dgp_alignment_diagnostics.csv")
)

# ---- 11. Quick plots of the known DGP ---------------------------------------
plot_meta <- target_meta %>%
  dplyr::mutate(
    true_longrun_tau_pct = (exp(site_longrun_tau) - 1) * 100
  )

p_map <- ggplot(plot_meta, aes(X_m / 1000, Y_m / 1000,
                              color = true_longrun_tau_pct,
                              shape = obs_group)) +
  geom_point(size = 2.2) +
  geom_point(
    data = tibble::tibble(X_m = new_station[, 1], Y_m = new_station[, 2]),
    aes(X_m / 1000, Y_m / 1000), inherit.aes = FALSE,
    shape = 8, size = 4
  ) +
  coord_equal() +
  labs(
    title = "Synthetic treatment sites and known long-run effect",
    subtitle = paste("Scenario:", SCENARIO, "| star = synthetic new station"),
    x = "X (km)", y = "Y (km)", color = "True effect (%)", shape = "Observation group"
  ) +
  theme_minimal()
ggsave(file.path(OUTPUT_DIR, "simulation_map_true_effect.png"), p_map,
       width = 8, height = 6, dpi = 180, bg = "white")

p_att <- ggplot(true_att, aes(year, true_ATT_pct)) +
  geom_hline(yintercept = 0, color = "grey70") +
  geom_line(linewidth = 1) + geom_point() +
  labs(title = "Known ATT in the synthetic DGP", x = NULL, y = "True ATT (%)") +
  theme_minimal()
ggsave(file.path(OUTPUT_DIR, "simulation_true_ATT.png"), p_att,
       width = 7, height = 4.5, dpi = 180, bg = "white")

cat("\n============================================================\n")
cat("Synthetic M1_LP dataset created.\n")
cat("Scenario:", SCENARIO, "\n")
cat("RDS:", rds_path, "\n")
cat("Controls:", N_CONTROL, " Targets:", N_TARGET, "\n")
if (SCENARIO == "spatially_separated_donors") {
  cat(sprintf(
    "Spatial support: target radius <= %.1f km | donor radius >= %.1f km | realized gap %.2f km\n",
    SPATIAL_TARGET_RADIUS_M / 1000,
    SPATIAL_BUFFER_OUTER_RADIUS_M / 1000,
    (min(spatial_center_distance_control) - max(spatial_center_distance_target)) / 1000
  ))
}
cat(sprintf("True effective donors: mean %.2f, median %.2f\n",
            truth_weight_concentration_summary$mean_effective_donors,
            truth_weight_concentration_summary$median_effective_donors))
cat("Observation groups:\n")
print(table(obs_group))
cat("Known post-treatment ATT range (%): ",
    sprintf("%.2f to %.2f", min(true_att$true_ATT_pct), max(true_att$true_ATT_pct)), "\n", sep = "")
cat("Next: run 04b_validate_graph_geoeco_simulation.R\n")

# v14 runtime profiling: total generator wall time.  04b reads this file and
# includes it in the per-scenario runtime breakdown used for Monte Carlo planning.
dgp_elapsed_sec <- as.numeric(difftime(Sys.time(), DGP_SCRIPT_START, units = "secs"))
dgp_runtime <- tibble::tibble(
  scenario = SCENARIO,
  component = "DGP_generation_04a",
  elapsed_sec = dgp_elapsed_sec,
  elapsed_min = dgp_elapsed_sec / 60,
  n_fits = 1L,
  component_class = "data_generation",
  estimator_required = TRUE,
  mc_default = "keep"
)
readr::write_csv(dgp_runtime, file.path(OUTPUT_DIR, "simulation_dgp_runtime.csv"))
cat(sprintf("DGP generation elapsed: %.2f min\n", dgp_elapsed_sec / 60))
cat("============================================================\n")
