# Scientific figure from archived replication-specific errors; base R only.
plot_archived <- function(project_root, output_file) {
  catalog <- read.csv(file.path(project_root, "replication", "design_catalog.csv"), stringsAsFactors = FALSE)
  data <- read.csv(file.path(project_root, "data", "counterfactual_replications.csv"), na.strings = c("NA", ""))
  reduction <- vapply(catalog$scenario, function(scenario) {
    graph <- data[data$scenario == scenario & data$obs_group == "post_only" & data$method == "Graph_SCM", ]
    econ <- data[data$scenario == scenario & data$obs_group == "post_only" & data$method == "GeoEco_SCM", ]
    econ <- econ[match(graph$seed, econ$seed), ]
    stopifnot(nrow(graph) == 100L, !anyNA(econ$seed))
    mean(100 * (graph$CF_RMSE_log - econ$CF_RMSE_log) / graph$CF_RMSE_log)
  }, numeric(1))
  dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
  grDevices::png(output_file, width = 1760, height = 1080, res = 200, pointsize = 12)
  on.exit(grDevices::dev.off(), add = TRUE)
  graphics::par(mar = c(4, 15, 1, 1), mgp = c(2.4, 0.7, 0), las = 1)
  limits <- c(floor(min(reduction) / 5) * 5, ceiling(max(reduction) / 5) * 5)
  graphics::plot(reduction, 10:1, pch = 19, col = "#24445a", cex = 1.15, xlim = limits,
    xlab = "Mean replication-specific RMSE reduction (%)", ylab = "", xaxt = "n", yaxt = "n", bty = "n")
  graphics::axis(1, at = pretty(limits, n = 4))
  graphics::abline(v = 0, lty = 2, col = "grey60")
  graphics::axis(2, at = 10:1, labels = paste(catalog$paper_id, catalog$title, sep = ": "),
                  las = 1, tick = FALSE, cex.axis = 0.85)
  invisible(reduction)
}
