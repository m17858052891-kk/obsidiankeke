# =============================================================================
# M1_LP - Proposal validation: Graph-SCM / GeoEco-SCM
# =============================================================================
# Purpose:
#   Apply the same 02 jointly spatially smoothed SCM to a small synthetic dataset with known truth.
#   This script NEVER rebuilds the annual land-price panel.
#
# Required input created by 04a_make_synthetic_M1_LP_dataset_graph_geoeco.R:
#   SIM_OUTPUT_ROOT/<scenario>/M1_LP_synthetic_dataset.rds
# =============================================================================

LOCAL_MISMATCH_PATCH_VERSION <- "2026-09-29-v8"

VALIDATION_SCRIPT_START <- Sys.time()

# ---- 0. Packages ------------------------------------------------------------
if (!requireNamespace("pacman", quietly = TRUE)) install.packages("pacman")
pacman::p_load(
  sf, tidyverse, data.table, glue, Matrix, FNN, scales
)

# ---- 1. User settings --------------------------------------------------------
env_flag <- function(name, default = FALSE) {
  z <- tolower(Sys.getenv(name, unset = if (default) "true" else "false"))
  z %in% c("1", "true", "t", "yes", "y")
}
env_int <- function(name, default) {
  z <- Sys.getenv(name, unset = "")
  if (!nzchar(z)) return(as.integer(default))
  as.integer(z)
}
env_num <- function(name, default) {
  z <- Sys.getenv(name, unset = "")
  if (!nzchar(z)) return(as.numeric(default))
  as.numeric(z)
}

# Monte Carlo acceleration switch. FALSE preserves the strict paper-validation
# workflow exactly; TRUE changes only hyperparameter tuning/diagnostics, not the
# final Graph-SCM / GeoEco-SCM estimators or their final convergence criteria.
FAST_MC_TUNING <- env_flag("SIM_FAST_MC_TUNING", FALSE)
RUN_BLOCK_STRESS <- env_flag("SIM_RUN_BLOCK_STRESS", !FAST_MC_TUNING)

WORK_DIR <- Sys.getenv(
  "M1_LP_WORK_DIR",
  unset = getwd()
)
setwd(WORK_DIR)

SCENARIO <- Sys.getenv("SIM_SCENARIO", unset = "smooth_geo_econ")
SIM_OUTPUT_ROOT <- Sys.getenv(
  "SIM_OUTPUT_ROOT",
  unset = file.path("output", "simulation_graph_geoeco")
)
DATASET_RDS <- file.path(SIM_OUTPUT_ROOT, SCENARIO, "M1_LP_synthetic_dataset.rds")
OUTPUT_DIR <- file.path(SIM_OUTPUT_ROOT, SCENARIO, "results_graph_geoeco")
dir.create(OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)

# v14 runtime profiling --------------------------------------------------------
# Scientific behavior is unchanged from v13.  The profiler records every FISTA
# solve plus the non-FISTA Gneiting/spCF/QP blocks so that Monte Carlo bottlenecks can
# be measured rather than guessed.
runtime_fit_log <- list()
runtime_fit_counter <- 0L
runtime_exact_qp_sec <- NA_real_
runtime_st_pre_total_sec <- NA_real_
runtime_st_direct_total_sec <- NA_real_
runtime_st_econ_pre_total_sec <- NA_real_
runtime_st_econ_direct_total_sec <- NA_real_
runtime_spcf_pre_sec <- NA_real_
runtime_spcf_direct_sec <- NA_real_
runtime_spcf_econ_pre_sec <- NA_real_
runtime_spcf_econ_direct_sec <- NA_real_

cat("Tuning mode:", if (FAST_MC_TUNING) "FAST_MC" else "STRICT",
    "| block stress:", RUN_BLOCK_STRESS, "\n")

if (!file.exists(DATASET_RDS)) {
  stop(
    "Prepared dataset is missing: ", DATASET_RDS,
    "\nRun 04a_make_synthetic_M1_LP_dataset_graph_geoeco.R before this validation script."
  )
}

# Paper-oriented validation / graph settings ----------------------------------
# Temporal holdout evaluates prediction for sites with some pre-treatment data.
CV_HOLDOUT_YEARS <- 2002:2004

# Graph construction: geographic kNN defines candidate edges.  Economic
# similarity reweights ONLY those local edges; it never creates a distant
# neighbor. Economic distance is a shrinkage-Mahalanobis distance across safe
# PRE covariates, so the only extra tuning parameter is beta_econ.
GRAPH_K <- 8
BETA_ECON_GRID <- if (FAST_MC_TUNING) c(0, 0.5, 1, 2, 4) else c(0, 0.5, 1, 2, 4, 8)
# The previous 160-run Monte Carlo selected beta=4 frequently and beta=8 in a
# few replications, while two lambda and two beta searches still ended at their
# safety boundary.  The revised production defaults therefore include beta=4 in
# the initial fast grid and extend the conditional tails more generously.  Tail
# expansion remains adaptive, so the extra range is paid for only when needed.
FAST_LAMBDA_TAIL_MAX_STEPS <- env_int("SIM_FAST_LAMBDA_TAIL_MAX_STEPS", 9L)
FAST_LAMBDA_TAIL_MAX_MULTIPLIER <- env_num("SIM_FAST_LAMBDA_TAIL_MAX_MULTIPLIER", 59049)
FAST_LAMBDA_TAIL_EXTRA_BETA_MAX <- env_num("SIM_FAST_LAMBDA_TAIL_EXTRA_BETA_MAX", 8)
FAST_BETA_TAIL_MAX_STEPS <- env_int("SIM_FAST_BETA_TAIL_MAX_STEPS", 3L)
FAST_BETA_TAIL_MAX <- env_num("SIM_FAST_BETA_TAIL_MAX", 32)

# Final fast-MC confirmation: after the cheap 2-fold search + adaptive tails,
# re-score only the leading candidates using the strict 3-fold pseudo-post-only
# design. Temporal holdout metrics are reused, so this adds only a small number
# of pseudo-post-only fits while resolving near ties more reliably.
FAST_FINAL_3FOLD_CONFIRM <- env_flag("SIM_FAST_FINAL_3FOLD_CONFIRM", FAST_MC_TUNING)
FAST_FINAL_CONFIRM_FOLDS <- max(2L, env_int("SIM_FAST_FINAL_CONFIRM_FOLDS", 3L))
FAST_FINAL_CONFIRM_TOP_N <- max(1L, env_int("SIM_FAST_FINAL_CONFIRM_TOP_N", 3L))
FAST_FINAL_CONFIRM_SITES_PER_FOLD <- max(1L, env_int("SIM_FAST_FINAL_CONFIRM_SITES_PER_FOLD", 8L))
# v14 isolates ECONOMIC similarity from spatial accessibility.  pre_access_z is
# deliberately excluded because it is itself a deterministic function of
# geography in the synthetic DGP.
ECON_FEATURES <- c(
  "pre_employment_density_z",
  "pre_commercial_share_z",
  "pre_income_z"
)
ECON_COV_SHRINKAGE <- 0.15
ECON_COV_RIDGE <- 1e-6

# All ECON_FEATURES must be determined before treatment. Never include current
# StationDistance, post-treatment prices, treatment effects, or simulation truth.
# For real-data adaptation, replace these columns with PRE land-use/population/
# accessibility/market variables prepared outside this script.

# Hyperparameter selection ------------------------------------------------------
# v14 separates the roles of the two PRE-only validation tasks and expands the
# upper lambda tail until the cold-confirmation score turns back or a safety cap
# is reached. beta_econ is explored jointly with positive lambda candidates.
# The two validation tasks are:
#   1) temporal holdout: can sites with some PRE history predict held-out PRE years?
#   2) scattered pseudo-post-only: can a site with NO own PRE history be recovered
#      from surrounding sites while keeping observed anchors nearby?
#
# The pseudo-post-only folds are deliberately SPATIALLY INTERMIXED. The older
# k-means block folds created unrealistically large missing islands. Those block
# folds are retained below only as a stress test, not for tuning.
LAMBDA_MULTIPLIERS_INITIAL <- if (FAST_MC_TUNING) c(0, 0.1, 0.3, 1, 3) else c(0, 0.03, 0.1, 0.3, 1, 3, 10)
LOCAL_LAMBDA_FACTORS <- c(1/3, 1, 3)
ADAPTIVE_LAMBDA_GROWTH <- 3
ADAPTIVE_LAMBDA_MAX_STEPS <- if (FAST_MC_TUNING) FAST_LAMBDA_TAIL_MAX_STEPS else 10L
ADAPTIVE_LAMBDA_MAX_MULTIPLIER <- if (FAST_MC_TUNING) FAST_LAMBDA_TAIL_MAX_MULTIPLIER else 1e6

PSEUDO_SCATTERED_FOLDS <- if (FAST_MC_TUNING) 2L else 3L
# v14 retains the v8 design and masks only a small number of complete-PRE sites in each fold. With N=120,
# 8 sites/fold is close to the ~6--7% post-only share in the empirical design,
# and avoids creating an unrealistically sparse anchor network.
PSEUDO_SCATTERED_SITES_PER_FOLD <- 8L
PSEUDO_BLOCK_STRESS_FOLDS <- 3L
PSEUDO_SPATIAL_STRATA <- 10L
CV_WEIGHT_TEMPORAL <- 0.5
CV_WEIGHT_PSEUDO <- 0.5
N_TOP_CONFIGS_CONFIRM <- if (FAST_MC_TUNING) 1L else 3L

# Near-tie diagnostics and conservative economic-complexity selection.
# The exact minimum is always reported.  For the authoritative Graph-SCM fit,
# candidates within CV_PARSIMONY_REL_TOL of the best eligible cold-confirmation
# score are treated as practically tied, and the smallest beta_econ is preferred.
# This prevents finite-sample noise from declaring economic distance useful in a
# geo-only DGP when beta=0 performs essentially identically.
CV_NEAR_TIE_REL_TOL <- 0.01
CV_PARSIMONY_REL_TOL <- 0.005

# If the selected economic-distance weight is still at the upper edge of the
# pre-specified grid, v14 can extend beta locally at the selected lambda. This is
# a safeguard against declaring beta=4 optimal merely because 4 was the cap.
ADAPTIVE_ECON_BETA_GROWTH <- 2
ADAPTIVE_ECON_BETA_MAX_STEPS <- if (FAST_MC_TUNING) FAST_BETA_TAIL_MAX_STEPS else 2L
ADAPTIVE_ECON_BETA_MAX <- if (FAST_MC_TUNING) FAST_BETA_TAIL_MAX else 32

# IMPORTANT: all simulation candidate fits and pseudo-post-only fits use a
# common cold start. This makes v14 a leakage-free reference implementation.
# The real-data 02 can later use safe acceleration only after this logic is fixed.
SIM_CV_USE_WARM_START <- FALSE

# Ridge / non-uniqueness diagnostics ------------------------------------------
# rho=0 remains the main estimator. Positive rho values are NOT selected for
# better performance; they diagnose whether non-unique SCM representations
# materially change counterfactuals / ATT and whether a small ridge stabilizes
# the solution against different simplex initializations.
RUN_RHO_STABILITY <- env_flag("SIM_RUN_RHO_STABILITY", TRUE)
RHO_STABILITY_MULTIPLIERS <- c(0, 0.01, 0.03, 0.1, 0.3, 1)
RUN_INITIALIZATION_STABILITY <- env_flag("SIM_RUN_INITIALIZATION_STABILITY", TRUE)
INIT_SENSITIVITY_SEED <- 20260917L
INIT_CF_STABILITY_TOL <- 1e-3

# Small-simulation-only exact-QP check. The real-data problem is too large for
# CVXR/OSQP in the earlier experiments, but N=120 and J=24 is small enough to
# use it as a reference solution. If CVXR or OSQP is unavailable, the main
# simulation still runs and writes a clear skipped-status file.
# Optional CVXR/OSQP cross-audit.  v6 no longer relies on this for the main
# Graph/GeoEco final estimates because the authoritative selected fit is solved
# directly with a native sparse OSQP QP below.
RUN_EXACT_QP_VALIDATION <- env_flag("SIM_RUN_EXACT_QP", FALSE)
EXACT_QP_SOLVER <- "OSQP"
EXACT_QP_EPS_ABS <- 1e-8
EXACT_QP_EPS_REL <- 1e-8
EXACT_QP_MAX_ITER <- 200000L

# v6 authoritative final solver. Hyperparameter screening/confirmation remains
# projected FISTA for speed, but after (lambda,beta) is selected the reported
# GeoEco-SCM and Graph-SCM final weights are solved as the exact convex QP with
# native sparse OSQP. FISTA is used only as an explicit fallback if OSQP fails.
USE_NATIVE_OSQP_FINAL <- env_flag("SIM_USE_NATIVE_OSQP_FINAL", TRUE)
NATIVE_OSQP_INSTALL_IF_MISSING <- env_flag("SIM_OSQP_INSTALL_IF_MISSING", TRUE)
NATIVE_OSQP_EPS_ABS <- env_num("SIM_OSQP_EPS_ABS", 1e-8)
NATIVE_OSQP_EPS_REL <- env_num("SIM_OSQP_EPS_REL", 1e-8)
NATIVE_OSQP_MAX_ITER <- env_int("SIM_OSQP_MAX_ITER", 200000L)
NATIVE_OSQP_CONSTRAINT_TOL <- env_num("SIM_OSQP_CONSTRAINT_TOL", 2e-5)
NATIVE_OSQP_FALLBACK_TO_FISTA <- env_flag("SIM_OSQP_FALLBACK_TO_FISTA", TRUE)

# Boundary stress: deliberately OVER-smooth the boundary DGP relative to its own
# selected lambda. This directly tests the cost of imposing too much continuity
# across a true discrete market boundary.
RUN_BOUNDARY_FORCED_SMOOTHING <- env_flag("SIM_RUN_BOUNDARY_FORCED", TRUE)
BOUNDARY_FORCED_FACTORS <- c(3, 10)

# Donor-pool reduction is a MODEL choice. Only PRE-treatment trajectories are
# used; no post-treatment information is allowed in donor reduction.
MAX_DONORS <- 40
DONOR_KMEANS_CLUSTERS <- 10
set.seed(123)

# Optional bias correction. It is trained only with cross-fitted PRE-period
# residuals; treatment-post outcomes are never used to learn the correction.
RUN_BIAS_CORRECTION <- env_flag("SIM_RUN_BIAS_CORRECTION", FALSE)
BIAS_FOLDS <- list(1994:1997, 1998:2001, 2002:2004)
BIAS_MESH_CUTOFF_KM <- 2
BIAS_INCLUDE_LINEAR_TIME <- FALSE
BIAS_SPATIAL_VARYING_TREND <- FALSE

# Numerical stabilization only; not the substantive rho penalty.
NUMERICAL_RIDGE <- 1e-10

# Projected-FISTA settings -----------------------------------------------------
# Screening is intentionally cheaper; top configurations are then cold-started
# again with stricter tolerances. Final fits are stricter still.
FISTA_MAX_ITER_CV <- if (FAST_MC_TUNING) 1500L else 3000L
FISTA_TOL_CV <- if (FAST_MC_TUNING) 2e-5 else 1e-5
FISTA_MIN_ITER_CV <- if (FAST_MC_TUNING) 100L else 200L

FISTA_MAX_ITER_CONFIRM <- if (FAST_MC_TUNING) 3000L else 6000L
FISTA_TOL_CONFIRM <- if (FAST_MC_TUNING) 5e-6 else 2e-6
FISTA_MIN_ITER_CONFIRM <- if (FAST_MC_TUNING) 150L else 300L

FISTA_MAX_ITER_FINAL <- env_int("SIM_FISTA_MAX_ITER_FINAL", 20000L)
FISTA_TOL_FINAL <- 1e-6
FISTA_MIN_ITER_FINAL <- 500L

FISTA_CHECK_EVERY <- 25L
FISTA_PROGRESS_EVERY <- 100L
FISTA_VERBOSE <- env_flag("SIM_FISTA_VERBOSE", TRUE)

# In addition to weight change, v14 records objective change, PRE-prediction
# change, and a projected-gradient mapping norm. These are diagnostics rather
# than extra tuning targets.
# Pre-only Gneiting nonseparable space-time kriging -> ordinary SCM benchmark --
# This benchmark directly addresses the alternative strategy:
#   (1) impute missing PRE-treatment target outcomes using only PRE-treatment
#       observations from untreated controls + observed target PRE cells, then
#   (2) apply ordinary (lambda=0) SCM to the pseudo-complete panel.
#
# Residual dependence follows the Gneiting nonseparable class
#   R(h,u) = exp[-(h/phi_s)^a_s / {1+(u/phi_t)^a_t}^{gamma*a_s/2}]
#            / {1+(u/phi_t)^a_t}.
# We fix a_s=a_t=1 and tune spatial scale, temporal scale, gamma in {0,.5,1},
# and nugget using PRE marginal likelihood only. gamma=0 is the separable
# boundary of this class. Legacy SIM_RUN_STK_* flags remain accepted.
RUN_GNEITING_SCM_BENCHMARK <- env_flag(
  "SIM_RUN_GNEITING_SCM", env_flag("SIM_RUN_STK_SCM", TRUE)
)
GNK_MAX_TUNING_OBS <- 350L
GNK_SPACE_MULTIPLIERS <- c(0.03125, 0.0625, 0.125, 0.25, 0.5, 1.5, 4)
GNK_TIME_RANGES_YEARS <- c(0.5, 1.5, 4, 8, 12, 24, 48, 96, 192, 384)
GNK_SEP_GRID <- c(0, 0.5, 1)
GNK_NUGGET_RATIOS <- c(0, 0.01, 0.15)
GNK_POWER_S <- 1
GNK_POWER_T <- 1
GNK_JITTER <- 1e-8
GNK_SEED <- 20260916L

# v14 comparison benchmarks ---------------------------------------------------
# 1) PRE Gneiting nonseparable kriging -> ordinary SCM (two-stage benchmark; PRE information only)
# 2) direct Gneiting nonseparable kriging, ONE-SIDED in calendar time:
#      - covariance hyperparameters are tuned using PRE information only;
#      - target POST year t is predicted using untreated controls only through t
#        plus observed target PRE outcomes; controls after t are never used.
# 3) PRE spCF -> ordinary SCM (two-stage benchmark; PRE information only)
# 4) direct spCF with the same ONE-SIDED information rule as direct Gneiting nonseparable kriging.
#    spCF is the scalable dynamic space-time alternative.
#
# PRE-imputation methods may use the full PRE period to reconstruct missing PRE
# cells, because every such observation is available before treatment begins.
RUN_DIRECT_GNEITING_BENCHMARK <- env_flag(
  "SIM_RUN_DIRECT_GNEITING", env_flag("SIM_RUN_DIRECT_STK", TRUE)
)
RUN_SPCF_SCM_BENCHMARK <- env_flag("SIM_RUN_SPCF_SCM", FALSE)
RUN_DIRECT_SPCF_BENCHMARK <- env_flag("SIM_RUN_DIRECT_SPCF", FALSE)

# Strong fairness benchmark: repeat both Gneiting kriging and spCF with the same safe
# PRE economic proxy variables in the mean/fixed-effect component.  The MAIN
# Gneiting/spCF benchmark remains spatial+temporal only.  Econ-X does NOT change the
# spatial covariance/distance itself; it only gives the competing method access
# to observed PRE economic information so the results cannot be attributed to
# withholding usable covariates.
RUN_ECON_X_BENCHMARKS <- env_flag("SIM_RUN_ECON_X", TRUE)

# Keep the scientific roles explicit.  Spatial-only is the main benchmark;
# Econ-X is a separately labelled strong benchmark.
MAIN_BENCHMARK_USE_ECON_COVARIATES <- FALSE

# spCF settings. cf_dglm_hv selects coarse-to-fine spatial scales by location-
# level holdout validation; cf_dglm refits and predicts with a dynamic AR(1)
# space-time cascade.  The code is wrapped in tryCatch so the rest of v14 still
# runs if spCF is unavailable.
SPCF_MIN_VERSION <- "0.2.0"
SPCF_TRAIN_RATIO <- 0.80
SPCF_ALPHA <- 0.90
SPCF_KERNEL <- "exp"
SPCF_SEED <- 20260919L

# Avoid automatic package installation on managed/offline machines.  If TRUE,
# v14 will try install.packages("spCF") only when a spCF benchmark is requested.
SPCF_AUTO_INSTALL <- FALSE

# ---- 2. Load prepared dataset -----------------------------------------------
dataset <- readRDS(DATASET_RDS)
if (is.null(dataset$schema_version) || dataset$schema_version != "M1_LP_spatial_scm_dataset_v1") {
  warning("Dataset schema version differs from the version expected by this script.")
}

study_area <- dataset$study_area
all_points <- dataset$all_points
target_points <- dataset$target_points
target_meta <- dataset$target_meta

YEARS <- as.integer(dataset$config$years)
PERIOD_PRE <- as.integer(dataset$config$period_pre)
PERIOD_POST <- as.integer(dataset$config$period_post)

price_cols_all <- paste0("price_", YEARS)
price_cols_pre <- paste0("price_", PERIOD_PRE)
price_cols_post <- paste0("price_", PERIOD_POST)

if (!all(price_cols_all %in% names(all_points))) {
  stop("Prepared dataset does not contain all expected price_YYYY columns.")
}
if (!all(CV_HOLDOUT_YEARS %in% PERIOD_PRE)) {
  stop("CV_HOLDOUT_YEARS must be contained in PERIOD_PRE.")
}

cat("Prepared dataset loaded:", DATASET_RDS, "\n")
cat("Targets:", nrow(target_points), "\n")

# ---- 3. Prepare donor pool ---------------------------------------------------
control_candidates <- all_points %>%
  dplyr::filter(stringr::str_detect(group_type, "Control")) %>%
  dplyr::filter(dplyr::if_all(dplyr::all_of(price_cols_all), ~ !is.na(.) & . > 0))

# remove flat pre-period series
control_mat_pre_raw <- as.matrix(sf::st_drop_geometry(control_candidates)[, price_cols_pre])
pre_sd <- apply(log(control_mat_pre_raw), 1, sd, na.rm = TRUE)
control_candidates <- control_candidates[is.finite(pre_sd) & pre_sd > 0, ]

reduce_donor_pool_pre <- function(control_sf, max_donors = 200, k_clusters = 20) {
  if (nrow(control_sf) <= max_donors) return(control_sf)

  z <- sf::st_drop_geometry(control_sf)
  X <- log(as.matrix(z[, price_cols_pre]))
  X <- sweep(X, 1, X[, 1], FUN = "-")  # pre-period log change from 1994
  X <- scale(X)
  X[!is.finite(X)] <- 0

  k_use <- min(k_clusters, nrow(X), max_donors)
  km <- stats::kmeans(X, centers = k_use, nstart = 25, iter.max = 100)

  keep <- integer(0)
  per_cluster <- ceiling(max_donors / k_use)
  for (g in seq_len(k_use)) {
    idx <- which(km$cluster == g)
    if (length(idx) == 0) next
    ctr <- km$centers[g, , drop = FALSE]
    d2 <- rowSums((X[idx, , drop = FALSE] - matrix(ctr, nrow = length(idx), ncol = ncol(X), byrow = TRUE))^2)
    keep <- c(keep, idx[order(d2)][seq_len(min(per_cluster, length(idx)))])
  }
  keep <- unique(keep)[seq_len(min(max_donors, length(unique(keep))))]
  control_sf[keep, ]
}

control_donors <- reduce_donor_pool_pre(
  control_candidates,
  max_donors = MAX_DONORS,
  k_clusters = DONOR_KMEANS_CLUSTERS
)
cat("Treatment targets:", nrow(target_points), "\n")
cat("Control donors:", nrow(control_donors), "\n")

readr::write_csv(
  sf::st_drop_geometry(control_donors) %>% dplyr::select(point_id, original_id),
  file.path(OUTPUT_DIR, "donor_ids.csv")
)

# ---- 4. Build matrices ------------------------------------------------------
target_df <- target_points %>% sf::st_drop_geometry() %>%
  dplyr::arrange(match(point_id, target_meta$point_id))
control_df <- control_donors %>% sf::st_drop_geometry()

# Ensure target_meta uses the exact target_df order
target_meta <- target_meta %>% dplyr::arrange(match(point_id, target_df$point_id))
stopifnot(identical(target_meta$point_id, target_df$point_id))

Y_target_all_raw <- as.matrix(target_df[, price_cols_all])
Y_target_all <- log(Y_target_all_raw)
Y_target_all[!is.finite(Y_target_all)] <- NA_real_
rownames(Y_target_all) <- target_df$point_id
colnames(Y_target_all) <- YEARS

Y_control_all_raw <- as.matrix(control_df[, price_cols_all])
Y_control_all <- log(Y_control_all_raw)
if (any(!is.finite(Y_control_all))) stop("Control donor matrix contains non-finite log prices.")
rownames(Y_control_all) <- control_df$point_id
colnames(Y_control_all) <- YEARS

pre_pos <- match(PERIOD_PRE, YEARS)
post_pos <- match(PERIOD_POST, YEARS)
Yt_pre <- Y_target_all[, pre_pos, drop = FALSE]                 # N x Tpre
Yc_pre <- t(Y_control_all[, pre_pos, drop = FALSE])             # Tpre x J
Yc_all <- t(Y_control_all)                                      # Tall x J

N <- nrow(Yt_pre)
J <- ncol(Yc_pre)

# ---- 4b. PRE economic covariates ---------------------------------------------
# Economic similarity is computed only from safe PRE variables. v14 uses a
# shrinkage-Mahalanobis distance so correlated variables do not each receive an
# independent tuning parameter.
missing_econ <- setdiff(ECON_FEATURES, names(target_meta))
if (length(missing_econ) > 0) {
  stop(
    "Missing PRE economic feature(s) in target_meta: ",
    paste(missing_econ, collapse = ", "),
    "\nRe-run the v14 synthetic generator or provide PRE-only economic covariates."
  )
}

has_pre_econ <- all(vapply(
  target_meta[ECON_FEATURES],
  function(z) all(is.finite(z)),
  logical(1)
))
if (!has_pre_econ) {
  stop("ECON_FEATURES contain missing/non-finite values. v14 requires complete safe PRE covariates.")
}
cat("PRE economic covariates available:", paste(ECON_FEATURES, collapse = ", "), "\n")

prepare_econ_metric <- function(meta, feature_cols = ECON_FEATURES,
                                shrinkage = ECON_COV_SHRINKAGE,
                                ridge = ECON_COV_RIDGE) {
  X <- as.matrix(meta[, feature_cols, drop = FALSE])
  storage.mode(X) <- "double"
  mu <- colMeans(X)
  ss <- apply(X, 2, stats::sd)
  ss[!is.finite(ss) | ss <= 0] <- 1
  Z <- sweep(sweep(X, 2, mu, "-"), 2, ss, "/")

  S <- stats::cov(Z)
  if (length(feature_cols) == 1L) S <- matrix(S, 1, 1)
  D <- diag(diag(S), nrow = ncol(S), ncol = ncol(S))
  S_shrink <- (1 - shrinkage) * S + shrinkage * D
  S_shrink <- S_shrink + diag(ridge, ncol(S_shrink))
  precision <- tryCatch(
    solve(S_shrink),
    error = function(e) solve(S_shrink + diag(1e-4, ncol(S_shrink)))
  )

  list(
    Z = Z,
    center = mu,
    scale = ss,
    covariance = S,
    covariance_shrunk = S_shrink,
    precision = precision,
    feature_cols = feature_cols,
    shrinkage = shrinkage,
    ridge = ridge
  )
}

econ_metric <- prepare_econ_metric(target_meta)

# Persist the economic metric so the Mahalanobis distance is fully auditable.
# These are PRE-only descriptive quantities; no treatment/post/truth information
# enters the metric.
readr::write_csv(
  tibble::tibble(
    feature = ECON_FEATURES,
    center = as.numeric(econ_metric$center),
    scale = as.numeric(econ_metric$scale)
  ),
  file.path(OUTPUT_DIR, "economic_metric_scaling.csv")
)
write_metric_matrix <- function(M, filename) {
  z <- as.data.frame(M, check.names = FALSE)
  z <- tibble::rownames_to_column(z, "feature")
  readr::write_csv(z, file.path(OUTPUT_DIR, filename))
}
rownames(econ_metric$covariance) <- colnames(econ_metric$covariance) <- ECON_FEATURES
rownames(econ_metric$covariance_shrunk) <- colnames(econ_metric$covariance_shrunk) <- ECON_FEATURES
rownames(econ_metric$precision) <- colnames(econ_metric$precision) <- ECON_FEATURES
write_metric_matrix(econ_metric$covariance, "economic_metric_covariance.csv")
write_metric_matrix(econ_metric$covariance_shrunk, "economic_metric_covariance_shrunk.csv")
write_metric_matrix(econ_metric$precision, "economic_metric_precision.csv")

mahalanobis_edge_distance <- function(Z, precision, i, k) {
  DZ <- Z[i, , drop = FALSE] - Z[k, , drop = FALSE]
  sqrt(pmax(rowSums((DZ %*% precision) * DZ), 0))
}

# ---- 5. Geography + economic-similarity graph -------------------------------
# DESIGN:
#   (i) geographic kNN defines candidate local edges;
#   (ii) shrinkage-Mahalanobis PRE economic distance reweights those edges;
#   (iii) mean(a_ik)=1 so lambda remains comparable across beta_econ values.
#
# a_ik = exp[- d_geo/h_geo - beta_econ * d_econ/h_econ].
# beta_econ=0 is the geography-only nested model.
make_paper_graph <- function(meta, k = 10, beta_econ = 0,
                             normalize_a = TRUE,
                             econ_metric_obj = econ_metric) {
  n <- nrow(meta)
  if (n < 2) stop("At least two treatment targets are needed.")
  k_eff <- min(k, n - 1)

  coords <- as.matrix(meta[, c("X_m", "Y_m")])
  knn <- FNN::get.knn(coords, k = k_eff)
  # FNN matrices are N x k. Flatten row-major to match edge_i.
  edge_i <- rep(seq_len(n), each = k_eff)
  edge_k <- as.vector(t(knn$nn.index))
  geo_dist_knn <- as.vector(t(knn$nn.dist))

  geo_dist <- sqrt(rowSums(
    (coords[edge_i, , drop = FALSE] - coords[edge_k, , drop = FALSE])^2
  ))
  graph_indexing_max_abs_error_m <- max(abs(geo_dist - geo_dist_knn), na.rm = TRUE)
  if (!is.finite(graph_indexing_max_abs_error_m) || graph_indexing_max_abs_error_m > 1e-6) {
    stop("kNN graph indexing check failed: neighbor indices/distances are misaligned.")
  }
  h_geo <- median(geo_dist[is.finite(geo_dist) & geo_dist > 0], na.rm = TRUE)
  if (!is.finite(h_geo) || h_geo <= 0) h_geo <- 1
  geo_std <- geo_dist / h_geo

  econ_dist <- mahalanobis_edge_distance(
    econ_metric_obj$Z, econ_metric_obj$precision, edge_i, edge_k
  )
  h_econ <- median(econ_dist[is.finite(econ_dist) & econ_dist > 0], na.rm = TRUE)
  if (!is.finite(h_econ) || h_econ <= 0) h_econ <- 1
  econ_std <- econ_dist / h_econ

  a_raw <- exp(-geo_std - beta_econ * econ_std)

  edges <- tibble::tibble(
    i = edge_i, k = edge_k,
    geo_dist_m = geo_dist,
    econ_mahalanobis = econ_dist,
    geo_dist_std = geo_std,
    econ_dist_std = econ_std,
    a_raw = a_raw
  ) %>%
    dplyr::filter(i != k) %>%
    dplyr::mutate(i2 = pmin(i, k), k2 = pmax(i, k)) %>%
    dplyr::group_by(i2, k2) %>%
    dplyr::summarise(
      geo_dist_m = mean(geo_dist_m),
      econ_mahalanobis = mean(econ_mahalanobis),
      geo_dist_std = mean(geo_dist_std),
      econ_dist_std = mean(econ_dist_std),
      a_raw = mean(a_raw),
      .groups = "drop"
    ) %>%
    dplyr::rename(i = i2, k = k2)

  edges$a <- edges$a_raw
  if (normalize_a) {
    ma <- mean(edges$a, na.rm = TRUE)
    if (is.finite(ma) && ma > 0) edges$a <- edges$a / ma
  }

  E <- nrow(edges)
  Dg <- Matrix::sparseMatrix(
    i = rep(seq_len(E), each = 2),
    j = as.vector(t(cbind(edges$i, edges$k))),
    x = as.vector(t(cbind(sqrt(edges$a), -sqrt(edges$a)))),
    dims = c(E, n)
  )

  list(
    edges = edges,
    Dg = Dg,
    h_geo = h_geo,
    h_econ = h_econ,
    beta_econ = beta_econ,
    econ_used = beta_econ > 0,
    econ_features = econ_metric_obj$feature_cols,
    econ_cov_shrinkage = econ_metric_obj$shrinkage,
    directed_knn_median_m = median(geo_dist_knn, na.rm = TRUE),
    graph_indexing_max_abs_error_m = graph_indexing_max_abs_error_m
  )
}

# ---- 6. Native sparse OSQP estimator ----------------------------------------
# Why not CVXR here?
# With N ~= 1,500 and J ~= 200, CVXR's canonicalized QP can lead the direct
# OSQP LDL solver to build a KKT factorization whose fill-in exceeds integer
# indexing limits. That can be reported as "problem seems non-convex" even
# though this objective is convex.
#
# This implementation keeps the problem sparse by introducing one residual
# variable per observed target-pre cell. Thus the fit term is represented by
# sparse linear equations instead of dense J x J Hessian blocks. OSQP's
# indirect CG linear solver then avoids the large sparse LDL factorization.

calc_losses_from_W <- function(W_hat, Yt, Yc, graph_obj) {
  site_mse <- numeric(0)
  for (i in seq_len(nrow(Yt))) {
    obs <- which(is.finite(Yt[i, ]))
    if (length(obs) == 0) next
    pred <- as.numeric(Yc[obs, , drop = FALSE] %*% W_hat[i, ])
    site_mse <- c(site_mse, mean((Yt[i, obs] - pred)^2))
  }
  fit_loss <- if (length(site_mse) == 0) NA_real_ else mean(site_mse)

  smooth_loss <- if (nrow(graph_obj$edges) == 0) 0 else {
    DW <- as.matrix(graph_obj$Dg %*% W_hat)
    sum(DW^2) / sum(graph_obj$edges$a)
  }
  ridge_loss <- mean(rowSums(W_hat^2))
  list(fit_loss = fit_loss, smooth_loss = smooth_loss, ridge_loss = ridge_loss)
}

# Row-wise Euclidean projection onto the probability simplex.
# Pure-R implementation: robust on Windows and requires no compiled add-on.
project_simplex_vec <- function(v) {
  u <- sort(v, decreasing = TRUE)
  cssv <- cumsum(u) - 1
  ind <- seq_along(u)
  rho_idx <- which(u - cssv / ind > 0)
  if (length(rho_idx) == 0) return(rep(1 / length(v), length(v)))
  rho0 <- max(rho_idx)
  theta <- cssv[rho0] / rho0
  pmax(v - theta, 0)
}

project_rows_simplex <- function(M) {
  # vapply returns J x N; transpose back to N x J.
  t(vapply(seq_len(nrow(M)), function(i) project_simplex_vec(M[i, ]),
           numeric(ncol(M))))
}

fit_smooth_scm <- function(Yt_train, Yc_train, graph_obj,
                           lambda = 0, rho = 0,
                           solver = "FISTA", verbose = FALSE,
                           W_start = NULL,
                           max_iter = FISTA_MAX_ITER_CV,
                           tol = FISTA_TOL_CV,
                           min_iter = FISTA_MIN_ITER_CV,
                           progress_every = FISTA_PROGRESS_EVERY,
                           fit_label = "FISTA") {
  N0 <- nrow(Yt_train)
  J0 <- ncol(Yc_train)

  mask <- is.finite(Yt_train)
  n_obs_site <- rowSums(mask)
  active <- n_obs_site > 0
  n_fit_sites <- sum(active)
  if (n_fit_sites == 0) stop("No treatment site has training pre-period observations.")

  Yobs <- Yt_train
  Yobs[!mask] <- 0

  Lg <- Matrix::crossprod(graph_obj$Dg)
  sum_a <- sum(graph_obj$edges$a)
  if (!is.finite(sum_a) || sum_a <= 0) sum_a <- 1

  row_norm2_Yc <- rowSums(Yc_train^2)
  L_fit <- 2 * max(row_norm2_Yc, na.rm = TRUE) / n_fit_sites
  weighted_degree <- as.numeric(Matrix::diag(Lg))
  L_smooth <- if (lambda > 0) {
    4 * lambda * max(weighted_degree, na.rm = TRUE) / sum_a
  } else 0
  L_ridge <- 2 * (rho + NUMERICAL_RIDGE) / N0
  L_total <- L_fit + L_smooth + L_ridge
  if (!is.finite(L_total) || L_total <= 0) L_total <- 1
  step <- 0.95 / L_total

  used_warm_start <- !is.null(W_start) &&
    all(dim(W_start) == c(N0, J0)) && all(is.finite(W_start))
  if (used_warm_start) {
    W <- project_rows_simplex(W_start)
  } else {
    W <- matrix(1 / J0, nrow = N0, ncol = J0)
  }
  Z <- W
  t_acc <- 1

  calc_obj_fast <- function(Wx) {
    pred <- Wx %*% t(Yc_train)
    err <- pred - Yobs
    err[!mask] <- 0
    fit_site <- rowSums(err^2)
    fit_val <- mean(fit_site[active] / n_obs_site[active])
    smooth_val <- if (lambda > 0) {
      DW <- graph_obj$Dg %*% Wx
      lambda * sum(DW^2) / sum_a
    } else 0
    ridge_val <- (rho + NUMERICAL_RIDGE) * sum(Wx^2) / N0
    fit_val + smooth_val + ridge_val
  }

  calc_grad <- function(Wx) {
    pred <- Wx %*% t(Yc_train)
    E <- pred - Yobs
    E[!mask] <- 0
    row_scale <- numeric(N0)
    row_scale[active] <- 1 / (n_fit_sites * n_obs_site[active])
    E <- E * row_scale
    grad <- 2 * (E %*% Yc_train)
    if (lambda > 0) {
      grad <- grad + (2 * lambda / sum_a) * as.matrix(Lg %*% Wx)
    }
    if (rho + NUMERICAL_RIDGE > 0) {
      grad <- grad + (2 * (rho + NUMERICAL_RIDGE) / N0) * Wx
    }
    grad
  }

  fit_start <- Sys.time()
  last_obj <- calc_obj_fast(W)
  last_check_obj <- last_obj
  last_check_pred <- W %*% t(Yc_train)
  converged <- FALSE
  iter_used <- 0L
  rel_change <- Inf
  obj_rel_change <- Inf
  pred_rel_change <- Inf

  if (verbose || FISTA_VERBOSE) {
    cat(sprintf(
      "  [%s] start | max.iter=%d | min.iter=%d | tol=%.2g | warm.start=%s | step=%.3g\n",
      fit_label, max_iter, min_iter, tol, ifelse(used_warm_start, "yes", "no"), step
    ))
  }

  for (iter in seq_len(max_iter)) {
    gradZ <- calc_grad(Z)
    W_new <- project_rows_simplex(Z - step * gradZ)
    rel_change <- sqrt(sum((W_new - W)^2)) / max(1, sqrt(sum(W^2)))

    t_new <- (1 + sqrt(1 + 4 * t_acc^2)) / 2
    Z_new <- W_new + ((t_acc - 1) / t_new) * (W_new - W)

    # Adaptive FISTA restart (O'Donoghue-Candes gradient restart).
    # IMPORTANT: use the CURRENT extrapolated point Z, not Z_new.
    # Earlier pre-v13 code tested (Z_new-W_new)'(W_new-W)>0; because
    # Z_new-W_new is a positive multiple of W_new-W, that condition is
    # almost always true and therefore reset the momentum every iteration.
    # In effect the old loop was projected gradient descent rather than FISTA,
    # which explains the repeated max.iter stops in the uploaded run.
    restart_now <- sum((Z - W_new) * (W_new - W)) > 0
    if (isTRUE(restart_now)) {
      t_new <- 1
      Z_new <- W_new
    }

    W <- W_new
    Z <- Z_new
    t_acc <- t_new
    iter_used <- iter

    do_check <- (iter %% FISTA_CHECK_EVERY == 0L || iter == 1L)
    do_progress <- (iter %% progress_every == 0L || iter == 1L)

    if (do_check) {
      obj_now <- calc_obj_fast(W)
      pred_now <- W %*% t(Yc_train)
      obj_rel_change <- abs(obj_now - last_check_obj) / max(1, abs(last_check_obj))
      pred_rel_change <- sqrt(sum((pred_now - last_check_pred)^2)) /
        max(1, sqrt(sum(last_check_pred^2)))
      last_obj <- obj_now
      last_check_obj <- obj_now
      last_check_pred <- pred_now

      if ((verbose || FISTA_VERBOSE) && do_progress) {
        elapsed_sec <- as.numeric(difftime(Sys.time(), fit_start, units = "secs"))
        sec_per_iter <- elapsed_sec / iter
        upper_eta_sec <- sec_per_iter * (max_iter - iter)
        cat(sprintf(
          paste0("  [%s] iter %d / %d | elapsed %.2f min | max-iter ETA %.2f min | ",
                 "obj %.8g | w.change %.3g | pred.change %.3g | obj.change %.3g\n"),
          fit_label, iter, max_iter, elapsed_sec / 60, upper_eta_sec / 60,
          obj_now, rel_change, pred_rel_change, obj_rel_change
        ))
      }

      # Keep the original, conservative stopping rule based on the primal weights.
      # Prediction/objective stability are saved separately for interpretation.
      if (rel_change < tol && iter >= min_iter) {
        converged <- TRUE
        break
      }
    }
  }

  # Projected-gradient mapping: zero is a first-order KKT condition for the
  # simplex-constrained smooth objective. This is more informative than weight
  # change alone when the SCM solution is nearly non-unique.
  grad_final <- calc_grad(W)
  W_pg <- project_rows_simplex(W - step * grad_final)
  pg_norm <- sqrt(sum(((W - W_pg) / step)^2)) / max(1, sqrt(sum(W^2)))

  elapsed_sec <- as.numeric(difftime(Sys.time(), fit_start, units = "secs"))
  if (verbose || FISTA_VERBOSE) {
    cat(sprintf(
      paste0("  [%s] %s at iter %d | elapsed %.2f min | final w.change %.3g | ",
             "pred.change %.3g | obj.change %.3g | PG %.3g\n"),
      fit_label, ifelse(converged, "converged", "stopped at max.iter"),
      iter_used, elapsed_sec / 60, rel_change, pred_rel_change,
      obj_rel_change, pg_norm
    ))
  }

  rownames(W) <- target_meta$point_id
  colnames(W) <- control_df$point_id
  losses <- calc_losses_from_W(W, Yt_train, Yc_train, graph_obj)

  # v14: retain a lightweight per-solve runtime ledger.  This has no effect on
  # optimization and is used only to diagnose Monte Carlo cost.
  runtime_fit_counter <<- runtime_fit_counter + 1L
  runtime_fit_log[[runtime_fit_counter]] <<- tibble::tibble(
    fit_id = runtime_fit_counter,
    fit_label = as.character(fit_label),
    lambda = as.numeric(lambda),
    rho = as.numeric(rho),
    elapsed_sec = as.numeric(elapsed_sec),
    elapsed_min = as.numeric(elapsed_sec) / 60,
    fista_iter = as.integer(iter_used),
    converged = as.logical(converged),
    status = if (converged) "solved_fista" else "max_iter_fista",
    warm_start_used = as.logical(used_warm_start)
  )

  list(
    W = W,
    status = if (converged) "solved_fista" else "max_iter_fista",
    value = last_obj,
    fit_loss = losses$fit_loss,
    smooth_loss = losses$smooth_loss,
    ridge_loss = losses$ridge_loss,
    lambda = lambda, rho = rho,
    fista_iter = iter_used,
    fista_min_iter = min_iter,
    fista_converged = converged,
    fista_step = step,
    fista_rel_change = rel_change,
    fista_pred_rel_change = pred_rel_change,
    fista_obj_rel_change = obj_rel_change,
    projected_gradient_norm = pg_norm,
    elapsed_sec = elapsed_sec,
    warm_start_used = used_warm_start
  )

}

# ---- 6c. Native sparse OSQP exact-QP solver for selected final fits ----------
ensure_osqp_available <- function() {
  if (requireNamespace("osqp", quietly = TRUE)) return(TRUE)
  if (isTRUE(NATIVE_OSQP_INSTALL_IF_MISSING)) {
    cat("Package 'osqp' is not installed. Attempting installation from CRAN...\n")
    try(utils::install.packages("osqp"), silent = TRUE)
  }
  requireNamespace("osqp", quietly = TRUE)
}

write_native_osqp_status <- function(prefix, stage, status = NA_character_,
                                     message = NA_character_, elapsed_sec = NA_real_,
                                     objective = NA_real_, n_var = NA_integer_,
                                     n_con = NA_integer_, nnz_P = NA_integer_,
                                     nnz_A = NA_integer_, simplex_error = NA_real_,
                                     min_weight = NA_real_) {
  readr::write_csv(
    tibble::tibble(
      timestamp = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
      prefix = prefix, stage = stage, osqp_status = status, message = message,
      elapsed_sec = elapsed_sec, elapsed_min = elapsed_sec / 60,
      objective_recalculated = objective, n_variables = n_var,
      n_constraints = n_con, nnz_P = nnz_P, nnz_A = nnz_A,
      max_simplex_error = simplex_error, min_weight = min_weight
    ),
    file.path(OUTPUT_DIR, paste0(prefix, "_status.csv"))
  )
}

fit_smooth_scm_native_osqp <- function(Yt_train, Yc_train, graph_obj,
                                       lambda = 0, rho = 0,
                                       status_prefix = "authoritative_exact_qp",
                                       fit_label = "Native sparse OSQP") {
  t0 <- Sys.time()
  fail <- function(stage, status, message, dims = list()) {
    elapsed <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
    write_native_osqp_status(
      status_prefix, stage, status, message, elapsed_sec = elapsed,
      n_var = if (!is.null(dims$n_var)) dims$n_var else NA_integer_,
      n_con = if (!is.null(dims$n_con)) dims$n_con else NA_integer_,
      nnz_P = if (!is.null(dims$nnz_P)) dims$nnz_P else NA_integer_,
      nnz_A = if (!is.null(dims$nnz_A)) dims$nnz_A else NA_integer_
    )
    list(
      ok = FALSE, W = NULL, status = paste0("FAILED_NATIVE_OSQP:", status),
      osqp_status = status, message = message, solver_family = "OSQP_NATIVE",
      value = NA_real_, fit_loss = NA_real_, smooth_loss = NA_real_, ridge_loss = NA_real_,
      lambda = lambda, rho = rho, elapsed_sec = elapsed, osqp_iter = NA_integer_,
      exact_qp_success = FALSE, fista_iter = NA_integer_, fista_min_iter = NA_integer_,
      fista_converged = NA, fista_step = NA_real_, fista_rel_change = NA_real_,
      fista_pred_rel_change = NA_real_, fista_obj_rel_change = NA_real_,
      projected_gradient_norm = NA_real_, warm_start_used = FALSE
    )
  }

  if (!isTRUE(USE_NATIVE_OSQP_FINAL)) {
    return(fail("SKIPPED", "DISABLED_BY_USER", "SIM_USE_NATIVE_OSQP_FINAL is FALSE"))
  }
  if (!ensure_osqp_available()) {
    return(fail("PACKAGE_CHECK", "OSQP_PACKAGE_UNAVAILABLE",
                "R package 'osqp' is unavailable and installation did not succeed."))
  }

  N0 <- nrow(Yt_train); J0 <- ncol(Yc_train)
  obs_idx <- which(is.finite(Yt_train), arr.ind = TRUE)
  if (nrow(obs_idx) == 0L) return(fail("INPUT_CHECK", "NO_OBSERVED_PRE", "No observed target-PRE cells."))
  site_idx <- as.integer(obs_idx[, 1]); time_idx <- as.integer(obs_idx[, 2])
  M0 <- length(site_idx); NW <- N0 * J0; NV <- NW + M0
  n_obs_site <- tabulate(site_idx, nbins = N0)
  active <- n_obs_site > 0; n_fit_sites <- sum(active)
  if (n_fit_sites == 0L) return(fail("INPUT_CHECK", "NO_ACTIVE_SITE", "No target has PRE observations."))
  dims <- list(n_var = NV)

  qp <- tryCatch({
    sum_a <- sum(graph_obj$edges$a)
    if (!is.finite(sum_a) || sum_a <= 0) sum_a <- 1
    ridge_coef <- rho + NUMERICAL_RIDGE
    P_w <- Matrix::Diagonal(NW, x = rep(2 * ridge_coef / N0, NW))
    if (lambda > 0 && nrow(graph_obj$edges) > 0) {
      Lg <- Matrix::crossprod(graph_obj$Dg)
      P_w <- P_w + (2 * lambda / sum_a) * (Lg %x% Matrix::Diagonal(J0))
    }
    r_weight <- 1 / (n_fit_sites * n_obs_site[site_idx])
    P_r <- Matrix::Diagonal(M0, x = 2 * r_weight)
    P_full <- Matrix::triu(Matrix::forceSymmetric(Matrix::bdiag(P_w, P_r)))
    P_full <- methods::as(P_full, "CsparseMatrix")
    q_full <- rep(0, NV)

    A_simplex <- Matrix::sparseMatrix(
      i = rep(seq_len(N0), each = J0), j = seq_len(NW), x = 1,
      dims = c(N0, NV)
    )
    A_nonneg <- Matrix::sparseMatrix(
      i = seq_len(NW), j = seq_len(NW), x = 1, dims = c(NW, NV)
    )
    fit_i <- rep(seq_len(M0), each = J0)
    fit_j <- rep((site_idx - 1L) * J0, each = J0) + rep(seq_len(J0), times = M0)
    fit_x <- -as.vector(t(Yc_train[time_idx, , drop = FALSE]))
    A_resid <- Matrix::sparseMatrix(
      i = c(fit_i, seq_len(M0)),
      j = c(fit_j, NW + seq_len(M0)),
      x = c(fit_x, rep(1, M0)), dims = c(M0, NV)
    )
    b_resid <- -Yt_train[cbind(site_idx, time_idx)]
    A_full <- methods::as(rbind(A_simplex, A_nonneg, A_resid), "CsparseMatrix")
    l_full <- c(rep(1, N0), rep(0, NW), b_resid)
    u_full <- c(rep(1, N0), rep(Inf, NW), b_resid)
    list(P = P_full, q = q_full, A = A_full, l = l_full, u = u_full,
         n_con = nrow(A_full), nnz_P = Matrix::nnzero(P_full), nnz_A = Matrix::nnzero(A_full))
  }, error = function(e) e)
  if (inherits(qp, "error")) return(fail("BUILDING_SPARSE_QP", "MATRIX_BUILD_ERROR", conditionMessage(qp), dims))
  dims$n_con <- qp$n_con; dims$nnz_P <- qp$nnz_P; dims$nnz_A <- qp$nnz_A

  settings <- tryCatch(
    osqp::osqpSettings(verbose = FALSE, eps_abs = NATIVE_OSQP_EPS_ABS,
                       eps_rel = NATIVE_OSQP_EPS_REL, max_iter = NATIVE_OSQP_MAX_ITER),
    error = function(e) e
  )
  if (inherits(settings, "error")) return(fail("SETTINGS", "OSQP_SETTINGS_ERROR", conditionMessage(settings), dims))

  cat(sprintf("  [%s] exact native OSQP started | vars=%d constraints=%d\n",
              fit_label, NV, qp$n_con))
  res <- tryCatch({
    model <- osqp::osqp(P = qp$P, q = qp$q, A = qp$A,
                        l = qp$l, u = qp$u, pars = settings)
    if (!is.null(model$Solve) && is.function(model$Solve)) {
      model$Solve()
    } else if ("solve_osqp" %in% getNamespaceExports("osqp")) {
      osqp::solve_osqp(P = qp$P, q = qp$q, A = qp$A,
                       l = qp$l, u = qp$u, pars = settings)
    } else stop("Unsupported osqp R API.")
  }, error = function(e) e)
  if (inherits(res, "error")) return(fail("SOLVING", "OSQP_RUNTIME_ERROR", conditionMessage(res), dims))

  status_txt <- tryCatch(as.character(res$info$status), error = function(e) NA_character_)
  if (!length(status_txt) || is.na(status_txt)) status_txt <- "STATUS_UNAVAILABLE"
  status_norm <- tolower(trimws(status_txt))
  solved_ok <- identical(status_norm, "solved")
  xhat <- tryCatch(as.numeric(res$x), error = function(e) numeric(0))
  if (!solved_ok || length(xhat) != NV || any(!is.finite(xhat))) {
    return(fail("SOLVE_RETURNED", status_txt,
                paste0("OSQP status='", status_txt, "'; solution length=", length(xhat),
                       " expected=", NV), dims))
  }

  W_raw <- matrix(xhat[seq_len(NW)], nrow = N0, ncol = J0, byrow = TRUE)
  simplex_err_raw <- max(abs(rowSums(W_raw) - 1)); min_w_raw <- min(W_raw)
  if (!is.finite(simplex_err_raw) || !is.finite(min_w_raw) ||
      simplex_err_raw > NATIVE_OSQP_CONSTRAINT_TOL || min_w_raw < -NATIVE_OSQP_CONSTRAINT_TOL) {
    return(fail("CONSTRAINT_CHECK", "OSQP_CONSTRAINT_VIOLATION",
                sprintf("max simplex error=%.3g; min weight=%.3g", simplex_err_raw, min_w_raw), dims))
  }

  W_exact <- project_rows_simplex(W_raw)
  rownames(W_exact) <- target_meta$point_id
  colnames(W_exact) <- control_df$point_id
  losses <- calc_losses_from_W(W_exact, Yt_train, Yc_train, graph_obj)
  obj_recalc <- losses$fit_loss + lambda * losses$smooth_loss +
    (rho + NUMERICAL_RIDGE) * losses$ridge_loss
  elapsed <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  iter_used <- tryCatch(as.integer(res$info$iter), error = function(e) NA_integer_)
  projection_rel_F <- sqrt(sum((W_exact - W_raw)^2)) / max(1, sqrt(sum(W_raw^2)))
  write_native_osqp_status(
    status_prefix, "SOLVED", status_txt,
    paste0("projection_relative_F=", signif(projection_rel_F, 5)),
    elapsed_sec = elapsed, objective = obj_recalc, n_var = NV, n_con = qp$n_con,
    nnz_P = qp$nnz_P, nnz_A = qp$nnz_A,
    simplex_error = max(abs(rowSums(W_exact) - 1)), min_weight = min(W_exact)
  )
  cat(sprintf("  [%s] exact native OSQP solved in %.2f min | iter=%s\n",
              fit_label, elapsed / 60, as.character(iter_used)))
  list(
    ok = TRUE, W = W_exact,
    status = paste0("solved_osqp_native_", gsub(" ", "_", status_norm)),
    osqp_status = status_txt, message = "", solver_family = "OSQP_NATIVE",
    value = obj_recalc, fit_loss = losses$fit_loss, smooth_loss = losses$smooth_loss,
    ridge_loss = losses$ridge_loss, lambda = lambda, rho = rho,
    elapsed_sec = elapsed, osqp_iter = iter_used, exact_qp_success = TRUE,
    fista_iter = NA_integer_, fista_min_iter = NA_integer_, fista_converged = NA,
    fista_step = NA_real_, fista_rel_change = NA_real_, fista_pred_rel_change = NA_real_,
    fista_obj_rel_change = NA_real_, projected_gradient_norm = NA_real_, warm_start_used = FALSE
  )
}

fit_final_authoritative <- function(Yt_train, Yc_train, graph_obj, lambda, rho = 0,
                                    status_prefix, fit_label) {
  if (isTRUE(USE_NATIVE_OSQP_FINAL)) {
    ex <- fit_smooth_scm_native_osqp(
      Yt_train, Yc_train, graph_obj, lambda = lambda, rho = rho,
      status_prefix = status_prefix, fit_label = fit_label
    )
    if (isTRUE(ex$ok)) return(ex)
    warning("Authoritative native OSQP final solve failed for ", fit_label,
            ": ", ex$message, ". Falling back to FISTA.")
    if (!isTRUE(NATIVE_OSQP_FALLBACK_TO_FISTA)) {
      stop("Native OSQP final solve failed and SIM_OSQP_FALLBACK_TO_FISTA=FALSE.")
    }
  }
  ff <- fit_smooth_scm(
    Yt_train, Yc_train, graph_obj, lambda = lambda, rho = rho,
    W_start = NULL, max_iter = FISTA_MAX_ITER_FINAL,
    tol = FISTA_TOL_FINAL, min_iter = FISTA_MIN_ITER_FINAL,
    fit_label = paste0(fit_label, " [FISTA fallback]")
  )
  ff$solver_family <- "FISTA_FALLBACK"
  ff$exact_qp_success <- FALSE
  ff$osqp_status <- NA_character_
  ff$osqp_iter <- NA_integer_
  ff
}

# ---- 7. Leakage-free PRE-only hyperparameter selection ----------------------
# The simulation is our reference implementation: all candidate fits use the
# same cold (uniform) initialization. No validation site's PRE outcomes can enter
# through a warm start.
cv_cache <- new.env(parent = emptyenv())
canonical_beta_econ <- function(lambda, beta_econ) {
  if (isTRUE(abs(lambda) < 1e-15)) 0 else beta_econ
}
cv_key <- function(lambda, rho, beta_econ, max_iter, tol, min_iter) {
  beta_econ <- canonical_beta_econ(lambda, beta_econ)
  paste(formatC(lambda, digits = 16, format = "fg"),
        formatC(rho, digits = 16, format = "fg"),
        formatC(beta_econ, digits = 16, format = "fg"),
        max_iter, formatC(tol, digits = 10, format = "fg"), min_iter, sep = "|")
}

summarise_temporal_fit <- function(fit, lambda, rho, beta_econ,
                                   holdout_years = CV_HOLDOUT_YEARS) {
  hold_pos <- match(holdout_years, PERIOD_PRE)
  hold_pos <- hold_pos[!is.na(hold_pos)]
  pred <- fit$W %*% t(Yc_pre[hold_pos, , drop = FALSE])
  truth_cv <- Yt_pre[, hold_pos, drop = FALSE]
  site_mse <- rep(NA_real_, N)
  n_hold <- integer(N)
  residual_cv <- truth_cv - pred
  for (i in seq_len(N)) {
    ok <- which(is.finite(truth_cv[i, ]))
    n_hold[i] <- length(ok)
    if (length(ok) > 0) site_mse[i] <- mean(residual_cv[i, ok]^2)
  }
  tibble::tibble(
    lambda = lambda, rho = rho, beta_econ = beta_econ,
    temporal_rmse = sqrt(mean(site_mse, na.rm = TRUE)),
    temporal_mae_site = mean(sqrt(site_mse), na.rm = TRUE),
    # Signed residual bias: positive means the counterfactual prediction is low.
    temporal_mean_bias_log = mean(residual_cv[is.finite(truth_cv)], na.rm = TRUE),
    temporal_abs_mean_bias_log = abs(temporal_mean_bias_log),
    n_eval_sites = sum(is.finite(site_mse)),
    n_eval_cells = sum(is.finite(truth_cv)),
    mean_holdout_obs = mean(n_hold[n_hold > 0]),
    train_fit_loss = fit$fit_loss,
    smooth_loss = fit$smooth_loss,
    ridge_loss = fit$ridge_loss,
    solver_status = fit$status,
    fista_iter = fit$fista_iter,
    fista_min_iter = fit$fista_min_iter,
    fista_converged = fit$fista_converged,
    fista_rel_change = fit$fista_rel_change,
    fista_pred_rel_change = fit$fista_pred_rel_change,
    fista_obj_rel_change = fit$fista_obj_rel_change,
    projected_gradient_norm = fit$projected_gradient_norm,
    fit_elapsed_min = fit$elapsed_sec / 60,
    warm_start_used = fit$warm_start_used
  )
}

temporal_cv_one <- function(lambda, rho = 0, beta_econ = 0,
                            holdout_years = CV_HOLDOUT_YEARS,
                            W_start = NULL,
                            max_iter = FISTA_MAX_ITER_CV,
                            tol = FISTA_TOL_CV,
                            min_iter = FISTA_MIN_ITER_CV,
                            fit_label = "temporal CV") {
  graph <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = beta_econ)
  hold_pos <- match(holdout_years, PERIOD_PRE)
  hold_pos <- hold_pos[!is.na(hold_pos)]
  Ytrain <- Yt_pre
  Ytrain[, hold_pos] <- NA_real_
  fit <- fit_smooth_scm(
    Ytrain, Yc_pre, graph, lambda = lambda, rho = rho,
    W_start = W_start, max_iter = max_iter, tol = tol, min_iter = min_iter,
    fit_label = fit_label
  )
  list(
    summary = summarise_temporal_fit(fit, lambda, rho, beta_econ, holdout_years),
    W = fit$W, fit = fit
  )
}

run_temporal_cv_cached <- function(lambda, rho = 0, beta_econ = 0,
                                   W_start = NULL,
                                   max_iter = FISTA_MAX_ITER_CV,
                                   tol = FISTA_TOL_CV,
                                   min_iter = FISTA_MIN_ITER_CV,
                                   fit_label = "temporal CV") {
  # Cache only cold-start fits. This prevents a path-dependent warm solution from
  # being silently reused as if it were a comparable candidate.
  use_cache <- is.null(W_start)
  key <- cv_key(lambda, rho, beta_econ, max_iter, tol, min_iter)
  if (use_cache && exists(key, envir = cv_cache, inherits = FALSE)) {
    ans <- get(key, envir = cv_cache, inherits = FALSE)
    ans$cached <- TRUE
    cat(sprintf("  [%s] reused cached cold fit\n", fit_label))
    return(ans)
  }
  ans <- tryCatch(
    temporal_cv_one(lambda, rho, beta_econ, W_start = W_start,
                    max_iter = max_iter, tol = tol, min_iter = min_iter,
                    fit_label = fit_label),
    error = function(e) list(
      summary = tibble::tibble(
        lambda = lambda, rho = rho, beta_econ = beta_econ,
        temporal_rmse = Inf, temporal_mae_site = Inf,
        temporal_mean_bias_log = NA_real_, temporal_abs_mean_bias_log = NA_real_,
        n_eval_sites = 0, n_eval_cells = 0L,
        mean_holdout_obs = NA_real_, train_fit_loss = NA_real_,
        smooth_loss = NA_real_, ridge_loss = NA_real_,
        solver_status = paste("ERROR:", conditionMessage(e)),
        fista_iter = NA_integer_, fista_min_iter = min_iter,
        fista_converged = FALSE, fista_rel_change = NA_real_,
        fista_pred_rel_change = NA_real_, fista_obj_rel_change = NA_real_,
        projected_gradient_norm = NA_real_, fit_elapsed_min = NA_real_,
        warm_start_used = !is.null(W_start)
      ), W = NULL, fit = NULL
    )
  )
  ans$cached <- FALSE
  if (use_cache) assign(key, ans, envir = cv_cache)
  ans
}

# ---- 7a. Fold construction --------------------------------------------------
complete_idx <- which(target_meta$obs_group == "complete_pre")
postonly_idx <- which(target_meta$obs_group == "post_only")

neighbor_anchor_counts <- function(graph_obj, Ytrain, idx) {
  pre_anchor <- rowSums(is.finite(Ytrain)) > 0
  ed <- graph_obj$edges
  vapply(idx, function(ii) {
    nb <- unique(c(ed$k[ed$i == ii], ed$i[ed$k == ii]))
    if (length(nb) == 0) return(0L)
    sum(pre_anchor[nb])
  }, integer(1))
}

# v14 primary pseudo-post-only folds:
#   * use only a small number of validation sites per fold;
#   * select complete-PRE sites whose immediate PRE-anchor count resembles the
#     REAL post-only sites;
#   * distribute selected sites spatially across folds so each fold is scattered.
# Geographic kNN edges do not depend on beta_econ, so anchor COUNT matching
# can safely be based on the beta=0 graph without favoring a tuning candidate.
make_anchor_matched_scattered_folds <- function(indices, k_folds,
                                                sites_per_fold,
                                                n_strata = 10L,
                                                seed = 123L) {
  out <- rep(NA_integer_, N)
  if (length(indices) < k_folds) return(out)

  graph_anchor_ref <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = 0)
  cand_anchor <- neighbor_anchor_counts(graph_anchor_ref, Yt_pre, indices)
  actual_anchor <- if (length(postonly_idx) > 0) {
    neighbor_anchor_counts(graph_anchor_ref, Yt_pre, postonly_idx)
  } else numeric(0)

  n_total <- min(length(indices), as.integer(k_folds * sites_per_fold))
  if (n_total < k_folds) return(out)

  # Match the empirical post-only anchor-count distribution by quantiles. When
  # no actual post-only sites exist, fall back to the candidate distribution.
  anchor_reference <- if (length(actual_anchor) > 0) actual_anchor else cand_anchor
  target_anchor <- as.numeric(stats::quantile(
    anchor_reference,
    probs = seq(0, 1, length.out = n_total),
    type = 1, names = FALSE, na.rm = TRUE
  ))

  set.seed(seed)
  remaining <- seq_along(indices)
  selected_pos <- integer(0)
  for (aa in target_anchor) {
    d <- abs(cand_anchor[remaining] - aa)
    best <- remaining[d == min(d, na.rm = TRUE)]
    # IMPORTANT: sample(x, 1) treats a length-1 numeric x as 1:x in R.
    # Index by sample.int(length(best), 1) so a singleton candidate is kept
    # exactly as that candidate rather than being re-sampled from 1:best.
    pick <- best[sample.int(length(best), 1L)]
    selected_pos <- c(selected_pos, pick)
    remaining <- setdiff(remaining, pick)
  }
  selected <- indices[selected_pos]

  # Spatially intermix the selected sites. K-means is used only to create local
  # strata; cycling fold labels over the stratum-ordered sites keeps fold sizes
  # essentially equal and avoids a contiguous missing block.
  xy <- scale(as.matrix(target_meta[selected, c("X_m", "Y_m")]))
  n_strata <- min(as.integer(n_strata), max(1L, floor(length(selected) / k_folds)))
  set.seed(seed + 1L)
  strata <- if (n_strata > 1L) {
    stats::kmeans(xy, centers = n_strata, nstart = 30, iter.max = 100)$cluster
  } else rep(1L, length(selected))
  strata_values <- sort(unique(strata))
  stratum_order <- if (length(strata_values) <= 1L) {
    strata_values
  } else {
    strata_values[sample.int(length(strata_values), length(strata_values))]
  }
  ord <- unlist(lapply(stratum_order, function(ss) {
    jj <- which(strata == ss)
    if (length(jj) <= 1L) {
      jj
    } else {
      jj[sample.int(length(jj), length(jj))]
    }
  }), use.names = FALSE)
  fold_labels <- rep(seq_len(k_folds), length.out = length(selected))
  out[selected[ord]] <- fold_labels

  attr(out, "selected_indices") <- selected
  attr(out, "candidate_anchor") <- cand_anchor
  attr(out, "actual_postonly_anchor") <- actual_anchor
  attr(out, "graph_anchor_ref") <- graph_anchor_ref
  out
}

make_block_pseudo_folds <- function(indices, k_folds, seed = 456L) {
  out <- rep(NA_integer_, N)
  if (length(indices) < k_folds * 5) return(out)
  xy <- scale(as.matrix(target_meta[indices, c("X_m", "Y_m")]))
  set.seed(seed)
  out[indices] <- stats::kmeans(xy, centers = k_folds, nstart = 30, iter.max = 100)$cluster
  out
}

pseudo_fold_scattered <- make_anchor_matched_scattered_folds(
  complete_idx, PSEUDO_SCATTERED_FOLDS, PSEUDO_SCATTERED_SITES_PER_FOLD,
  PSEUDO_SPATIAL_STRATA, seed = 123L
)
pseudo_fold_block <- make_block_pseudo_folds(
  complete_idx, PSEUDO_BLOCK_STRESS_FOLDS, seed = 456L
)

# Fast-MC final confirmation deliberately recreates the strict 3-fold scattered
# pseudo-post-only design (same construction/seed, normally 3 x 8 sites). This
# is separate from the cheap 2-fold search folds above.
pseudo_fold_final_confirm <- if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) {
  make_anchor_matched_scattered_folds(
    complete_idx, FAST_FINAL_CONFIRM_FOLDS, FAST_FINAL_CONFIRM_SITES_PER_FOLD,
    PSEUDO_SPATIAL_STRATA, seed = 123L
  )
} else {
  rep(NA_integer_, N)
}

# v14 retains the v8 fold-integrity checks. These stop immediately if the scattered pseudo-post-only
# construction does not create the requested number of unique validation sites.
expected_pseudo_total <- min(
  length(complete_idx),
  as.integer(PSEUDO_SCATTERED_FOLDS * PSEUDO_SCATTERED_SITES_PER_FOLD)
)
selected_pseudo_idx <- attr(pseudo_fold_scattered, "selected_indices")
assigned_pseudo_idx <- which(!is.na(pseudo_fold_scattered))

if (length(selected_pseudo_idx) != expected_pseudo_total) {
  stop(
    "Pseudo-scattered fold construction selected ", length(selected_pseudo_idx),
    " unique sites; expected ", expected_pseudo_total, "."
  )
}
if (anyDuplicated(selected_pseudo_idx)) {
  stop("Pseudo-scattered fold construction contains duplicated selected indices.")
}
if (!setequal(selected_pseudo_idx, assigned_pseudo_idx)) {
  stop("Pseudo-scattered fold assignments do not match the selected validation sites.")
}
if (any(!pseudo_fold_scattered[assigned_pseudo_idx] %in% seq_len(PSEUDO_SCATTERED_FOLDS))) {
  stop("Pseudo-scattered fold assignments contain an invalid fold label.")
}

pseudo_fold_n <- tabulate(
  pseudo_fold_scattered[assigned_pseudo_idx],
  nbins = PSEUDO_SCATTERED_FOLDS
)
if (expected_pseudo_total ==
    PSEUDO_SCATTERED_FOLDS * PSEUDO_SCATTERED_SITES_PER_FOLD) {
  if (any(pseudo_fold_n != PSEUDO_SCATTERED_SITES_PER_FOLD)) {
    stop(
      "Pseudo-scattered fold sizes are ", paste(pseudo_fold_n, collapse = ", "),
      "; expected exactly ", PSEUDO_SCATTERED_SITES_PER_FOLD, " per fold."
    )
  }
} else if ((max(pseudo_fold_n) - min(pseudo_fold_n)) > 1L) {
  stop(
    "Pseudo-scattered folds are unexpectedly unbalanced: ",
    paste(pseudo_fold_n, collapse = ", "), "."
  )
}
cat(
  "Pseudo-scattered fold integrity PASS | selected=", expected_pseudo_total,
  " | fold sizes=", paste(pseudo_fold_n, collapse = "/"), "\n", sep = ""
)

if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) {
  final_assigned <- which(!is.na(pseudo_fold_final_confirm))
  final_expected <- min(
    length(complete_idx),
    as.integer(FAST_FINAL_CONFIRM_FOLDS * FAST_FINAL_CONFIRM_SITES_PER_FOLD)
  )
  if (length(final_assigned) != final_expected) {
    stop("Fast final-confirm fold construction assigned ", length(final_assigned),
         " sites; expected ", final_expected, ".")
  }
  final_fold_n <- tabulate(
    pseudo_fold_final_confirm[final_assigned],
    nbins = FAST_FINAL_CONFIRM_FOLDS
  )
  if ((max(final_fold_n) - min(final_fold_n)) > 1L) {
    stop("Fast final-confirm folds are unexpectedly unbalanced: ",
         paste(final_fold_n, collapse = ", "), ".")
  }
  cat("Fast final 3-fold confirmation design PASS | selected=", final_expected,
      " | fold sizes=", paste(final_fold_n, collapse = "/"), "\n", sep = "")
}

fold_assignment_out <- target_meta %>%
  dplyr::transmute(
    point_id, obs_group, X_m, Y_m,
    scattered_fold = pseudo_fold_scattered,
    final_confirm_fold = pseudo_fold_final_confirm,
    block_stress_fold = pseudo_fold_block
  )
readr::write_csv(fold_assignment_out, file.path(OUTPUT_DIR, "cv_pseudo_fold_assignments.csv"))

# Document whether the pseudo validation design actually resembles the real
# post-only anchor environment after masking the selected validation sites.
graph_anchor_design <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = 0)
actual_anchor_design <- if (length(postonly_idx) > 0) {
  neighbor_anchor_counts(graph_anchor_design, Yt_pre, postonly_idx)
} else numeric(0)
anchor_design_rows <- list()
for (ff in seq_len(PSEUDO_SCATTERED_FOLDS)) {
  vi <- which(pseudo_fold_scattered == ff)
  if (length(vi) == 0) next
  Ytmp <- Yt_pre
  Ytmp[vi, ] <- NA_real_
  aa <- neighbor_anchor_counts(graph_anchor_design, Ytmp, vi)
  anchor_design_rows[[length(anchor_design_rows) + 1L]] <- tibble::tibble(
    group = paste0("pseudo_fold_", ff),
    n_sites = length(aa),
    mean_anchor_neighbors = mean(aa),
    median_anchor_neighbors = stats::median(aa),
    min_anchor_neighbors = min(aa),
    max_anchor_neighbors = max(aa)
  )
}
anchor_design_summary <- dplyr::bind_rows(
  if (length(actual_anchor_design) > 0) tibble::tibble(
    group = "actual_post_only",
    n_sites = length(actual_anchor_design),
    mean_anchor_neighbors = mean(actual_anchor_design),
    median_anchor_neighbors = stats::median(actual_anchor_design),
    min_anchor_neighbors = min(actual_anchor_design),
    max_anchor_neighbors = max(actual_anchor_design)
  ) else tibble::tibble(),
  dplyr::bind_rows(anchor_design_rows)
)
readr::write_csv(anchor_design_summary,
                 file.path(OUTPUT_DIR, "cv_pseudo_anchor_matching_summary.csv"))

run_pseudo_config <- function(lambda, beta_econ, pseudo_fold, n_folds,
                              rho = 0, W_start = NULL,
                              max_iter = FISTA_MAX_ITER_CV,
                              tol = FISTA_TOL_CV,
                              min_iter = FISTA_MIN_ITER_CV,
                              label_prefix = "pseudo") {
  graph_r <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = beta_econ)
  rows <- vector("list", n_folds)
  for (f in seq_len(n_folds)) {
    val_idx <- which(pseudo_fold == f)
    if (length(val_idx) == 0) next
    Ytrain <- Yt_pre
    Ytrain[val_idx, ] <- NA_real_
    cat(sprintf("%s | lambda=%.6g beta=%.3g | fold %d/%d | n=%d\n",
                label_prefix, lambda, beta_econ, f, n_folds, length(val_idx)))
    one <- tryCatch({
      fit_f <- fit_smooth_scm(
        Ytrain, Yc_pre, graph_r, lambda = lambda, rho = rho,
        W_start = W_start, max_iter = max_iter, tol = tol, min_iter = min_iter,
        fit_label = sprintf("%s f%d", label_prefix, f)
      )
      pred_f <- fit_f$W[val_idx, , drop = FALSE] %*% t(Yc_pre)
      truth_f <- Yt_pre[val_idx, , drop = FALSE]
      residual_f <- truth_f - pred_f
      site_mse <- apply(residual_f^2, 1, mean, na.rm = TRUE)
      anchors <- neighbor_anchor_counts(graph_r, Ytrain, val_idx)
      tibble::tibble(
        lambda = lambda, beta_econ = beta_econ, rho = rho, fold = f,
        pseudo_rmse = sqrt(mean(site_mse, na.rm = TRUE)),
        # Signed residual bias: positive means the counterfactual prediction is low.
        pseudo_mean_bias_log = mean(residual_f[is.finite(truth_f)], na.rm = TRUE),
        pseudo_abs_mean_bias_log = abs(pseudo_mean_bias_log),
        n_eval_sites = sum(is.finite(site_mse)),
        n_eval_cells = sum(is.finite(truth_f)),
        mean_anchor_neighbors = mean(anchors),
        min_anchor_neighbors = min(anchors),
        solver_status = fit_f$status,
        fista_iter = fit_f$fista_iter,
        fista_converged = fit_f$fista_converged,
        fista_rel_change = fit_f$fista_rel_change,
        fista_pred_rel_change = fit_f$fista_pred_rel_change,
        fista_obj_rel_change = fit_f$fista_obj_rel_change,
        projected_gradient_norm = fit_f$projected_gradient_norm
      )
    }, error = function(e) tibble::tibble(
      lambda = lambda, beta_econ = beta_econ, rho = rho, fold = f,
      pseudo_rmse = Inf, pseudo_mean_bias_log = NA_real_,
      pseudo_abs_mean_bias_log = NA_real_,
      n_eval_sites = 0L, n_eval_cells = 0L,
      mean_anchor_neighbors = NA_real_, min_anchor_neighbors = NA_real_,
      solver_status = paste("ERROR:", conditionMessage(e)),
      fista_iter = NA_integer_, fista_converged = FALSE,
      fista_rel_change = NA_real_, fista_pred_rel_change = NA_real_,
      fista_obj_rel_change = NA_real_, projected_gradient_norm = NA_real_
    ))
    rows[[f]] <- one
  }
  folds <- dplyr::bind_rows(rows)
  if (nrow(folds) == 0) {
    sm <- tibble::tibble(
      lambda = lambda, beta_econ = beta_econ, rho = rho,
      pseudo_postonly_rmse = NA_real_, pseudo_postonly_rmse_sd = NA_real_,
      pseudo_postonly_mean_bias_log = NA_real_,
      pseudo_postonly_abs_mean_bias_log = NA_real_,
      pseudo_eval_sites = 0L, pseudo_eval_cells = 0L,
      mean_anchor_neighbors = NA_real_, min_anchor_neighbors = NA_real_
    )
  } else {
    sm <- tibble::tibble(
      lambda = lambda, beta_econ = beta_econ, rho = rho,
      pseudo_postonly_rmse = mean(folds$pseudo_rmse),
      pseudo_postonly_rmse_sd = stats::sd(folds$pseudo_rmse),
      # Weight fold-level signed biases by the number of evaluated PRE cells.
      pseudo_postonly_mean_bias_log = if (sum(folds$n_eval_cells, na.rm = TRUE) > 0)
        stats::weighted.mean(folds$pseudo_mean_bias_log, folds$n_eval_cells, na.rm = TRUE) else NA_real_,
      pseudo_postonly_abs_mean_bias_log = abs(pseudo_postonly_mean_bias_log),
      pseudo_eval_sites = sum(folds$n_eval_sites),
      pseudo_eval_cells = sum(folds$n_eval_cells),
      mean_anchor_neighbors = mean(folds$mean_anchor_neighbors, na.rm = TRUE),
      min_anchor_neighbors = min(folds$min_anchor_neighbors, na.rm = TRUE)
    )
  }
  list(folds = folds, summary = sm)
}

selection_score_fun <- function(temporal_rmse, pseudo_rmse) {
  ifelse(is.finite(pseudo_rmse),
         CV_WEIGHT_TEMPORAL * temporal_rmse + CV_WEIGHT_PSEUDO * pseudo_rmse,
         temporal_rmse)
}

# ---- 7b. Initial cold-start candidate grid ----------------------------------
graph_ref <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = 0)
Y_ref_train <- Yt_pre
ref_hold_pos <- match(CV_HOLDOUT_YEARS, PERIOD_PRE)
Y_ref_train[, ref_hold_pos] <- NA_real_
cat("Reference fit started at", format(Sys.time(), "%H:%M:%S"), "\n")
fit_ref <- fit_smooth_scm(
  Y_ref_train, Yc_pre, graph_ref, lambda = 0, rho = 0, W_start = NULL,
  max_iter = FISTA_MAX_ITER_CV, tol = FISTA_TOL_CV, min_iter = FISTA_MIN_ITER_CV,
  fit_label = "reference lambda=0"
)
fit_loss_ref <- fit_ref$fit_loss
lambda_base <- max(fit_loss_ref / 2, 1e-8)
rho_base <- max(fit_loss_ref, 1e-8)
cat("Reference training fit loss:", fit_loss_ref, "\n")
cat("lambda_base:", lambda_base, " rho_base:", rho_base, "\n")

ref_ans <- list(summary = summarise_temporal_fit(fit_ref, 0, 0, 0), W = fit_ref$W, fit = fit_ref)
assign(cv_key(0, 0, 0, FISTA_MAX_ITER_CV, FISTA_TOL_CV, FISTA_MIN_ITER_CV),
       ref_ans, envir = cv_cache)

stageA_grid <- tibble::tibble(
  beta_econ = 0,
  lambda = lambda_base * LAMBDA_MULTIPLIERS_INITIAL
)
stageA_res <- vector("list", nrow(stageA_grid))
for (g in seq_len(nrow(stageA_grid))) {
  cat(sprintf("CV Stage A %d/%d | lambda=%.6g beta=0\n",
              g, nrow(stageA_grid), stageA_grid$lambda[g]))
  ans <- run_temporal_cv_cached(
    stageA_grid$lambda[g], 0, 0, W_start = NULL,
    fit_label = sprintf("Stage A %d/%d", g, nrow(stageA_grid))
  )
  stageA_res[[g]] <- ans$summary
}
stageA_table <- dplyr::bind_rows(stageA_res) %>% dplyr::arrange(temporal_rmse)
readr::write_csv(stageA_table, file.path(OUTPUT_DIR, "cv_stageA_geo_lambda.csv"))

# Stage B v14: beta_econ must be explored even when temporal CV alone prefers
# lambda=0. Cross every positive Stage-A lambda with the economic-similarity beta grid. This
# prevents the old logic from silently fixing beta_econ=0 before the
# pseudo-post-only criterion has a chance to contribute.
if (has_pre_econ) {
  stageB_grid <- tidyr::expand_grid(
    lambda = sort(unique(stageA_grid$lambda[stageA_grid$lambda > 0])),
    beta_econ = BETA_ECON_GRID
  )
} else {
  stageB_grid <- stageA_grid
}
stageB_grid <- stageB_grid %>%
  dplyr::mutate(beta_econ = ifelse(abs(lambda) < 1e-15, 0, beta_econ)) %>%
  dplyr::distinct(lambda, beta_econ)
stageB_res <- vector("list", nrow(stageB_grid))
for (g in seq_len(nrow(stageB_grid))) {
  ans <- run_temporal_cv_cached(
    stageB_grid$lambda[g], 0, stageB_grid$beta_econ[g], W_start = NULL,
    fit_label = sprintf("Stage B %d/%d", g, nrow(stageB_grid))
  )
  stageB_res[[g]] <- ans$summary
}
stageB_table <- dplyr::bind_rows(stageB_res) %>% dplyr::arrange(temporal_rmse)
readr::write_csv(stageB_table, file.path(OUTPUT_DIR, "cv_stageB_joint_lambda_station.csv"))
# Keep the old filename as a compatibility output.
readr::write_csv(stageB_table, file.path(OUTPUT_DIR, "cv_stageB_station.csv"))

# Stage C v7: local lambda refinement around the best POSITIVE Stage-B candidate.
# In fast-MC mode this stage is skipped: Stage B already evaluates the reduced
# lambda x beta grid, and local refinement was a material runtime cost with little
# value for repeated Monte Carlo replications. Strict mode is unchanged.
if (FAST_MC_TUNING) {
  stageC_table <- tibble::tibble()
  readr::write_csv(stageC_table, file.path(OUTPUT_DIR, "cv_stageC_local_joint_refinement.csv"))
  readr::write_csv(stageC_table, file.path(OUTPUT_DIR, "cv_stageC_local_refinement.csv"))
} else {
  # still retain a positive center because post-only validation may prefer it.
  stageB_positive <- stageB_table %>%
    dplyr::filter(lambda > 0, is.finite(temporal_rmse)) %>%
    dplyr::arrange(temporal_rmse)
  if (nrow(stageB_positive) > 0) {
    local_center_lambda <- stageB_positive$lambda[1]
  } else {
    local_center_lambda <- lambda_base
  }
  local_lambda <- sort(unique(c(0, local_center_lambda * LOCAL_LAMBDA_FACTORS)))
  if (has_pre_econ) {
    stageC_grid <- dplyr::bind_rows(
      tibble::tibble(lambda = 0, beta_econ = 0),
      tidyr::expand_grid(
        lambda = local_lambda[local_lambda > 0],
        beta_econ = BETA_ECON_GRID
      )
    )
  } else {
    stageC_grid <- tibble::tibble(lambda = local_lambda, beta_econ = 0)
  }
  stageC_grid <- stageC_grid %>% dplyr::distinct(lambda, beta_econ)
  stageC_res <- vector("list", nrow(stageC_grid))
  for (g in seq_len(nrow(stageC_grid))) {
    ans <- run_temporal_cv_cached(
      stageC_grid$lambda[g], 0, stageC_grid$beta_econ[g], W_start = NULL,
      fit_label = sprintf("Stage C %d/%d", g, nrow(stageC_grid))
    )
    stageC_res[[g]] <- ans$summary
  }
  stageC_table <- dplyr::bind_rows(stageC_res) %>% dplyr::arrange(temporal_rmse)
  readr::write_csv(stageC_table, file.path(OUTPUT_DIR, "cv_stageC_local_joint_refinement.csv"))
  # Keep the old filename as a compatibility output.
  readr::write_csv(stageC_table, file.path(OUTPUT_DIR, "cv_stageC_local_refinement.csv"))

}

cv_all_table <- dplyr::bind_rows(stageA_table, stageB_table, stageC_table) %>%
  dplyr::distinct(lambda, beta_econ, .keep_all = TRUE) %>%
  dplyr::arrange(temporal_rmse)
readr::write_csv(cv_all_table, file.path(OUTPUT_DIR, "cv_all_temporal_candidates.csv"))

# Evaluate scattered pseudo-post-only performance for every initial candidate.
pseudo_fold_rows <- list()
pseudo_sum_rows <- list()
for (r in seq_len(nrow(cv_all_table))) {
  out <- run_pseudo_config(
    cv_all_table$lambda[r], cv_all_table$beta_econ[r],
    pseudo_fold_scattered, PSEUDO_SCATTERED_FOLDS,
    W_start = NULL, max_iter = FISTA_MAX_ITER_CV,
    tol = FISTA_TOL_CV, min_iter = FISTA_MIN_ITER_CV,
    label_prefix = sprintf("Pseudo-scattered %d/%d", r, nrow(cv_all_table))
  )
  pseudo_fold_rows[[r]] <- out$folds
  pseudo_sum_rows[[r]] <- out$summary
}
pseudo_table <- dplyr::bind_rows(pseudo_sum_rows)
pseudo_folds_table <- dplyr::bind_rows(pseudo_fold_rows)
readr::write_csv(pseudo_table, file.path(OUTPUT_DIR, "cv_pseudo_postonly_scattered.csv"))
readr::write_csv(pseudo_folds_table, file.path(OUTPUT_DIR, "cv_pseudo_postonly_scattered_folds.csv"))

screening_selection_table <- cv_all_table %>%
  dplyr::left_join(pseudo_table %>% dplyr::select(-rho), by = c("lambda", "beta_econ")) %>%
  dplyr::mutate(
    selection_score = selection_score_fun(temporal_rmse, pseudo_postonly_rmse),
    selection_eligible = if (length(postonly_idx) > 0) lambda > 0 else TRUE
  ) %>%
  dplyr::arrange(selection_score)
readr::write_csv(screening_selection_table,
                 file.path(OUTPUT_DIR, "cv_screening_selection_table.csv"))

# ---- 7c. Strict cold confirmation + adaptive upper-tail expansion -----------
# Include the leading candidates AND the current maximum lambda. This guarantees
# that an upper-edge solution cannot be missed merely because its screening rank
# was just outside the top N.
eligible_screening <- screening_selection_table %>%
  dplyr::filter(selection_eligible, is.finite(selection_score))
if (nrow(eligible_screening) == 0) stop("No identified positive-lambda screening candidate.")
max_initial_lambda <- max(eligible_screening$lambda, na.rm = TRUE)
max_initial_rows <- eligible_screening %>%
  dplyr::filter(lambda == max_initial_lambda, is.finite(selection_score))
# Always cold-confirm the best geography-only candidate as an explicit nested
# benchmark for the value of economic similarity, even if it is not among the
# overall top-N configurations.
best_geo_only_screen <- eligible_screening %>%
  dplyr::filter(abs(beta_econ) < 1e-15, is.finite(selection_score)) %>%
  dplyr::slice_min(selection_score, n = 1, with_ties = FALSE)
lambda0_screen_diagnostic <- screening_selection_table %>%
  dplyr::filter(abs(lambda) < 1e-15, is.finite(selection_score)) %>%
  dplyr::slice_head(n = 1)
if (FAST_MC_TUNING) {
  # Confirm only scientifically essential candidates: the overall screening
  # winner, the nested geography-only winner, and the best positive-beta winner.
  # This preserves the Graph-vs-GeoEco comparison without cold-confirming the
  # whole screening frontier in every Monte Carlo replication.
  best_overall_screen <- eligible_screening %>%
    dplyr::slice_min(selection_score, n = 1, with_ties = FALSE)
  best_positive_beta_screen <- eligible_screening %>%
    dplyr::filter(beta_econ > 0) %>%
    dplyr::slice_min(selection_score, n = 1, with_ties = FALSE)
  confirm_candidates <- dplyr::bind_rows(
    best_overall_screen,
    best_geo_only_screen,
    best_positive_beta_screen
  ) %>% dplyr::distinct(lambda, beta_econ, .keep_all = TRUE)
} else {
  confirm_candidates <- dplyr::bind_rows(
    eligible_screening %>%
      dplyr::slice_head(n = min(N_TOP_CONFIGS_CONFIRM, nrow(eligible_screening))),
    max_initial_rows,
    best_geo_only_screen,
    lambda0_screen_diagnostic
  ) %>% dplyr::distinct(lambda, beta_econ, .keep_all = TRUE)
}
readr::write_csv(confirm_candidates,
                 file.path(OUTPUT_DIR, "cv_cold_confirmation_candidates.csv"))

confirm_one_config <- function(lambda, beta_econ, tag) {
  tc <- run_temporal_cv_cached(
    lambda, 0, beta_econ, W_start = NULL,
    max_iter = FISTA_MAX_ITER_CONFIRM, tol = FISTA_TOL_CONFIRM,
    min_iter = FISTA_MIN_ITER_CONFIRM,
    fit_label = paste0("Cold temporal ", tag)
  )
  pc <- run_pseudo_config(
    lambda, beta_econ, pseudo_fold_scattered, PSEUDO_SCATTERED_FOLDS,
    W_start = NULL, max_iter = FISTA_MAX_ITER_CONFIRM,
    tol = FISTA_TOL_CONFIRM, min_iter = FISTA_MIN_ITER_CONFIRM,
    label_prefix = paste0("Cold pseudo ", tag)
  )
  row <- tc$summary %>%
    dplyr::left_join(pc$summary %>% dplyr::select(-rho), by = c("lambda", "beta_econ")) %>%
    dplyr::mutate(selection_score = selection_score_fun(temporal_rmse, pseudo_postonly_rmse))
  list(row = row, folds = pc$folds, W = tc$W)
}

cold_rows <- list(); cold_folds <- list(); cold_W <- list()
for (r in seq_len(nrow(confirm_candidates))) {
  z <- confirm_one_config(confirm_candidates$lambda[r], confirm_candidates$beta_econ[r],
                          sprintf("%d/%d", r, nrow(confirm_candidates)))
  cold_rows[[length(cold_rows) + 1L]] <- z$row
  cold_folds[[length(cold_folds) + 1L]] <- z$folds
  cold_W[[paste(confirm_candidates$lambda[r], confirm_candidates$beta_econ[r], sep = "|")]] <- z$W
}

# Adaptive upper-tail search: if the best cold-confirmed configuration lies at
# the largest evaluated lambda, expand lambda by x3. Strict mode reconsiders the
# full beta grid; fast-MC uses a targeted beta subset to preserve the key
# lambda-beta interaction at much lower cost. Continue until an interior optimum
# is observed or the mode-specific safety cap is reached.
adaptive_history <- list()
adapt_step <- 0L
lambda_search_boundary_remaining <- FALSE
repeat {
  cold_table_now <- dplyr::bind_rows(cold_rows) %>%
    dplyr::distinct(lambda, beta_econ, .keep_all = TRUE) %>%
    dplyr::arrange(selection_score)
  cold_eligible_now <- cold_table_now %>%
    dplyr::filter((length(postonly_idx) == 0) | lambda > 0,
                  is.finite(selection_score))
  if (nrow(cold_eligible_now) == 0) stop("No identified cold-confirmed candidate during adaptive lambda search.")
  best_now <- cold_eligible_now[1, , drop = FALSE]
  max_eval_lambda <- max(cold_eligible_now$lambda, na.rm = TRUE)
  boundary_best <- is.finite(best_now$lambda) && best_now$lambda > 0 &&
    isTRUE(all.equal(as.numeric(best_now$lambda), as.numeric(max_eval_lambda), tolerance = 1e-12))
  current_mult <- max_eval_lambda / lambda_base
  at_safety_cap <- adapt_step >= ADAPTIVE_LAMBDA_MAX_STEPS ||
    current_mult >= ADAPTIVE_LAMBDA_MAX_MULTIPLIER * (1 - 1e-12)
  adaptive_history[[length(adaptive_history) + 1L]] <- tibble::tibble(
    step = adapt_step,
    best_lambda = best_now$lambda,
    best_beta_econ = best_now$beta_econ,
    best_selection_score = best_now$selection_score,
    max_evaluated_lambda = max_eval_lambda,
    max_evaluated_multiplier = current_mult,
    boundary_best = boundary_best,
    safety_cap_reached = at_safety_cap
  )
  if (!boundary_best) break
  if (at_safety_cap) {
    lambda_search_boundary_remaining <- TRUE
    if (FAST_MC_TUNING) {
      warning("Fast-MC lambda tail stopped at its safety cap while the best configuration was still on the upper boundary. Inspect lambda_search_boundary_remaining and consider increasing MC_FAST_LAMBDA_TAIL_MAX_STEPS/MAX_MULTIPLIER for this design.")
    } else {
      warning("Adaptive lambda search stopped at its safety cap while the best configuration was still on the upper boundary. Consider extending ADAPTIVE_LAMBDA_MAX_MULTIPLIER.")
    }
    break
  }

  new_mult <- min(current_mult * ADAPTIVE_LAMBDA_GROWTH,
                  ADAPTIVE_LAMBDA_MAX_MULTIPLIER)
  if (!is.finite(new_mult) || new_mult <= current_mult * (1 + 1e-12)) {
    lambda_search_boundary_remaining <- TRUE
    break
  }
  new_lambda <- lambda_base * new_mult
  adapt_step <- adapt_step + 1L
  beta_expand <- if (has_pre_econ) {
    if (FAST_MC_TUNING) {
      # Targeted fast tail: follow the current winner, retain the nested
      # geography-only benchmark, keep the top initial-grid beta, and add one
      # economically stronger beta (=4 by default).  This captures lambda-beta
      # interaction in the upper tail without re-running the full beta grid.
      sort(unique(c(
        0,
        best_now$beta_econ,
        max(BETA_ECON_GRID),
        min(FAST_LAMBDA_TAIL_EXTRA_BETA_MAX, ADAPTIVE_ECON_BETA_MAX)
      )))
    } else {
      BETA_ECON_GRID
    }
  } else 0
  cat(sprintf("Adaptive cold lambda expansion %d: %.3g -> %.3g (lambda %.6g); beta grid = %s\n",
              adapt_step, current_mult, new_mult, new_lambda,
              paste(beta_expand, collapse = ",")))
  for (bb in beta_expand) {
    z <- confirm_one_config(new_lambda, bb,
                            paste0("adaptive", adapt_step, "_beta", format(bb, trim = TRUE)))
    cold_rows[[length(cold_rows) + 1L]] <- z$row
    cold_folds[[length(cold_folds) + 1L]] <- z$folds
    cold_W[[paste(new_lambda, bb, sep = "|")]] <- z$W
  }
}

# v14 beta upper-bound safeguard. After lambda has an interior solution, check
# whether the winning economic-similarity weight is still sitting at the
# largest evaluated beta. If so, extend beta locally at that lambda by x2.
adaptive_beta_history <- list()
beta_search_boundary_remaining <- FALSE
if (has_pre_econ) {
  beta_step <- 0L
  repeat {
    tab_now <- dplyr::bind_rows(cold_rows) %>%
      dplyr::distinct(lambda, beta_econ, .keep_all = TRUE) %>%
      dplyr::arrange(selection_score)
    tab_eligible <- tab_now %>%
      dplyr::filter((length(postonly_idx) == 0) | lambda > 0,
                    is.finite(selection_score))
    if (nrow(tab_eligible) == 0) stop("No identified cold-confirmed candidate during adaptive beta search.")
    best_now <- tab_eligible[1, , drop = FALSE]
    same_lambda <- tab_eligible %>%
      dplyr::filter(abs(lambda - best_now$lambda) <= 1e-12)
    max_beta_here <- max(same_lambda$beta_econ, na.rm = TRUE)
    beta_boundary <- best_now$lambda > 0 &&
      isTRUE(all.equal(as.numeric(best_now$beta_econ),
                       as.numeric(max_beta_here), tolerance = 1e-12)) &&
      max_beta_here > 0
    at_beta_cap <- beta_step >= ADAPTIVE_ECON_BETA_MAX_STEPS ||
      max_beta_here >= ADAPTIVE_ECON_BETA_MAX * (1 - 1e-12)

    adaptive_beta_history[[length(adaptive_beta_history) + 1L]] <- tibble::tibble(
      step = beta_step,
      best_lambda = best_now$lambda,
      best_beta_econ = best_now$beta_econ,
      best_selection_score = best_now$selection_score,
      max_evaluated_beta_at_best_lambda = max_beta_here,
      boundary_best = beta_boundary,
      safety_cap_reached = at_beta_cap
    )

    if (!beta_boundary) break
    if (at_beta_cap) {
      beta_search_boundary_remaining <- TRUE
      if (FAST_MC_TUNING) {
        warning("Fast-MC beta tail stopped at its safety cap while the best beta was still on the upper boundary. Inspect beta_search_boundary_remaining and consider increasing MC_FAST_BETA_TAIL_MAX_STEPS/MAX.")
      } else {
        warning("beta_econ search stopped at its safety cap while the best beta was still on the upper boundary.")
      }
      break
    }

    new_beta <- min(max_beta_here * ADAPTIVE_ECON_BETA_GROWTH, ADAPTIVE_ECON_BETA_MAX)
    if (!is.finite(new_beta) || new_beta <= max_beta_here * (1 + 1e-12)) {
      beta_search_boundary_remaining <- TRUE
      break
    }
    beta_step <- beta_step + 1L
    cat(sprintf("Adaptive beta expansion %d at lambda %.6g: %.3g -> %.3g\n",
                beta_step, best_now$lambda, max_beta_here, new_beta))
    z <- confirm_one_config(best_now$lambda, new_beta,
                            paste0("adaptive_beta", beta_step))
    cold_rows[[length(cold_rows) + 1L]] <- z$row
    cold_folds[[length(cold_folds) + 1L]] <- z$folds
    cold_W[[paste(best_now$lambda, new_beta, sep = "|")]] <- z$W
  }
}
readr::write_csv(dplyr::bind_rows(adaptive_beta_history),
                 file.path(OUTPUT_DIR, "adaptive_beta_history.csv"))

cold_confirmation_table_pre_final <- dplyr::bind_rows(cold_rows) %>%
  dplyr::distinct(lambda, beta_econ, .keep_all = TRUE) %>%
  dplyr::arrange(selection_score)

# Selection diagnostics and conservative parsimony rule -----------------------
# lambda=0 cannot identify a site-specific SCM representation for an actual
# post-only target because that site has no PRE fit term.  It is retained in the
# tables only as a numerical/uniform-null diagnostic and is NOT eligible for the
# authoritative Graph-SCM selection whenever actual post-only sites exist.
has_actual_post_only <- any(target_meta$obs_group == "post_only")
cold_confirmation_table_pre_final$selection_eligible <-
  !has_actual_post_only | cold_confirmation_table_pre_final$lambda > 0
cold_confirmation_table_pre_final$lambda0_interpretation <- ifelse(
  abs(cold_confirmation_table_pre_final$lambda) < 1e-15,
  "uniform/null diagnostic for pseudo-post-only; not site-specific SCM identified",
  "identified graph candidate"
)

# Save every 2-fold adaptive candidate before the final small 3-fold confirmation.
readr::write_csv(
  cold_confirmation_table_pre_final,
  file.path(OUTPUT_DIR, "cv_cold_confirmation_2fold_all_raw.csv")
)

fast_final_confirmation_table <- tibble::tibble()
fast_final_confirmation_folds <- tibble::tibble()
fast_final_confirmation_candidate_n <- 0L

if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) {
  pre_eligible <- cold_confirmation_table_pre_final %>%
    dplyr::filter(selection_eligible, is.finite(selection_score)) %>%
    dplyr::arrange(selection_score)
  if (nrow(pre_eligible) == 0) stop("No eligible candidate before fast final 3-fold confirmation.")

  # Re-score only the leading overall candidates plus the best nested geo-only
  # candidate.  In a near-tie such as lambda=0.0167 vs 0.0500, both normally
  # enter this set.  Temporal CV is reused; only pseudo-post-only CV is rerun.
  final_top <- pre_eligible %>%
    dplyr::slice_head(n = min(FAST_FINAL_CONFIRM_TOP_N, nrow(pre_eligible)))
  final_geo <- pre_eligible %>%
    dplyr::filter(abs(beta_econ) < 1e-15) %>%
    dplyr::slice_min(selection_score, n = 1, with_ties = FALSE)
  final_candidates <- dplyr::bind_rows(final_top, final_geo) %>%
    dplyr::distinct(lambda, beta_econ, .keep_all = TRUE)
  fast_final_confirmation_candidate_n <- nrow(final_candidates)
  readr::write_csv(
    final_candidates,
    file.path(OUTPUT_DIR, "cv_fast_final_3fold_candidates.csv")
  )

  final_rows <- vector("list", nrow(final_candidates))
  final_folds_rows <- vector("list", nrow(final_candidates))
  for (rr in seq_len(nrow(final_candidates))) {
    lam <- final_candidates$lambda[rr]
    bet <- final_candidates$beta_econ[rr]
    pc3 <- run_pseudo_config(
      lam, bet, pseudo_fold_final_confirm, FAST_FINAL_CONFIRM_FOLDS,
      W_start = NULL, max_iter = FISTA_MAX_ITER_CONFIRM,
      tol = FISTA_TOL_CONFIRM, min_iter = FISTA_MIN_ITER_CONFIRM,
      label_prefix = paste0("Final3fold pseudo ", rr, "/", nrow(final_candidates))
    )
    base <- final_candidates[rr, , drop = FALSE]
    # Replace only pseudo-validation fields; temporal holdout remains exactly the
    # already cold-confirmed value for the same (lambda, beta) candidate.
    for (nm in setdiff(names(pc3$summary), c("lambda", "rho", "beta_econ"))) {
      base[[nm]] <- pc3$summary[[nm]][1]
    }
    base$selection_score <- selection_score_fun(
      base$temporal_rmse, base$pseudo_postonly_rmse
    )
    base$fast_final_confirmation <- TRUE
    base$final_confirmation_folds <- FAST_FINAL_CONFIRM_FOLDS
    final_rows[[rr]] <- base
    final_folds_rows[[rr]] <- pc3$folds %>%
      dplyr::mutate(
        candidate_lambda = lam, candidate_beta_econ = bet,
        final_confirmation = TRUE, .before = 1
      )
  }
  fast_final_confirmation_table <- dplyr::bind_rows(final_rows) %>%
    dplyr::arrange(selection_score)
  fast_final_confirmation_folds <- dplyr::bind_rows(final_folds_rows)
  readr::write_csv(
    fast_final_confirmation_table,
    file.path(OUTPUT_DIR, "cv_fast_final_3fold_confirmation.csv")
  )
  readr::write_csv(
    fast_final_confirmation_folds,
    file.path(OUTPUT_DIR, "cv_fast_final_3fold_confirmation_folds.csv")
  )
  cold_confirmation_table <- fast_final_confirmation_table
} else {
  cold_confirmation_table <- cold_confirmation_table_pre_final
  readr::write_csv(
    fast_final_confirmation_table,
    file.path(OUTPUT_DIR, "cv_fast_final_3fold_confirmation.csv")
  )
  readr::write_csv(
    fast_final_confirmation_folds,
    file.path(OUTPUT_DIR, "cv_fast_final_3fold_confirmation_folds.csv")
  )
}

# Save the authoritative candidate table used for final selection before derived
# near-tie columns are added.
readr::write_csv(
  cold_confirmation_table,
  file.path(OUTPUT_DIR, "cv_cold_confirmation_all_raw.csv")
)

eligible_cold <- cold_confirmation_table %>%
  dplyr::filter(selection_eligible, is.finite(selection_score))
if (nrow(eligible_cold) == 0) {
  stop("Cold-start hyperparameter confirmation produced no identified candidate for the actual post-only design.")
}
strict_best <- eligible_cold %>%
  dplyr::slice_min(selection_score, n = 1, with_ties = FALSE)
best_cold_score <- strict_best$selection_score[1]
strict_best_lambda <- strict_best$lambda[1]
strict_best_beta_econ <- strict_best$beta_econ[1]

if (is.finite(best_cold_score) && best_cold_score > 0) {
  cold_confirmation_table$selection_score_ratio_to_best <-
    cold_confirmation_table$selection_score / best_cold_score
} else {
  cold_confirmation_table$selection_score_ratio_to_best <-
    rep(NA_real_, nrow(cold_confirmation_table))
}
cold_confirmation_table$selection_score_excess_pct <- ifelse(
  is.finite(cold_confirmation_table$selection_score_ratio_to_best),
  100 * (cold_confirmation_table$selection_score_ratio_to_best - 1),
  NA_real_
)
cold_confirmation_table$near_tie_1pct <-
  cold_confirmation_table$selection_eligible &
  is.finite(cold_confirmation_table$selection_score) &
  is.finite(best_cold_score) &
  cold_confirmation_table$selection_score <=
    best_cold_score * (1 + CV_NEAR_TIE_REL_TOL)

near_tie_candidates <- cold_confirmation_table %>%
  dplyr::filter(near_tie_1pct) %>%
  dplyr::arrange(beta_econ, selection_score, lambda)
readr::write_csv(near_tie_candidates,
                 file.path(OUTPUT_DIR, "cv_near_tie_candidates.csv"))

# Authoritative parsimony rule: among identified candidates within 0.5% of the
# strict best score, prefer the smallest economic-distance complexity beta_econ.
# Conditional on that beta, retain the smallest score (lambda is not treated as
# a model-complexity dimension).  The strict minimum is still saved separately.
parsimony_candidates <- eligible_cold %>%
  dplyr::filter(
    selection_score <= best_cold_score * (1 + CV_PARSIMONY_REL_TOL)
  )
min_beta_parsimony <- min(parsimony_candidates$beta_econ, na.rm = TRUE)
selected_row <- parsimony_candidates %>%
  dplyr::filter(abs(beta_econ - min_beta_parsimony) < 1e-12) %>%
  dplyr::slice_min(selection_score, n = 1, with_ties = FALSE)
if (nrow(selected_row) == 0) stop("Parsimony selection failed unexpectedly.")

readr::write_csv(
  parsimony_candidates %>% dplyr::arrange(beta_econ, selection_score, lambda),
  file.path(OUTPUT_DIR, "cv_parsimony_candidates.csv")
)
selection_rule_summary <- tibble::tibble(
  strict_best_lambda = strict_best_lambda,
  strict_best_beta_econ = strict_best_beta_econ,
  strict_best_score = best_cold_score,
  parsimony_rel_tolerance = CV_PARSIMONY_REL_TOL,
  selected_lambda = selected_row$lambda[1],
  selected_beta_econ = selected_row$beta_econ[1],
  selected_score = selected_row$selection_score[1],
  selected_score_excess_vs_strict_pct =
    100 * (selected_row$selection_score[1] / best_cold_score - 1),
  actual_post_only_present = has_actual_post_only,
  lambda0_selection_eligible = !has_actual_post_only,
  selection_rule = "identified positive-lambda candidates; within tolerance prefer smallest beta_econ"
)
readr::write_csv(selection_rule_summary,
                 file.path(OUTPUT_DIR, "cv_selection_rule_summary.csv"))

near_tie_conservative <- if (nrow(near_tie_candidates) > 0) {
  near_tie_candidates %>% dplyr::slice_head(n = 1) %>%
    dplyr::mutate(note = "diagnostic near-tie; authoritative choice uses 0.5pct parsimony rule")
} else tibble::tibble()
readr::write_csv(near_tie_conservative,
                 file.path(OUTPUT_DIR, "cv_near_tie_conservative_candidate.csv"))

cold_confirmation_folds <- if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) {
  fast_final_confirmation_folds
} else {
  dplyr::bind_rows(cold_folds)
}
readr::write_csv(cold_confirmation_table,
                 file.path(OUTPUT_DIR, "cv_cold_confirmation.csv"))
readr::write_csv(cold_confirmation_folds,
                 file.path(OUTPUT_DIR, "cv_cold_confirmation_pseudo_folds.csv"))
# Keep the complete 2-fold adaptive fold log as a separate audit file in fast mode.
if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) {
  readr::write_csv(dplyr::bind_rows(cold_folds),
                   file.path(OUTPUT_DIR, "cv_cold_confirmation_2fold_pseudo_folds.csv"))
}
readr::write_csv(dplyr::bind_rows(adaptive_history),
                 file.path(OUTPUT_DIR, "adaptive_lambda_history.csv"))

# cv_selection_table retains all candidates plus eligibility; selected_parameters
# below records the authoritative parsimony choice.
selection_table <- cold_confirmation_table %>% dplyr::arrange(selection_score)
readr::write_csv(selection_table, file.path(OUTPUT_DIR, "cv_selection_table.csv"))
best_lambda <- selected_row$lambda[1]
best_beta_econ <- selected_row$beta_econ[1]
best_rho <- 0
cat("Selected after leakage-free cold confirmation",
    if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) " + final 3-fold recheck" else "",
    " + parsimony | lambda:", best_lambda,
    " beta_econ:", best_beta_econ,
    " | strict best beta:", strict_best_beta_econ, "\n", sep = "")


geo_only_selected <- selection_table %>%
  dplyr::filter(selection_eligible, abs(beta_econ) < 1e-15, is.finite(selection_score)) %>%
  dplyr::slice_min(selection_score, n = 1, with_ties = FALSE)
if (nrow(geo_only_selected) == 0) {
  warning("No cold-confirmed geography-only candidate was available; geo-only benchmark will be skipped.")
  geo_only_lambda <- NA_real_
} else {
  geo_only_lambda <- geo_only_selected$lambda[1]
}

# ---- 7d. Spatial-block pseudo-post-only stress test -------------------------
# This is deliberately NOT used for tuning. It is useful for strict validation,
# but is disabled by default in fast-MC because the station-selected DGPs already
# provide dedicated missingness stress tests.
if (RUN_BLOCK_STRESS) {
  block_stress_cfg <- dplyr::bind_rows(
    tibble::tibble(method = "selected_geo_econ", lambda = best_lambda, beta_econ = best_beta_econ),
    if (is.finite(geo_only_lambda)) tibble::tibble(method = "graph_geo_only", lambda = geo_only_lambda, beta_econ = 0) else NULL,
    tibble::tibble(method = "lambda0_uniform_null", lambda = 0, beta_econ = 0)
  ) %>% dplyr::distinct(lambda, beta_econ, .keep_all = TRUE)
  block_stress_rows <- list(); block_stress_folds <- list()
  for (r in seq_len(nrow(block_stress_cfg))) {
    z <- run_pseudo_config(
      block_stress_cfg$lambda[r], block_stress_cfg$beta_econ[r],
      pseudo_fold_block, PSEUDO_BLOCK_STRESS_FOLDS,
      W_start = NULL, max_iter = FISTA_MAX_ITER_CONFIRM,
      tol = FISTA_TOL_CONFIRM, min_iter = FISTA_MIN_ITER_CONFIRM,
      label_prefix = paste0("Block-stress ", block_stress_cfg$method[r])
    )
    block_stress_rows[[r]] <- z$summary %>% dplyr::mutate(method = block_stress_cfg$method[r], .before = 1)
    block_stress_folds[[r]] <- z$folds %>% dplyr::mutate(method = block_stress_cfg$method[r], .before = 1)
  }
  block_stress_table <- dplyr::bind_rows(block_stress_rows)
  block_stress_folds_table <- dplyr::bind_rows(block_stress_folds)
  readr::write_csv(block_stress_table,
                   file.path(OUTPUT_DIR, "cv_pseudo_postonly_block_stress.csv"))
  readr::write_csv(block_stress_folds_table,
                   file.path(OUTPUT_DIR, "cv_pseudo_postonly_block_stress_folds.csv"))

} else {
  block_stress_table <- tibble::tibble()
  block_stress_folds_table <- tibble::tibble()
  readr::write_csv(block_stress_table,
                   file.path(OUTPUT_DIR, "cv_pseudo_postonly_block_stress.csv"))
  readr::write_csv(block_stress_folds_table,
                   file.path(OUTPUT_DIR, "cv_pseudo_postonly_block_stress_folds.csv"))
}

# ---- 8. Final main fit (rho=0) + graph identifiability diagnostics -----------
final_graph <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = best_beta_econ)

# Main v14 estimator keeps rho=0 so the rho analysis below is a genuine
# sensitivity check rather than part of model selection. Use a common cold start.
cat("Final main rho=0 fit started at", format(Sys.time(), "%H:%M:%S"), "\n")
final_fit <- fit_final_authoritative(
  Yt_pre, Yc_pre, final_graph, lambda = best_lambda, rho = 0,
  status_prefix = "authoritative_exact_qp_geoeco",
  fit_label = "Final GeoEco-SCM rho=0"
)
W_hat <- final_fit$W

max_w_stage1 <- apply(W_hat, 1, max)
weight_diag_stage1 <- tibble::tibble(
  point_id = rownames(W_hat),
  max_weight = max_w_stage1,
  effective_donors = 1 / rowSums(W_hat^2)
) %>%
  dplyr::left_join(target_meta %>% dplyr::select(point_id, obs_group, n_pre_obs), by = "point_id")
readr::write_csv(weight_diag_stage1, file.path(OUTPUT_DIR, "weight_concentration_stage1.csv"))

edges_out <- final_graph$edges %>%
  dplyr::mutate(
    point_id_i = target_meta$point_id[i],
    point_id_k = target_meta$point_id[k]
  )
readr::write_csv(edges_out, file.path(OUTPUT_DIR, "graph_edges.csv"))

# Union-find components for a necessary post-only identifiability diagnostic.
graph_components <- function(n, edges) {
  parent <- seq_len(n)
  find_root <- function(x) {
    while (parent[x] != x) {
      parent[x] <<- parent[parent[x]]
      x <- parent[x]
    }
    x
  }
  unite <- function(a, b) {
    ra <- find_root(a); rb <- find_root(b)
    if (ra != rb) parent[rb] <<- ra
  }
  if (nrow(edges) > 0) {
    for (rr in seq_len(nrow(edges))) unite(edges$i[rr], edges$k[rr])
  }
  vapply(seq_len(n), find_root, integer(1))
}
comp_id <- graph_components(N, final_graph$edges)
pre_anchor_full <- rowSums(is.finite(Yt_pre)) > 0
immediate_anchor <- vapply(seq_len(N), function(ii) {
  nb <- unique(c(final_graph$edges$k[final_graph$edges$i == ii],
                 final_graph$edges$i[final_graph$edges$k == ii]))
  if (length(nb) == 0) return(0L)
  sum(pre_anchor_full[nb])
}, integer(1))
component_anchor <- vapply(seq_len(N), function(ii) {
  sum(pre_anchor_full[comp_id == comp_id[ii]])
}, integer(1))
anchor_diag <- target_meta %>%
  dplyr::transmute(
    point_id, obs_group, n_pre_obs,
    immediate_pre_anchor_neighbors = immediate_anchor,
    graph_component = comp_id,
    pre_anchors_in_component = component_anchor,
    component_has_pre_anchor = pre_anchors_in_component > 0,
    # A post-only target is data-identified by this model only when lambda>0 and
    # its graph component is connected to at least one PRE-observed target.
    model_data_identified = dplyr::if_else(
      obs_group == "post_only",
      best_lambda > 0 & component_has_pre_anchor,
      n_pre_obs > 0
    )
  )
readr::write_csv(anchor_diag, file.path(OUTPUT_DIR, "postonly_graph_anchor_diagnostics.csv"))
if (any(anchor_diag$obs_group == "post_only" & !anchor_diag$model_data_identified)) {
  warning("At least one post-only target is not data-identified by the selected model. Its numerical simplex solution will be retained only as a diagnostic and excluded from main counterfactual/ATT metrics.")
}

param_summary <- tibble::tibble(
  tuning_mode = if (FAST_MC_TUNING) "fast_mc" else "strict",
  fast_mc_tuning = FAST_MC_TUNING,
  block_stress_run = RUN_BLOCK_STRESS,
  fast_final_3fold_confirmation = FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM,
  fast_final_confirmation_folds = if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) FAST_FINAL_CONFIRM_FOLDS else NA_integer_,
  fast_final_confirmation_top_n = if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) FAST_FINAL_CONFIRM_TOP_N else NA_integer_,
  fast_final_confirmation_candidate_n = if (FAST_MC_TUNING && FAST_FINAL_3FOLD_CONFIRM) fast_final_confirmation_candidate_n else NA_integer_,
  graph_edge_definition = "geographic_kNN_reweighted_by_PRE_Mahalanobis_economic_distance",
  economic_features = paste(ECON_FEATURES, collapse = ";"),
  economic_covariance_shrinkage = ECON_COV_SHRINKAGE,
  beta_econ = best_beta_econ,
  pre_econ_used = final_graph$econ_used,
  lambda = best_lambda,
  geography_only_selected_lambda = geo_only_lambda,
  rho = 0,
  h_geo_m = final_graph$h_geo,
  h_econ_mahalanobis = final_graph$h_econ,
  directed_knn_median_m = final_graph$directed_knn_median_m,
  graph_indexing_max_abs_error_m = final_graph$graph_indexing_max_abs_error_m,
  hyperparameter_selection = if (FAST_MC_TUNING)
    "fast MC: reduced joint lambda/beta screening + 2-fold scattered pseudo-post-only + essential cold confirmation + targeted adaptive lambda/beta upper tail + top-candidate 3-fold final pseudo-post-only confirmation + beta parsimony"
  else
    "cold temporal + joint lambda/beta screening + scattered pseudo-post-only + cold confirmation + adaptive upper tail + identified-positive-lambda + beta parsimony",
  strict_best_lambda = strict_best_lambda,
  strict_best_beta_econ = strict_best_beta_econ,
  strict_best_selection_score = best_cold_score,
  cv_parsimony_relative_tolerance = CV_PARSIMONY_REL_TOL,
  adaptive_lambda_steps = adapt_step,
  adaptive_lambda_max_multiplier = ADAPTIVE_LAMBDA_MAX_MULTIPLIER,
  fast_lambda_tail_extra_beta_max = if (FAST_MC_TUNING) FAST_LAMBDA_TAIL_EXTRA_BETA_MAX else NA_real_,
  lambda_search_boundary_remaining = lambda_search_boundary_remaining,
  adaptive_beta_max_steps = ADAPTIVE_ECON_BETA_MAX_STEPS,
  adaptive_beta_max = ADAPTIVE_ECON_BETA_MAX,
  beta_search_boundary_remaining = beta_search_boundary_remaining,
  cv_near_tie_relative_tolerance = CV_NEAR_TIE_REL_TOL,
  cv_near_tie_candidate_n = sum(selection_table$near_tie_1pct, na.rm = TRUE),
  cv_selected_temporal_mean_bias_log = selected_row$temporal_mean_bias_log[1],
  cv_selected_pseudo_mean_bias_log = selected_row$pseudo_postonly_mean_bias_log[1],
  cv_selected_temporal_abs_mean_bias_log = selected_row$temporal_abs_mean_bias_log[1],
  cv_selected_pseudo_abs_mean_bias_log = selected_row$pseudo_postonly_abs_mean_bias_log[1],
  cv_conservative_near_tie_lambda = if (nrow(near_tie_conservative) > 0) near_tie_conservative$lambda[1] else NA_real_,
  cv_conservative_near_tie_beta_econ = if (nrow(near_tie_conservative) > 0) near_tie_conservative$beta_econ[1] else NA_real_,
  final_fit_loss = final_fit$fit_loss,
  final_smooth_loss = final_fit$smooth_loss,
  final_ridge_loss = final_fit$ridge_loss,
  final_solver_family = if (!is.null(final_fit$solver_family)) final_fit$solver_family else "FISTA",
  final_exact_qp_success = isTRUE(final_fit$exact_qp_success),
  final_osqp_status = if (!is.null(final_fit$osqp_status)) final_fit$osqp_status else NA_character_,
  final_osqp_iter = if (!is.null(final_fit$osqp_iter)) final_fit$osqp_iter else NA_integer_,
  final_solver_elapsed_sec = final_fit$elapsed_sec,
  solver_status = final_fit$status,
  final_fista_iter = final_fit$fista_iter,
  final_fista_converged = final_fit$fista_converged,
  final_fista_rel_change = final_fit$fista_rel_change,
  final_fista_pred_rel_change = final_fit$fista_pred_rel_change,
  final_fista_obj_rel_change = final_fit$fista_obj_rel_change,
  final_projected_gradient_norm = final_fit$projected_gradient_norm,
  post_only_n = sum(target_meta$obs_group == "post_only"),
  post_only_data_identified_n = sum(anchor_diag$obs_group == "post_only" & anchor_diag$model_data_identified),
  post_only_unidentified_n = sum(anchor_diag$obs_group == "post_only" & !anchor_diag$model_data_identified),
  post_only_min_immediate_anchor_neighbors = min(immediate_anchor[target_meta$obs_group == "post_only"]),
  post_only_min_component_anchors = min(component_anchor[target_meta$obs_group == "post_only"])
)
readr::write_csv(param_summary, file.path(OUTPUT_DIR, "selected_parameters.csv"))

weights_out <- as.data.frame(W_hat, check.names = FALSE) %>%
  tibble::rownames_to_column("point_id")
readr::write_csv(weights_out, file.path(OUTPUT_DIR, "joint_scm_weights.csv"))

# ---- 9. Raw counterfactuals -------------------------------------------------
# Keep the optimizer's numerical continuation for diagnostics, but mask targets
# that are not identified by PRE data + graph borrowing in the scientific main
# counterfactual. In particular, lambda=0 cannot identify post-only targets.
Y0_numeric <- W_hat %*% t(Yc_all)   # N x Tall
colnames(Y0_numeric) <- YEARS
rownames(Y0_numeric) <- target_meta$point_id
identified_main <- anchor_diag$model_data_identified
Y0_raw <- Y0_numeric
Y0_raw[!identified_main, ] <- NA_real_

# Nested geography-only Graph-SCM benchmark.  This isolates the incremental
# value of PRE economic similarity from the value of graph smoothing itself.
geo_only_fit <- NULL
Y0_geo_only <- NULL
if (is.finite(geo_only_lambda)) {
  geo_only_graph <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = 0)
  geo_only_fit <- fit_final_authoritative(
    Yt_pre, Yc_pre, geo_only_graph, lambda = geo_only_lambda, rho = 0,
    status_prefix = "authoritative_exact_qp_graph",
    fit_label = "Final Graph-SCM rho=0"
  )
  Y0_geo_only <- geo_only_fit$W %*% t(Yc_all)
  colnames(Y0_geo_only) <- YEARS
  rownames(Y0_geo_only) <- target_meta$point_id
  if (geo_only_lambda <= 0) {
    Y0_geo_only[target_meta$obs_group == "post_only", ] <- NA_real_
  }
  readr::write_csv(
    tibble::tibble(
      lambda = geo_only_lambda,
      beta_econ = 0,
      selection_score = geo_only_selected$selection_score[1],
      temporal_rmse = geo_only_selected$temporal_rmse[1],
      pseudo_postonly_rmse = geo_only_selected$pseudo_postonly_rmse[1],
      solver_status = geo_only_fit$status,
      solver_family = if (!is.null(geo_only_fit$solver_family)) geo_only_fit$solver_family else "FISTA",
      exact_qp_success = isTRUE(geo_only_fit$exact_qp_success),
      osqp_status = if (!is.null(geo_only_fit$osqp_status)) geo_only_fit$osqp_status else NA_character_,
      osqp_iter = if (!is.null(geo_only_fit$osqp_iter)) geo_only_fit$osqp_iter else NA_integer_,
      fista_iter = geo_only_fit$fista_iter,
      projected_gradient_norm = geo_only_fit$projected_gradient_norm
    ),
    file.path(OUTPUT_DIR, "geography_only_graph_benchmark.csv")
  )
}

identification_summary <- anchor_diag %>%
  dplyr::count(obs_group, model_data_identified, name = "n")
readr::write_csv(identification_summary,
                 file.path(OUTPUT_DIR, "simulation_identification_summary.csv"))
if (any(!identified_main)) {
  numerical_unidentified <- tibble::tibble(
    point_id = target_meta$point_id[!identified_main],
    obs_group = target_meta$obs_group[!identified_main],
    reason = ifelse(target_meta$obs_group[!identified_main] == "post_only" & best_lambda <= 0,
                    "post_only_with_lambda0", "no_PRE_anchor_in_graph_component")
  )
  readr::write_csv(numerical_unidentified,
                   file.path(OUTPUT_DIR, "simulation_unidentified_targets.csv"))
}

# ---- 10. Cross-fitted PRE-period residuals for optional bias correction ----
collect_bias_crossfit <- function(folds, lambda, rho, beta_econ) {
  graph <- make_paper_graph(
    target_meta, k = GRAPH_K, beta_econ = beta_econ
  )

  out <- list()
  for (f in seq_along(folds)) {
    yrs <- intersect(folds[[f]], PERIOD_PRE)
    pos <- match(yrs, PERIOD_PRE)
    Ytrain <- Yt_pre
    Ytrain[, pos] <- NA_real_

    bias_fold_start <- Sys.time()
    cat(sprintf("Bias cross-fit fold %d / %d started at %s\n",
                f, length(folds), format(bias_fold_start, "%H:%M:%S")))
    fit_f <- fit_smooth_scm(
      Ytrain, Yc_pre, graph, lambda = lambda, rho = rho,
      W_start = W_hat,
      max_iter = FISTA_MAX_ITER_CV, tol = FISTA_TOL_CV,
      fit_label = sprintf("Bias fold %d/%d", f, length(folds))
    )
    cat(sprintf("  -> bias fold %d finished in %.2f min\n", f,
                as.numeric(difftime(Sys.time(), bias_fold_start, units = "secs")) / 60))
    pred_f <- fit_f$W %*% t(Yc_pre[pos, , drop = FALSE])
    truth_f <- Yt_pre[, pos, drop = FALSE]

    rows <- list()
    cc <- 1
    for (i in seq_len(N)) {
      for (h in seq_along(pos)) {
        if (!is.finite(truth_f[i, h])) next
        rows[[cc]] <- tibble::tibble(
          point_id = target_meta$point_id[i],
          year = yrs[h],
          actual_log = truth_f[i, h],
          cf_log = pred_f[i, h],
          bias = truth_f[i, h] - pred_f[i, h],
          fold = f,
          X_km = target_meta$X_m[i] / 1000,
          Y_km = target_meta$Y_m[i] / 1000,
          year_c = yrs[h] - mean(PERIOD_PRE)
        )
        cc <- cc + 1
      }
    }
    out[[f]] <- dplyr::bind_rows(rows)
  }
  dplyr::bind_rows(out)
}

if (RUN_BIAS_CORRECTION) {
  bias_crossfit <- collect_bias_crossfit(
    BIAS_FOLDS, best_lambda, best_rho, best_beta_econ
  )
} else {
  bias_crossfit <- tibble::tibble()
}
readr::write_csv(bias_crossfit, file.path(OUTPUT_DIR, "bias_crossfit_residuals.csv"))

# Build long prediction grid for all treatment targets and years
pred_grid <- tidyr::expand_grid(
  point_id = target_meta$point_id,
  year = YEARS
) %>%
  dplyr::left_join(
    target_meta %>% dplyr::select(point_id, X_m, Y_m, obs_group, n_pre_obs, n_post_obs),
    by = "point_id"
  ) %>%
  dplyr::mutate(
    X_km = X_m / 1000,
    Y_km = Y_m / 1000,
    year_c = year - mean(PERIOD_PRE)
  )

pred_grid$bias_pred <- 0
bias_model_name <- "none"

if (RUN_BIAS_CORRECTION && nrow(bias_crossfit) >= 30) {
  # Conservative default: spatial field + global linear time trend.
  # Optional spatially varying time trend can be switched on above.
  bias_fit <- tryCatch({
    mesh <- sdmTMB::make_mesh(
      bias_crossfit,
      xy_cols = c("X_km", "Y_km"),
      cutoff = BIAS_MESH_CUTOFF_KM
    )

    if (BIAS_INCLUDE_LINEAR_TIME && BIAS_SPATIAL_VARYING_TREND) {
      sdmTMB::sdmTMB(
        bias ~ year_c,
        data = bias_crossfit,
        mesh = mesh,
        family = gaussian(link = "identity"),
        spatial = "on",
        spatial_varying = ~ year_c,
        reml = FALSE
      )
    } else if (BIAS_INCLUDE_LINEAR_TIME) {
      sdmTMB::sdmTMB(
        bias ~ year_c,
        data = bias_crossfit,
        mesh = mesh,
        family = gaussian(link = "identity"),
        spatial = "on",
        reml = FALSE
      )
    } else {
      # Conservative default: a time-invariant spatial bias field.
      # This avoids mechanically extrapolating a pre-period linear trend to 2025.
      sdmTMB::sdmTMB(
        bias ~ 1,
        data = bias_crossfit,
        mesh = mesh,
        family = gaussian(link = "identity"),
        spatial = "on",
        reml = FALSE
      )
    }
  }, error = function(e) NULL)

  if (!is.null(bias_fit)) {
    bp <- predict(bias_fit, newdata = pred_grid)
    pred_grid$bias_pred <- bp$est
    bias_model_name <- "sdmTMB_pre_crossfit"
    saveRDS(bias_fit, file.path(OUTPUT_DIR, "bias_model_sdmTMB.rds"))
  } else {
    warning("sdmTMB bias model failed; trying mgcv fallback.")
    k_gam <- min(80, max(10, floor(nrow(bias_crossfit) / 5)))
    bias_formula <- if (BIAS_INCLUDE_LINEAR_TIME) {
      stats::as.formula(glue::glue("bias ~ year_c + s(X_km, Y_km, bs = 'tp', k = {k_gam})"))
    } else {
      stats::as.formula(glue::glue("bias ~ s(X_km, Y_km, bs = 'tp', k = {k_gam})"))
    }
    bias_gam <- mgcv::gam(
      bias_formula,
      data = bias_crossfit,
      method = "REML"
    )
    pred_grid$bias_pred <- predict(bias_gam, newdata = pred_grid)
    bias_model_name <- "mgcv_pre_crossfit_fallback"
    saveRDS(bias_gam, file.path(OUTPUT_DIR, "bias_model_mgcv.rds"))
  }
}

# ---- 11. Merge actual, raw CF, corrected CF, and effects -------------------
raw_cf_long <- as.data.frame(Y0_raw) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "cf_log_raw") %>%
  dplyr::mutate(year = as.integer(year))

actual_long <- as.data.frame(Y_target_all) %>%
  tibble::rownames_to_column("point_id") %>%
  tidyr::pivot_longer(-point_id, names_to = "year", values_to = "actual_log") %>%
  dplyr::mutate(year = as.integer(year))

result_long <- actual_long %>%
  dplyr::left_join(raw_cf_long, by = c("point_id", "year")) %>%
  dplyr::left_join(pred_grid %>% dplyr::select(point_id, year, bias_pred), by = c("point_id", "year")) %>%
  dplyr::left_join(target_meta %>% dplyr::select(point_id, obs_group, n_pre_obs, n_post_obs, StationDistance), by = "point_id") %>%
  dplyr::mutate(
    cf_log_corrected = cf_log_raw + dplyr::coalesce(bias_pred, 0),
    actual_yen = exp(actual_log),
    cf_yen_raw = exp(cf_log_raw),
    cf_yen_corrected = exp(cf_log_corrected),
    effect_log_raw = actual_log - cf_log_raw,
    effect_log_corrected = actual_log - cf_log_corrected,
    effect_pct_raw = (exp(effect_log_raw) - 1) * 100,
    effect_pct_corrected = (exp(effect_log_corrected) - 1) * 100,
    effect_yen_raw = actual_yen - cf_yen_raw,
    effect_yen_corrected = actual_yen - cf_yen_corrected,
    period = ifelse(year %in% PERIOD_PRE, "pre", "post"),
    bias_model = bias_model_name
  )

readr::write_csv(result_long, file.path(OUTPUT_DIR, "counterfactual_and_effects_long.csv"))

# ---- 12. ATT summaries ------------------------------------------------------
att_by_year <- result_long %>%
  dplyr::filter(year %in% PERIOD_POST, is.finite(actual_log)) %>%
  dplyr::group_by(year) %>%
  dplyr::summarise(
    n = dplyr::n(),
    ATT_log_raw = mean(effect_log_raw, na.rm = TRUE),
    ATT_log_corrected = mean(effect_log_corrected, na.rm = TRUE),
    ATT_pct_raw = (exp(ATT_log_raw) - 1) * 100,
    ATT_pct_corrected = (exp(ATT_log_corrected) - 1) * 100,
    ATT_yen_raw = mean(effect_yen_raw, na.rm = TRUE),
    ATT_yen_corrected = mean(effect_yen_corrected, na.rm = TRUE),
    .groups = "drop"
  )
readr::write_csv(att_by_year, file.path(OUTPUT_DIR, "ATT_by_year.csv"))

att_by_group <- result_long %>%
  dplyr::filter(year %in% PERIOD_POST, is.finite(actual_log)) %>%
  dplyr::group_by(obs_group, year) %>%
  dplyr::summarise(
    n = dplyr::n(),
    ATT_log_raw = mean(effect_log_raw, na.rm = TRUE),
    ATT_log_corrected = mean(effect_log_corrected, na.rm = TRUE),
    ATT_pct_raw = (exp(ATT_log_raw) - 1) * 100,
    ATT_pct_corrected = (exp(ATT_log_corrected) - 1) * 100,
    .groups = "drop"
  )
readr::write_csv(att_by_group, file.path(OUTPUT_DIR, "ATT_by_observation_group.csv"))

# ---- 13. Diagnostic plots ---------------------------------------------------
p_cv <- selection_table %>%
  dplyr::filter(is.finite(temporal_rmse)) %>%
  ggplot(aes(x = lambda, y = temporal_rmse, color = factor(beta_econ))) +
  geom_line() + geom_point() +
  scale_x_continuous(trans = scales::pseudo_log_trans(base = 10)) +
  labs(
    title = "Pre-period temporal holdout CV",
    subtitle = "Geographic kNN edges; PRE Mahalanobis economic similarity reweights local edges",
    x = expression(lambda), y = "Temporal holdout RMSE",
    color = expression(beta[econ])
  ) +
  theme_minimal()
ggsave(file.path(OUTPUT_DIR, "cv_lambda_graph.png"), p_cv,
       width = 8, height = 5, dpi = 200, bg = "white")

if (nrow(pseudo_table) > 0) {
  p_pseudo <- selection_table %>%
    dplyr::filter(is.finite(pseudo_postonly_rmse)) %>%
    ggplot(aes(x = temporal_rmse, y = pseudo_postonly_rmse,
               label = paste0("b=", beta_econ, ", l=", signif(lambda, 2)))) +
    geom_point(size = 2) +
    geom_text(check_overlap = TRUE, vjust = -0.5, size = 3) +
    labs(title = "Temporal vs pseudo-post-only validation",
         x = "Temporal holdout RMSE", y = "Pseudo-post-only RMSE") +
    theme_minimal()
  ggsave(file.path(OUTPUT_DIR, "cv_temporal_vs_pseudo_postonly.png"), p_pseudo,
         width = 7, height = 5, dpi = 200, bg = "white")
}

p_att <- att_by_year %>%
  dplyr::select(year, ATT_pct_raw, ATT_pct_corrected) %>%
  tidyr::pivot_longer(-year, names_to = "model", values_to = "ATT_pct") %>%
  ggplot(aes(year, ATT_pct, linetype = model)) +
  geom_hline(yintercept = 0, color = "grey60") +
  geom_line(linewidth = 1) + geom_point() +
  labs(title = "Treatment-area ATT", x = NULL, y = "ATT (%)", linetype = NULL) +
  theme_minimal() + theme(legend.position = "bottom")
ggsave(file.path(OUTPUT_DIR, "ATT_time_series.png"), p_att,
       width = 8, height = 5, dpi = 200, bg = "white")

# ---- 14. Summary to console -------------------------------------------------
cat("\n============================================================\n")
cat("Spatially smoothed SCM finished.\n")
cat("Output directory:", OUTPUT_DIR, "\n")
cat("Graph edges: geographic kNN\n")
cat("Selected beta_econ:", best_beta_econ, "\n")
cat(sprintf("Graph kNN median distance: %.1f m | indexing max error: %.3g m\n", final_graph$directed_knn_median_m, final_graph$graph_indexing_max_abs_error_m))
cat("Pre-treatment economic similarity used:", final_graph$econ_used, "\n")
cat("Selected lambda:", best_lambda, "\n")
cat("Selected rho:", best_rho, "\n")
cat("Bias model:", bias_model_name, "\n")
cat("Target observation groups:\n")
print(table(target_meta$obs_group))
cat("============================================================\n")

# IMPORTANT FOR INFERENCE:
# The placebo distribution in the old code7 is based on the ordinary SCM
# estimator and should NOT be directly reused for p-values of this new estimator.
# Formal placebo/randomization inference should re-run this entire estimator
# (including graph construction, tuning policy, and optional bias correction)
# for pseudo-treated areas/sites.


# =============================================================================
# 15. Simulation-only truth diagnostics
# =============================================================================
if (is.null(dataset$simulation_truth)) {
  stop("simulation_truth is missing. This script must be run on the 04a synthetic dataset.")
}

truth <- dataset$simulation_truth
ECONOMIC_DISTANCE_ACTIVE_TRUTH <- isTRUE(truth$parameters$economic_distance_active)
cat("Truth uses economic distance:", ECONOMIC_DISTANCE_ACTIVE_TRUTH, "\n")
cat("Main Gneiting kriging/spCF economic covariates: OFF by v14 design\n")
cat("Direct Gneiting kriging/spCF information mode: ONE-SIDED; hyperparameters tuned on PRE only\n")
W_true_all <- truth$W_true
true_cf_log_all <- truth$true_cf_log
true_tau_log_all <- truth$tau_log

# Align truth to the exact treatment and donor order used by the fitted model.
W_true_use <- W_true_all[target_meta$point_id, control_df$point_id, drop = FALSE]
true_cf_use <- true_cf_log_all[target_meta$point_id, as.character(YEARS), drop = FALSE]
true_tau_use <- true_tau_log_all[target_meta$point_id, as.character(YEARS), drop = FALSE]

# ---- 15a. Small-simulation exact QP validation ------------------------------
# This is NOT used to choose hyperparameters. In v6 the authoritative final
# Graph/GeoEco fits already use native sparse OSQP. This optional CVXR solve is
# therefore only an independent exact-QP cross-audit (disabled in production by default).
fit_exact_qp_cvxr <- function(Yt_train, Yc_train, graph_obj, lambda, rho = 0) {
  if (!requireNamespace("CVXR", quietly = TRUE)) {
    return(list(ok = FALSE, status = "SKIPPED_CVXR_NOT_INSTALLED", W = NULL,
                value = NA_real_, solver = NA_character_, message =
                  "Install CVXR to run the exact-QP validation."))
  }
  solvers <- tryCatch(CVXR::installed_solvers(), error = function(e) character(0))
  if (!EXACT_QP_SOLVER %in% solvers) {
    return(list(ok = FALSE, status = "SKIPPED_OSQP_NOT_AVAILABLE", W = NULL,
                value = NA_real_, solver = EXACT_QP_SOLVER,
                message = paste0("CVXR is installed but solver ", EXACT_QP_SOLVER,
                                 " is unavailable. Installed: ", paste(solvers, collapse = ", "))))
  }

  N0 <- nrow(Yt_train); J0 <- ncol(Yc_train)
  n_obs <- rowSums(is.finite(Yt_train))
  active <- which(n_obs > 0)
  n_fit_sites <- length(active)
  if (n_fit_sites == 0) stop("Exact-QP validation has no active PRE sites.")
  sum_a <- sum(graph_obj$edges$a)
  if (!is.finite(sum_a) || sum_a <= 0) sum_a <- 1

  # CVXR >= 1.0 expects matrix dimensions as one vector, e.g. Variable(c(n, p)).
  # Keep the entire diagnostic solve inside tryCatch: exact-QP validation is only a
  # numerical cross-check and must never abort the simulation suite.
  ans <- tryCatch({
    Wv <- CVXR::Variable(c(N0, J0), name = "W_exact_qp")
    obj <- 0
    for (ii in active) {
      obs <- which(is.finite(Yt_train[ii, ]))
      # CVXR 1.8 preserves 2D shapes. Wv[ii, , drop = FALSE] is 1 x J,
      # so transpose it to a J x 1 column vector before matrix multiplication.
      w_i_col <- t(Wv[ii, , drop = FALSE])
      pred_i <- Yc_train[obs, , drop = FALSE] %*% w_i_col
      obj <- obj + CVXR::sum_squares(pred_i - Yt_train[ii, obs]) /
        (n_fit_sites * length(obs))
    }
    if (lambda > 0) {
      Ddense <- as.matrix(graph_obj$Dg)
      obj <- obj + (lambda / sum_a) * CVXR::sum_squares(Ddense %*% Wv)
    }
    obj <- obj + ((rho + NUMERICAL_RIDGE) / N0) * CVXR::sum_squares(Wv)

    cons <- list(Wv >= 0)
    for (ii in seq_len(N0)) {
      cons[[length(cons) + 1L]] <- CVXR::sum_entries(Wv[ii, ]) == 1
    }
    prob <- CVXR::Problem(CVXR::Minimize(obj), cons)

    # Current CVXR API: psolve() returns the optimal objective value; value()
    # extracts the variable. Standard tolerance names are mapped to OSQP.
    opt_value <- CVXR::psolve(
      prob, solver = EXACT_QP_SOLVER, verbose = FALSE,
      abstol = EXACT_QP_EPS_ABS, reltol = EXACT_QP_EPS_REL,
      num_iter = EXACT_QP_MAX_ITER
    )
    Wq <- CVXR::value(Wv)
    status_qp <- tryCatch(as.character(prob@status), error = function(e) NA_character_)
    if (length(status_qp) == 0L || is.na(status_qp) || !nzchar(status_qp)) {
      status_qp <- "SOLVED"
    }
    ok <- !is.null(Wq) && all(dim(Wq) == c(N0, J0)) && all(is.finite(Wq))
    list(ok = ok, status = status_qp, W = Wq,
         value = as.numeric(opt_value), solver = EXACT_QP_SOLVER,
         message = if (ok) NA_character_ else "CVXR returned no finite matrix solution.")
  }, error = function(e) {
    list(ok = FALSE, status = "ERROR", W = NULL, value = NA_real_,
         solver = EXACT_QP_SOLVER, message = conditionMessage(e))
  })
  ans
}

exact_qp_result <- list(ok = FALSE, status = "NOT_RUN", W = NULL,
                        value = NA_real_, solver = NA_character_, message = NA_character_)
exact_qp_validation <- tibble::tibble(
  exact_qp_requested = RUN_EXACT_QP_VALIDATION,
  exact_qp_ok = FALSE,
  exact_qp_status = "NOT_RUN",
  exact_qp_solver = NA_character_,
  exact_qp_message = NA_character_,
  fista_objective = final_fit$value,
  exact_qp_objective = NA_real_,
  objective_relative_gap = NA_real_,
  weight_relative_F = NA_real_,
  pre_prediction_disagreement_RMSE = NA_real_,
  post_counterfactual_disagreement_RMSE = NA_real_,
  fista_projected_gradient_norm = final_fit$projected_gradient_norm
)

if (RUN_EXACT_QP_VALIDATION) {
  cat("\nExact-QP validation of the selected final fit (simulation only)...\n")
  runtime_exact_qp_start <- Sys.time()
  exact_qp_result <- fit_exact_qp_cvxr(
    Yt_pre, Yc_pre, final_graph, lambda = best_lambda, rho = 0
  )
  if (isTRUE(exact_qp_result$ok)) {
    W_qp <- exact_qp_result$W
    rownames(W_qp) <- target_meta$point_id
    colnames(W_qp) <- control_df$point_id
    pre_f <- W_hat %*% t(Yc_pre)
    pre_q <- W_qp %*% t(Yc_pre)
    post_pos_exact <- match(PERIOD_POST, YEARS)
    post_f <- (W_hat %*% t(Yc_all))[, post_pos_exact, drop = FALSE]
    post_q <- (W_qp %*% t(Yc_all))[, post_pos_exact, drop = FALSE]
    obj_den <- max(1, abs(exact_qp_result$value))
    exact_qp_validation <- tibble::tibble(
      exact_qp_requested = TRUE,
      exact_qp_ok = TRUE,
      exact_qp_status = exact_qp_result$status,
      exact_qp_solver = exact_qp_result$solver,
      exact_qp_message = NA_character_,
      fista_objective = final_fit$value,
      exact_qp_objective = exact_qp_result$value,
      objective_relative_gap = abs(final_fit$value - exact_qp_result$value) / obj_den,
      weight_relative_F = sqrt(sum((W_hat - W_qp)^2)) / max(1, sqrt(sum(W_qp^2))),
      pre_prediction_disagreement_RMSE = sqrt(mean((pre_f - pre_q)^2)),
      post_counterfactual_disagreement_RMSE = sqrt(mean((post_f - post_q)^2)),
      fista_projected_gradient_norm = final_fit$projected_gradient_norm
    )
    exact_weight_diff <- tibble::tibble(
      point_id = target_meta$point_id,
      obs_group = target_meta$obs_group,
      weight_L2_difference = sqrt(rowSums((W_hat - W_qp)^2)),
      pre_prediction_RMSE_difference = sqrt(rowMeans((pre_f - pre_q)^2)),
      post_counterfactual_RMSE_difference = sqrt(rowMeans((post_f - post_q)^2))
    )
    readr::write_csv(exact_weight_diff,
                     file.path(OUTPUT_DIR, "simulation_exact_qp_validation_by_site.csv"))
  } else {
    exact_qp_validation <- exact_qp_validation %>%
      dplyr::mutate(
        exact_qp_status = exact_qp_result$status,
        exact_qp_solver = exact_qp_result$solver,
        exact_qp_message = exact_qp_result$message
      )
    warning("Exact-QP validation was skipped/failed: ", exact_qp_result$status,
            ifelse(is.na(exact_qp_result$message), "", paste0(" | ", exact_qp_result$message)))
  }
  runtime_exact_qp_sec <- as.numeric(difftime(Sys.time(), runtime_exact_qp_start, units = "secs"))
}
readr::write_csv(exact_qp_validation,
                 file.path(OUTPUT_DIR, "simulation_exact_qp_validation.csv"))

# ---- 15b. Weight recovery ----------------------------------------------------
# Weight recovery is reported as a secondary diagnostic because SCM weights can
# be non-unique when donors are collinear. Counterfactual recovery is primary.
cosine_row <- function(a, b) {
  den <- sqrt(sum(a^2)) * sqrt(sum(b^2))
  if (!is.finite(den) || den <= 0) return(NA_real_)
  sum(a * b) / den
}

weight_diag_truth <- tibble::tibble(
  point_id = target_meta$point_id,
  obs_group = target_meta$obs_group,
  weight_RMSE = sqrt(rowMeans((W_hat - W_true_use)^2)),
  weight_L1 = rowSums(abs(W_hat - W_true_use)),
  weight_cosine = vapply(seq_len(nrow(W_hat)), function(i) {
    cosine_row(W_hat[i, ], W_true_use[i, ])
  }, numeric(1))
)
readr::write_csv(weight_diag_truth,
                 file.path(OUTPUT_DIR, "simulation_weight_recovery_by_site.csv"))

weight_summary <- weight_diag_truth %>%
  dplyr::group_by(obs_group) %>%
  dplyr::summarise(
    n = dplyr::n(),
    mean_weight_RMSE = mean(weight_RMSE, na.rm = TRUE),
    mean_weight_L1 = mean(weight_L1, na.rm = TRUE),
    mean_weight_cosine = mean(weight_cosine, na.rm = TRUE),
    .groups = "drop"
  )

# ---- 15c. Counterfactual recovery -------------------------------------------
post_pos_truth <- match(PERIOD_POST, YEARS)
pre_pos_truth <- match(PERIOD_PRE, YEARS)

cf_err_post <- Y0_raw[, post_pos_truth, drop = FALSE] -
  true_cf_use[, post_pos_truth, drop = FALSE]
cf_err_pre <- Y0_raw[, pre_pos_truth, drop = FALSE] -
  true_cf_use[, pre_pos_truth, drop = FALSE]

cf_site <- tibble::tibble(
  point_id = target_meta$point_id,
  obs_group = target_meta$obs_group,
  post_CF_RMSE_log = sqrt(rowMeans(cf_err_post^2)),
  post_CF_MAE_log = rowMeans(abs(cf_err_post)),
  post_CF_signed_mean_bias_log = rowMeans(cf_err_post),
  post_CF_signed_mean_bias_pct = rowMeans((exp(cf_err_post) - 1) * 100),
  post_CF_RMSE_pct = sqrt(rowMeans(((exp(cf_err_post) - 1) * 100)^2)),
  pre_CF_RMSE_log_all_truth = sqrt(rowMeans(cf_err_pre^2))
)
readr::write_csv(cf_site,
                 file.path(OUTPUT_DIR, "simulation_counterfactual_recovery_by_site.csv"))

cf_group_summary <- cf_site %>%
  dplyr::group_by(obs_group) %>%
  dplyr::summarise(
    n = dplyr::n(),
    post_CF_RMSE_log = sqrt(mean(post_CF_RMSE_log^2)),
    mean_post_CF_MAE_log = mean(post_CF_MAE_log),
    post_CF_signed_mean_bias_log = mean(post_CF_signed_mean_bias_log),
    post_CF_signed_mean_bias_pct = mean(post_CF_signed_mean_bias_pct),
    post_CF_RMSE_pct = sqrt(mean(post_CF_RMSE_pct^2)),
    .groups = "drop"
  )

cf_overall <- tibble::tibble(
  obs_group = "ALL",
  n = nrow(cf_site),
  post_CF_RMSE_log = sqrt(mean(cf_err_post^2)),
  mean_post_CF_MAE_log = mean(abs(cf_err_post)),
  post_CF_signed_mean_bias_log = mean(cf_err_post),
  post_CF_signed_mean_bias_pct = mean((exp(cf_err_post) - 1) * 100),
  post_CF_RMSE_pct = sqrt(mean(((exp(cf_err_post) - 1) * 100)^2))
)

cf_summary <- dplyr::bind_rows(cf_group_summary, cf_overall)
readr::write_csv(cf_summary,
                 file.path(OUTPUT_DIR, "simulation_counterfactual_recovery_summary.csv"))

# ---- 15c. Treatment-effect / ATT recovery -----------------------------------
# Compute ATT directly from aligned matrices. This avoids fragile long-table
# joins and fixes the earlier NA issue in ATT diagnostics.
estimated_effect_log_mat <- Y_target_all - Y0_raw
true_effect_log_mat <- true_tau_use

att_rows <- vector("list", length(PERIOD_POST))
for (hh in seq_along(PERIOD_POST)) {
  yy <- PERIOD_POST[hh]
  pp <- match(yy, YEARS)
  est_v <- estimated_effect_log_mat[, pp]
  tru_v <- true_effect_log_mat[, pp]
  ok <- is.finite(est_v) & is.finite(tru_v)

  if (!any(ok)) {
    att_rows[[hh]] <- tibble::tibble(
      year = yy, n = 0L,
      true_ATT_log = NA_real_, estimated_ATT_log = NA_real_,
      ATT_bias_log = NA_real_, true_ATT_pct = NA_real_,
      estimated_ATT_pct = NA_real_, ATT_bias_percentage_points = NA_real_
    )
  } else {
    true_att_log_h <- mean(tru_v[ok])
    est_att_log_h <- mean(est_v[ok])
    true_att_pct_h <- (exp(true_att_log_h) - 1) * 100
    est_att_pct_h <- (exp(est_att_log_h) - 1) * 100
    att_rows[[hh]] <- tibble::tibble(
      year = yy,
      n = sum(ok),
      true_ATT_log = true_att_log_h,
      estimated_ATT_log = est_att_log_h,
      ATT_bias_log = est_att_log_h - true_att_log_h,
      true_ATT_pct = true_att_pct_h,
      estimated_ATT_pct = est_att_pct_h,
      ATT_bias_percentage_points = est_att_pct_h - true_att_pct_h
    )
  }
}
att_truth_compare <- dplyr::bind_rows(att_rows)
readr::write_csv(att_truth_compare,
                 file.path(OUTPUT_DIR, "simulation_ATT_truth_vs_estimated.csv"))

# Individual site-year effects with truth, built from matrices with guaranteed
# row/column alignment.
make_matrix_long <- function(M, value_name) {
  z <- as.data.frame(M, check.names = FALSE) %>%
    tibble::rownames_to_column("point_id") %>%
    tidyr::pivot_longer(-point_id, names_to = "year", values_to = value_name) %>%
    dplyr::mutate(year = as.integer(year))
  z
}

est_effect_long <- make_matrix_long(estimated_effect_log_mat, "estimated_effect_log")
true_effect_long <- make_matrix_long(true_effect_log_mat, "true_tau_log")

sim_effect_long <- est_effect_long %>%
  dplyr::left_join(true_effect_long, by = c("point_id", "year")) %>%
  dplyr::left_join(target_meta %>% dplyr::select(point_id, obs_group), by = "point_id") %>%
  dplyr::mutate(
    true_tau_pct = (exp(true_tau_log) - 1) * 100,
    estimated_effect_pct = (exp(estimated_effect_log) - 1) * 100,
    effect_error_log_raw = estimated_effect_log - true_tau_log,
    effect_error_pct_raw = estimated_effect_pct - true_tau_pct
  )
readr::write_csv(sim_effect_long,
                 file.path(OUTPUT_DIR, "simulation_effects_with_truth_long.csv"))

att_overall_metrics <- tibble::tibble(
  metric = c(
    "ATT_RMSE_log_across_years",
    "ATT_MAE_log_across_years",
    "ATT_RMSE_percentage_points_across_years",
    "ATT_MAE_percentage_points_across_years",
    "mean_individual_post_effect_RMSE_log"
  ),
  value = c(
    sqrt(mean(att_truth_compare$ATT_bias_log^2, na.rm = TRUE)),
    mean(abs(att_truth_compare$ATT_bias_log), na.rm = TRUE),
    sqrt(mean(att_truth_compare$ATT_bias_percentage_points^2, na.rm = TRUE)),
    mean(abs(att_truth_compare$ATT_bias_percentage_points), na.rm = TRUE),
    sqrt(mean(sim_effect_long$effect_error_log_raw[
      sim_effect_long$year %in% PERIOD_POST & is.finite(sim_effect_long$estimated_effect_log)
    ]^2, na.rm = TRUE))
  )
)
readr::write_csv(att_overall_metrics,
                 file.path(OUTPUT_DIR, "simulation_ATT_recovery_metrics.csv"))

# ATT recovery by observation group.
att_group_rows <- list()
cc_att <- 1L
for (g in unique(target_meta$obs_group)) {
  ii <- which(target_meta$obs_group == g)
  for (yy in PERIOD_POST) {
    pp <- match(yy, YEARS)
    est_v <- estimated_effect_log_mat[ii, pp]
    tru_v <- true_effect_log_mat[ii, pp]
    ok <- is.finite(est_v) & is.finite(tru_v)
    if (!any(ok)) next
    ta <- mean(tru_v[ok])
    ea <- mean(est_v[ok])
    att_group_rows[[cc_att]] <- tibble::tibble(
      obs_group = g, year = yy, n = sum(ok),
      true_ATT_log = ta, estimated_ATT_log = ea,
      true_ATT_pct = (exp(ta) - 1) * 100,
      estimated_ATT_pct = (exp(ea) - 1) * 100,
      ATT_bias_percentage_points = (exp(ea) - exp(ta)) * 100
    )
    cc_att <- cc_att + 1L
  }
}
att_by_group_truth <- dplyr::bind_rows(att_group_rows)
readr::write_csv(att_by_group_truth,
                 file.path(OUTPUT_DIR, "simulation_ATT_truth_vs_estimated_by_group.csv"))

# ---- 15c-2. Weight non-uniqueness / rho + initialization stability ----------
# The substantive question is not whether W itself changes, but whether those
# changes propagate to counterfactuals and ATT. v6 widens rho to a practically
# meaningful range and, at EVERY tested rho, compares a uniform cold start with
# an independent random-simplex start. rho remains a sensitivity diagnostic; it
# is not selected to maximize simulation performance.
rho_sensitivity <- tibble::tibble()
rho_sensitivity_by_group <- tibble::tibble()
initialization_sensitivity <- tibble::tibble()
rho_initialization_stability_summary <- tibble::tibble()

att_rmse_from_cf <- function(Y0_candidate, ii = seq_len(N)) {
  rows <- numeric(length(PERIOD_POST))
  for (hh in seq_along(PERIOD_POST)) {
    pp <- match(PERIOD_POST[hh], YEARS)
    est_eff <- Y_target_all[ii, pp] - Y0_candidate[ii, pp]
    tru_eff <- true_tau_use[ii, pp]
    ok <- is.finite(est_eff) & is.finite(tru_eff)
    if (!any(ok)) { rows[hh] <- NA_real_; next }
    ea <- mean(est_eff[ok]); ta <- mean(tru_eff[ok])
    rows[hh] <- (exp(ea) - exp(ta)) * 100
  }
  if (!any(is.finite(rows))) return(NA_real_)
  sqrt(mean(rows^2, na.rm = TRUE))
}

safe_rmse <- function(x) {
  z <- x[is.finite(x)]
  if (!length(z)) return(NA_real_)
  sqrt(mean(z^2))
}

if (RUN_RHO_STABILITY) {
  rho_values <- unique(rho_base * RHO_STABILITY_MULTIPLIERS)
  base_W <- W_hat
  base_Y0_numeric <- Y0_numeric
  rho_rows <- list(); rho_group_rows <- list(); init_rows <- list()

  for (rr in seq_along(rho_values)) {
    rv <- rho_values[rr]
    rmult <- rv / rho_base
    if (isTRUE(all.equal(rv, 0))) {
      fit_r <- final_fit
      W_r <- base_W
      Y0_r_numeric <- base_Y0_numeric
    } else {
      cat(sprintf("Rho stability %d/%d | rho=%.6g (%.3g x rho_base)\n",
                  rr, length(rho_values), rv, rmult))
      fit_r <- fit_smooth_scm(
        Yt_pre, Yc_pre, final_graph, lambda = best_lambda, rho = rv,
        W_start = NULL, max_iter = FISTA_MAX_ITER_FINAL,
        tol = FISTA_TOL_FINAL, min_iter = FISTA_MIN_ITER_FINAL,
        fit_label = sprintf("rho stability %.3g", rv)
      )
      W_r <- fit_r$W
      Y0_r_numeric <- W_r %*% t(Yc_all)
      colnames(Y0_r_numeric) <- YEARS
      rownames(Y0_r_numeric) <- target_meta$point_id
    }

    # Compare each rho to the rho=0 numerical solution.
    err_true <- Y0_r_numeric[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
    disagree0 <- Y0_r_numeric[, post_pos_truth, drop = FALSE] -
      base_Y0_numeric[, post_pos_truth, drop = FALSE]

    # At the same rho, perturb the initialization. This is the key v6 test of
    # whether ridge regularization stabilizes a non-unique donor representation.
    fit_alt <- NULL
    W_alt <- NULL
    Y0_alt_numeric <- NULL
    init_w_diff <- NA_real_
    init_cf_diff <- NA_real_
    init_pass <- NA
    if (RUN_INITIALIZATION_STABILITY) {
      set.seed(INIT_SENSITIVITY_SEED + rr - 1L)
      W_random_start <- matrix(stats::rexp(N * J), nrow = N, ncol = J)
      W_random_start <- W_random_start / rowSums(W_random_start)
      fit_alt <- fit_smooth_scm(
        Yt_pre, Yc_pre, final_graph, lambda = best_lambda, rho = rv,
        W_start = W_random_start, max_iter = FISTA_MAX_ITER_FINAL,
        tol = FISTA_TOL_FINAL, min_iter = FISTA_MIN_ITER_FINAL,
        fit_label = sprintf("rho %.3g alternative initialization", rv)
      )
      W_alt <- fit_alt$W
      Y0_alt_numeric <- W_alt %*% t(Yc_all)
      colnames(Y0_alt_numeric) <- YEARS
      rownames(Y0_alt_numeric) <- target_meta$point_id
      init_w_diff <- sqrt(sum((W_alt - W_r)^2)) /
        max(1e-12, sqrt(sum(W_r^2)))
      init_cf_diff <- safe_rmse(
        Y0_alt_numeric[, post_pos_truth, drop = FALSE] -
          Y0_r_numeric[, post_pos_truth, drop = FALSE]
      )
      init_pass <- is.finite(init_cf_diff) && init_cf_diff <= INIT_CF_STABILITY_TOL
      init_rows[[length(init_rows) + 1L]] <- tibble::tibble(
        rho = rv,
        rho_multiplier = rmult,
        weight_relative_F = init_w_diff,
        post_CF_disagreement_RMSE = init_cf_diff,
        init_CF_stability_threshold = INIT_CF_STABILITY_TOL,
        init_stability_pass = init_pass,
        true_post_CF_RMSE_log_uniform_start = safe_rmse(err_true),
        true_post_CF_RMSE_log_random_start = safe_rmse(
          Y0_alt_numeric[, post_pos_truth, drop = FALSE] -
            true_cf_use[, post_pos_truth, drop = FALSE]
        ),
        ATT_RMSE_pp_uniform_start = att_rmse_from_cf(Y0_r_numeric),
        ATT_RMSE_pp_random_start = att_rmse_from_cf(Y0_alt_numeric),
        solver_status_uniform = fit_r$status,
        solver_status_random = fit_alt$status,
        projected_gradient_norm_uniform = fit_r$projected_gradient_norm,
        projected_gradient_norm_random = fit_alt$projected_gradient_norm
      )
    }

    rho_rows[[rr]] <- tibble::tibble(
      rho = rv,
      rho_multiplier = rmult,
      weight_relative_F_vs_rho0 = sqrt(sum((W_r - base_W)^2)) /
        max(1e-12, sqrt(sum(base_W^2))),
      post_CF_disagreement_RMSE_vs_rho0 = safe_rmse(disagree0),
      true_post_CF_RMSE_log = safe_rmse(err_true),
      ATT_RMSE_pp = att_rmse_from_cf(Y0_r_numeric),
      pre_fit_loss = fit_r$fit_loss,
      median_effective_donors = median(1 / rowSums(W_r^2)),
      median_max_weight = median(apply(W_r, 1, max)),
      initialization_weight_relative_F = init_w_diff,
      initialization_post_CF_disagreement_RMSE = init_cf_diff,
      initialization_stability_pass = init_pass,
      solver_status = fit_r$status,
      fista_iter = fit_r$fista_iter,
      fista_rel_change = fit_r$fista_rel_change,
      fista_pred_rel_change = fit_r$fista_pred_rel_change,
      fista_obj_rel_change = fit_r$fista_obj_rel_change,
      projected_gradient_norm = fit_r$projected_gradient_norm
    )

    for (gg in c("complete_pre", "partial_pre", "post_only", "ALL")) {
      ii <- if (gg == "ALL") seq_len(N) else which(target_meta$obs_group == gg)
      er <- Y0_r_numeric[ii, post_pos_truth, drop = FALSE] -
        true_cf_use[ii, post_pos_truth, drop = FALSE]
      ds <- Y0_r_numeric[ii, post_pos_truth, drop = FALSE] -
        base_Y0_numeric[ii, post_pos_truth, drop = FALSE]
      rho_group_rows[[length(rho_group_rows) + 1L]] <- tibble::tibble(
        rho = rv,
        rho_multiplier = rmult,
        obs_group = gg,
        n = length(ii),
        true_post_CF_RMSE_log = safe_rmse(er),
        post_CF_disagreement_RMSE_vs_rho0 = safe_rmse(ds),
        ATT_RMSE_pp = att_rmse_from_cf(Y0_r_numeric, ii)
      )
    }
  }

  rho_sensitivity <- dplyr::bind_rows(rho_rows)
  rho_sensitivity_by_group <- dplyr::bind_rows(rho_group_rows)
  initialization_sensitivity <- dplyr::bind_rows(init_rows)

  readr::write_csv(rho_sensitivity,
                   file.path(OUTPUT_DIR, "simulation_rho_sensitivity.csv"))
  readr::write_csv(rho_sensitivity_by_group,
                   file.path(OUTPUT_DIR, "simulation_rho_sensitivity_by_group.csv"))
  readr::write_csv(initialization_sensitivity,
                   file.path(OUTPUT_DIR, "simulation_initialization_sensitivity.csv"))

  if (nrow(initialization_sensitivity) > 0) {
    stable_rows <- initialization_sensitivity %>%
      dplyr::filter(init_stability_pass %in% TRUE) %>%
      dplyr::arrange(rho_multiplier)
    rho_initialization_stability_summary <- tibble::tibble(
      threshold_post_CF_RMSE = INIT_CF_STABILITY_TOL,
      any_tested_rho_stable = nrow(stable_rows) > 0,
      min_stable_rho = if (nrow(stable_rows) > 0) stable_rows$rho[1] else NA_real_,
      min_stable_rho_multiplier = if (nrow(stable_rows) > 0) stable_rows$rho_multiplier[1] else NA_real_,
      note = "Diagnostic only: rho is not selected by simulation truth or ATT performance."
    )
    readr::write_csv(rho_initialization_stability_summary,
                     file.path(OUTPUT_DIR, "simulation_rho_initialization_stability_summary.csv"))
  }
}

# ---- 15d. Benchmarks ---------------------------------------------------------
# Benchmark 1: lambda=0. For complete/partial sites this is independent SCM.
# Post-only sites are NOT data-identified at lambda=0. We therefore keep the
# optimizer's numerical continuation separately, but mask post-only rows in the
# scientific lambda=0 benchmark. The explicit uniform benchmark below remains
# available as a clearly labelled numerical fallback.
cat("\nSimulation benchmark: estimating lambda=0 model...\n")
graph_lambda0 <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = 0)
fit_lambda0 <- fit_smooth_scm(
  Yt_pre, Yc_pre, graph_lambda0,
  lambda = 0, rho = 0,
  W_start = NULL,
  max_iter = FISTA_MAX_ITER_FINAL,
  tol = FISTA_TOL_FINAL,
  progress_every = FISTA_PROGRESS_EVERY,
  fit_label = "simulation lambda=0 benchmark"
)
Y0_lambda0_numeric <- fit_lambda0$W %*% t(Yc_all)
colnames(Y0_lambda0_numeric) <- YEARS
rownames(Y0_lambda0_numeric) <- target_meta$point_id
Y0_lambda0 <- Y0_lambda0_numeric
Y0_lambda0[target_meta$obs_group == "post_only", ] <- NA_real_
err_lambda0 <- Y0_lambda0[, post_pos_truth, drop = FALSE] -
  true_cf_use[, post_pos_truth, drop = FALSE]
err_lambda0_numeric <- Y0_lambda0_numeric[, post_pos_truth, drop = FALSE] -
  true_cf_use[, post_pos_truth, drop = FALSE]
readr::write_csv(
  tibble::tibble(
    method = "Ordinary_SCM",
    n_targets = N,
    n_pre_observed = sum(target_meta$obs_group != "post_only"),
    n_post_only = sum(target_meta$obs_group == "post_only"),
    post_only_site_specific_SCM_identified = FALSE,
    scientific_post_only_counterfactual = "NA",
    numerical_post_only_solution = "optimizer continuation approximately uniform; diagnostic only",
    selection_eligible_for_graph_model = FALSE
  ),
  file.path(OUTPUT_DIR, "simulation_lambda0_identification_status.csv")
)

err_geo_only <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                       dimnames = list(target_meta$point_id, PERIOD_POST))
if (!is.null(Y0_geo_only)) {
  err_geo_only <- Y0_geo_only[, post_pos_truth, drop = FALSE] -
    true_cf_use[, post_pos_truth, drop = FALSE]
}

# Benchmark 2: explicitly uniform donor weights for every site. This diagnoses
# whether the DGP is too easy/diffuse for spatial regularization to matter.
W_uniform <- matrix(1 / J, nrow = N, ncol = J,
                    dimnames = list(target_meta$point_id, control_df$point_id))
Y0_uniform <- W_uniform %*% t(Yc_all)
colnames(Y0_uniform) <- YEARS
rownames(Y0_uniform) <- target_meta$point_id
err_uniform <- Y0_uniform[, post_pos_truth, drop = FALSE] -
  true_cf_use[, post_pos_truth, drop = FALSE]

# Benchmark 3-6: Gneiting kriging / spCF, direct and two-stage -----------------------
# Information sets are deliberately separated:
#   PRE -> SCM methods:
#     use ONLY observed target PRE outcomes to reconstruct missing target PRE,
#     then estimate ordinary SCM weights and apply them to donor outcomes.
#   Direct methods (ONE-SIDED):
#     for prediction year t, use untreated donor outcomes only through t plus
#     observed target PRE outcomes. Controls after t and treated target POST
#     outcomes are NEVER used. Hyperparameters are tuned on PRE only.
#
# The Gaussian Gneiting kriging benchmark is intentionally transparent but cubic in
# the number of training cells. spCF is included as the scalable alternative.

pairwise_space <- function(xy_a, xy_b = NULL) {
  if (is.null(xy_b)) xy_b <- xy_a
  dx <- outer(xy_a[, 1], xy_b[, 1], "-")
  dy <- outer(xy_a[, 2], xy_b[, 2], "-")
  sqrt(dx^2 + dy^2)
}

chol_solve <- function(R, b) {
  # R is upper triangular with t(R) %*% R = K.
  backsolve(R, forwardsolve(t(R), b))
}

# Benchmark data builders carry coordinates and safe PRE economic proxies.
# Whether those proxies are USED is controlled explicitly by use_econ in each
# model call.  Spatial-only benchmark calls use_econ=FALSE; Econ-X calls use TRUE.
make_target_pre_long <- function(Y_pre, meta, observed_only = TRUE) {
  z0 <- as.data.frame(Y_pre, optional = TRUE)
  names(z0) <- colnames(Y_pre)
  z <- z0 %>%
    tibble::rownames_to_column("point_id") %>%
    tidyr::pivot_longer(-point_id, names_to = "year", values_to = "y") %>%
    dplyr::mutate(year = as.integer(year)) %>%
    dplyr::left_join(
      meta %>% dplyr::select(point_id, X_m, Y_m, dplyr::all_of(ECON_FEATURES)),
      by = "point_id"
    )
  if (observed_only) z <- z %>% dplyr::filter(is.finite(y))
  z
}

make_control_long <- function(Y_control, control_meta) {
  z0 <- as.data.frame(Y_control, optional = TRUE)
  names(z0) <- colnames(Y_control)
  z0 %>%
    tibble::rownames_to_column("point_id") %>%
    tidyr::pivot_longer(-point_id, names_to = "year", values_to = "y") %>%
    dplyr::mutate(year = as.integer(year)) %>%
    dplyr::left_join(
      control_meta %>% dplyr::select(point_id, X_m, Y_m, dplyr::all_of(ECON_FEATURES)),
      by = "point_id"
    ) %>%
    dplyr::filter(is.finite(y))
}

make_target_post_prediction_grid <- function(meta) {
  tidyr::expand_grid(point_id = meta$point_id, year = PERIOD_POST) %>%
    dplyr::left_join(
      meta %>% dplyr::select(point_id, X_m, Y_m, dplyr::all_of(ECON_FEATURES)),
      by = "point_id"
    )
}

build_uk_formula <- function(use_econ = FALSE) {
  rhs <- c("factor(year)", "X_km", "Y_km")
  if (isTRUE(use_econ)) rhs <- c(rhs, ECON_FEATURES)
  stats::as.formula(paste("y ~", paste(rhs, collapse = " + ")))
}

prepare_st_training <- function(train, label = "Gneiting kriging", use_econ = FALSE) {
  req <- c("year", "y", "X_m", "Y_m")
  if (!all(req %in% names(train))) stop(label, ": malformed training table.")
  if (isTRUE(use_econ)) {
    miss_econ_train <- setdiff(ECON_FEATURES, names(train))
    if (length(miss_econ_train)) {
      stop(label, ": safe PRE economic covariates are missing for Econ-X benchmark.")
    }
  }
  train <- train %>%
    dplyr::filter(is.finite(y), is.finite(X_m), is.finite(Y_m)) %>%
    dplyr::mutate(X_km = X_m / 1000, Y_km = Y_m / 1000)
  if (nrow(train) < 30) stop(label, ": too few observed cells.")
  train
}

gneiting_corr_matrix <- function(Ds, Dt, phi_space_m, phi_time_year, sep,
                                 power_s = GNK_POWER_S, power_t = GNK_POWER_T) {
  hs <- pmax(Ds / phi_space_m, 0)
  ut <- pmax(Dt / phi_time_year, 0)
  temporal_scale <- 1 + ut^power_t
  exp(-(hs^power_s) / temporal_scale^(0.5 * sep * power_s)) / temporal_scale
}

# Tuning is cached separately for Econ-X and no-Econ because the PRE training
# set is identical for two-stage and direct benchmarks. This avoids repeating
# the 54-candidate covariance search for the direct benchmark.
.gneiting_tuning_cache <- new.env(parent = emptyenv())

get_gneiting_tuning_cached <- function(train, seed = GNK_SEED,
                                       label = "Gneiting tuning", use_econ = FALSE) {
  key <- if (isTRUE(use_econ)) "econ" else "noecon"
  if (exists(key, envir = .gneiting_tuning_cache, inherits = FALSE)) {
    out <- get(key, envir = .gneiting_tuning_cache, inherits = FALSE)
    out$cache_hit <- TRUE
    return(out)
  }
  out <- tune_gneiting_kriging_long(
    train, seed = seed, label = label, use_econ = use_econ
  )
  out$cache_hit <- FALSE
  assign(key, out, envir = .gneiting_tuning_cache)
  out
}

tune_gneiting_kriging_long <- function(train, seed = GNK_SEED,
                                  label = "Gneiting kriging tuning", use_econ = FALSE) {
  train <- prepare_st_training(train, label = label, use_econ = use_econ)
  trend_formula <- build_uk_formula(use_econ = use_econ)
  trend_fit <- stats::lm(trend_formula, data = train)
  train$trend <- as.numeric(stats::predict(trend_fit, newdata = train))
  train$resid <- train$y - train$trend

  unique_xy <- unique(as.matrix(train[, c("X_m", "Y_m")]))
  if (nrow(unique_xy) >= 2) {
    k0 <- min(5L, nrow(unique_xy) - 1L)
    nn0 <- FNN::get.knn(unique_xy, k = k0)
    space_base <- stats::median(
      nn0$nn.dist[is.finite(nn0$nn.dist) & nn0$nn.dist > 0], na.rm = TRUE
    )
  } else {
    space_base <- 2000
  }
  if (!is.finite(space_base) || space_base <= 0) space_base <- 2000

  set.seed(seed)
  tune_idx <- if (nrow(train) > GNK_MAX_TUNING_OBS) {
    sort(sample(seq_len(nrow(train)), GNK_MAX_TUNING_OBS, replace = FALSE))
  } else seq_len(nrow(train))

  tune <- train[tune_idx, , drop = FALSE]
  xy_tune <- as.matrix(tune[, c("X_m", "Y_m")])
  Ds <- pairwise_space(xy_tune)
  Dt <- abs(outer(tune$year, tune$year, "-"))
  rr <- tune$resid

  param_grid <- tidyr::expand_grid(
    phi_space_m = space_base * GNK_SPACE_MULTIPLIERS,
    phi_time_year = GNK_TIME_RANGES_YEARS,
    sep = GNK_SEP_GRID,
    nugget_ratio = GNK_NUGGET_RATIOS
  )

  stk_nll <- function(phi_s, phi_t, sep, nug) {
    K <- gneiting_corr_matrix(Ds, Dt, phi_s, phi_t, sep)
    diag(K) <- diag(K) + nug + GNK_JITTER
    R <- tryCatch(chol(K), error = function(e) NULL)
    if (is.null(R)) return(Inf)
    alpha <- chol_solve(R, rr)
    quad <- sum(rr * alpha)
    if (!is.finite(quad) || quad <= 0) return(Inf)
    sigma2_hat <- quad / length(rr)
    logdet <- 2 * sum(log(diag(R)))
    0.5 * (length(rr) * log(sigma2_hat) + logdet)
  }

  param_grid$nll <- vapply(seq_len(nrow(param_grid)), function(g) {
    stk_nll(
      param_grid$phi_space_m[g],
      param_grid$phi_time_year[g],
      param_grid$sep[g],
      param_grid$nugget_ratio[g]
    )
  }, numeric(1))
  param_grid <- param_grid %>% dplyr::arrange(nll)
  best <- param_grid[1, , drop = FALSE]
  if (!is.finite(best$nll[1])) stop(label, ": all covariance candidates failed.")

  list(
    tuning = param_grid,
    best = best,
    space_base_m = space_base,
    n_tuning = length(tune_idx),
    tuning_max_year = max(train$year, na.rm = TRUE),
    use_econ = use_econ
  )
}

fit_gneiting_kriging_fixed_long <- function(train, pred, best,
                                      label = "Gneiting kriging fixed-parameter fit",
                                      use_econ = FALSE) {
  if (!all(c("year", "X_m", "Y_m") %in% names(pred))) {
    stop(label, ": malformed prediction table.")
  }
  if (isTRUE(use_econ)) {
    miss_econ_pred <- setdiff(ECON_FEATURES, names(pred))
    if (length(miss_econ_pred)) {
      stop(label, ": safe PRE economic covariates are missing for Econ-X benchmark.")
    }
  }
  train <- prepare_st_training(train, label = label, use_econ = use_econ)
  pred <- pred %>% dplyr::mutate(X_km = X_m / 1000, Y_km = Y_m / 1000)

  trend_formula <- build_uk_formula(use_econ = use_econ)
  trend_fit <- stats::lm(trend_formula, data = train)
  train$trend <- as.numeric(stats::predict(trend_fit, newdata = train))
  train$resid <- train$y - train$trend

  phi_space_m <- as.numeric(best$phi_space_m[1])
  phi_time_year <- as.numeric(best$phi_time_year[1])
  sep <- as.numeric(best$sep[1])
  nugget_ratio <- as.numeric(best$nugget_ratio[1])

  xy_obs <- as.matrix(train[, c("X_m", "Y_m")])
  Ds_obs <- pairwise_space(xy_obs)
  Dt_obs <- abs(outer(train$year, train$year, "-"))
  Kobs <- gneiting_corr_matrix(Ds_obs, Dt_obs, phi_space_m, phi_time_year, sep)
  diag(Kobs) <- diag(Kobs) + nugget_ratio + GNK_JITTER
  Rfull <- chol(Kobs)
  alpha_full <- chol_solve(Rfull, train$resid)

  pred$trend <- as.numeric(stats::predict(trend_fit, newdata = pred))
  xy_pred <- as.matrix(pred[, c("X_m", "Y_m")])
  Ds_po <- pairwise_space(xy_pred, xy_obs)
  Dt_po <- abs(outer(pred$year, train$year, "-"))
  Kpo <- gneiting_corr_matrix(Ds_po, Dt_po, phi_space_m, phi_time_year, sep)
  pred$resid_pred <- as.numeric(Kpo %*% alpha_full)
  pred$pred <- pred$trend + pred$resid_pred

  list(pred = pred, train = train, best = best, trend_fit = trend_fit,
       use_econ = use_econ)
}

fit_gneiting_kriging_long <- function(train, pred, seed = GNK_SEED,
                                label = "Gneiting kriging", use_econ = FALSE) {
  tuned <- get_gneiting_tuning_cached(
    train, seed = seed, label = paste0(label, " tuning"), use_econ = use_econ
  )
  fit <- fit_gneiting_kriging_fixed_long(
    train, pred, tuned$best, label = label, use_econ = use_econ
  )
  fit$tuning <- tuned$tuning
  fit$space_base_m <- tuned$space_base_m
  fit$n_tuning <- tuned$n_tuning
  fit$tuning_max_year <- tuned$tuning_max_year
  fit$tuning_cache_hit <- isTRUE(tuned$cache_hit)
  fit
}

fit_preonly_gneiting_kriging <- function(Y_pre, meta, control_pre_long, use_econ = FALSE) {
  full <- make_target_pre_long(Y_pre, meta, observed_only = FALSE)
  target_obs <- full %>% dplyr::filter(is.finite(y))
  # Strong/fair benchmark: every untreated control PRE observation is also safe
  # information for spatial interpolation of missing target PRE outcomes.
  train <- dplyr::bind_rows(control_pre_long, target_obs)
  pred <- full %>% dplyr::filter(!is.finite(y)) %>% dplyr::select(-y)
  fit <- fit_gneiting_kriging_long(
    train, pred,
    label = if (use_econ) "PRE Gneiting kriging + Econ-X" else "PRE Gneiting kriging",
    use_econ = use_econ
  )

  Y_imp <- Y_pre
  miss_idx <- which(!is.finite(Y_pre), arr.ind = TRUE)
  if (nrow(miss_idx) > 0) {
    key <- tidyr::expand_grid(point_id = rownames(Y_pre), year = as.integer(colnames(Y_pre))) %>%
      dplyr::mutate(row_i = rep(seq_len(nrow(Y_pre)), each = ncol(Y_pre)),
                    col_i = rep(seq_len(ncol(Y_pre)), times = nrow(Y_pre)))
    pp <- fit$pred %>% dplyr::select(point_id, year, pred)
    key <- key %>% dplyr::left_join(pp, by = c("point_id", "year"))
    for (rr in seq_len(nrow(key))) {
      if (is.finite(key$pred[rr]) && !is.finite(Y_imp[key$row_i[rr], key$col_i[rr]])) {
        Y_imp[key$row_i[rr], key$col_i[rr]] <- key$pred[rr]
      }
    }
  }
  fit$Y_imputed <- Y_imp
  fit$missing_index <- miss_idx
  fit
}

# Direct-counterfactual data builders.  v14 enforces a one-sided information
# filtration for every POST year t.  Hyperparameters are tuned on PRE only.
# At prediction year t, training contains untreated controls through t plus the
# observed target PRE history; no control observation after t is permitted.
control_long_all <- make_control_long(Y_control_all, control_df)
control_pre_long <- make_control_long(Y_control_all[, pre_pos, drop = FALSE], control_df)
target_pre_obs_long <- make_target_pre_long(Yt_pre, target_meta, observed_only = TRUE)
direct_tuning_long <- dplyr::bind_rows(control_pre_long, target_pre_obs_long)
direct_pred_grid <- make_target_post_prediction_grid(target_meta)

make_direct_train_through_year <- function(prediction_year) {
  dplyr::bind_rows(
    control_long_all %>% dplyr::filter(year <= prediction_year),
    target_pre_obs_long
  )
}

# Utility: put long POST predictions into an N x T matrix.
post_long_to_matrix <- function(pred_long, value_col = "pred") {
  M <- matrix(NA_real_, nrow = N, ncol = length(YEARS),
              dimnames = list(target_meta$point_id, YEARS))
  if (is.null(pred_long) || nrow(pred_long) == 0) return(M)
  ii <- match(pred_long$point_id, target_meta$point_id)
  tt <- match(pred_long$year, YEARS)
  vv <- pred_long[[value_col]]
  ok <- is.finite(ii) & is.finite(tt) & is.finite(vv)
  M[cbind(ii[ok], tt[ok])] <- vv[ok]
  M
}

fit_direct_gneiting_kriging_one_sided <- function(use_econ = FALSE,
                                             seed = GNK_SEED + 1L,
                                             label = "direct Gneiting nonseparable kriging") {
  # PRE-only tuning is fixed before any POST prediction is formed.
  tuned <- get_gneiting_tuning_cached(
    direct_tuning_long,
    seed = seed,
    label = paste0(label, " PRE-only tuning"),
    use_econ = use_econ
  )

  pred_rows <- vector("list", length(PERIOD_POST))
  audit_rows <- vector("list", length(PERIOD_POST))
  elapsed_rows <- numeric(length(PERIOD_POST))

  for (kk in seq_along(PERIOD_POST)) {
    yy <- PERIOD_POST[kk]
    train_y <- make_direct_train_through_year(yy)
    pred_y <- direct_pred_grid %>% dplyr::filter(year == yy)
    t0 <- Sys.time()
    fit_y <- fit_gneiting_kriging_fixed_long(
      train_y, pred_y, tuned$best,
      label = paste0(label, " one-sided year ", yy),
      use_econ = use_econ
    )
    elapsed_rows[kk] <- as.numeric(difftime(Sys.time(), t0, units = "secs")) / 60
    pred_rows[[kk]] <- fit_y$pred
    audit_rows[[kk]] <- tibble::tibble(
      method = if (use_econ) "direct_Gneiting_kriging_EconX" else "direct_Gneiting_kriging",
      information_mode = "one_sided",
      prediction_year = yy,
      hyperparameter_tuning_max_year = tuned$tuning_max_year,
      max_train_year = max(train_y$year, na.rm = TRUE),
      n_train_cells = nrow(train_y),
      n_control_train_cells = sum(train_y$point_id %in% control_df$point_id),
      n_target_pre_train_cells = sum(train_y$point_id %in% target_meta$point_id),
      future_control_cells_used = sum(train_y$point_id %in% control_df$point_id & train_y$year > yy),
      target_post_cells_used = sum(train_y$point_id %in% target_meta$point_id & train_y$year >= min(PERIOD_POST)),
      elapsed_min = elapsed_rows[kk]
    )
  }

  list(
    pred = dplyr::bind_rows(pred_rows),
    tuning = tuned$tuning,
    best = tuned$best,
    space_base_m = tuned$space_base_m,
    n_tuning = tuned$n_tuning,
    tuning_max_year = tuned$tuning_max_year,
    audit = dplyr::bind_rows(audit_rows),
    elapsed_by_year_min = elapsed_rows,
    tuning_cache_hit = isTRUE(tuned$cache_hit),
    use_econ = use_econ
  )
}

# --- 3. PRE Gneiting kriging -> SCM ------------------------------------------------
stk_fit <- NULL
fit_stk_scm <- NULL
Y0_stk_scm <- NULL
err_stk_scm <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                      dimnames = list(target_meta$point_id, PERIOD_POST))
stk_imputation_summary <- tibble::tibble()

if (RUN_GNEITING_SCM_BENCHMARK) {
  cat("\nSimulation benchmark: PRE-only Gneiting nonseparable kriging -> ordinary SCM...\n")
  stk_start <- Sys.time()
  stk_fit <- fit_preonly_gneiting_kriging(Yt_pre, target_meta, control_pre_long)
  readr::write_csv(stk_fit$tuning,
                   file.path(OUTPUT_DIR, "simulation_gneiting_tuning.csv"))

  stk_best <- tibble::tibble(
    phi_space_m = stk_fit$best$phi_space_m,
    phi_time_year = stk_fit$best$phi_time_year,
    sep = stk_fit$best$sep,
    power_s = GNK_POWER_S, power_t = GNK_POWER_T,
    nugget_ratio = stk_fit$best$nugget_ratio,
    nll = stk_fit$best$nll,
    space_base_m = stk_fit$space_base_m,
    n_tuning_cells = stk_fit$n_tuning,
    n_covariance_candidates = nrow(stk_fit$tuning),
    tuning_cache_hit = isTRUE(stk_fit$tuning_cache_hit)
  )
  readr::write_csv(stk_best,
                   file.path(OUTPUT_DIR, "simulation_gneiting_selected_parameters.csv"))

  if (nrow(stk_fit$missing_index) > 0) {
    noise_use <- truth$target_noise[target_meta$point_id, as.character(PERIOD_PRE), drop = FALSE]
    true_realized_pre <- true_cf_use[, pre_pos_truth, drop = FALSE] + noise_use
    true_signal_pre <- true_cf_use[, pre_pos_truth, drop = FALSE]
    mi <- stk_fit$missing_index
    imp_tbl <- tibble::tibble(
      point_id = target_meta$point_id[mi[, 1]],
      obs_group = target_meta$obs_group[mi[, 1]],
      year = PERIOD_PRE[mi[, 2]],
      imputed_log = stk_fit$Y_imputed[mi],
      true_realized_log = true_realized_pre[mi],
      true_signal_log = true_signal_pre[mi]
    ) %>%
      dplyr::mutate(
        error_realized = imputed_log - true_realized_log,
        error_signal = imputed_log - true_signal_log
      )
    readr::write_csv(imp_tbl,
                     file.path(OUTPUT_DIR, "simulation_gneiting_hidden_pre_predictions.csv"))

    stk_imputation_summary <- dplyr::bind_rows(
      imp_tbl %>%
        dplyr::group_by(obs_group) %>%
        dplyr::summarise(
          n_hidden = dplyr::n(),
          RMSE_hidden_realized_log = sqrt(mean(error_realized^2)),
          RMSE_hidden_signal_log = sqrt(mean(error_signal^2)),
          signed_mean_bias_hidden_signal_log = mean(error_signal),
          .groups = "drop"
        ),
      imp_tbl %>%
        dplyr::summarise(
          obs_group = "ALL", n_hidden = dplyr::n(),
          RMSE_hidden_realized_log = sqrt(mean(error_realized^2)),
          RMSE_hidden_signal_log = sqrt(mean(error_signal^2)),
          signed_mean_bias_hidden_signal_log = mean(error_signal)
        )
    )
    readr::write_csv(stk_imputation_summary,
                     file.path(OUTPUT_DIR, "simulation_gneiting_imputation_metrics.csv"))
  }

  fit_stk_scm <- fit_smooth_scm(
    stk_fit$Y_imputed, Yc_pre, graph_lambda0,
    lambda = 0, rho = 0, W_start = NULL,
    max_iter = FISTA_MAX_ITER_FINAL, tol = FISTA_TOL_FINAL,
    progress_every = FISTA_PROGRESS_EVERY,
    fit_label = "Gneiting kriging -> ordinary SCM"
  )
  Y0_stk_scm <- fit_stk_scm$W %*% t(Yc_all)
  colnames(Y0_stk_scm) <- YEARS
  rownames(Y0_stk_scm) <- target_meta$point_id
  err_stk_scm <- Y0_stk_scm[, post_pos_truth, drop = FALSE] -
    true_cf_use[, post_pos_truth, drop = FALSE]

  runtime_st_pre_total_sec <- as.numeric(difftime(Sys.time(), stk_start, units = "secs"))
  cat(sprintf("Gneiting kriging -> SCM benchmark finished in %.2f min\n",
              runtime_st_pre_total_sec / 60))
}

# --- 4. Direct Gneiting kriging: ONE-SIDED -----------------------------------------
direct_stk_fit <- NULL
Y0_direct_stk <- NULL
err_direct_stk <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                         dimnames = list(target_meta$point_id, PERIOD_POST))
if (RUN_DIRECT_GNEITING_BENCHMARK) {
  cat("\nSimulation benchmark: ONE-SIDED direct Gneiting nonseparable kriging of POST counterfactual...\n")
  direct_stk_start <- Sys.time()
  direct_stk_fit <- tryCatch(
    fit_direct_gneiting_kriging_one_sided(
      use_econ = FALSE, seed = GNK_SEED + 1L,
      label = "direct Gneiting nonseparable kriging"
    ),
    error = function(e) {
      warning("One-sided direct Gneiting nonseparable kriging failed: ", conditionMessage(e))
      NULL
    }
  )
  if (!is.null(direct_stk_fit)) {
    Y0_direct_stk <- post_long_to_matrix(direct_stk_fit$pred, "pred")
    err_direct_stk <- Y0_direct_stk[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
    readr::write_csv(direct_stk_fit$tuning,
                     file.path(OUTPUT_DIR, "simulation_direct_gneiting_tuning.csv"))
    readr::write_csv(
      tibble::tibble(
        information_mode = "one_sided",
        hyperparameter_tuning_period = paste0(min(PERIOD_PRE), "-", max(PERIOD_PRE)),
        phi_space_m = direct_stk_fit$best$phi_space_m,
        phi_time_year = direct_stk_fit$best$phi_time_year,
        sep = direct_stk_fit$best$sep,
        power_s = GNK_POWER_S, power_t = GNK_POWER_T,
        nugget_ratio = direct_stk_fit$best$nugget_ratio,
        nll = direct_stk_fit$best$nll,
        space_base_m = direct_stk_fit$space_base_m,
        n_tuning_cells = direct_stk_fit$n_tuning,
        n_covariance_candidates = nrow(direct_stk_fit$tuning),
        tuning_cache_hit = isTRUE(direct_stk_fit$tuning_cache_hit),
        max_prediction_train_cells = max(direct_stk_fit$audit$n_train_cells),
        elapsed_min = as.numeric(difftime(Sys.time(), direct_stk_start, units = "secs")) / 60
      ),
      file.path(OUTPUT_DIR, "simulation_direct_gneiting_selected_parameters.csv")
    )
  }
  runtime_st_direct_total_sec <- as.numeric(difftime(Sys.time(), direct_stk_start, units = "secs"))
}

# --- 4b. Gneiting kriging + Econ-X strong benchmark -------------------------------
# Same information set as the corresponding spatial-only Gneiting benchmark, but the
# safe PRE economic proxies enter the universal-kriging mean.  The residual
# covariance follows the Gneiting nonseparable geographic-time class.
stk_econ_fit <- NULL
fit_stk_econ_scm <- NULL
Y0_stk_econ_scm <- NULL
err_stk_econ_scm <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                           dimnames = list(target_meta$point_id, PERIOD_POST))
direct_stk_econ_fit <- NULL
Y0_direct_stk_econ <- NULL
err_direct_stk_econ <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                              dimnames = list(target_meta$point_id, PERIOD_POST))

if (RUN_ECON_X_BENCHMARKS && RUN_GNEITING_SCM_BENCHMARK) {
  cat("\nStrong benchmark: PRE Gneiting kriging + Econ-X -> ordinary SCM...\n")
  econ_stk_start <- Sys.time()
  stk_econ_fit <- tryCatch(
    fit_preonly_gneiting_kriging(Yt_pre, target_meta, control_pre_long, use_econ = TRUE),
    error = function(e) {
      warning("PRE Gneiting kriging + Econ-X failed: ", conditionMessage(e)); NULL
    }
  )
  if (!is.null(stk_econ_fit)) {
    readr::write_csv(stk_econ_fit$tuning,
                     file.path(OUTPUT_DIR, "simulation_gneiting_econX_tuning.csv"))
    readr::write_csv(
      tibble::tibble(
        benchmark = "PRE_Gneiting_kriging_EconX_then_SCM",
        phi_space_m = stk_econ_fit$best$phi_space_m,
        phi_time_year = stk_econ_fit$best$phi_time_year,
        sep = stk_econ_fit$best$sep,
        power_s = GNK_POWER_S, power_t = GNK_POWER_T,
        nugget_ratio = stk_econ_fit$best$nugget_ratio,
        nll = stk_econ_fit$best$nll,
        space_base_m = stk_econ_fit$space_base_m,
        n_tuning_cells = stk_econ_fit$n_tuning,
        n_covariance_candidates = nrow(stk_econ_fit$tuning),
        tuning_cache_hit = isTRUE(stk_econ_fit$tuning_cache_hit),
        elapsed_min = as.numeric(difftime(Sys.time(), econ_stk_start, units = "secs")) / 60
      ),
      file.path(OUTPUT_DIR, "simulation_gneiting_econX_selected_parameters.csv")
    )
    fit_stk_econ_scm <- fit_smooth_scm(
      stk_econ_fit$Y_imputed, Yc_pre, graph_lambda0,
      lambda = 0, rho = 0, W_start = NULL,
      max_iter = FISTA_MAX_ITER_FINAL, tol = FISTA_TOL_FINAL,
      progress_every = FISTA_PROGRESS_EVERY,
      fit_label = "Gneiting kriging + Econ-X -> ordinary SCM"
    )
    Y0_stk_econ_scm <- fit_stk_econ_scm$W %*% t(Yc_all)
    colnames(Y0_stk_econ_scm) <- YEARS
    rownames(Y0_stk_econ_scm) <- target_meta$point_id
    err_stk_econ_scm <- Y0_stk_econ_scm[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
  }
  runtime_st_econ_pre_total_sec <- as.numeric(difftime(Sys.time(), econ_stk_start, units = "secs"))
}

if (RUN_ECON_X_BENCHMARKS && RUN_DIRECT_GNEITING_BENCHMARK) {
  cat("\nStrong benchmark: ONE-SIDED direct Gneiting nonseparable kriging + Econ-X POST counterfactual...\n")
  direct_stk_econ_start <- Sys.time()
  direct_stk_econ_fit <- tryCatch(
    fit_direct_gneiting_kriging_one_sided(
      use_econ = TRUE, seed = GNK_SEED + 101L,
      label = "direct Gneiting nonseparable kriging + Econ-X"
    ),
    error = function(e) {
      warning("One-sided direct Gneiting nonseparable kriging + Econ-X failed: ", conditionMessage(e)); NULL
    }
  )
  if (!is.null(direct_stk_econ_fit)) {
    Y0_direct_stk_econ <- post_long_to_matrix(direct_stk_econ_fit$pred, "pred")
    err_direct_stk_econ <- Y0_direct_stk_econ[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
    readr::write_csv(direct_stk_econ_fit$tuning,
                     file.path(OUTPUT_DIR, "simulation_direct_gneiting_econX_tuning.csv"))
    readr::write_csv(
      tibble::tibble(
        benchmark = "direct_Gneiting_kriging_EconX",
        information_mode = "one_sided",
        hyperparameter_tuning_period = paste0(min(PERIOD_PRE), "-", max(PERIOD_PRE)),
        phi_space_m = direct_stk_econ_fit$best$phi_space_m,
        phi_time_year = direct_stk_econ_fit$best$phi_time_year,
        sep = direct_stk_econ_fit$best$sep,
        power_s = GNK_POWER_S, power_t = GNK_POWER_T,
        nugget_ratio = direct_stk_econ_fit$best$nugget_ratio,
        nll = direct_stk_econ_fit$best$nll,
        space_base_m = direct_stk_econ_fit$space_base_m,
        n_tuning_cells = direct_stk_econ_fit$n_tuning,
        n_covariance_candidates = nrow(direct_stk_econ_fit$tuning),
        tuning_cache_hit = isTRUE(direct_stk_econ_fit$tuning_cache_hit),
        max_prediction_train_cells = max(direct_stk_econ_fit$audit$n_train_cells),
        elapsed_min = as.numeric(difftime(Sys.time(), direct_stk_econ_start, units = "secs")) / 60
      ),
      file.path(OUTPUT_DIR, "simulation_direct_gneiting_econX_selected_parameters.csv")
    )
  }
  runtime_st_econ_direct_total_sec <- as.numeric(difftime(Sys.time(), direct_stk_econ_start, units = "secs"))
}

# --- spCF helpers -------------------------------------------------------------
spcf_available <- FALSE
spcf_status <- "not_requested"
spcf_version_detected <- NA_character_
if (RUN_SPCF_SCM_BENCHMARK || RUN_DIRECT_SPCF_BENCHMARK) {
  if (!requireNamespace("spCF", quietly = TRUE) && SPCF_AUTO_INSTALL) {
    try(utils::install.packages("spCF"), silent = TRUE)
  }
  spcf_installed <- requireNamespace("spCF", quietly = TRUE)
  if (spcf_installed) {
    spcf_version_detected <- as.character(utils::packageVersion("spCF"))
    if (utils::compareVersion(spcf_version_detected, SPCF_MIN_VERSION) < 0) {
      spcf_status <- paste0("version_too_old_", spcf_version_detected)
      warning(
        "spCF version ", spcf_version_detected, " is older than required ",
        SPCF_MIN_VERSION, "; dynamic cf_dglm/cf_dglm_hv benchmarks are skipped."
      )
      spcf_available <- FALSE
    } else {
      spcf_available <- TRUE
      spcf_status <- paste0("available_", spcf_version_detected)
    }
  } else {
    spcf_status <- "package_not_installed"
    warning(
      "spCF is not installed; spCF benchmarks will be skipped. ",
      "Set SPCF_AUTO_INSTALL=TRUE or run install.packages('spCF')."
    )
  }
}

build_spcf_x <- function(df, use_econ = FALSE) {
  year_c <- (df$year - mean(PERIOD_PRE)) / 10
  out <- data.frame(
    year_c = year_c,
    year_c2 = year_c^2,
    sin_t = sin((df$year - min(YEARS)) / 2.8),
    cos_t = cos((df$year - min(YEARS)) / 4.2)
  )
  if (isTRUE(use_econ)) {
    miss <- setdiff(ECON_FEATURES, names(df))
    if (length(miss)) stop("spCF Econ-X benchmark missing safe PRE economic covariates.")
    for (nm in ECON_FEATURES) out[[nm]] <- df[[nm]]
  }
  out
}

fit_spcf_long <- function(train, pred, label = "spCF", use_econ = FALSE, mod_hv = NULL) {
  if (!spcf_available) stop("spCF package is unavailable.")
  x <- build_spcf_x(train, use_econ = use_econ)
  x0 <- build_spcf_x(pred, use_econ = use_econ)
  coords <- as.matrix(train[, c("X_m", "Y_m")])
  coords0 <- as.matrix(pred[, c("X_m", "Y_m")])

  hv <- mod_hv
  if (is.null(hv)) {
    hv <- spCF::cf_dglm_hv(
      y = train$y,
      x = x,
      coords = coords,
      time = train$year,
      train_rat = SPCF_TRAIN_RATIO,
      alpha = SPCF_ALPHA,
      kernel = SPCF_KERNEL,
      family = gaussian(),
      seed = SPCF_SEED
    )
  }
  mod <- spCF::cf_dglm(
    y = train$y,
    x = x,
    coords = coords,
    time = train$year,
    x0 = x0,
    coords0 = coords0,
    time0 = pred$year,
    mod_hv = hv
  )
  pred_out <- pred
  pred_out$pred <- as.numeric(mod$pred0$pred)
  list(hv = hv, mod = mod, pred = pred_out, label = label, use_econ = use_econ)
}

fit_direct_spcf_one_sided <- function(use_econ = FALSE,
                                         label = "direct spCF") {
  if (!spcf_available) stop("spCF package is unavailable.")

  # Select spCF hyperparameters using PRE information only.  This object is then
  # held fixed across POST prediction years.
  x_pre <- build_spcf_x(direct_tuning_long, use_econ = use_econ)
  coords_pre <- as.matrix(direct_tuning_long[, c("X_m", "Y_m")])
  hv_pre <- spCF::cf_dglm_hv(
    y = direct_tuning_long$y,
    x = x_pre,
    coords = coords_pre,
    time = direct_tuning_long$year,
    train_rat = SPCF_TRAIN_RATIO,
    alpha = SPCF_ALPHA,
    kernel = SPCF_KERNEL,
    family = gaussian(),
    seed = SPCF_SEED
  )

  pred_rows <- vector("list", length(PERIOD_POST))
  audit_rows <- vector("list", length(PERIOD_POST))
  last_mod <- NULL
  elapsed_rows <- numeric(length(PERIOD_POST))

  for (kk in seq_along(PERIOD_POST)) {
    yy <- PERIOD_POST[kk]
    train_y <- make_direct_train_through_year(yy)
    pred_y <- direct_pred_grid %>% dplyr::filter(year == yy)
    t0 <- Sys.time()
    fit_y <- fit_spcf_long(
      train_y, pred_y,
      label = paste0(label, " one-sided year ", yy),
      use_econ = use_econ,
      mod_hv = hv_pre
    )
    elapsed_rows[kk] <- as.numeric(difftime(Sys.time(), t0, units = "secs")) / 60
    pred_rows[[kk]] <- fit_y$pred
    last_mod <- fit_y$mod
    audit_rows[[kk]] <- tibble::tibble(
      method = if (use_econ) "direct_spCF_EconX" else "direct_spCF",
      information_mode = "one_sided",
      prediction_year = yy,
      hyperparameter_tuning_max_year = max(direct_tuning_long$year, na.rm = TRUE),
      max_train_year = max(train_y$year, na.rm = TRUE),
      n_train_cells = nrow(train_y),
      n_control_train_cells = sum(train_y$point_id %in% control_df$point_id),
      n_target_pre_train_cells = sum(train_y$point_id %in% target_meta$point_id),
      future_control_cells_used = sum(train_y$point_id %in% control_df$point_id & train_y$year > yy),
      target_post_cells_used = sum(train_y$point_id %in% target_meta$point_id & train_y$year >= min(PERIOD_POST)),
      elapsed_min = elapsed_rows[kk]
    )
  }

  list(
    hv = hv_pre,
    mod = last_mod,
    pred = dplyr::bind_rows(pred_rows),
    audit = dplyr::bind_rows(audit_rows),
    elapsed_by_year_min = elapsed_rows,
    label = label,
    use_econ = use_econ
  )
}

write_spcf_status <- function(fit, filename, elapsed_min, benchmark_name) {
  validation_rmse <- NA_real_
  validation_mae <- NA_real_
  bands <- NA_character_
  rho <- NA_real_
  Q <- NA_real_
  if (!is.null(fit)) {
    es <- tryCatch(fit$hv$e_summary, error = function(e) NULL)
    if (!is.null(es)) {
      nm <- names(es)
      if ("validation_RMSE" %in% nm) validation_rmse <- as.numeric(es[["validation_RMSE"]][1])
      if ("validation_MAE" %in% nm) validation_mae <- as.numeric(es[["validation_MAE"]][1])
    }
    bands <- tryCatch(paste(signif(fit$mod$bands, 6), collapse = ";"), error = function(e) NA_character_)
    rho <- tryCatch(as.numeric(fit$mod$other$rho)[1], error = function(e) NA_real_)
    Q <- tryCatch(as.numeric(fit$mod$other$Q)[1], error = function(e) NA_real_)
  }
  readr::write_csv(
    tibble::tibble(
      benchmark = benchmark_name,
      status = if (is.null(fit)) spcf_status else "ok",
      spCF_version = spcf_version_detected,
      elapsed_min = elapsed_min,
      validation_RMSE = validation_rmse,
      validation_MAE = validation_mae,
      selected_bands = bands,
      rho = rho,
      Q = Q
    ),
    file.path(OUTPUT_DIR, filename)
  )
}

# --- 5. PRE spCF -> ordinary SCM ---------------------------------------------
spcf_pre_fit <- NULL
fit_spcf_scm <- NULL
Y0_spcf_scm <- NULL
err_spcf_scm <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                       dimnames = list(target_meta$point_id, PERIOD_POST))
spcf_imputation_summary <- tibble::tibble()
if (RUN_SPCF_SCM_BENCHMARK && spcf_available) {
  cat("\nSimulation benchmark: PRE spCF -> ordinary SCM...\n")
  spcf_pre_start <- Sys.time()
  full_pre <- make_target_pre_long(Yt_pre, target_meta, observed_only = FALSE)
  target_pre_train <- full_pre %>% dplyr::filter(is.finite(y))
  pre_train <- dplyr::bind_rows(control_pre_long, target_pre_train)
  pre_pred <- full_pre %>% dplyr::filter(!is.finite(y)) %>% dplyr::select(-y)
  spcf_pre_fit <- tryCatch(
    fit_spcf_long(pre_train, pre_pred, label = "PRE spCF"),
    error = function(e) {
      warning("PRE spCF failed: ", conditionMessage(e))
      NULL
    }
  )
  runtime_spcf_pre_sec <- as.numeric(difftime(Sys.time(), spcf_pre_start, units = "secs"))
  spcf_pre_elapsed <- runtime_spcf_pre_sec / 60
  write_spcf_status(spcf_pre_fit, "simulation_spcf_pre_status.csv", spcf_pre_elapsed, "PRE_spCF_then_SCM")

  if (!is.null(spcf_pre_fit)) {
    Y_imp_spcf <- Yt_pre
    pp <- spcf_pre_fit$pred %>% dplyr::select(point_id, year, pred)
    ii <- match(pp$point_id, target_meta$point_id)
    tt <- match(pp$year, PERIOD_PRE)
    ok <- is.finite(ii) & is.finite(tt) & is.finite(pp$pred)
    Y_imp_spcf[cbind(ii[ok], tt[ok])] <- pp$pred[ok]

    noise_use <- truth$target_noise[target_meta$point_id, as.character(PERIOD_PRE), drop = FALSE]
    true_signal_pre <- true_cf_use[, pre_pos_truth, drop = FALSE]
    true_realized_pre <- true_signal_pre + noise_use
    spcf_imp_tbl <- pp %>%
      dplyr::mutate(
        row_i = match(point_id, target_meta$point_id),
        col_i = match(year, PERIOD_PRE),
        obs_group = target_meta$obs_group[row_i],
        true_signal_log = true_signal_pre[cbind(row_i, col_i)],
        true_realized_log = true_realized_pre[cbind(row_i, col_i)],
        error_signal = pred - true_signal_log,
        error_realized = pred - true_realized_log
      )
    readr::write_csv(spcf_imp_tbl,
                     file.path(OUTPUT_DIR, "simulation_spcf_hidden_pre_predictions.csv"))
    spcf_imputation_summary <- dplyr::bind_rows(
      spcf_imp_tbl %>%
        dplyr::group_by(obs_group) %>%
        dplyr::summarise(
          n_hidden = dplyr::n(),
          RMSE_hidden_realized_log = sqrt(mean(error_realized^2)),
          RMSE_hidden_signal_log = sqrt(mean(error_signal^2)),
          signed_mean_bias_hidden_signal_log = mean(error_signal),
          .groups = "drop"
        ),
      spcf_imp_tbl %>%
        dplyr::summarise(
          obs_group = "ALL", n_hidden = dplyr::n(),
          RMSE_hidden_realized_log = sqrt(mean(error_realized^2)),
          RMSE_hidden_signal_log = sqrt(mean(error_signal^2)),
          signed_mean_bias_hidden_signal_log = mean(error_signal)
        )
    )
    readr::write_csv(spcf_imputation_summary,
                     file.path(OUTPUT_DIR, "simulation_spcf_imputation_metrics.csv"))

    fit_spcf_scm <- fit_smooth_scm(
      Y_imp_spcf, Yc_pre, graph_lambda0,
      lambda = 0, rho = 0, W_start = NULL,
      max_iter = FISTA_MAX_ITER_FINAL, tol = FISTA_TOL_FINAL,
      progress_every = FISTA_PROGRESS_EVERY,
      fit_label = "spCF -> ordinary SCM"
    )
    Y0_spcf_scm <- fit_spcf_scm$W %*% t(Yc_all)
    colnames(Y0_spcf_scm) <- YEARS
    rownames(Y0_spcf_scm) <- target_meta$point_id
    err_spcf_scm <- Y0_spcf_scm[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
  }
} else if (RUN_SPCF_SCM_BENCHMARK) {
  write_spcf_status(NULL, "simulation_spcf_pre_status.csv", NA_real_, "PRE_spCF_then_SCM")
}

# --- 6. Direct spCF: ONE-SIDED -----------------------------------------------
direct_spcf_fit <- NULL
Y0_direct_spcf <- NULL
err_direct_spcf <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                          dimnames = list(target_meta$point_id, PERIOD_POST))
if (RUN_DIRECT_SPCF_BENCHMARK && spcf_available) {
  cat("\nSimulation benchmark: ONE-SIDED direct spCF POST counterfactual...\n")
  direct_spcf_start <- Sys.time()
  direct_spcf_fit <- tryCatch(
    fit_direct_spcf_one_sided(use_econ = FALSE, label = "direct spCF"),
    error = function(e) {
      warning("One-sided direct spCF failed: ", conditionMessage(e))
      NULL
    }
  )
  runtime_spcf_direct_sec <- as.numeric(difftime(Sys.time(), direct_spcf_start, units = "secs"))
  direct_spcf_elapsed <- runtime_spcf_direct_sec / 60
  write_spcf_status(direct_spcf_fit, "simulation_spcf_direct_status.csv", direct_spcf_elapsed, "direct_spCF_one_sided")
  if (!is.null(direct_spcf_fit)) {
    Y0_direct_spcf <- post_long_to_matrix(direct_spcf_fit$pred, "pred")
    err_direct_spcf <- Y0_direct_spcf[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
  }
} else if (RUN_DIRECT_SPCF_BENCHMARK) {
  write_spcf_status(NULL, "simulation_spcf_direct_status.csv", NA_real_, "direct_spCF_one_sided")
}

# --- 6b. spCF + Econ-X strong benchmark --------------------------------------
spcf_econ_pre_fit <- NULL
fit_spcf_econ_scm <- NULL
Y0_spcf_econ_scm <- NULL
err_spcf_econ_scm <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                            dimnames = list(target_meta$point_id, PERIOD_POST))
direct_spcf_econ_fit <- NULL
Y0_direct_spcf_econ <- NULL
err_direct_spcf_econ <- matrix(NA_real_, nrow = N, ncol = length(post_pos_truth),
                               dimnames = list(target_meta$point_id, PERIOD_POST))

if (RUN_ECON_X_BENCHMARKS && RUN_SPCF_SCM_BENCHMARK && spcf_available) {
  cat("\nStrong benchmark: PRE spCF + Econ-X -> ordinary SCM...\n")
  spcf_econ_pre_start <- Sys.time()
  full_pre_econ <- make_target_pre_long(Yt_pre, target_meta, observed_only = FALSE)
  pre_train_econ <- dplyr::bind_rows(
    control_pre_long,
    full_pre_econ %>% dplyr::filter(is.finite(y))
  )
  pre_pred_econ <- full_pre_econ %>% dplyr::filter(!is.finite(y)) %>% dplyr::select(-y)
  spcf_econ_pre_fit <- tryCatch(
    fit_spcf_long(pre_train_econ, pre_pred_econ,
                  label = "PRE spCF + Econ-X", use_econ = TRUE),
    error = function(e) {
      warning("PRE spCF + Econ-X failed: ", conditionMessage(e)); NULL
    }
  )
  runtime_spcf_econ_pre_sec <- as.numeric(
    difftime(Sys.time(), spcf_econ_pre_start, units = "secs")
  )
  spcf_econ_pre_elapsed <- runtime_spcf_econ_pre_sec / 60
  write_spcf_status(
    spcf_econ_pre_fit, "simulation_spcf_econX_pre_status.csv",
    spcf_econ_pre_elapsed, "PRE_spCF_EconX_then_SCM"
  )
  if (!is.null(spcf_econ_pre_fit)) {
    Y_imp_spcf_econ <- Yt_pre
    pp <- spcf_econ_pre_fit$pred %>% dplyr::select(point_id, year, pred)
    ii <- match(pp$point_id, target_meta$point_id)
    tt <- match(pp$year, PERIOD_PRE)
    ok <- is.finite(ii) & is.finite(tt) & is.finite(pp$pred)
    Y_imp_spcf_econ[cbind(ii[ok], tt[ok])] <- pp$pred[ok]
    fit_spcf_econ_scm <- fit_smooth_scm(
      Y_imp_spcf_econ, Yc_pre, graph_lambda0,
      lambda = 0, rho = 0, W_start = NULL,
      max_iter = FISTA_MAX_ITER_FINAL, tol = FISTA_TOL_FINAL,
      progress_every = FISTA_PROGRESS_EVERY,
      fit_label = "spCF + Econ-X -> ordinary SCM"
    )
    Y0_spcf_econ_scm <- fit_spcf_econ_scm$W %*% t(Yc_all)
    colnames(Y0_spcf_econ_scm) <- YEARS
    rownames(Y0_spcf_econ_scm) <- target_meta$point_id
    err_spcf_econ_scm <- Y0_spcf_econ_scm[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
  }
} else if (RUN_ECON_X_BENCHMARKS && RUN_SPCF_SCM_BENCHMARK) {
  write_spcf_status(NULL, "simulation_spcf_econX_pre_status.csv", NA_real_,
                    "PRE_spCF_EconX_then_SCM")
}

if (RUN_ECON_X_BENCHMARKS && RUN_DIRECT_SPCF_BENCHMARK && spcf_available) {
  cat("\nStrong benchmark: ONE-SIDED direct spCF + Econ-X POST counterfactual...\n")
  direct_spcf_econ_start <- Sys.time()
  direct_spcf_econ_fit <- tryCatch(
    fit_direct_spcf_one_sided(use_econ = TRUE, label = "direct spCF + Econ-X"),
    error = function(e) {
      warning("One-sided direct spCF + Econ-X failed: ", conditionMessage(e)); NULL
    }
  )
  runtime_spcf_econ_direct_sec <- as.numeric(
    difftime(Sys.time(), direct_spcf_econ_start, units = "secs")
  )
  direct_spcf_econ_elapsed <- runtime_spcf_econ_direct_sec / 60
  write_spcf_status(
    direct_spcf_econ_fit, "simulation_spcf_econX_direct_status.csv",
    direct_spcf_econ_elapsed, "direct_spCF_EconX_one_sided"
  )
  if (!is.null(direct_spcf_econ_fit)) {
    Y0_direct_spcf_econ <- post_long_to_matrix(direct_spcf_econ_fit$pred, "pred")
    err_direct_spcf_econ <- Y0_direct_spcf_econ[, post_pos_truth, drop = FALSE] -
      true_cf_use[, post_pos_truth, drop = FALSE]
  }
} else if (RUN_ECON_X_BENCHMARKS && RUN_DIRECT_SPCF_BENCHMARK) {
  write_spcf_status(NULL, "simulation_spcf_econX_direct_status.csv", NA_real_,
                    "direct_spCF_EconX_one_sided")
}

# Audit the causal information filtration used by all direct space-time methods.
one_sided_information_audit <- dplyr::bind_rows(
  if (!is.null(direct_stk_fit)) direct_stk_fit$audit else NULL,
  if (!is.null(direct_stk_econ_fit)) direct_stk_econ_fit$audit else NULL,
  if (!is.null(direct_spcf_fit)) direct_spcf_fit$audit else NULL,
  if (!is.null(direct_spcf_econ_fit)) direct_spcf_econ_fit$audit else NULL
)
if (nrow(one_sided_information_audit) > 0) {
  one_sided_information_audit <- one_sided_information_audit %>%
    dplyr::mutate(
      passes_no_future_control_check = future_control_cells_used == 0 & max_train_year <= prediction_year,
      passes_no_target_post_check = target_post_cells_used == 0,
      passes_preonly_tuning_check = hyperparameter_tuning_max_year <= max(PERIOD_PRE)
    )
  readr::write_csv(
    one_sided_information_audit,
    file.path(OUTPUT_DIR, "simulation_one_sided_information_audit.csv")
  )
  if (any(!one_sided_information_audit$passes_no_future_control_check |
          !one_sided_information_audit$passes_no_target_post_check |
          !one_sided_information_audit$passes_preonly_tuning_check)) {
    stop("One-sided information audit failed: future or treated-target information leaked into a direct benchmark.")
  }
}

# Counterfactual comparison in long format.  Signed mean bias uses
# prediction - truth, so positive values mean the estimated counterfactual is
# systematically too high (which tends to bias ATT downward).
cf_method_one <- function(err_post, method_name) {
  out <- list(); cc <- 1L
  groups <- c(unique(target_meta$obs_group), "ALL")
  for (g in groups) {
    ii <- if (g == "ALL") seq_len(N) else which(target_meta$obs_group == g)
    e <- err_post[ii, , drop = FALSE]
    vals <- e[is.finite(e)]
    n_eval_sites <- sum(rowSums(is.finite(e)) > 0)
    out[[cc]] <- tibble::tibble(
      method = method_name,
      obs_group = g,
      n_sites = length(ii),
      n_eval_sites = n_eval_sites,
      n_eval_cells = length(vals),
      CF_RMSE_log = if (length(vals)) sqrt(mean(vals^2)) else NA_real_,
      CF_MAE_log = if (length(vals)) mean(abs(vals)) else NA_real_,
      CF_signed_mean_bias_log = if (length(vals)) mean(vals) else NA_real_,
      CF_signed_mean_bias_pct = if (length(vals)) mean((exp(vals) - 1) * 100) else NA_real_
    )
    cc <- cc + 1L
  }
  dplyr::bind_rows(out)
}

cf_method_comparison <- dplyr::bind_rows(
  cf_method_one(cf_err_post, "GeoEco_SCM"),
  cf_method_one(err_geo_only, "Graph_SCM"),
  cf_method_one(err_lambda0, "Ordinary_SCM"),
  cf_method_one(err_uniform, "uniform_weights"),
  cf_method_one(err_stk_scm, "Gneiting_kriging_then_SCM"),
  cf_method_one(err_direct_stk, "direct_Gneiting_kriging"),
  cf_method_one(err_stk_econ_scm, "Gneiting_kriging_EconX_then_SCM"),
  cf_method_one(err_direct_stk_econ, "direct_Gneiting_kriging_EconX"),
  cf_method_one(err_spcf_scm, "spCF_then_SCM"),
  cf_method_one(err_direct_spcf, "direct_spCF"),
  cf_method_one(err_spcf_econ_scm, "spCF_EconX_then_SCM"),
  cf_method_one(err_direct_spcf_econ, "direct_spCF_EconX")
)
readr::write_csv(
  cf_method_comparison,
  file.path(OUTPUT_DIR, "simulation_counterfactual_method_comparison_by_group.csv")
)

# Local socioeconomic-mismatch diagnostic.  This is a simulation-only mechanism
# check motivated by the empirical application: pure geographic smoothing can
# be hazardous when a post-only site is economically unlike its closest spatial
# neighbors.  The diagnostic uses the PRE-only observed economic mismatch score
# created by 04a; true-weight mismatch is reported only as a truth-side check.
row_metric_from_err <- function(err, method_name) {
  n0 <- nrow(err)
  ok_n <- rowSums(is.finite(err))
  rmse <- mae <- bias <- rep(NA_real_, n0)
  for (ii in seq_len(n0)) {
    z <- err[ii, is.finite(err[ii, ])]
    if (!length(z)) next
    rmse[ii] <- sqrt(mean(z^2))
    mae[ii] <- mean(abs(z))
    bias[ii] <- mean(z)
  }
  tibble::tibble(
    point_id = target_meta$point_id,
    obs_group = target_meta$obs_group,
    method = method_name,
    n_eval_post = ok_n,
    CF_RMSE_log = rmse,
    CF_MAE_log = mae,
    CF_signed_mean_bias_log = bias
  )
}

local_mismatch_by_site <- dplyr::bind_rows(
  row_metric_from_err(cf_err_post, "GeoEco_SCM"),
  row_metric_from_err(err_geo_only, "Graph_SCM"),
  row_metric_from_err(err_lambda0, "Ordinary_SCM")
)

if (!is.null(truth$local_mismatch_diagnostics)) {
  md <- tibble::as_tibble(truth$local_mismatch_diagnostics)
  keep_md <- intersect(
    c("point_id", "local_econ_mismatch_score", "local_econ_mismatch_z",
      "local_similar_neighbor_count", "local_dissimilar_neighbor_count",
      "local_mixed_neighbor_eligible", "local_mixed_neighbor_score",
      "local_similar_pre_anchor_count", "local_dissimilar_pre_anchor_count",
      "local_mixed_pre_anchor_support",
      "local_true_weight_dissimilarity", "high_observed_econ_mismatch",
      "high_true_weight_mismatch", "new_station_distance_m"),
    names(md)
  )
  local_mismatch_by_site <- local_mismatch_by_site %>%
    dplyr::left_join(md %>% dplyr::select(dplyr::all_of(keep_md)), by = "point_id")
}
readr::write_csv(
  local_mismatch_by_site,
  file.path(OUTPUT_DIR, "simulation_local_mismatch_CF_by_site_by_method.csv")
)

if (all(c("high_observed_econ_mismatch", "high_true_weight_mismatch") %in%
        names(local_mismatch_by_site))) {
  group_defs <- list(
    ALL = rep(TRUE, nrow(local_mismatch_by_site)),
    post_only = local_mismatch_by_site$obs_group == "post_only",
    high_observed_econ_mismatch = local_mismatch_by_site$high_observed_econ_mismatch %in% TRUE,
    post_only_high_observed_econ_mismatch =
      local_mismatch_by_site$obs_group == "post_only" &
      local_mismatch_by_site$high_observed_econ_mismatch %in% TRUE,
    high_true_weight_mismatch = local_mismatch_by_site$high_true_weight_mismatch %in% TRUE,
    post_only_high_true_weight_mismatch =
      local_mismatch_by_site$obs_group == "post_only" &
      local_mismatch_by_site$high_true_weight_mismatch %in% TRUE
  )
  if ("local_mixed_neighbor_eligible" %in% names(local_mismatch_by_site)) {
    group_defs$mixed_neighborhood <-
      local_mismatch_by_site$local_mixed_neighbor_eligible %in% TRUE
    group_defs$post_only_mixed_neighborhood <-
      local_mismatch_by_site$obs_group == "post_only" &
      local_mismatch_by_site$local_mixed_neighbor_eligible %in% TRUE
  }
  if ("local_mixed_pre_anchor_support" %in% names(local_mismatch_by_site)) {
    group_defs$mixed_pre_anchor_support <-
      local_mismatch_by_site$local_mixed_pre_anchor_support %in% TRUE
    group_defs$post_only_mixed_pre_anchor_support <-
      local_mismatch_by_site$obs_group == "post_only" &
      local_mismatch_by_site$local_mixed_pre_anchor_support %in% TRUE
  }
  mm_rows <- list(); mm_i <- 1L
  for (gn in names(group_defs)) {
    idx0 <- group_defs[[gn]]
    for (mn in unique(local_mismatch_by_site$method)) {
      z <- local_mismatch_by_site[idx0 & local_mismatch_by_site$method == mn, , drop = FALSE]
      ok <- is.finite(z$CF_RMSE_log)
      mm_rows[[mm_i]] <- tibble::tibble(
        mismatch_group = gn,
        method = mn,
        n_sites = nrow(z),
        n_eval_sites = sum(ok),
        coverage = if (nrow(z)) mean(ok) else NA_real_,
        CF_RMSE_log = if (any(ok)) sqrt(mean(z$CF_RMSE_log[ok]^2)) else NA_real_,
        mean_site_CF_MAE_log = if (any(ok)) mean(z$CF_MAE_log[ok]) else NA_real_,
        mean_site_CF_signed_bias_log = if (any(ok)) mean(z$CF_signed_mean_bias_log[ok]) else NA_real_
      )
      mm_i <- mm_i + 1L
    }
  }
  local_mismatch_summary <- dplyr::bind_rows(mm_rows)
  readr::write_csv(
    local_mismatch_summary,
    file.path(OUTPUT_DIR, "simulation_local_mismatch_method_comparison.csv")
  )

  mm_pair <- local_mismatch_summary %>%
    dplyr::filter(method %in% c("GeoEco_SCM", "Graph_SCM")) %>%
    dplyr::select(mismatch_group, method, CF_RMSE_log) %>%
    tidyr::pivot_wider(names_from = method, values_from = CF_RMSE_log) %>%
    dplyr::mutate(
      GeoEco_minus_Graph_RMSE = GeoEco_SCM - Graph_SCM,
      GeoEco_improvement_vs_Graph_pct =
        100 * (Graph_SCM - GeoEco_SCM) / Graph_SCM
    )
  readr::write_csv(
    mm_pair,
    file.path(OUTPUT_DIR, "simulation_local_mismatch_GeoEco_vs_Graph.csv")
  )
}

# Year-specific signed CF bias is useful for diagnosing why ATT can be biased
# even when pointwise CF RMSE is small.  Error is prediction - truth.
cf_method_year_one <- function(err_post, method_name) {
  out <- list(); cc <- 1L
  groups <- c(unique(target_meta$obs_group), "ALL")
  for (g in groups) {
    ii <- if (g == "ALL") seq_len(N) else which(target_meta$obs_group == g)
    for (tt in seq_along(PERIOD_POST)) {
      z <- err_post[ii, tt]
      z <- z[is.finite(z)]
      out[[cc]] <- tibble::tibble(
        method = method_name,
        obs_group = g,
        year = PERIOD_POST[tt],
        n_eval = length(z),
        CF_signed_mean_bias_log = if (length(z)) mean(z) else NA_real_,
        CF_signed_mean_bias_pct = if (length(z)) mean((exp(z) - 1) * 100) else NA_real_,
        CF_RMSE_log = if (length(z)) sqrt(mean(z^2)) else NA_real_,
        CF_MAE_log = if (length(z)) mean(abs(z)) else NA_real_
      )
      cc <- cc + 1L
    }
  }
  dplyr::bind_rows(out)
}

cf_bias_by_year <- dplyr::bind_rows(
  cf_method_year_one(cf_err_post, "GeoEco_SCM"),
  cf_method_year_one(err_geo_only, "Graph_SCM"),
  cf_method_year_one(err_lambda0, "Ordinary_SCM"),
  cf_method_year_one(err_uniform, "uniform_weights"),
  cf_method_year_one(err_stk_scm, "Gneiting_kriging_then_SCM"),
  cf_method_year_one(err_direct_stk, "direct_Gneiting_kriging"),
  cf_method_year_one(err_stk_econ_scm, "Gneiting_kriging_EconX_then_SCM"),
  cf_method_year_one(err_direct_stk_econ, "direct_Gneiting_kriging_EconX"),
  cf_method_year_one(err_spcf_scm, "spCF_then_SCM"),
  cf_method_year_one(err_direct_spcf, "direct_spCF"),
  cf_method_year_one(err_spcf_econ_scm, "spCF_EconX_then_SCM"),
  cf_method_year_one(err_direct_spcf_econ, "direct_spCF_EconX")
)
readr::write_csv(
  cf_bias_by_year,
  file.path(OUTPUT_DIR, "simulation_counterfactual_signed_bias_by_year.csv")
)

benchmark_one_group <- function(ii, label) {
  e02 <- cf_err_post[ii, , drop = FALSE]
  eg <- err_geo_only[ii, , drop = FALSE]
  e0 <- err_lambda0[ii, , drop = FALSE]
  eu <- err_uniform[ii, , drop = FALSE]
  ek <- err_stk_scm[ii, , drop = FALSE]
  edk <- err_direct_stk[ii, , drop = FALSE]
  escf <- err_spcf_scm[ii, , drop = FALSE]
  edcf <- err_direct_spcf[ii, , drop = FALSE]

  has02 <- rowSums(is.finite(e02)) > 0
  has0 <- rowSums(is.finite(e0)) > 0
  common0 <- has02 & has0
  bias_log <- function(e) {
    z <- e[is.finite(e)]
    if (length(z)) mean(z) else NA_real_
  }

  r02 <- safe_rmse(e02)
  rg <- safe_rmse(eg)
  r0_available <- safe_rmse(e0)
  ru <- safe_rmse(eu)
  rk <- safe_rmse(ek)
  rdk <- safe_rmse(edk)
  rscf <- safe_rmse(escf)
  rdcf <- safe_rmse(edcf)
  r02_common0 <- if (any(common0)) safe_rmse(e02[common0, , drop = FALSE]) else NA_real_
  r0_common <- if (any(common0)) safe_rmse(e0[common0, , drop = FALSE]) else NA_real_

  n02 <- sum(has02)
  ng <- sum(rowSums(is.finite(eg)) > 0)
  n0 <- sum(has0)
  nu <- sum(rowSums(is.finite(eu)) > 0)
  nk <- sum(rowSums(is.finite(ek)) > 0)
  ndk <- sum(rowSums(is.finite(edk)) > 0)
  nscf <- sum(rowSums(is.finite(escf)) > 0)
  ndcf <- sum(rowSums(is.finite(edcf)) > 0)
  ncommon0 <- sum(common0)

  tibble::tibble(
    obs_group = label,
    n = length(ii),
    n_eval_02 = n02,
    n_eval_graph_geo_only = ng,
    n_eval_lambda0 = n0,
    n_common_02_lambda0 = ncommon0,
    n_eval_uniform = nu,
    n_eval_gneiting_SCM = nk,
    n_eval_direct_gneiting = ndk,
    n_eval_spCF_SCM = nscf,
    n_eval_direct_spCF = ndcf,
    RMSE_02_log = r02,
    RMSE_graph_geo_only_log = rg,
    RMSE_lambda0_available_log = r0_available,
    RMSE_02_common_lambda0_log = r02_common0,
    RMSE_lambda0_common_log = r0_common,
    RMSE_uniform_log = ru,
    RMSE_gneiting_SCM_log = rk,
    RMSE_direct_gneiting_log = rdk,
    RMSE_spCF_SCM_log = rscf,
    RMSE_direct_spCF_log = rdcf,
    signed_mean_bias_02_log = bias_log(e02),
    signed_mean_bias_graph_geo_only_log = bias_log(eg),
    signed_mean_bias_gneiting_SCM_log = bias_log(ek),
    signed_mean_bias_direct_gneiting_log = bias_log(edk),
    signed_mean_bias_spCF_SCM_log = bias_log(escf),
    signed_mean_bias_direct_spCF_log = bias_log(edcf),
    # lambda=0 is compared ONLY on sites identified by BOTH methods.
    improvement_vs_lambda0_pct = ifelse(
      ncommon0 > 0 && is.finite(r0_common) && r0_common > 0 && is.finite(r02_common0),
      100 * (r0_common - r02_common0) / r0_common, NA_real_
    ),
    improvement_vs_graph_geo_only_pct = ifelse(
      is.finite(rg) && rg > 0 && is.finite(r02), 100 * (rg - r02) / rg, NA_real_
    ),
    improvement_vs_uniform_pct = ifelse(
      is.finite(ru) && ru > 0 && is.finite(r02), 100 * (ru - r02) / ru, NA_real_
    ),
    improvement_vs_gneiting_SCM_pct = ifelse(
      is.finite(rk) && rk > 0 && is.finite(r02), 100 * (rk - r02) / rk, NA_real_
    ),
    improvement_vs_direct_gneiting_pct = ifelse(
      is.finite(rdk) && rdk > 0 && is.finite(r02), 100 * (rdk - r02) / rdk, NA_real_
    ),
    improvement_vs_spCF_SCM_pct = ifelse(
      is.finite(rscf) && rscf > 0 && is.finite(r02), 100 * (rscf - r02) / rscf, NA_real_
    ),
    improvement_vs_direct_spCF_pct = ifelse(
      is.finite(rdcf) && rdcf > 0 && is.finite(r02), 100 * (rdcf - r02) / rdcf, NA_real_
    )
  )
}

benchmark_by_group <- dplyr::bind_rows(
  lapply(unique(target_meta$obs_group), function(g) {
    benchmark_one_group(which(target_meta$obs_group == g), g)
  }),
  benchmark_one_group(seq_len(N), "ALL")
)
readr::write_csv(benchmark_by_group,
                 file.path(OUTPUT_DIR, "simulation_02_vs_benchmarks.csv"))

# Explicit common-sample table for 02 vs lambda=0. This is the authoritative
# comparison whenever the two methods identify different sets of sites.
lambda0_common_comparison <- benchmark_by_group %>%
  dplyr::select(
    obs_group, n, n_eval_02, n_eval_lambda0, n_common_02_lambda0,
    RMSE_02_common_lambda0_log, RMSE_lambda0_common_log,
    improvement_vs_lambda0_pct
  )
readr::write_csv(lambda0_common_comparison,
                 file.path(OUTPUT_DIR, "simulation_02_vs_lambda0_common_sample.csv"))
# Keep the old filename as a compatibility output, but its RMSE columns now
# explicitly refer to the shared identifiable sample.
readr::write_csv(
  lambda0_common_comparison %>%
    dplyr::transmute(
      obs_group, n, n_eval_02, n_eval_lambda0, n_common_02_lambda0,
      RMSE_02_log = RMSE_02_common_lambda0_log,
      RMSE_lambda0_log = RMSE_lambda0_common_log,
      improvement_pct = improvement_vs_lambda0_pct
    ),
  file.path(OUTPUT_DIR, "simulation_02_vs_lambda0.csv")
)

# ATT recovery comparison across methods. This is important because aggregate
# ATT can look accurate when biases in complete/partial/post-only groups cancel.
att_method_one <- function(Y0_method, method_name) {
  if (is.null(Y0_method)) return(tibble::tibble())
  eff <- Y_target_all - Y0_method
  out <- list()
  cc <- 1L
  groups <- c(unique(target_meta$obs_group), "ALL")
  for (g in groups) {
    ii <- if (g == "ALL") seq_len(N) else which(target_meta$obs_group == g)
    year_bias <- numeric(0)
    for (yy in PERIOD_POST) {
      pp <- match(yy, YEARS)
      ev <- eff[ii, pp]
      tv <- true_effect_log_mat[ii, pp]
      ok <- is.finite(ev) & is.finite(tv)
      if (!any(ok)) next
      ebar <- mean(ev[ok])
      tbar <- mean(tv[ok])
      year_bias <- c(year_bias, (exp(ebar) - exp(tbar)) * 100)
    }
    n_eval_sites <- sum(rowSums(is.finite(Y0_method[ii, post_pos_truth, drop = FALSE])) > 0)
    out[[cc]] <- tibble::tibble(
      method = method_name,
      obs_group = g,
      n_sites = length(ii),
      n_eval_sites = n_eval_sites,
      ATT_RMSE_pp = if (length(year_bias)) sqrt(mean(year_bias^2)) else NA_real_,
      ATT_MAE_pp = if (length(year_bias)) mean(abs(year_bias)) else NA_real_,
      ATT_mean_bias_pp = if (length(year_bias)) mean(year_bias) else NA_real_
    )
    cc <- cc + 1L
  }
  dplyr::bind_rows(out)
}

att_method_comparison <- dplyr::bind_rows(
  att_method_one(Y0_raw, "GeoEco_SCM"),
  att_method_one(Y0_geo_only, "Graph_SCM"),
  att_method_one(Y0_lambda0, "Ordinary_SCM"),
  att_method_one(Y0_uniform, "uniform_weights"),
  att_method_one(Y0_stk_scm, "Gneiting_kriging_then_SCM"),
  att_method_one(Y0_direct_stk, "direct_Gneiting_kriging"),
  att_method_one(Y0_stk_econ_scm, "Gneiting_kriging_EconX_then_SCM"),
  att_method_one(Y0_direct_stk_econ, "direct_Gneiting_kriging_EconX"),
  att_method_one(Y0_spcf_scm, "spCF_then_SCM"),
  att_method_one(Y0_direct_spcf, "direct_spCF"),
  att_method_one(Y0_spcf_econ_scm, "spCF_EconX_then_SCM"),
  att_method_one(Y0_direct_spcf_econ, "direct_spCF_EconX")
)
readr::write_csv(att_method_comparison,
                 file.path(OUTPUT_DIR, "simulation_ATT_method_comparison_by_group.csv"))

# ---- ATT estimand / observation-selection decomposition ----------------------
# Ordinary lambda=0 SCM has no site-specific counterfactual for post-only sites.
# Therefore two different issues must be separated:
#   (a) estimation error on the PRE-observed population; and
#   (b) selection of the ATT population itself when post-only sites have different
#       treatment effects.  The station-selected DGP is designed to make (b)
#       visible rather than silently comparing different populations.
pre_observed_idx <- which(target_meta$obs_group != "post_only")
post_only_idx_att <- which(target_meta$obs_group == "post_only")
all_idx_att <- seq_len(N)

true_att_pct_for <- function(ii, tt) {
  if (!length(ii)) return(NA_real_)
  (exp(mean(true_effect_log_mat[ii, tt], na.rm = TRUE)) - 1) * 100
}
est_att_pct_for <- function(Y0_method, ii, tt) {
  if (is.null(Y0_method) || !length(ii)) return(NA_real_)
  ev <- Y_target_all[ii, tt] - Y0_method[ii, tt]
  ev <- ev[is.finite(ev)]
  if (!length(ev)) return(NA_real_)
  (exp(mean(ev)) - 1) * 100
}

truth_selection_by_year <- dplyr::bind_rows(lapply(PERIOD_POST, function(yy) {
  tt <- match(yy, YEARS)
  all_true <- true_att_pct_for(all_idx_att, tt)
  pre_true <- true_att_pct_for(pre_observed_idx, tt)
  post_true <- true_att_pct_for(post_only_idx_att, tt)
  tibble::tibble(
    year = yy,
    n_all = length(all_idx_att),
    n_pre_observed = length(pre_observed_idx),
    n_post_only = length(post_only_idx_att),
    true_ATT_all_pct = all_true,
    true_ATT_pre_observed_pct = pre_true,
    true_ATT_post_only_pct = post_true,
    pure_selection_gap_pre_minus_all_pp = pre_true - all_true,
    post_only_minus_pre_observed_true_ATT_pp = post_true - pre_true
  )
}))
readr::write_csv(
  truth_selection_by_year,
  file.path(OUTPUT_DIR, "simulation_true_ATT_selection_by_year.csv")
)

# Methods that can in principle cover post-only sites.  lambda0 is handled
# separately because its scientifically identified population is PRE_OBSERVED.
att_estimand_methods <- list(
  GeoEco_SCM = Y0_raw,
  Graph_SCM = Y0_geo_only,
  Gneiting_kriging_then_SCM = Y0_stk_scm,
  direct_Gneiting_kriging = Y0_direct_stk,
  Gneiting_kriging_EconX_then_SCM = Y0_stk_econ_scm,
  direct_Gneiting_kriging_EconX = Y0_direct_stk_econ,
  spCF_then_SCM = Y0_spcf_scm,
  direct_spCF = Y0_direct_spcf,
  spCF_EconX_then_SCM = Y0_spcf_econ_scm,
  direct_spCF_EconX = Y0_direct_spcf_econ
)

att_estimand_year_rows <- list(); att_ec <- 1L
for (nm in names(att_estimand_methods)) {
  Y0m <- att_estimand_methods[[nm]]
  for (yy in PERIOD_POST) {
    tt <- match(yy, YEARS)
    est <- est_att_pct_for(Y0m, all_idx_att, tt)
    tru <- true_att_pct_for(all_idx_att, tt)
    att_estimand_year_rows[[att_ec]] <- tibble::tibble(
      method = nm,
      estimated_population = "ALL",
      target_estimand = "ALL",
      year = yy,
      n_target_sites = length(all_idx_att),
      estimated_ATT_pct = est,
      true_ATT_target_pct = tru,
      ATT_bias_pp = est - tru
    )
    att_ec <- att_ec + 1L
  }
}

# Ordinary SCM: identified PRE-observed estimand and the same estimate judged
# against the ALL-site estimand, which exposes total (estimation + selection) bias.
for (yy in PERIOD_POST) {
  tt <- match(yy, YEARS)
  est0 <- est_att_pct_for(Y0_lambda0, pre_observed_idx, tt)
  true_pre <- true_att_pct_for(pre_observed_idx, tt)
  true_all <- true_att_pct_for(all_idx_att, tt)
  att_estimand_year_rows[[att_ec]] <- tibble::tibble(
    method = "Ordinary_SCM",
    estimated_population = "PRE_OBSERVED",
    target_estimand = "PRE_OBSERVED",
    year = yy, n_target_sites = length(pre_observed_idx),
    estimated_ATT_pct = est0, true_ATT_target_pct = true_pre,
    ATT_bias_pp = est0 - true_pre
  ); att_ec <- att_ec + 1L
  att_estimand_year_rows[[att_ec]] <- tibble::tibble(
    method = "Ordinary_SCM",
    estimated_population = "PRE_OBSERVED",
    target_estimand = "ALL",
    year = yy, n_target_sites = length(pre_observed_idx),
    estimated_ATT_pct = est0, true_ATT_target_pct = true_all,
    ATT_bias_pp = est0 - true_all
  ); att_ec <- att_ec + 1L
}
att_estimand_by_year <- dplyr::bind_rows(att_estimand_year_rows)
readr::write_csv(
  att_estimand_by_year,
  file.path(OUTPUT_DIR, "simulation_ATT_estimand_selection_by_year.csv")
)
att_estimand_summary <- att_estimand_by_year %>%
  dplyr::group_by(method, estimated_population, target_estimand) %>%
  dplyr::summarise(
    n_years = sum(is.finite(ATT_bias_pp)),
    ATT_RMSE_pp = ifelse(n_years > 0, sqrt(mean(ATT_bias_pp^2, na.rm = TRUE)), NA_real_),
    ATT_MAE_pp = ifelse(n_years > 0, mean(abs(ATT_bias_pp), na.rm = TRUE), NA_real_),
    ATT_mean_bias_pp = ifelse(n_years > 0, mean(ATT_bias_pp, na.rm = TRUE), NA_real_),
    .groups = "drop"
  )
readr::write_csv(
  att_estimand_summary,
  file.path(OUTPUT_DIR, "simulation_ATT_estimand_selection_summary.csv")
)

# Pairwise ATT comparison on the SAME identifiable sites for 02 vs lambda=0.
# This avoids an apparent ALL-sample comparison where lambda=0 silently drops
# post-only targets while the joint model includes them.
att_common_02_lambda0 <- dplyr::bind_rows(lapply(
  c(unique(target_meta$obs_group), "ALL"),
  function(g) {
    ii0 <- if (g == "ALL") seq_len(N) else which(target_meta$obs_group == g)
    has02 <- rowSums(is.finite(Y0_raw[ii0, post_pos_truth, drop = FALSE])) > 0
    has0 <- rowSums(is.finite(Y0_lambda0[ii0, post_pos_truth, drop = FALSE])) > 0
    ii <- ii0[has02 & has0]
    if (length(ii) == 0) {
      return(tibble::tibble(
        obs_group = g, n_common_sites = 0L,
        ATT_RMSE_02_common_pp = NA_real_, ATT_RMSE_lambda0_common_pp = NA_real_,
        ATT_MAE_02_common_pp = NA_real_, ATT_MAE_lambda0_common_pp = NA_real_,
        ATT_mean_bias_02_common_pp = NA_real_, ATT_mean_bias_lambda0_common_pp = NA_real_,
        improvement_02_vs_lambda0_ATT_RMSE_pct = NA_real_
      ))
    }
    eff02 <- Y_target_all - Y0_raw
    eff0 <- Y_target_all - Y0_lambda0
    b02 <- numeric(0); b0 <- numeric(0)
    for (yy in PERIOD_POST) {
      pp <- match(yy, YEARS)
      ok <- is.finite(eff02[ii, pp]) & is.finite(eff0[ii, pp]) &
        is.finite(true_effect_log_mat[ii, pp])
      if (!any(ok)) next
      ids <- ii[ok]
      tbar <- mean(true_effect_log_mat[ids, pp])
      b02 <- c(b02, (exp(mean(eff02[ids, pp])) - exp(tbar)) * 100)
      b0 <- c(b0, (exp(mean(eff0[ids, pp])) - exp(tbar)) * 100)
    }
    r02 <- if (length(b02)) sqrt(mean(b02^2)) else NA_real_
    r0 <- if (length(b0)) sqrt(mean(b0^2)) else NA_real_
    tibble::tibble(
      obs_group = g, n_common_sites = length(ii),
      ATT_RMSE_02_common_pp = r02,
      ATT_RMSE_lambda0_common_pp = r0,
      ATT_MAE_02_common_pp = if (length(b02)) mean(abs(b02)) else NA_real_,
      ATT_MAE_lambda0_common_pp = if (length(b0)) mean(abs(b0)) else NA_real_,
      ATT_mean_bias_02_common_pp = if (length(b02)) mean(b02) else NA_real_,
      ATT_mean_bias_lambda0_common_pp = if (length(b0)) mean(b0) else NA_real_,
      improvement_02_vs_lambda0_ATT_RMSE_pct = ifelse(
        is.finite(r0) && r0 > 0 && is.finite(r02), 100 * (r0 - r02) / r0, NA_real_
      )
    )
  }
))
readr::write_csv(att_common_02_lambda0,
                 file.path(OUTPUT_DIR, "simulation_ATT_02_vs_lambda0_common_sample.csv"))

# ---- 15d-2. Is the true weight surface actually smooth on the fitted graph? --

truth_graph_edges <- final_graph$edges
# Same geographic edges with beta_econ=0, used only to diagnose whether the
# economic reweighting aligns more strongly with the TRUE representation field.
truth_geo_graph <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = 0)
geo_key <- paste(truth_geo_graph$edges$i, truth_geo_graph$edges$k, sep = "|")
truth_key <- paste(truth_graph_edges$i, truth_graph_edges$k, sep = "|")
truth_graph_edges$a_geo_only <- truth_geo_graph$edges$a[match(truth_key, geo_key)]
truth_graph_edges$point_id_i <- target_meta$point_id[truth_graph_edges$i]
truth_graph_edges$point_id_k <- target_meta$point_id[truth_graph_edges$k]
truth_graph_edges$true_weight_cosine <- vapply(seq_len(nrow(truth_graph_edges)), function(rr) {
  cosine_row(
    W_true_use[truth_graph_edges$i[rr], ],
    W_true_use[truth_graph_edges$k[rr], ]
  )
}, numeric(1))
truth_graph_edges$true_weight_L1 <- vapply(seq_len(nrow(truth_graph_edges)), function(rr) {
  sum(abs(
    W_true_use[truth_graph_edges$i[rr], ] -
      W_true_use[truth_graph_edges$k[rr], ]
  ))
}, numeric(1))
# Outcome-side counterpart: spatial-only ST methods require nearby locations to
# have similar untreated trajectories.  This truth-only statistic quantifies
# how much neighboring POST counterfactual paths differ.
truth_graph_edges$true_cf_post_RMSE <- vapply(seq_len(nrow(truth_graph_edges)), function(rr) {
  di <- true_cf_use[truth_graph_edges$i[rr], post_pos_truth] -
    true_cf_use[truth_graph_edges$k[rr], post_pos_truth]
  sqrt(mean(di^2))
}, numeric(1))
truth_graph_edges$crosses_boundary <-
  (target_meta$X_m[truth_graph_edges$i] < 10000) !=
  (target_meta$X_m[truth_graph_edges$k] < 10000)
readr::write_csv(truth_graph_edges,
                 file.path(OUTPUT_DIR, "simulation_true_weight_similarity_on_graph.csv"))

truth_graph_summary <- truth_graph_edges %>%
  dplyr::summarise(
    mean_neighbor_weight_cosine = mean(true_weight_cosine, na.rm = TRUE),
    median_neighbor_weight_cosine = median(true_weight_cosine, na.rm = TRUE),
    mean_neighbor_weight_L1 = mean(true_weight_L1, na.rm = TRUE),
    weighted_cosine_selected_graph = stats::weighted.mean(true_weight_cosine, a, na.rm = TRUE),
    weighted_cosine_geo_only_graph = stats::weighted.mean(true_weight_cosine, a_geo_only, na.rm = TRUE),
    weighted_L1_selected_graph = stats::weighted.mean(true_weight_L1, a, na.rm = TRUE),
    weighted_L1_geo_only_graph = stats::weighted.mean(true_weight_L1, a_geo_only, na.rm = TRUE),
    mean_cosine_same_side = mean(true_weight_cosine[!crosses_boundary], na.rm = TRUE),
    mean_cosine_cross_boundary = mean(true_weight_cosine[crosses_boundary], na.rm = TRUE),
    cor_geo_distance_weight_dissimilarity = suppressWarnings(
      stats::cor(geo_dist_std, 1 - true_weight_cosine, use = "complete.obs")
    ),
    cor_econ_distance_weight_dissimilarity = suppressWarnings(
      stats::cor(econ_dist_std, 1 - true_weight_cosine, use = "complete.obs")
    ),
    mean_neighbor_true_cf_post_RMSE_log = mean(true_cf_post_RMSE, na.rm = TRUE),
    cor_geo_distance_true_cf_post_RMSE = suppressWarnings(
      stats::cor(geo_dist_std, true_cf_post_RMSE, use = "complete.obs")
    ),
    cor_econ_distance_true_cf_post_RMSE = suppressWarnings(
      stats::cor(econ_dist_std, true_cf_post_RMSE, use = "complete.obs")
    ),
    n_edges = dplyr::n(),
    n_cross_boundary_edges = sum(crosses_boundary)
  )

# Truth-only DGP diagnostic: how much additional variation in neighboring true
# representation dissimilarity is explained by observed PRE economic distance
# after geography?  This is never used for tuning; it verifies that v14's main
# scenario contrast was actually generated as intended.
distance_diag_dat <- truth_graph_edges %>%
  dplyr::transmute(
    weight_dissimilarity = 1 - true_weight_cosine,
    geo_dist_std, econ_dist_std
  ) %>%
  dplyr::filter(dplyr::if_all(dplyr::everything(), is.finite))
if (nrow(distance_diag_dat) >= 10) {
  lm_geo_truth <- stats::lm(weight_dissimilarity ~ geo_dist_std, data = distance_diag_dat)
  lm_geo_econ_truth <- stats::lm(
    weight_dissimilarity ~ geo_dist_std + econ_dist_std, data = distance_diag_dat
  )
  r2_geo_truth <- summary(lm_geo_truth)$r.squared
  r2_geo_econ_truth <- summary(lm_geo_econ_truth)$r.squared
  econ_coef_truth <- unname(stats::coef(lm_geo_econ_truth)["econ_dist_std"])
} else {
  r2_geo_truth <- r2_geo_econ_truth <- econ_coef_truth <- NA_real_
}
truth_distance_diagnostic <- tibble::tibble(
  scenario = SCENARIO,
  economic_distance_active_truth = ECONOMIC_DISTANCE_ACTIVE_TRUTH,
  n_graph_edges = nrow(distance_diag_dat),
  R2_true_weight_dissimilarity_geo_only = r2_geo_truth,
  R2_true_weight_dissimilarity_geo_plus_econ = r2_geo_econ_truth,
  delta_R2_from_economic_distance = r2_geo_econ_truth - r2_geo_truth,
  econ_distance_coefficient_given_geo = econ_coef_truth,
  cor_geo_distance_weight_dissimilarity = truth_graph_summary$cor_geo_distance_weight_dissimilarity,
  cor_econ_distance_weight_dissimilarity = truth_graph_summary$cor_econ_distance_weight_dissimilarity,
  mean_neighbor_true_cf_post_RMSE_log = truth_graph_summary$mean_neighbor_true_cf_post_RMSE_log,
  cor_geo_distance_true_cf_post_RMSE = truth_graph_summary$cor_geo_distance_true_cf_post_RMSE,
  cor_econ_distance_true_cf_post_RMSE = truth_graph_summary$cor_econ_distance_true_cf_post_RMSE
)
readr::write_csv(truth_graph_summary,
                 file.path(OUTPUT_DIR, "simulation_true_weight_similarity_summary.csv"))
readr::write_csv(truth_distance_diagnostic,
                 file.path(OUTPUT_DIR, "simulation_true_weight_distance_diagnostic.csv"))

# True weight concentration.
true_weight_concentration <- tibble::tibble(
  point_id = target_meta$point_id,
  obs_group = target_meta$obs_group,
  max_true_weight = apply(W_true_use, 1, max),
  true_effective_donors = 1 / rowSums(W_true_use^2)
)
true_weight_concentration_summary <- true_weight_concentration %>%
  dplyr::summarise(
    mean_true_effective_donors = mean(true_effective_donors),
    median_true_effective_donors = median(true_effective_donors),
    mean_max_true_weight = mean(max_true_weight)
  )
readr::write_csv(true_weight_concentration,
                 file.path(OUTPUT_DIR, "simulation_true_weight_concentration.csv"))

# Boundary stress diagnostic: if the DGP contains a sharp boundary, errors should
# increase close to x=10 km because geographic kNN can connect opposite markets.
cf_site_boundary <- cf_site %>%
  dplyr::left_join(target_meta %>% dplyr::select(point_id, X_m), by = "point_id") %>%
  dplyr::mutate(
    distance_to_boundary_m = abs(X_m - 10000),
    boundary_band = dplyr::case_when(
      distance_to_boundary_m <= 1000 ~ "0-1km",
      distance_to_boundary_m <= 3000 ~ "1-3km",
      TRUE ~ ">3km"
    )
  )
boundary_error_summary <- cf_site_boundary %>%
  dplyr::group_by(boundary_band) %>%
  dplyr::summarise(
    n = dplyr::n(),
    post_CF_RMSE_log = sqrt(mean(post_CF_RMSE_log^2, na.rm = TRUE)),
    post_CF_RMSE_pct = sqrt(mean(post_CF_RMSE_pct^2, na.rm = TRUE)),
    .groups = "drop"
  )
readr::write_csv(boundary_error_summary,
                 file.path(OUTPUT_DIR, "simulation_boundary_error_summary.csv"))


# Boundary-only forced-smoothing diagnostic -----------------------------------
# v6 deliberately uses multiples ABOVE the boundary scenario's own selected
# lambda. This is a true over-smoothing stress test, unlike the v5 comparison
# that could accidentally impose a smaller lambda than the boundary optimum.
boundary_forced_smoothing <- tibble::tibble()
if (identical(SCENARIO, "boundary") && RUN_BOUNDARY_FORCED_SMOOTHING) {
  forced_rows <- list()
  base_force_lambda <- if (is.finite(best_lambda) && best_lambda > 0) best_lambda else lambda_base
  forced_source <- if (best_lambda > 0) "multiple_of_boundary_selected_lambda" else "multiple_of_lambda_base"
  selected_site_rmse <- cf_site$post_CF_RMSE_log
  lambda0_numeric_site_rmse <- sqrt(rowMeans(err_lambda0_numeric^2))

  for (ff in BOUNDARY_FORCED_FACTORS) {
    forced_lambda <- base_force_lambda * ff
    forced_beta <- best_beta_econ
    cat(sprintf("Boundary forced OVER-smoothing | factor=%.3g lambda=%.6g beta=%.3g\n",
                ff, forced_lambda, forced_beta))
    forced_graph <- make_paper_graph(target_meta, k = GRAPH_K, beta_econ = forced_beta)
    forced_fit <- fit_smooth_scm(
      Yt_pre, Yc_pre, forced_graph, lambda = forced_lambda, rho = 0,
      W_start = NULL, max_iter = FISTA_MAX_ITER_FINAL,
      tol = FISTA_TOL_FINAL, min_iter = FISTA_MIN_ITER_FINAL,
      fit_label = sprintf("boundary forced smoothing x%.3g", ff)
    )
    Y0_forced <- forced_fit$W %*% t(Yc_all)
    colnames(Y0_forced) <- YEARS
    rownames(Y0_forced) <- target_meta$point_id
    forced_site_rmse <- sqrt(rowMeans(
      (Y0_forced[, post_pos_truth, drop = FALSE] -
         true_cf_use[, post_pos_truth, drop = FALSE])^2
    ))

    forced_rows[[length(forced_rows) + 1L]] <- cf_site_boundary %>%
      dplyr::mutate(
        selected_RMSE_site = selected_site_rmse,
        forced_RMSE_site = forced_site_rmse,
        lambda0_numerical_RMSE_site = lambda0_numeric_site_rmse
      ) %>%
      dplyr::group_by(boundary_band) %>%
      dplyr::summarise(
        n = dplyr::n(),
        n_selected_identified = sum(is.finite(selected_RMSE_site)),
        selected_post_CF_RMSE_log = safe_rmse(selected_RMSE_site),
        forced_post_CF_RMSE_log = safe_rmse(forced_RMSE_site),
        lambda0_numerical_post_CF_RMSE_log = safe_rmse(lambda0_numerical_RMSE_site),
        forced_minus_selected_RMSE = forced_post_CF_RMSE_log - selected_post_CF_RMSE_log,
        forced_factor = ff,
        forced_lambda = forced_lambda,
        forced_beta_econ = forced_beta,
        forced_source = forced_source,
        forced_solver_status = forced_fit$status,
        .groups = "drop"
      )
  }
  boundary_forced_smoothing <- dplyr::bind_rows(forced_rows)
  readr::write_csv(boundary_forced_smoothing,
                   file.path(OUTPUT_DIR, "simulation_boundary_forced_smoothing.csv"))
}

# ---- 15e. Plots --------------------------------------------------------------
p_att_truth <- att_truth_compare %>%
  dplyr::select(year, true_ATT_pct, estimated_ATT_pct) %>%
  tidyr::pivot_longer(-year, names_to = "series", values_to = "ATT_pct") %>%
  ggplot(aes(year, ATT_pct, linetype = series)) +
  geom_line(linewidth = 1) + geom_point() +
  labs(
    title = "Synthetic validation: true vs estimated ATT",
    x = NULL, y = "ATT (%)", linetype = NULL
  ) +
  theme_minimal() + theme(legend.position = "bottom")
ggsave(file.path(OUTPUT_DIR, "simulation_true_vs_estimated_ATT.png"),
       p_att_truth, width = 8, height = 5, dpi = 200, bg = "white")

plot_cf <- tibble::tibble(
  true_cf_log = as.vector(true_cf_use[, post_pos_truth, drop = FALSE]),
  estimated_cf_log = as.vector(Y0_raw[, post_pos_truth, drop = FALSE]),
  obs_group = rep(target_meta$obs_group, times = length(post_pos_truth))
)
p_cf <- ggplot(plot_cf, aes(true_cf_log, estimated_cf_log, shape = obs_group)) +
  geom_point(alpha = 0.45, size = 1.3) +
  geom_abline(slope = 1, intercept = 0, linetype = 2) +
  coord_equal() +
  labs(
    title = "Synthetic validation: true vs estimated post-treatment counterfactual",
    x = "True counterfactual log price", y = "Estimated counterfactual log price",
    shape = "Observation group"
  ) +
  theme_minimal()
ggsave(file.path(OUTPUT_DIR, "simulation_true_vs_estimated_counterfactual.png"),
       p_cf, width = 7, height = 6, dpi = 200, bg = "white")

# Method-comparison plots for the simulation benchmark.
# IMPORTANT: lambda=0 is not identified for post-only targets. Therefore the
# all-method plot uses methods that are defined on the full evaluation sample,
# while the lambda=0 comparison is plotted separately on the common identifiable
# sample only. This avoids silently comparing different target sets.
bench_plot <- benchmark_by_group %>%
  dplyr::select(obs_group, RMSE_02_log, RMSE_graph_geo_only_log,
                RMSE_uniform_log, RMSE_gneiting_SCM_log,
                RMSE_direct_gneiting_log, RMSE_spCF_SCM_log,
                RMSE_direct_spCF_log) %>%
  tidyr::pivot_longer(-obs_group, names_to = "method", values_to = "RMSE_log") %>%
  dplyr::filter(is.finite(RMSE_log))
p_bench <- ggplot(bench_plot, aes(obs_group, RMSE_log, shape = method, group = method)) +
  geom_point(size = 2.5, position = position_dodge(width = 0.35)) +
  labs(title = "Synthetic validation: counterfactual RMSE by method",
       subtitle = "Full-sample methods; lambda=0 is shown separately on the common identifiable sample",
       x = NULL, y = "Post-treatment counterfactual RMSE (log)", shape = NULL) +
  theme_minimal() + theme(legend.position = "bottom")
ggsave(file.path(OUTPUT_DIR, "simulation_method_counterfactual_RMSE.png"),
       p_bench, width = 9, height = 5, dpi = 200, bg = "white")


bias_plot <- cf_method_comparison %>%
  dplyr::filter(obs_group %in% c("ALL", "post_only"),
                is.finite(CF_signed_mean_bias_log))
p_bias <- ggplot(bias_plot,
                 aes(obs_group, CF_signed_mean_bias_log, shape = method, group = method)) +
  geom_hline(yintercept = 0, linetype = 2) +
  geom_point(size = 2.5, position = position_dodge(width = 0.35)) +
  labs(title = "Synthetic validation: signed counterfactual mean bias",
       subtitle = "Positive = estimated counterfactual too high; negative = too low",
       x = NULL, y = "Signed mean bias (log: prediction - truth)", shape = NULL) +
  theme_minimal() + theme(legend.position = "bottom")
ggsave(file.path(OUTPUT_DIR, "simulation_method_counterfactual_signed_bias.png"),
       p_bias, width = 10, height = 5, dpi = 200, bg = "white")

lambda0_plot <- benchmark_by_group %>%
  dplyr::select(obs_group,
                RMSE_02_common_lambda0_log, RMSE_lambda0_common_log) %>%
  tidyr::pivot_longer(-obs_group, names_to = "method", values_to = "RMSE_log") %>%
  dplyr::filter(is.finite(RMSE_log))
p_lambda0 <- ggplot(lambda0_plot, aes(obs_group, RMSE_log, shape = method, group = method)) +
  geom_point(size = 2.5, position = position_dodge(width = 0.35)) +
  labs(title = "Graph-SCM vs lambda=0 on common identifiable sample",
       x = NULL, y = "Post-treatment counterfactual RMSE (log)", shape = NULL) +
  theme_minimal() + theme(legend.position = "bottom")
ggsave(file.path(OUTPUT_DIR, "simulation_graph_vs_lambda0_common_sample_RMSE.png"),
       p_lambda0, width = 9, height = 5, dpi = 200, bg = "white")

att_plot <- att_method_comparison %>%
  dplyr::filter(obs_group %in% c("ALL", "post_only"), is.finite(ATT_RMSE_pp))
p_att_methods <- ggplot(att_plot, aes(obs_group, ATT_RMSE_pp, shape = method, group = method)) +
  geom_point(size = 2.5, position = position_dodge(width = 0.35)) +
  labs(title = "Synthetic validation: ATT RMSE by method",
       x = NULL, y = "ATT RMSE (percentage points)", shape = NULL) +
  theme_minimal() + theme(legend.position = "bottom")
ggsave(file.path(OUTPUT_DIR, "simulation_method_ATT_RMSE.png"),
       p_att_methods, width = 9, height = 5, dpi = 200, bg = "white")

# ---- 15f. Compact scorecard --------------------------------------------------
att_rmse_pp <- att_overall_metrics$value[
  att_overall_metrics$metric == "ATT_RMSE_percentage_points_across_years"
]

get_bench <- function(group, column) {
  z <- benchmark_by_group[benchmark_by_group$obs_group == group, column, drop = TRUE]
  if (length(z) == 0) NA_real_ else as.numeric(z[1])
}

att_group_rmse <- att_by_group_truth %>%
  dplyr::group_by(obs_group) %>%
  dplyr::summarise(
    ATT_RMSE_pp = sqrt(mean(ATT_bias_percentage_points^2, na.rm = TRUE)),
    ATT_mean_bias_pp = mean(ATT_bias_percentage_points, na.rm = TRUE),
    .groups = "drop"
  )
get_att_group <- function(group, column) {
  z <- att_group_rmse[att_group_rmse$obs_group == group, column, drop = TRUE]
  if (length(z) == 0) NA_real_ else as.numeric(z[1])
}

get_att_method <- function(method, group, column) {
  z <- att_method_comparison[
    att_method_comparison$method == method & att_method_comparison$obs_group == group,
    column, drop = TRUE
  ]
  if (length(z) == 0) NA_real_ else as.numeric(z[1])
}

get_stk_imp <- function(group, column) {
  if (nrow(stk_imputation_summary) == 0) return(NA_real_)
  z <- stk_imputation_summary[stk_imputation_summary$obs_group == group, column, drop = TRUE]
  if (length(z) == 0) NA_real_ else as.numeric(z[1])
}

stk_phi_space <- if (!is.null(stk_fit)) as.numeric(stk_fit$best$phi_space_m) else NA_real_
stk_phi_time <- if (!is.null(stk_fit)) as.numeric(stk_fit$best$phi_time_year) else NA_real_
stk_sep <- if (!is.null(stk_fit)) as.numeric(stk_fit$best$sep) else NA_real_
stk_nugget <- if (!is.null(stk_fit)) as.numeric(stk_fit$best$nugget_ratio) else NA_real_

scorecard <- tibble::tibble(
  quantity = c(
    "Scenario",
    "Selected lambda",
    "Selected beta_econ",
    "Post-CF RMSE log (ALL)",
    "Post-CF RMSE % (ALL)",
    "ATT RMSE percentage points",
    "Mean weight cosine",
    "Mean true effective donors",
    "Mean neighboring true-weight cosine",
    "02 improvement vs lambda=0: complete_pre (%)",
    "02 improvement vs lambda=0: partial_pre (%)",
    "02 improvement vs lambda=0: post_only (%)",
    "02 improvement vs uniform: ALL (%)",
    "02 improvement vs uniform: post_only (%)",
    "02 improvement vs Gneiting kriging->SCM: ALL (%)",
    "02 improvement vs Gneiting kriging->SCM: post_only (%)",
    "Gneiting kriging->SCM Post-CF RMSE log: ALL",
    "Gneiting kriging->SCM Post-CF RMSE log: post_only",
    "Gneiting kriging hidden-PRE RMSE realized log: ALL",
    "Gneiting kriging phi_space (m)",
    "Gneiting kriging phi_time (years)",
    "Gneiting kriging nonseparability gamma",
    "Gneiting kriging nugget ratio",
    "ATT RMSE pp: complete_pre",
    "ATT RMSE pp: partial_pre",
    "ATT RMSE pp: post_only",
    "ATT mean bias pp: post_only",
    "ATT RMSE pp Gneiting kriging->SCM: ALL",
    "ATT RMSE pp Gneiting kriging->SCM: post_only",
    "ATT mean bias pp Gneiting kriging->SCM: post_only",
    "Graph directed-kNN median distance (m)",
    "Graph indexing max abs distance error (m)"
  ),
  value = c(
    as.character(truth$scenario),
    as.character(best_lambda),
    as.character(best_beta_econ),
    as.character(cf_overall$post_CF_RMSE_log),
    as.character(cf_overall$post_CF_RMSE_pct),
    as.character(att_rmse_pp),
    as.character(mean(weight_diag_truth$weight_cosine, na.rm = TRUE)),
    as.character(true_weight_concentration_summary$mean_true_effective_donors),
    as.character(truth_graph_summary$mean_neighbor_weight_cosine),
    as.character(get_bench("complete_pre", "improvement_vs_lambda0_pct")),
    as.character(get_bench("partial_pre", "improvement_vs_lambda0_pct")),
    as.character(get_bench("post_only", "improvement_vs_lambda0_pct")),
    as.character(get_bench("ALL", "improvement_vs_uniform_pct")),
    as.character(get_bench("post_only", "improvement_vs_uniform_pct")),
    as.character(get_bench("ALL", "improvement_vs_gneiting_SCM_pct")),
    as.character(get_bench("post_only", "improvement_vs_gneiting_SCM_pct")),
    as.character(get_bench("ALL", "RMSE_gneiting_SCM_log")),
    as.character(get_bench("post_only", "RMSE_gneiting_SCM_log")),
    as.character(get_stk_imp("ALL", "RMSE_hidden_realized_log")),
    as.character(stk_phi_space),
    as.character(stk_phi_time),
    as.character(stk_sep),
    as.character(stk_nugget),
    as.character(get_att_group("complete_pre", "ATT_RMSE_pp")),
    as.character(get_att_group("partial_pre", "ATT_RMSE_pp")),
    as.character(get_att_group("post_only", "ATT_RMSE_pp")),
    as.character(get_att_group("post_only", "ATT_mean_bias_pp")),
    as.character(get_att_method("Gneiting_kriging_then_SCM", "ALL", "ATT_RMSE_pp")),
    as.character(get_att_method("Gneiting_kriging_then_SCM", "post_only", "ATT_RMSE_pp")),
    as.character(get_att_method("Gneiting_kriging_then_SCM", "post_only", "ATT_mean_bias_pp")),
    as.character(final_graph$directed_knn_median_m),
    as.character(final_graph$graph_indexing_max_abs_error_m)
  )
)
# v14 benchmark/bias additions.
scorecard <- dplyr::bind_rows(
  scorecard,
  tibble::tibble(
    quantity = c(
      "Geography-only selected lambda",
      "Geo+econ improvement vs geography-only Graph-SCM: ALL (%)",
      "Geo+econ improvement vs geography-only Graph-SCM: post_only (%)",
      "Geography-only Graph-SCM Post-CF RMSE log: ALL",
      "Geography-only Graph-SCM signed CF bias log: ALL",
      "ATT RMSE pp geography-only Graph-SCM: ALL",
      "Weighted true-weight cosine selected graph",
      "Weighted true-weight cosine geography-only graph",
      "CF signed mean bias log Graph-SCM: ALL",
      "CF signed mean bias log Graph-SCM: post_only",
      "Direct Gneiting kriging Post-CF RMSE log: ALL",
      "Direct Gneiting kriging signed CF bias log: ALL",
      "spCF->SCM Post-CF RMSE log: ALL",
      "spCF->SCM signed CF bias log: ALL",
      "Direct spCF Post-CF RMSE log: ALL",
      "Direct spCF signed CF bias log: ALL",
      "ATT RMSE pp direct Gneiting nonseparable kriging: ALL",
      "ATT RMSE pp spCF->SCM: ALL",
      "ATT RMSE pp direct spCF: ALL",
      "Truth uses economic distance",
      "Main Gneiting/spCF economic covariates included",
      "Separate Econ-X strong benchmarks run",
      "Truth delta R2 from economic distance",
      "Economic graph features",
      "Economic covariance shrinkage"
    ),
    value = c(
      as.character(geo_only_lambda),
      as.character(get_bench("ALL", "improvement_vs_graph_geo_only_pct")),
      as.character(get_bench("post_only", "improvement_vs_graph_geo_only_pct")),
      as.character(get_bench("ALL", "RMSE_graph_geo_only_log")),
      as.character(get_bench("ALL", "signed_mean_bias_graph_geo_only_log")),
      as.character(get_att_method("Graph_SCM", "ALL", "ATT_RMSE_pp")),
      as.character(truth_graph_summary$weighted_cosine_selected_graph),
      as.character(truth_graph_summary$weighted_cosine_geo_only_graph),
      as.character(get_bench("ALL", "signed_mean_bias_02_log")),
      as.character(get_bench("post_only", "signed_mean_bias_02_log")),
      as.character(get_bench("ALL", "RMSE_direct_gneiting_log")),
      as.character(get_bench("ALL", "signed_mean_bias_direct_gneiting_log")),
      as.character(get_bench("ALL", "RMSE_spCF_SCM_log")),
      as.character(get_bench("ALL", "signed_mean_bias_spCF_SCM_log")),
      as.character(get_bench("ALL", "RMSE_direct_spCF_log")),
      as.character(get_bench("ALL", "signed_mean_bias_direct_spCF_log")),
      as.character(get_att_method("direct_Gneiting_kriging", "ALL", "ATT_RMSE_pp")),
      as.character(get_att_method("spCF_then_SCM", "ALL", "ATT_RMSE_pp")),
      as.character(get_att_method("direct_spCF", "ALL", "ATT_RMSE_pp")),
      as.character(ECONOMIC_DISTANCE_ACTIVE_TRUTH),
      as.character(MAIN_BENCHMARK_USE_ECON_COVARIATES),
      as.character(RUN_ECON_X_BENCHMARKS),
      as.character(truth_distance_diagnostic$delta_R2_from_economic_distance),
      paste(ECON_FEATURES, collapse = ";"),
      as.character(ECON_COV_SHRINKAGE)
    )
  )
)

# Extra solver/stability diagnostics appended without changing the legacy scorecard fields.
get_rho_diag <- function(mult, column) {
  if (nrow(rho_sensitivity) == 0 || !column %in% names(rho_sensitivity)) return(NA_real_)
  z <- rho_sensitivity[abs(rho_sensitivity$rho_multiplier - mult) < 1e-12, column, drop = TRUE]
  if (length(z) == 0) NA_real_ else as.numeric(z[1])
}
get_init_diag <- function(mult, column) {
  if (nrow(initialization_sensitivity) == 0 || !column %in% names(initialization_sensitivity)) return(NA_real_)
  z <- initialization_sensitivity[
    abs(initialization_sensitivity$rho_multiplier - mult) < 1e-12,
    column, drop = TRUE
  ]
  if (length(z) == 0) NA_real_ else as.numeric(z[1])
}
block_selected_rmse <- if (nrow(block_stress_table) > 0 && any(block_stress_table$method == "selected")) {
  block_stress_table$pseudo_postonly_rmse[match("selected", block_stress_table$method)]
} else NA_real_
block_lambda0_rmse <- if (nrow(block_stress_table) > 0 && any(block_stress_table$method == "lambda0_uniform_null")) {
  block_stress_table$pseudo_postonly_rmse[match("lambda0_uniform_null", block_stress_table$method)]
} else NA_real_
init_cf_disagree0 <- get_init_diag(0, "post_CF_disagreement_RMSE")
init_w_diff0 <- get_init_diag(0, "weight_relative_F")
min_stable_rho_mult <- if (nrow(rho_initialization_stability_summary) > 0) {
  rho_initialization_stability_summary$min_stable_rho_multiplier[1]
} else NA_real_
post_anchor_min <- min(anchor_diag$immediate_pre_anchor_neighbors[anchor_diag$obs_group == "post_only"], na.rm = TRUE)
post_component_anchor_min <- min(anchor_diag$pre_anchors_in_component[anchor_diag$obs_group == "post_only"], na.rm = TRUE)
post_unidentified_n <- sum(anchor_diag$obs_group == "post_only" & !anchor_diag$model_data_identified)
forced_boundary_penalty <- if (nrow(boundary_forced_smoothing) > 0 &&
                                  any(is.finite(boundary_forced_smoothing$forced_minus_selected_RMSE))) {
  max(boundary_forced_smoothing$forced_minus_selected_RMSE, na.rm = TRUE)
} else NA_real_

scorecard_extra <- tibble::tibble(
  quantity = c(
    "Adaptive lambda expansion steps",
    "Lambda search still on upper boundary at safety cap",
    "Final FISTA weight relative change",
    "Final FISTA PRE-prediction relative change",
    "Final FISTA objective relative change",
    "Final projected-gradient norm",
    "Post-only minimum immediate PRE anchors",
    "Post-only minimum PRE anchors in graph component",
    "Post-only unidentified targets under selected model",
    "Block-stress pseudo-post-only RMSE: selected",
    "Block-stress pseudo-post-only RMSE: lambda0",
    "rho sensitivity CF disagreement at 0.01*rho_base",
    "rho sensitivity CF disagreement at 0.1*rho_base",
    "rho sensitivity CF disagreement at 1*rho_base",
    "rho0 alternative-init weight relative difference",
    "rho0 alternative-init post-CF disagreement RMSE",
    "alternative-init post-CF disagreement at 0.1*rho_base",
    "alternative-init post-CF disagreement at 1*rho_base",
    "minimum tested rho multiplier passing init-CF stability threshold",
    "Boundary forced over-smoothing max RMSE penalty"
  ),
  value = as.character(c(
    adapt_step,
    lambda_search_boundary_remaining,
    final_fit$fista_rel_change,
    final_fit$fista_pred_rel_change,
    final_fit$fista_obj_rel_change,
    final_fit$projected_gradient_norm,
    post_anchor_min,
    post_component_anchor_min,
    post_unidentified_n,
    block_selected_rmse,
    block_lambda0_rmse,
    get_rho_diag(0.01, "post_CF_disagreement_RMSE_vs_rho0"),
    get_rho_diag(0.1, "post_CF_disagreement_RMSE_vs_rho0"),
    get_rho_diag(1, "post_CF_disagreement_RMSE_vs_rho0"),
    init_w_diff0,
    init_cf_disagree0,
    get_init_diag(0.1, "post_CF_disagreement_RMSE"),
    get_init_diag(1, "post_CF_disagreement_RMSE"),
    min_stable_rho_mult,
    forced_boundary_penalty
  ))
)
scorecard <- dplyr::bind_rows(scorecard, scorecard_extra)

readr::write_csv(scorecard,
                 file.path(OUTPUT_DIR, "simulation_validation_scorecard.csv"))

# =============================================================================
# v14 runtime profiling for Monte Carlo planning
# =============================================================================
fista_runtime <- if (length(runtime_fit_log) > 0) {
  dplyr::bind_rows(runtime_fit_log)
} else {
  tibble::tibble(
    fit_id = integer(), fit_label = character(), lambda = numeric(), rho = numeric(),
    elapsed_sec = numeric(), elapsed_min = numeric(), fista_iter = integer(),
    converged = logical(), status = character(), warm_start_used = logical()
  )
}

classify_fista_component <- function(lbl) {
  dplyr::case_when(
    grepl("^(reference lambda=0|Stage A|Stage B|Stage C|Pseudo-scattered)", lbl) ~
      "Graph_SCM_CV_screening",
    grepl("^Final3fold pseudo", lbl) ~
      "Graph_SCM_CV_final_3fold_confirmation",
    grepl("^(Cold temporal|Cold pseudo|Cold adaptive|Adaptive|Cold beta|Beta adaptive)", lbl) ~
      "Graph_SCM_CV_cold_adaptive",
    grepl("^Block-stress", lbl) ~ "diagnostic_block_stress",
    identical(lbl, "Final main rho=0") ~ "Graph_SCM_final_geo_econ",
    identical(lbl, "Geography-only Graph-SCM benchmark") ~ "Graph_SCM_final_geo_only",
    grepl("^Bias fold", lbl) ~ "optional_bias_correction",
    grepl("^rho stability", lbl) ~ "diagnostic_rho_stability",
    grepl("alternative initialization", lbl) ~ "diagnostic_initialization_stability",
    identical(lbl, "simulation lambda=0 benchmark") ~ "SCM_lambda0_available_sites",
    identical(lbl, "Gneiting kriging -> ordinary SCM") ~ "Gneiting_kriging_then_SCM_downstream_SCM",
    identical(lbl, "Gneiting kriging + Econ-X -> ordinary SCM") ~ "Gneiting_kriging_EconX_then_SCM_downstream_SCM",
    identical(lbl, "spCF -> ordinary SCM") ~ "spCF_then_SCM_downstream_SCM",
    identical(lbl, "spCF + Econ-X -> ordinary SCM") ~ "spCF_EconX_then_SCM_downstream_SCM",
    grepl("^boundary forced smoothing", lbl) ~ "diagnostic_boundary_forced_smoothing",
    TRUE ~ "FISTA_other"
  )
}

if (nrow(fista_runtime) > 0) {
  fista_runtime$component <- vapply(fista_runtime$fit_label, classify_fista_component, character(1))
  readr::write_csv(fista_runtime,
                   file.path(OUTPUT_DIR, "simulation_fista_fit_runtime_log.csv"))
  fista_component <- fista_runtime %>%
    dplyr::group_by(component) %>%
    dplyr::summarise(
      elapsed_sec = sum(elapsed_sec, na.rm = TRUE),
      n_fits = dplyr::n(),
      n_max_iter = sum(status == "max_iter_fista", na.rm = TRUE),
      .groups = "drop"
    )
} else {
  fista_component <- tibble::tibble(
    component = character(), elapsed_sec = numeric(), n_fits = integer(), n_max_iter = integer()
  )
}

fista_sec_for <- function(component_name) {
  z <- fista_component$elapsed_sec[fista_component$component == component_name]
  if (length(z) == 0) 0 else sum(z, na.rm = TRUE)
}

# PRE Gneiting/spCF timers are measured before their downstream ordinary-SCM solve;
# the downstream FISTA time is therefore reported separately.  Direct methods
# have no downstream SCM fit.
nonfista_runtime <- tibble::tibble(
  component = c(
    "Gneiting_kriging_PRE_imputation",
    "Gneiting_kriging_direct_one_sided",
    "Gneiting_kriging_EconX_PRE_imputation",
    "Gneiting_kriging_EconX_direct_one_sided",
    "spCF_PRE_imputation",
    "spCF_direct_one_sided",
    "spCF_EconX_PRE_imputation",
    "spCF_EconX_direct_one_sided",
    "diagnostic_exact_QP"
  ),
  elapsed_sec = c(
    if (is.finite(runtime_st_pre_total_sec))
      max(0, runtime_st_pre_total_sec - fista_sec_for("Gneiting_kriging_then_SCM_downstream_SCM")) else NA_real_,
    runtime_st_direct_total_sec,
    if (is.finite(runtime_st_econ_pre_total_sec))
      max(0, runtime_st_econ_pre_total_sec - fista_sec_for("Gneiting_kriging_EconX_then_SCM_downstream_SCM")) else NA_real_,
    runtime_st_econ_direct_total_sec,
    runtime_spcf_pre_sec,
    runtime_spcf_direct_sec,
    runtime_spcf_econ_pre_sec,
    runtime_spcf_econ_direct_sec,
    runtime_exact_qp_sec
  ),
  n_fits = c(
    ifelse(is.finite(runtime_st_pre_total_sec), 1L, 0L),
    ifelse(is.finite(runtime_st_direct_total_sec), length(PERIOD_POST), 0L),
    ifelse(is.finite(runtime_st_econ_pre_total_sec), 1L, 0L),
    ifelse(is.finite(runtime_st_econ_direct_total_sec), length(PERIOD_POST), 0L),
    ifelse(is.finite(runtime_spcf_pre_sec), 1L, 0L),
    ifelse(is.finite(runtime_spcf_direct_sec), length(PERIOD_POST), 0L),
    ifelse(is.finite(runtime_spcf_econ_pre_sec), 1L, 0L),
    ifelse(is.finite(runtime_spcf_econ_direct_sec), length(PERIOD_POST), 0L),
    ifelse(is.finite(runtime_exact_qp_sec), 1L, 0L)
  ),
  n_max_iter = NA_integer_
) %>%
  dplyr::filter(is.finite(elapsed_sec))

runtime_breakdown_core <- dplyr::bind_rows(fista_component, nonfista_runtime)

# Bring in the 04a wall time when available.
dgp_runtime_file <- file.path(dirname(OUTPUT_DIR), "simulation_dgp_runtime.csv")
dgp_runtime_row <- if (file.exists(dgp_runtime_file)) {
  z <- readr::read_csv(dgp_runtime_file, show_col_types = FALSE)
  tibble::tibble(
    component = "DGP_generation_04a",
    elapsed_sec = as.numeric(z$elapsed_sec[1]),
    n_fits = 1L,
    n_max_iter = NA_integer_
  )
} else tibble::tibble()

validation_elapsed_sec <- as.numeric(difftime(Sys.time(), VALIDATION_SCRIPT_START, units = "secs"))
measured_validation_sec <- sum(runtime_breakdown_core$elapsed_sec, na.rm = TRUE)
other_validation_sec <- max(0, validation_elapsed_sec - measured_validation_sec)
runtime_breakdown <- dplyr::bind_rows(
  dgp_runtime_row,
  runtime_breakdown_core,
  tibble::tibble(
    component = "other_validation_overhead",
    elapsed_sec = other_validation_sec,
    n_fits = NA_integer_,
    n_max_iter = NA_integer_
  )
) %>%
  dplyr::mutate(
    scenario = SCENARIO,
    elapsed_min = elapsed_sec / 60,
    component_class = dplyr::case_when(
      grepl("^Graph_SCM", component) ~ "main_estimator",
      component %in% c("SCM_lambda0_available_sites") ~ "benchmark",
      grepl("^Gneiting_kriging", component) ~ "benchmark",
      grepl("^spCF", component) ~ "benchmark",
      grepl("^diagnostic_|^optional_bias", component) ~ "diagnostic",
      component == "DGP_generation_04a" ~ "data_generation",
      TRUE ~ "overhead"
    ),
    estimator_required = component_class %in% c("main_estimator", "benchmark", "data_generation"),
    mc_default = dplyr::case_when(
      component %in% c(
        "diagnostic_exact_QP", "diagnostic_rho_stability",
        "diagnostic_initialization_stability", "diagnostic_block_stress",
        "diagnostic_boundary_forced_smoothing", "optional_bias_correction"
      ) ~ "diagnostic_subset_only",
      component %in% c(
        "Gneiting_kriging_PRE_imputation", "Gneiting_kriging_direct_one_sided",
        "Gneiting_kriging_EconX_PRE_imputation", "Gneiting_kriging_EconX_direct_one_sided",
        "Gneiting_kriging_then_SCM_downstream_SCM",
        "Gneiting_kriging_EconX_then_SCM_downstream_SCM"
      ) ~ "consider_heavy_subset",
      TRUE ~ "keep"
    )
  ) %>%
  dplyr::arrange(dplyr::desc(elapsed_sec))

runtime_total_sec <- sum(runtime_breakdown$elapsed_sec, na.rm = TRUE)
runtime_breakdown <- runtime_breakdown %>%
  dplyr::mutate(
    share_of_profiled_runtime_pct = if (runtime_total_sec > 0) 100 * elapsed_sec / runtime_total_sec else NA_real_
  )
readr::write_csv(runtime_breakdown,
                 file.path(OUTPUT_DIR, "simulation_runtime_breakdown.csv"))

runtime_mc_projection <- tidyr::expand_grid(
  replicates = c(20L, 50L, 100L),
  workload = c("full_proposal", "without_diagnostics", "spCF_focused_no_Gneiting")
) %>%
  dplyr::rowwise() %>%
  dplyr::mutate(
    per_replicate_sec = {
      keep <- rep(TRUE, nrow(runtime_breakdown))
      if (workload %in% c("without_diagnostics", "spCF_focused_no_Gneiting")) {
        keep <- keep & runtime_breakdown$mc_default != "diagnostic_subset_only"
      }
      if (workload == "spCF_focused_no_Gneiting") {
        keep <- keep & !grepl("^Gneiting_kriging", runtime_breakdown$component)
      }
      sum(runtime_breakdown$elapsed_sec[keep], na.rm = TRUE)
    },
    projected_hours = per_replicate_sec * replicates / 3600
  ) %>%
  dplyr::ungroup()
readr::write_csv(runtime_mc_projection,
                 file.path(OUTPUT_DIR, "simulation_runtime_mc_projection.csv"))

cat("\nRuntime bottlenecks (v14 profiler):\n")
print(runtime_breakdown %>%
        dplyr::select(component, elapsed_min, share_of_profiled_runtime_pct, n_fits, n_max_iter, mc_default) %>%
        dplyr::slice_head(n = 12L))

cat("\n============================================================\n")
cat("SIMULATION VALIDATION FINISHED\n")
cat("Scenario:", truth$scenario, "\n")
cat("Selected lambda:", best_lambda, "\n")
cat("Selected beta_econ:", best_beta_econ, "\n")
cat(sprintf("Post-CF RMSE (log), all targets: %.5f\n", cf_overall$post_CF_RMSE_log))
cat(sprintf("Post-CF RMSE (%%), all targets: %.2f\n", cf_overall$post_CF_RMSE_pct))
cat(sprintf("ATT RMSE across post years (percentage points): %.3f\n", att_rmse_pp))
cat(sprintf("True effective donors: mean %.2f, median %.2f\n",
            true_weight_concentration_summary$mean_true_effective_donors,
            true_weight_concentration_summary$median_true_effective_donors))
cat(sprintf("Mean neighboring true-weight cosine on selected graph: %.3f\n",
            truth_graph_summary$mean_neighbor_weight_cosine))
cat("\n02 vs benchmarks counterfactual RMSE:\n")
print(benchmark_by_group)
cat("\nATT recovery by method and observation group:\n")
print(att_method_comparison)
cat("\nWeight recovery (secondary diagnostic):\n")
print(weight_summary)
cat("\nMain files to inspect:\n")
cat("  simulation_validation_scorecard.csv\n")
cat("  simulation_counterfactual_recovery_summary.csv\n")
cat("  simulation_ATT_truth_vs_estimated.csv\n")
cat("  simulation_02_vs_benchmarks.csv\n")
cat("  simulation_true_weight_similarity_summary.csv\n")
cat("  simulation_true_weight_distance_diagnostic.csv\n")
cat("  cv_near_tie_candidates.csv\n")
cat("  cv_selection_rule_summary.csv\n")
cat("  simulation_lambda0_identification_status.csv\n")
cat("  simulation_gneiting_selected_parameters.csv\n")
cat("  simulation_gneiting_econX_selected_parameters.csv\n")
cat("  simulation_direct_gneiting_econX_selected_parameters.csv\n")
cat("  simulation_gneiting_imputation_metrics.csv\n")
cat("  simulation_ATT_method_comparison_by_group.csv\n")
cat("  simulation_ATT_estimand_selection_summary.csv\n")
cat("  simulation_true_ATT_selection_by_year.csv\n")
cat("  simulation_boundary_error_summary.csv\n")
cat("  simulation_rho_sensitivity.csv\n")
cat("  simulation_initialization_sensitivity.csv\n")
cat("  cv_pseudo_postonly_block_stress.csv\n")
cat("  postonly_graph_anchor_diagnostics.csv\n")
if (identical(SCENARIO, "boundary")) cat("  simulation_boundary_forced_smoothing.csv\n")
cat("  simulation_true_vs_estimated_ATT.png\n")
cat("  simulation_true_vs_estimated_counterfactual.png\n")
cat("============================================================\n")
