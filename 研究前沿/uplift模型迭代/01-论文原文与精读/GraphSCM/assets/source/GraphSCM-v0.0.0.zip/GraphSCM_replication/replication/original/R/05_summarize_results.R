args_all <- commandArgs(trailingOnly = FALSE)
file_arg <- grep('^--file=', args_all, value = TRUE)
R_DIR <- if (length(file_arg)) normalizePath(dirname(sub('^--file=', '', file_arg[1])), winslash='/', mustWork=TRUE) else normalizePath(getwd(), winslash='/', mustWork=TRUE)
source(file.path(R_DIR, '00_config.R'))
for (p in c('readr','dplyr','tidyr','tibble','ggplot2','forcats')) if (!requireNamespace(p,quietly=TRUE)) stop('Package required: ',p)

OUT <- file.path(OUTPUT_ROOT,'_publication_summary'); dir.create(OUT,recursive=TRUE,showWarnings=FALSE); dir.create(file.path(OUT,'figures'),showWarnings=FALSE)
core_methods <- c('Graph_SCM','GeoEco_SCM','uniform_weights','Ordinary_SCM','Gneiting_kriging_then_SCM','Gneiting_kriging_EconX_then_SCM','direct_Gneiting_kriging','direct_Gneiting_kriging_EconX')
full_methods <- setdiff(core_methods,'Ordinary_SCM')
rows <- list(); att_rows <- list(); params <- list(); idx <- 0L; ip <- 0L; ia <- 0L
for (sc in SCENARIOS_ALL) for (rp in completed_reps_for(sc)) {
  seed <- seed_for(sc,rp); rd <- result_dir_for(sc,rp)
  f <- file.path(rd,'simulation_counterfactual_method_comparison_by_group.csv')
  p <- file.path(rd,'selected_parameters.csv')
  if (!file.exists(f)) next
  idx <- idx+1L; d <- readr::read_csv(f,show_col_types=FALSE) |> dplyr::filter(method %in% core_methods) |> dplyr::mutate(scenario=sc,rep=rp,seed=seed)
  rows[[idx]] <- d
  af <- file.path(rd,'simulation_ATT_method_comparison_by_group.csv')
  if (file.exists(af)) {
    ia <- ia + 1L
    att_rows[[ia]] <- readr::read_csv(af,show_col_types=FALSE) |>
      dplyr::filter(method %in% core_methods) |> dplyr::mutate(scenario=sc,rep=rp,seed=seed)
  }
  if (file.exists(p)) { ip <- ip+1L; params[[ip]] <- readr::read_csv(p,show_col_types=FALSE) |> dplyr::mutate(scenario=sc,rep=rp,seed=seed) }
}
all_cf <- dplyr::bind_rows(rows)
if (!nrow(all_cf)) stop('No completed results found under ',OUTPUT_ROOT)
readr::write_csv(all_cf,file.path(OUT,'all_10dgp_CF_replications.csv'))
all_att <- dplyr::bind_rows(att_rows)
if (nrow(all_att)) {
  readr::write_csv(all_att,file.path(OUT,'all_10dgp_ATT_replications.csv'))
  att_summary <- all_att |> dplyr::group_by(scenario,method,obs_group) |> dplyr::summarise(
    n_rep=dplyr::n_distinct(seed), mean_ATT_RMSE_pp=mean(ATT_RMSE_pp,na.rm=TRUE),
    mcse_ATT_RMSE_pp=stats::sd(ATT_RMSE_pp,na.rm=TRUE)/sqrt(sum(is.finite(ATT_RMSE_pp))),
    mean_ATT_bias_pp=mean(ATT_mean_bias_pp,na.rm=TRUE),.groups='drop')
  readr::write_csv(att_summary,file.path(OUT,'ATT_summary_long.csv'))
}


summ <- all_cf |> dplyr::group_by(scenario,method,obs_group) |> dplyr::summarise(
  n_rep=dplyr::n_distinct(seed), mean_CF_RMSE_log=mean(CF_RMSE_log,na.rm=TRUE),
  mcse_CF_RMSE_log=stats::sd(CF_RMSE_log,na.rm=TRUE)/sqrt(sum(is.finite(CF_RMSE_log))),
  mean_CF_signed_bias_log=mean(CF_signed_mean_bias_log,na.rm=TRUE),
  mean_abs_CF_bias_log=mean(abs(CF_signed_mean_bias_log),na.rm=TRUE),
  mean_coverage=mean(n_eval_sites/n_sites,na.rm=TRUE),.groups='drop')
readr::write_csv(summ,file.path(OUT,'CF_summary_long.csv'))

for (grp in c('ALL','post_only')) {
  wide <- summ |> dplyr::filter(obs_group==grp) |> dplyr::select(scenario,method,mean_CF_RMSE_log) |> tidyr::pivot_wider(names_from=method,values_from=mean_CF_RMSE_log)
  readr::write_csv(wide,file.path(OUT,paste0('CF_RMSE_',grp,'.csv')))
}
ranking <- summ |> dplyr::filter(obs_group %in% c('ALL','post_only'),method %in% full_methods) |> dplyr::group_by(scenario,obs_group) |> dplyr::arrange(mean_CF_RMSE_log,.by_group=TRUE) |> dplyr::mutate(rank=dplyr::row_number(),best=rank==1L) |> dplyr::ungroup()
readr::write_csv(ranking,file.path(OUT,'full_coverage_ranking.csv'))

gg <- all_cf |> dplyr::filter(method %in% c('Graph_SCM','GeoEco_SCM')) |> dplyr::select(scenario,seed,obs_group,method,CF_RMSE_log) |> tidyr::pivot_wider(names_from=method,values_from=CF_RMSE_log) |> dplyr::mutate(diff_geoeco_minus_graph=GeoEco_SCM-Graph_SCM,improvement_pct=100*(Graph_SCM-GeoEco_SCM)/Graph_SCM,geoeco_wins=GeoEco_SCM<Graph_SCM)
gg_sum <- gg |> dplyr::group_by(scenario,obs_group) |> dplyr::summarise(n=sum(is.finite(diff_geoeco_minus_graph)),mean_graph=mean(Graph_SCM,na.rm=TRUE),mean_geoeco=mean(GeoEco_SCM,na.rm=TRUE),mean_diff=mean(diff_geoeco_minus_graph,na.rm=TRUE),se_diff=stats::sd(diff_geoeco_minus_graph,na.rm=TRUE)/sqrt(n),mean_improvement_pct=mean(improvement_pct,na.rm=TRUE),win_rate=mean(geoeco_wins,na.rm=TRUE),.groups='drop') |> dplyr::mutate(ci_lo=mean_diff-stats::qt(.975,pmax(n-1,1))*se_diff,ci_hi=mean_diff+stats::qt(.975,pmax(n-1,1))*se_diff)
readr::write_csv(gg_sum,file.path(OUT,'Graph_vs_GeoEco_paired.csv'))

pp <- dplyr::bind_rows(params)
if (nrow(pp)) {
  beta <- pp |> dplyr::count(scenario,beta_econ,name='n') |> dplyr::group_by(scenario) |> dplyr::mutate(prop=n/sum(n)) |> dplyr::ungroup()
  readr::write_csv(beta,file.path(OUT,'beta_selection_frequency.csv'))
  audit <- pp |> dplyr::group_by(scenario) |> dplyr::summarise(n_rep=dplyr::n(),n_lambda_boundary=sum(lambda_search_boundary_remaining %in% TRUE,na.rm=TRUE),n_beta_boundary=sum(beta_search_boundary_remaining %in% TRUE,na.rm=TRUE),n_exact_qp_success=sum(final_exact_qp_success %in% TRUE,na.rm=TRUE),n_osqp_solved=sum(final_osqp_status=='solved',na.rm=TRUE),.groups='drop')
  readr::write_csv(audit,file.path(OUT,'solver_search_audit.csv'))
}

labels <- c(smooth_geo_only='Smooth geo-only',smooth_geo_econ='Smooth geo+econ',station_selected_geo_only='Station-selected geo-only',station_selected_geo_econ='Station-selected geo+econ',smooth_geo_econ_latent_factor='Latent factor',no_spatial='No spatial',spatially_separated_donors='Spatially separated donors',boundary='Boundary',station_selected_local_standard='Local paired: standard',station_selected_local_mismatch='Local paired: mismatch')
labels <- setNames(paste(DESIGN_CATALOG$paper_id, DESIGN_CATALOG$title, sep=': '), DESIGN_CATALOG$scenario)
methods <- c(Graph_SCM='Graph-SCM',GeoEco_SCM='GeoEco-SCM',Gneiting_kriging_then_SCM='Gneiting -> SCM',Gneiting_kriging_EconX_then_SCM='Gneiting + EconX -> SCM',direct_Gneiting_kriging='Direct Gneiting',direct_Gneiting_kriging_EconX='Direct Gneiting + EconX')
for (grp in c('ALL','post_only')) {
  dat <- summ |> dplyr::filter(obs_group==grp,method %in% names(methods)) |> dplyr::mutate(scenario_label=factor(labels[scenario],levels=rev(unname(labels))),method_label=methods[method])
  g <- ggplot2::ggplot(dat,ggplot2::aes(x=mean_CF_RMSE_log,y=scenario_label,shape=method_label))+ggplot2::geom_point(size=2.5,position=ggplot2::position_dodge(width=.5))+ggplot2::labs(x='Mean counterfactual RMSE (log scale)',y=NULL,shape='Method')+ggplot2::theme_minimal(base_size=11)+ggplot2::theme(legend.position='bottom')
  ggplot2::ggsave(file.path(OUT,'figures',paste0('RMSE_',grp,'.png')),g,width=9.5,height=6.2,dpi=180)
}
imp <- gg_sum |> dplyr::filter(obs_group=='post_only') |> dplyr::mutate(scenario_label=factor(labels[scenario],levels=rev(unname(labels))))
g <- ggplot2::ggplot(imp,ggplot2::aes(x=mean_improvement_pct,y=scenario_label))+ggplot2::geom_vline(xintercept=0,linetype=2)+ggplot2::geom_point(size=3)+ggplot2::labs(x='Mean GeoEco improvement over Graph (%)',y=NULL)+ggplot2::theme_minimal(base_size=11)
ggplot2::ggsave(file.path(OUT,'figures','GeoEco_vs_Graph_post_only.png'),g,width=8.8,height=5.8,dpi=180)
cat('Summary written to:',OUT,'\n')
