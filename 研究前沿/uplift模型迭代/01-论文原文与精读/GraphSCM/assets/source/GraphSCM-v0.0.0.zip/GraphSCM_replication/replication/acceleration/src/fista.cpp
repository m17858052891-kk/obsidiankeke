// FISTA kernel for Graph-SCM. All tuning decisions remain in the original R code.
// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::plugins(graphscm_blas)]]
#include <Rcpp.h>
#include <R_ext/BLAS.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <vector>

namespace {
struct CSC {
  int nr, nc;
  Rcpp::IntegerVector p, i;
  Rcpp::NumericVector x;
  explicit CSC(const Rcpp::List& a) : nr(Rcpp::as<int>(a["nrow"])),
    nc(Rcpp::as<int>(a["ncol"])), p(a["p"]), i(a["i"]), x(a["x"]) {
    if (nr < 0 || nc < 0 || p.size() != nc + 1 || i.size() != x.size() ||
        p[0] != 0 || p[nc] != x.size()) Rcpp::stop("Invalid sparse matrix.");
    for (int c = 0; c < nc; ++c)
      if (p[c] < 0 || p[c] > p[c+1]) Rcpp::stop("Invalid sparse column pointers.");
    for (int k = 0; k < x.size(); ++k)
      if (i[k] < 0 || i[k] >= nr || !R_FINITE(x[k])) Rcpp::stop("Invalid sparse entries.");
  }
  void multiply(const std::vector<double>& w, int columns, std::vector<double>& out) const {
    std::fill(out.begin(), out.end(), 0.0);
    for (int d = 0; d < columns; ++d) {
      double* dest = out.data() + static_cast<size_t>(nr)*d;
      const double* src = w.data() + static_cast<size_t>(nc)*d;
      for (int c = 0; c < nc; ++c)
        for (int k = p[c]; k < p[c+1]; ++k) dest[i[k]] += x[k]*src[c];
    }
  }
};

double squared_norm(const std::vector<double>& a) {
  long double value = 0;
  for (double x : a) value += static_cast<long double>(x)*x;
  return static_cast<double>(value);
}

void project_rows(std::vector<double>& w, int n, int j, std::vector<double>& tmp) {
  for (int row = 0; row < n; ++row) {
    for (int d = 0; d < j; ++d) tmp[d] = w[row + static_cast<size_t>(n)*d];
    std::sort(tmp.begin(), tmp.end(), std::greater<double>());
    double sum = 0.0, theta = 0.0;
    bool found = false;
    for (int d = 0; d < j; ++d) {
      sum += tmp[d];
      const double threshold = (sum - 1.0)/(d+1);
      if (tmp[d] - threshold > 0.0) { theta = threshold; found = true; }
    }
    for (int d = 0; d < j; ++d) {
      double& x = w[row + static_cast<size_t>(n)*d];
      x = found ? std::max(x-theta, 0.0) : 1.0/j;
    }
  }
}
}

// [[Rcpp::export]]
Rcpp::NumericMatrix scm_project_rows_cpp(Rcpp::NumericMatrix input) {
  const int n = input.nrow(), j = input.ncol();
  if (n < 1 || j < 1) Rcpp::stop("Empty weight matrix.");
  std::vector<double> w(input.begin(), input.end()), tmp(j);
  for (double x : w) if (!R_FINITE(x)) Rcpp::stop("Non-finite weights.");
  project_rows(w, n, j, tmp);
  Rcpp::NumericMatrix answer(n,j);
  std::copy(w.begin(), w.end(), answer.begin());
  return answer;
}

// [[Rcpp::export]]
Rcpp::List scm_fista_cpp(Rcpp::NumericMatrix yobs, Rcpp::LogicalMatrix mask,
    Rcpp::NumericMatrix yc, Rcpp::List laplacian, Rcpp::List incidence,
    double sum_a, double lambda, double ridge, double step,
    Rcpp::NumericMatrix initial, int max_iter, double tol, int min_iter,
    int check_every, bool verbose, int progress_every, std::string fit_label) {
  const int n = yobs.nrow(), tt = yobs.ncol(), j = yc.ncol();
  if (n < 1 || tt < 1 || j < 1 || yc.nrow() != tt || mask.nrow() != n ||
      mask.ncol() != tt || initial.nrow() != n || initial.ncol() != j)
    Rcpp::stop("Incompatible FISTA dimensions.");
  if (!R_FINITE(sum_a) || sum_a <= 0 || !R_FINITE(lambda) || lambda < 0 ||
      !R_FINITE(ridge) || ridge < 0 || !R_FINITE(step) || step <= 0 ||
      !R_FINITE(tol) || tol <= 0 || max_iter < 1 || min_iter < 0 ||
      check_every < 1 || progress_every < 1) Rcpp::stop("Invalid FISTA settings.");
  const CSC lap(laplacian), dg(incidence);
  if (lap.nr != n || lap.nc != n || dg.nc != n) Rcpp::stop("Graph dimensions disagree.");
  for (double x : yc) if (!R_FINITE(x)) Rcpp::stop("Non-finite donor outcomes.");
  for (double x : yobs) if (!R_FINITE(x)) Rcpp::stop("Non-finite filled outcomes.");
  std::vector<int> count(n,0);
  for (int t = 0; t < tt; ++t) for (int r = 0; r < n; ++r) {
    if (mask(r,t) == NA_LOGICAL) Rcpp::stop("Missing observation mask.");
    count[r] += mask(r,t) ? 1 : 0;
  }
  int n_active = 0;
  for (int c : count) n_active += c > 0;
  if (!n_active) Rcpp::stop("No observed training outcomes.");
  std::vector<double> row_scale(n,0.0);
  for (int r=0; r<n; ++r) if (count[r]) row_scale[r] = 1.0/(n_active*count[r]);
  std::vector<double> w(initial.begin(), initial.end());
  for (double x : w) if (!R_FINITE(x)) Rcpp::stop("Invalid initial weights.");
  std::vector<double> z(w), wnew(w.size()), znew(w.size()), grad(w.size()),
    lapw(w.size()), tmp(j), pred(static_cast<size_t>(n)*tt), error(pred.size()),
    previous_pred(pred.size()), dw(static_cast<size_t>(dg.nr)*j);
  const double one=1.0, zero=0.0, graph_factor=2*lambda/sum_a, ridge_factor=2*ridge/n;
  const char normal='N', transpose='T';
  auto predict = [&](const std::vector<double>& a, std::vector<double>& b) {
    F77_CALL(dgemm)(&normal, &transpose, &n, &tt, &j, &one, a.data(), &n,
      yc.begin(), &tt, &zero, b.data(), &n FCONE FCONE);
  };
  auto gradient = [&](const std::vector<double>& a, std::vector<double>& b) {
    predict(a,pred);
    for (int t=0; t<tt; ++t) for (int r=0; r<n; ++r) {
      const size_t k=r+static_cast<size_t>(n)*t;
      error[k] = mask(r,t) ? (pred[k]-yobs(r,t))*row_scale[r] : 0.0;
    }
    F77_CALL(dgemm)(&normal, &normal, &n, &j, &tt, &one, error.data(), &n,
      yc.begin(), &tt, &zero, b.data(), &n FCONE FCONE);
    if (lambda>0) lap.multiply(a,j,lapw);
    for (size_t k=0; k<b.size(); ++k) {
      b[k] *= 2.0;
      if (lambda>0) b[k] += graph_factor*lapw[k];
      if (ridge>0) b[k] += ridge_factor*a[k];
    }
  };
  auto objective = [&](const std::vector<double>& a) {
    predict(a,pred);
    long double fit=0;
    for (int r=0; r<n; ++r) if (count[r]) {
      long double site=0;
      for (int t=0; t<tt; ++t) if (mask(r,t)) {
        const double e=pred[r+static_cast<size_t>(n)*t]-yobs(r,t);
        site += static_cast<long double>(e)*e;
      }
      fit += static_cast<double>(site)/count[r];
    }
    double smooth=0;
    if (lambda>0) { dg.multiply(a,j,dw); smooth=lambda*squared_norm(dw)/sum_a; }
    return static_cast<double>(fit/n_active)+smooth+ridge*squared_norm(a)/n;
  };
  double last_obj=objective(w), previous_obj=last_obj;
  previous_pred=pred;
  double acceleration=1.0, change=R_PosInf, obj_change=R_PosInf, pred_change=R_PosInf;
  bool converged=false;
  int iterations=0;
  const auto started=std::chrono::steady_clock::now();
  for (int iter=1; iter<=max_iter; ++iter) {
    gradient(z,grad);
    for (size_t k=0; k<w.size(); ++k) wnew[k]=z[k]-step*grad[k];
    project_rows(wnew,n,j,tmp);
    long double delta=0, restart=0;
    double anew=(1+std::sqrt(1+4*acceleration*acceleration))/2;
    const double momentum=(acceleration-1)/anew;
    for (size_t k=0; k<w.size(); ++k) {
      const double d=wnew[k]-w[k];
      delta += static_cast<long double>(d)*d;
      restart += static_cast<long double>(z[k]-wnew[k])*d;
      znew[k]=wnew[k]+momentum*d;
    }
    change=std::sqrt(static_cast<double>(delta))/std::max(1.0,std::sqrt(squared_norm(w)));
    if (restart>0) { anew=1.0; znew=wnew; }
    w.swap(wnew); z.swap(znew); acceleration=anew; iterations=iter;
    if (iter%check_every==0 || iter==1) {
      Rcpp::checkUserInterrupt();
      const double current=objective(w);
      obj_change=std::abs(current-previous_obj)/std::max(1.0,std::abs(previous_obj));
      long double difference=0;
      for (size_t k=0; k<pred.size(); ++k) {
        const double d=pred[k]-previous_pred[k];
        difference += static_cast<long double>(d)*d;
      }
      pred_change=std::sqrt(static_cast<double>(difference))/std::max(1.0,std::sqrt(squared_norm(previous_pred)));
      last_obj=current; previous_obj=current; previous_pred=pred;
      if (verbose && (iter%progress_every==0 || iter==1)) {
        const double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
        Rprintf("  [%s] iter %d / %d | elapsed %.2f min | max-iter ETA %.2f min | obj %.8g | w.change %.3g | pred.change %.3g | obj.change %.3g\n",
          fit_label.c_str(),iter,max_iter,seconds/60,(seconds/iter)*(max_iter-iter)/60,
          current,change,pred_change,obj_change);
      }
      if (change<tol && iter>=min_iter) { converged=true; break; }
    }
  }
  gradient(w,grad);
  for (size_t k=0; k<w.size(); ++k) wnew[k]=w[k]-step*grad[k];
  project_rows(wnew,n,j,tmp);
  long double mapping=0;
  for (size_t k=0; k<w.size(); ++k) {
    const double d=(w[k]-wnew[k])/step;
    mapping += static_cast<long double>(d)*d;
  }
  const double pg=std::sqrt(static_cast<double>(mapping))/std::max(1.0,std::sqrt(squared_norm(w)));
  Rcpp::NumericMatrix result(n,j);
  std::copy(w.begin(),w.end(),result.begin());
  return Rcpp::List::create(Rcpp::Named("W")=result, Rcpp::Named("last_obj")=last_obj,
    Rcpp::Named("iterations")=iterations, Rcpp::Named("converged")=converged,
    Rcpp::Named("rel_change")=change, Rcpp::Named("obj_rel_change")=obj_change,
    Rcpp::Named("pred_rel_change")=pred_change, Rcpp::Named("pg_norm")=pg);
}
