@echo off
setlocal
cd /d "%~dp0"
Rscript R\04_audit_local_pair.R
if errorlevel 1 exit /b %errorlevel%
Rscript R\05_summarize_results.R
if errorlevel 1 exit /b %errorlevel%
Rscript R\06_export_paper_assets.R
pause
