# -*- coding: utf-8 -*-
"""
Supplementary Material S4
Python code used to calculate preterm estimate the probability of
a small for gestational age fetus (birthweight under 10th percentile) 
before 37 gestational week, based on measurements at 19+0 to 24+6 gestational 
according to the Fetal Medicine Foundation (FMF) competing-risks algorithm.

This script was created as supplementary material for the manuscript:
"Representation of Preterm Small-for-Gestational-Age Risk Factors in LLMs Compared with the FMF Competing-Risks Model".

Author: Dragos Nemescu
Copyright (c) 2026 Dragos Nemescu. All rights reserved.

This file is provided for academic transparency, peer review, and
reproducibility of the analyses described in the manuscript. Any reuse,
modification, redistribution, or publication of this code should cite the
associated manuscript and acknowledge the author. No warranty is provided;
the code is supplied "as is" and is not intended for direct clinical use or
clinical decision-making.
"""

# PyMC Bayesian model for SGA competing-risks core with folded-plane UtA likelihood
# Single-case posterior conditioning
import tkinter as tk
from tkinter import filedialog
import pandas as pd
import numpy as np
from scipy.stats import multivariate_normal
import sys
import os
from multiprocessing import Pool, cpu_count
import time
from typing import Any, Optional, cast


# Define the path to the directory containing .xlsx files
directory_path = 'insert_your_directory_path_here'  # Replace with your desired directory path

# Threshold for preterm delivery (< 37 weeks)
GA_CUT = 37.0
# Threshold for 10th percentile BW Z-score 
BW_Z_P10 = -1.28155

# Patient data
#data = {
#    'case_no': 1,
#    'height': 165,  # cm
#    'weight': 67,   # kg
#    'race': 'white',
#    'conception': 'spontaneous',
#    'smoking': 'no',
#    'chronic_hypertension': 'no',
#    'diabetes': 'no',
#    'sle_aps': 'no', #systemic lupus erythematosus or antiphospholipid syndrome
#    'parity': 'nullipara',
#    'is_parous': False,
#    'efw_zscore': 0,    # Observed mid-trimester markers
#    'utapi_mom': 1,
#    'prev_preeclampsia': 'no', # multiparous-specific fields
#    'prev_stillbirth': 'no',
#    'bw_zscore_last': 0,
#    'interp_interval': 0,
#    'efw_z_score': 0,
#    'utapi_mom': 1
#}

# =============================
# Grids & cutoffs (wide + fine)
# =============================
GA_MIN, GA_MAX, GA_STEP = 24.0, 64.0, 0.025
BW_Z_MIN,  BW_Z_MAX,  BW_Z_STEP  = -5.0,  5.0,  0.01

GA_GRID = np.arange(GA_MIN, GA_MAX + 1e-12, GA_STEP)
BW_Z_GRID  = np.arange(BW_Z_MIN,  BW_Z_MAX  + 1e-12, BW_Z_STEP)

num_ga = GA_GRID.size
num_z = BW_Z_GRID.size
total_points = num_ga * num_z

# Model parameters - moved to global scope for multiprocessing
BW_PARAMS = {
    'intercept': 0.444662,
    'black': -0.524625,
    'south_asian': -0.482211,
    'mixed': -0.280160,
    'height_centered': 0.026730,
    'weight_centered': 0.012648,
    'weight_squared': -0.000189,
    'ivf': -0.098920,
    'smoker': -0.693680,
    'chronic_hypertension': -0.706842,
    'sle_aps': -0.443860,
    'parous': 0.138451,
    'ga_last_pregnancy': 0.068527,
    'bw_zscore_last': 0.344370,
    'interpregnancy_inv': -0.380348,
    'interpregnancy_sqrt': 1.004172,
    'sd_bw': 1.399757
}

GA_PARAMS = {
    'intercept': 45.490642,
    'mean_bw_zscore': 1.499151,
    'weight_centered': -0.024432,
    'ivf': -1.214127,
    'chronic_hypertension': -0.989338,
    'diabetes': -3.964919,
    'previous_preeclampsia': -1.157569,
    'previous_stillbirth': -1.474475,
    'parous': 0.551989,
    'ga_last_pregnancy': 0.865976,
    'ga_last_pregnancy_sq': 0.041513,
    'sd_ga': 5.730152
}

BW_Z_GA_CORRELATION = 0.366211 # prior corr between z and g

EFW_PARAMS = {          
    'beta0': 0.000582608,
    'beta1': 0.275778696,
    'beta2': -0.014074987,
    'sd_efw': 0.894125012
}

UTAPI_PARAMS = {        
    'intercept': -0.028947,
    'bw_zscore': -0.033732,
    'ga_minus_40': -0.009792,
    'ga_minus_40_sq': -0.000248,
    'sd_utapi': 0.11881
}

EFW_UTAPI_CORRELATION = -0.068655

# Create a hidden Tkinter root window
root = tk.Tk()
root.withdraw()  # Hide the root window

def validate_input_data(row: pd.Series, case_no: str) -> dict[str, Any]:
    """
    Validate and parse input data for a single case.
    Returns parsed data dictionary or raises exception if validation fails.
    """
    required_fields = [
        'Case_no', 'Height', 'Weight', 'Race', 'Smoking', 'Conception', 'Chronic_hypertension', 'Diabetes_mellitus',
        'SLE_APS', 'Parity', 'EFW_z-score', 'Uterine_artery_PI_MOM'
    ]
    
    # Check for missing values
    missing_fields = []
    for field in required_fields:
        value: Any = row.get(field)
        if pd.isna(value) or value == '' or value is None:
            missing_fields.append(field)
    
    # Check multiparous-specific fields
    parity_val = str(row.get('Parity', '')).strip().lower()
    is_parous = parity_val in ['multipara', 'parous', 'multi']
    
    if is_parous:
        multiparous_fields = [
            'Previous_pregnancy_preeclampsia', 'Previous_stillbirth',
            'Previous_last_birth_gestational_age', 'Previous_birthweight_z-score',
            'Last_pregnancy_interval_years'
        ]
        
        for field in multiparous_fields:
            value: Any = row.get(field)
            if pd.isna(value) or value == '' or value is None:
                missing_fields.append(field)
    
    if missing_fields:
        raise ValueError(f"Missing values in Case {case_no}: {', '.join(missing_fields)}")
    
    # Parse and return validated data
    try:
        data = {
            'case_no': case_no,
            'race': str(row['Race']).strip().lower(),
            'smoking': str(row['Smoking']).strip().lower(),
            'conception': str(row['Conception']).strip().lower(),
            'chronic_hypertension': str(row['Chronic_hypertension']).strip().lower(),
            'diabetes': str(row['Diabetes_mellitus']).strip().lower(),
            'sle_aps': str(row['SLE_APS']).strip().lower(),
            'parity': parity_val,
            'is_parous': is_parous,
            'height': float(row['Height']),
            'weight': float(row['Weight']),
            'efw_z_score': float(row['EFW_z-score']),
            'utapi_mom': float(row['Uterine_artery_PI_MOM'])
        }
        
        # Add multiparous-specific data
        if is_parous:
            data.update({
                'prev_preeclampsia': str(row['Previous_pregnancy_preeclampsia']).strip().lower(),
                'prev_stillbirth': str(row['Previous_stillbirth']).strip().lower(),
                'ga_last': float(row['Previous_last_birth_gestational_age']),
                'bw_zscore_last': float(row['Previous_birthweight_z-score']),
                'interp_interval': max(float(row['Last_pregnancy_interval_years']), 0.75)
            })
        
        return data

    except (ValueError, TypeError) as e:
        raise ValueError(f"Invalid data format in Case {case_no}: {str(e)}")

def compute_prior_means(data: dict[str, Any]) -> tuple[float, float]: #optimized
    """
    Optimized computation of prior means using vectorized operations where possible.
    """
    # Encode categorical variables

    black = 1 if data['race'] == 'black' else 0
    south_asian = 1 if data['race'] == 'south asian' else 0
    mixed = 1 if data['race'] == 'mixed' else 0
    
    smoking = 1 if data['smoking'] in ['reports', 'smoker', 'yes', 'da'] else 0
    ivf = 1 if 'ivf' in data['conception'] else 0
    chronic_hypertension = 1 if data['chronic_hypertension'] in ['has', 'yes', 'da'] else 0
    diabetes = 1 if data['diabetes'] in ['has', 'yes', 'da'] else 0
    sle_aps = 1 if data['sle_aps'] in ['reports', 'yes', 'da'] else 0
    parous = 1 if data['is_parous'] else 0
    
    # Center continuous variables
    height_centered = data['height'] - 165
    weight_centered = data['weight'] - 69
    weight_squared = weight_centered ** 2
    
    # Handle parous-specific variables
    if data['is_parous']:
        previous_preeclampsia = 1 if data['prev_preeclampsia'] in ['had', 'yes', 'da'] else 0
        previous_stillbirth = 1 if data['prev_stillbirth'] in ['had', 'yes', 'da'] else 0
        ga_last_centered = data['ga_last'] - 40
        ga_last_centered_sq = ga_last_centered ** 2
        bw_zscore_last = data['bw_zscore_last']
        interpregnancy_inv = 1.0 / data['interp_interval']
        interpregnancy_sqrt = 1.0 / np.sqrt(data['interp_interval'])
    else:
        previous_preeclampsia = previous_stillbirth = 0
        ga_last_centered = ga_last_centered_sq = bw_zscore_last = 0
        interpregnancy_inv = interpregnancy_sqrt = 0
    
    # Calculate birth-weight Z-score mean using dot product for efficiency
    bw_features = np.array([
        1, black, south_asian, mixed, height_centered, weight_centered,
        weight_squared, ivf, smoking, chronic_hypertension, sle_aps,
        parous, ga_last_centered, bw_zscore_last, interpregnancy_inv, interpregnancy_sqrt
    ])
    
    bw_coeffs = np.array([
        BW_PARAMS['intercept'], BW_PARAMS['black'], BW_PARAMS['south_asian'],
        BW_PARAMS['mixed'], BW_PARAMS['height_centered'], BW_PARAMS['weight_centered'],
        BW_PARAMS['weight_squared'], BW_PARAMS['ivf'], BW_PARAMS['smoker'],
        BW_PARAMS['chronic_hypertension'], BW_PARAMS['sle_aps'], BW_PARAMS['parous'],
        BW_PARAMS['ga_last_pregnancy'], BW_PARAMS['bw_zscore_last'],
        BW_PARAMS['interpregnancy_inv'], BW_PARAMS['interpregnancy_sqrt']
    ])
    
    bw_mu = np.dot(bw_features, bw_coeffs)
    
    # Calculate gestational age mean
    ga_features = np.array([
        1, bw_mu, weight_centered, ivf, chronic_hypertension, diabetes,
        previous_preeclampsia, previous_stillbirth, parous, ga_last_centered, ga_last_centered_sq
    ])
    
    ga_coeffs = np.array([
        GA_PARAMS['intercept'], GA_PARAMS['mean_bw_zscore'], GA_PARAMS['weight_centered'],
        GA_PARAMS['ivf'], GA_PARAMS['chronic_hypertension'], GA_PARAMS['diabetes'],
        GA_PARAMS['previous_preeclampsia'], GA_PARAMS['previous_stillbirth'],
        GA_PARAMS['parous'], GA_PARAMS['ga_last_pregnancy'], GA_PARAMS['ga_last_pregnancy_sq']
    ])
    
    ga_mu = np.dot(ga_features, ga_coeffs)
    
    return bw_mu, ga_mu

def format_inv(p):
    return "∞" if p <= 0 else f"{1.0/p:,.0f}"

def trapz2(f):
    int_z = np.trapezoid(f, BW_Z_GRID, axis=0)
    return float(np.trapezoid(int_z, GA_GRID, axis=0))

def compute_single_case_risk(data: dict[str, Any]) -> tuple[str, float, float, float, float, float]:
    """
    Compute SGA risk for a single case.
    Returns (case_no, bw_mu, ga_mu, prior_risk_probability, posterior_efw_probability, posterior_risk_probability).
    """
    try:
        # Step 1: Compute prior means
        bw_mu, ga_mu = compute_prior_means(data)
        # Step 2: Create prior covariance matrix
        prior_cov = np.array([
            [BW_PARAMS['sd_bw']**2, BW_Z_GA_CORRELATION * BW_PARAMS['sd_bw'] * GA_PARAMS['sd_ga']],
            [BW_Z_GA_CORRELATION * BW_PARAMS['sd_bw'] * GA_PARAMS['sd_ga'], GA_PARAMS['sd_ga']**2]
        ])
        # =============================
        # Compute PRIOR risk
        # =============================
        ZZ, GG = np.meshgrid(BW_Z_GRID, GA_GRID, indexing='ij')
        # SciPy accepts an ndarray covariance; cast only works around incomplete type hints.
        mvn = multivariate_normal(mean=[bw_mu, ga_mu], cov=cast(Any, prior_cov), allow_singular=False)
        pos = np.dstack((ZZ, GG))
        pdf = mvn.pdf(pos)

        prior = pdf / trapz2(pdf)  # normalized on the wide grid        
        
        Z_mask = BW_Z_GRID[:, None] <= BW_Z_P10
        G_mask = GA_GRID[None, :]  < GA_CUT
        REGION = Z_mask & G_mask

        prior_risk = trapz2(np.where(REGION, prior, 0.0))

        # =============================
        # Compute POSTERIOR (+EFW) univariate risk
        # =============================
        g_m40 = GG - 40.0
        mu_efw = EFW_PARAMS['beta0'] + (EFW_PARAMS['beta1'] + EFW_PARAMS['beta2']*g_m40) * ZZ
        sd_efw = EFW_PARAMS['sd_efw']
        res_efw = data['efw_z_score'] - mu_efw # Residuals

        like_efw = (1.0/(np.sqrt(2*np.pi)*sd_efw)) * np.exp(-0.5*(res_efw/sd_efw)**2)
        
        post_efw_unn = prior * like_efw
        post_efw_norm = trapz2(post_efw_unn)
        risk_history_efw = trapz2(np.where(REGION, post_efw_unn, 0.0)) / post_efw_norm

        # =============================
        # Compute POSTERIOR (EFW+UtA PI) risk
        # =============================
        # Observed biomarkers
        log10_uta_pi_mom = np.log10(data['utapi_mom'])
        mu_utapi = (UTAPI_PARAMS['intercept'] +
                UTAPI_PARAMS['bw_zscore'] * ZZ +
                UTAPI_PARAMS['ga_minus_40'] * g_m40 +
                UTAPI_PARAMS['ga_minus_40_sq'] * (g_m40**2))
        mu_utapi = np.maximum(mu_utapi, 0.0) # floor0
        #sd_utapi = UTAPI_PARAMS['sd_utapi']
        res_utapi = log10_uta_pi_mom - mu_utapi # Residuals

        # Compute likelihood using vectorized operations
        var_efw = EFW_PARAMS['sd_efw']**2
        var_utapi = UTAPI_PARAMS['sd_utapi']**2
        cov_efw_utapi = EFW_UTAPI_CORRELATION * EFW_PARAMS['sd_efw'] * UTAPI_PARAMS['sd_utapi']
        det_cov = var_efw * var_utapi - cov_efw_utapi**2
        inv_det = 1.0 / det_cov
        
        norm_const = 1.0 / (2 * np.pi * np.sqrt(det_cov))

        # Quadratic form
        quad_form = (var_utapi * res_efw**2 - 2 * cov_efw_utapi * res_efw * res_utapi + 
                 var_efw * res_utapi**2) * inv_det
        # Likelihood
        like_biomarkers = norm_const * np.exp(-0.5 * quad_form)

        posterior_unnorm = prior * like_biomarkers
        posterior_norm = trapz2(posterior_unnorm)
        risk_history_biomarkers = trapz2(np.where(REGION, posterior_unnorm, 0.0)) / posterior_norm

        return data['case_no'], bw_mu, ga_mu, prior_risk, risk_history_efw, risk_history_biomarkers

    except Exception as e:
        raise RuntimeError(f"Error processing case {data['case_no']}: {str(e)}")

def process_cases_parallel(
    df: pd.DataFrame, n_processes: Optional[int] = None
) -> tuple[list[str], list[float], list[float], list[float], list[float], list[float]]:
    if n_processes is None:
        n_processes = min(cpu_count(), len(df))

    print(f"Using {n_processes} processes for computation...")

    case_data = []
    for idx, row in df.iterrows():
        case_no: Any = row.get('Case_no', f'Index_{idx}')
        try:
            data = validate_input_data(row, case_no)
            case_data.append(data)
        except ValueError as e:
            print(f"ERROR: {e}")
            sys.exit(1)

    start_time = time.time()
    with Pool(processes=n_processes) as pool:
        results = pool.map(compute_single_case_risk, case_data)
    end_time = time.time()
    print(f"Computation completed in {end_time - start_time:.2f} seconds")

    case_nos, bw_mus, ga_mus, prior_risks, post_efw_risks, post_risks = zip(*results)
    return list(case_nos), list(bw_mus), list(ga_mus), list(prior_risks), list(post_efw_risks), list(post_risks)

def main():
    # File selection
    file_path = filedialog.askopenfilename(
        initialdir=directory_path,
        title="Select an Excel File",
        filetypes=[("Excel files", "*.xlsx")]
    )
    
    if not file_path:
        print("No file selected.")
        sys.exit(0)
    
    print(f"Selected file: {file_path}")

    # Load data
    try:
        df = pd.read_excel(file_path, sheet_name=0, header=0)
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        sys.exit(1)

    print(f"Loaded {len(df)} cases from {file_path}")
    print(f"Available CPUs: {cpu_count()}")

    case_nos, bw_mus, ga_mus, prior_risks, post_efw_risks, post_risks = process_cases_parallel(df)

    # Add results to dataframe
    df['BW_mu_prior'] = bw_mus
    df['GA_mu_prior'] = ga_mus
    df['Risk_prior'] = prior_risks
    df['Risk_post_efw'] = post_efw_risks
    df['Risk_post'] = post_risks
    
    # Save results as a new file in the same folder
    base, ext = os.path.splitext(file_path)
    new_path = f"{base}_with_prior_posterior_risk{ext}"

    try:
        df.to_excel(new_path, index=False)
        print(f"✅ Results saved to: {new_path}")
    except Exception as e:
        print(f"❌ Error saving results: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()