# -*- coding: utf-8 -*-
"""Supplementary Material S5: LIME-inspired coefficients, agreement with FMF and figures.

Manuscript: "Preterm Small-for-Gestational-Age Risk Estimates from Large Language Models versus the FMF Competing-Risks Model".
Author: Dragos Nemescu. Copyright (c) 2026 Dragos Nemescu. All rights reserved.
Reuse should cite the associated manuscript and acknowledge the author.

Input: Supplementary Table S1 (.xlsx): Patient_no, the 16 scenario columns and one probability
column per model (FMF from Supplementary Material S4, and the eight LLM systems).

1. Coefficients - LIME-inspired weighted linear surrogate (Ribeiro et al. 2016, Eq. 2) fitted to
   logit-transformed probabilities of all 108 scenarios, without feature selection. Continuous
   changes from the reference (Patient_no = 1) are divided by their SD; categories are contrasts
   to the reference category; kernel width = 0.75 * sqrt(16) = 3.0 on the scaled distances.
   Previous-pregnancy fields of nulliparous rows are recoded to the multiparous reference values.
   Local fidelity of each surrogate is reported as weighted R2.
2. Table 1 - Pearson r, Spearman rho, directional concordance, cosine similarity, NRMSE similarity,
   top-eight overlap and composite score = 0.30 direction + 0.30 Spearman + 0.25 cosine
   + 0.15 NRMSE similarity (negative Spearman/cosine set to 0). Coefficients are rounded to 10
   decimals first, so that identical LLM outputs are ranked as ties.
   Sensitivity: composite under alternative weights and kernel widths (0.5, 1.0, 2.0 x sqrt(16));
   directional concordance with |coefficient| < 0.10 treated as null.
3. Absolute agreement with FMF on the logit scale: reference and maximum probability,
   distinct values, Pearson r, mean absolute log-odds difference, calibration intercept and slope
   (logit FMF regressed on logit model) and Bland-Altman bias with 95% limits of agreement.
4. Figures - coefficient heat map, radar chart, composite-score bar charts (vertical, horizontal,
   weighted components), coefficient scatterplots, Bland-Altman plots and response curves
   (PNG, 300 dpi; Palatino font).
Outputs are saved next to the input file. Requires numpy, pandas, scipy, matplotlib, openpyxl.
Run with no argument to choose the input file in a window.
"""
import argparse
import sys
from pathlib import Path
from typing import Any
import warnings

import numpy as np
import pandas as pd

BASE_FOLDER = Path("write your path here")
PATIENT_START, PATIENT_END = 2, 109
FEATURE_COLUMNS = None          # None: columns 2-17; otherwise list exact headers.
CATEGORICAL_COLUMNS = set()      # Add any INTEGER-CODED nominal feature headers.
MODEL_COLUMNS = None            # None: detect names below; or list exact headers.
INCLUDE_BASE = True
IMPUTE_MISSING_WITH_BASE = False  # Enable only when justified by scenario design.
KERNEL_MULTIPLIER, EPSILON = 0.75, 1e-10
LAST_FIDELITY = {}
MODEL_NAMES = ("fmf", "gpt6", "claude", "deepseek", "mistral",
               "copilot", "meta", "grok", "qwen")
NULLIPAROUS_PLACEHOLDER_COLUMNS = ("Previous_pregnancy_preeclampsia", "Previous_stillbirth",
                                   "Last_pregnancy_interval_years", "Previous_last_birth_gestational_age",
                                   "Previous_birthweight_z-score")


def apply_surrogate_coding(df):
    """Recode previous-pregnancy fields of nulliparous rows to the multiparous reference values.
    Surrogate coding only; the nulliparity indicator then carries the parity contrast."""
    df = df.copy()
    if "Parity" not in df or "Patient_no" not in df:
        return df
    nulli = df["Parity"].astype(str).str.strip().str.lower().eq("nullipara")
    base = df.loc[pd.to_numeric(df["Patient_no"], errors="coerce") == 1]
    if base.empty:
        return df
    for col in NULLIPAROUS_PLACEHOLDER_COLUMNS:
        if col in df:
            df[col] = df[col].astype(object)
            df.loc[nulli, col] = base.iloc[0][col]
    return df


def category(value):
    if isinstance(value, (bool, int, float, np.number)):
        if not np.isfinite(value):
            raise ValueError("Categorical values must be finite.")
        return format(float(value), ".15g")
    return str(value).strip()


def predictor_table(df):
    """Return one coefficient column per model; unestimable values stay blank."""
    if not df.columns.is_unique or "Patient_no" not in df:
        raise ValueError("Unique headers and a Patient_no column are required.")
    ids = pd.to_numeric(df["Patient_no"], errors="raise").to_numpy(float)
    if not np.isfinite(ids).all() or np.any(ids != np.floor(ids)) or len(set(ids)) != len(ids):
        raise ValueError("Patient_no values must be unique finite integers.")
    if np.sum(ids == 1) != 1:
        raise ValueError("Exactly one baseline row (Patient_no = 1) is required.")
    base = df.loc[ids == 1].iloc[0]
    perturbations = df.loc[(ids >= PATIENT_START) & (ids <= PATIENT_END) & (ids != 1)]
    if perturbations.empty:
        raise ValueError("No perturbation rows in the configured Patient_no interval.")
    fit = pd.concat([df.loc[ids == 1], perturbations], ignore_index=True) if INCLUDE_BASE else perturbations.copy()
    features = list(FEATURE_COLUMNS) if FEATURE_COLUMNS is not None else list(df.columns[1:17])
    if FEATURE_COLUMNS is None and len(features) != 16:
        raise ValueError("Expected 16 feature columns after Patient_no; set FEATURE_COLUMNS for another layout.")
    if (not features or len(set(features)) != len(features) or "Patient_no" in features
            or any(c not in df for c in features) or not CATEGORICAL_COLUMNS <= set(features)):
        raise ValueError("Check FEATURE_COLUMNS and CATEGORICAL_COLUMNS.")
    x = fit[features].copy()
    if base[features].isna().any():
        raise ValueError("Baseline feature values must be complete.")
    if x.isna().any().any():
        if not IMPUTE_MISSING_WITH_BASE:
            raise ValueError("Missing features: resolve them or explicitly enable baseline imputation.")
        warnings.warn("Missing features were filled with baseline values.")
        x = x.fillna(base[features])

    names, columns, distance2, n_varying = [], [], np.zeros(len(fit)), 0
    for col in features:
        numeric = pd.to_numeric(x[col], errors="coerce")
        base_numeric = pd.to_numeric(pd.Series([base[col]]), errors="coerce").iloc[0]
        is_numeric = numeric.notna().all() and pd.notna(base_numeric)
        is_binary = is_numeric and set(numeric.tolist() + [base_numeric]) <= {0, 1}
        if col not in CATEGORICAL_COLUMNS and is_numeric and not is_binary:
            values, reference = numeric.to_numpy(float), float(base_numeric)
            if not np.isfinite(values).all() or not np.isfinite(reference):
                raise ValueError(f"{col}: continuous values must be finite.")
            sd = values.std(ddof=0)
            delta = (values - reference) / (sd if sd > 0 else 1.0)
            names.append(f"{col} [per SD]")
            columns.append(delta)
            distance2 += delta ** 2
            n_varying += int(np.any(np.abs(delta) > 1e-10))
        else:
            source = numeric if is_binary and col not in CATEGORICAL_COLUMNS else x[col]
            values = source.map(category).to_numpy()
            reference = category(base_numeric if is_binary and col not in CATEGORICAL_COLUMNS else base[col])
            levels = sorted(set(values) | {reference})
            alternatives = [level for level in levels if level != reference]
            for level in alternatives:
                names.append(f"{col}: {level} vs {reference}")
                columns.append((values == level).astype(float))
            if not alternatives:
                names.append(f"{col} [no observed alternative]")
                columns.append(np.zeros(len(fit)))
            distance2 += (values != reference).astype(float)
            n_varying += int(np.any(values != reference))
    if len(set(names)) != len(names):
        raise ValueError("Encoded predictor names collide; rename the input features.")
    design = np.column_stack(columns)
    active = np.any(np.abs(design) > 1e-10, axis=0)
    if KERNEL_MULTIPLIER <= 0 or not 0 < EPSILON < .5:
        raise ValueError("Kernel multiplier must be positive and 0 < EPSILON < 0.5.")
    weights = np.exp(-distance2 / (KERNEL_MULTIPLIER ** 2 * max(1, n_varying)))
    if not np.isfinite(weights).all() or weights.sum() <= 0:
        raise ValueError("Invalid proximity weights; check feature values and scaling.")
    augmented = np.column_stack([np.ones(len(fit)), design[:, active]])
    weighted_design = augmented * np.sqrt(weights[:, None])

    models = list(MODEL_COLUMNS) if MODEL_COLUMNS is not None else [
        c for c in df.columns if c not in features and c != "Patient_no"
        and "logit" not in str(c).lower() and any(m in str(c).lower() for m in MODEL_NAMES)]
    if (not models or len(set(models)) != len(models) or "Predictor" in models
            or any(c not in df or c in features or c == "Patient_no" for c in models)):
        raise ValueError("No valid model columns; check MODEL_COLUMNS and probability headers.")
    output = pd.DataFrame({"Predictor": names})
    complete, targets = [], []
    for model in models:
        output[model] = np.nan
        if fit[model].isna().any():
            warnings.warn(f"{model}: missing probabilities; its output column is blank.")
            continue
        p = pd.to_numeric(fit[model], errors="raise").to_numpy(float)
        if not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
            raise ValueError(f"{model}: probabilities must be finite fractions in [0,1].")
        clipped = np.clip(p, EPSILON, 1 - EPSILON)
        if np.any(clipped != p):
            warnings.warn(f"{model}: {np.sum(clipped != p)} probabilities clipped for the logit transform.")
        complete.append(model)
        targets.append(np.log(clipped) - np.log1p(-clipped))
    if not complete:
        raise ValueError("No model has complete probability values.")
    coefficients, _, rank, _ = np.linalg.lstsq(
        weighted_design, np.column_stack(targets) * np.sqrt(weights[:, None]), rcond=None)
    if rank < augmented.shape[1]:
        raise ValueError("Weighted design is rank deficient: coefficients are not uniquely identifiable. "
                         "Check dependent features and scenario coverage.")
    output.loc[active, complete] = coefficients[1:, :]
    y = np.column_stack(targets)
    fitted = augmented @ coefficients
    LAST_FIDELITY.clear()
    for j, model in enumerate(complete):            # weighted R2 of each surrogate (local fidelity)
        ybar = np.sum(weights * y[:, j]) / weights.sum()
        LAST_FIDELITY[model] = 1 - np.sum(weights * (y[:, j] - fitted[:, j]) ** 2) / np.sum(weights * (y[:, j] - ybar) ** 2)
    LAST_FIDELITY["_ess"] = weights.sum() ** 2 / np.sum(weights ** 2)
    return output  # full precision; invariant predictors and skipped models are NaN


# =============================================================================
# 2. AGREEMENT WITH FMF (Table 1): composite alignment score
# =============================================================================
WEIGHTS = {"directionality": 0.30, "spearman": 0.30, "cosine": 0.25, "nrmse_similarity": 0.15}
TOP_OVERLAP_K = 8
EPS_FMF = 1e-6            # FMF effects with |coefficient| <= EPS_FMF are not used for directionality
TOLERANCE = 0.10          # |coefficient| below this value is treated as a null effect (sensitivity)
TIE_DECIMALS = 10         # identical LLM outputs give identical coefficients: rank them as ties

DISPLAY = {"fmf": "FMF", "gpt6": "GPT-6", "gpt-6": "GPT-6", "claude": "Claude", "deepseek": "DeepSeek",
           "mistral": "Mistral", "copilot": "Copilot", "meta": "Meta", "grok": "Grok", "qwen": "Qwen"}
COLORS = {"GPT-6": "#ff7f0e", "Claude": "#1f77b4", "DeepSeek": "#2ca02c", "Mistral": "#e377c2",
          "Copilot": "#9467bd", "Meta": "#8c564b", "Grok": "#7f7f7f", "Qwen": "#d62728"}
PREDICTOR_LABELS = [  # (prefix of the S5 predictor name, label used in tables and figures)
    ("Height", "Maternal height"), ("Weight", "Maternal weight"),
    ("Race: Black", "Black race"), ("Race: East Asian", "East Asian race"), ("Race: Mixed", "Mixed race"),
    ("Race: South Asian", "South Asian race"), ("Smoking", "Smoking"), ("Conception", "IVF conception"),
    ("Chronic_hypertension", "Chronic hypertension"), ("Diabetes_mellitus", "Diabetes mellitus"),
    ("SLE_APS", "SLE/APS"), ("Parity", "Nulliparity"), ("Previous_pregnancy_preeclampsia", "Previous PE"),
    ("Previous_stillbirth", "Previous stillbirth"), ("Last_pregnancy_interval_years", "Interpregnancy interval"),
    ("Previous_last_birth_gestational_age", "GA at previous delivery"),
    ("Previous_birthweight_z-score", "Previous BW Z-score"), ("EFW_z-score", "EFW Z-score"),
    ("Uterine_artery_PI_MOM", "UtA-PI MoM")]


def display_name(column):
    key = str(column).strip().lower()
    for prefix, name in DISPLAY.items():
        if key.startswith(prefix):
            return name
    return str(column)


def predictor_label(name):
    for prefix, label in PREDICTOR_LABELS:
        if str(name).startswith(prefix):
            return label
    return str(name)


def tidy_coefficients(table):
    """Coefficient table with readable predictor labels and model display names."""
    coef = table.set_index("Predictor")
    coef.index = [predictor_label(n) for n in coef.index]
    coef.columns = [display_name(c) for c in coef.columns]
    return coef.astype(float)


def pearson_r(x, y) -> float:
    """Pearson correlation (typed as Any: Pylance does not know scipy's result attributes)."""
    from scipy.stats import pearsonr
    result: Any = pearsonr(x, y)
    return float(result.statistic)


def spearman_rho(x, y) -> float:
    """Spearman correlation (typed as Any for the same reason)."""
    from scipy.stats import spearmanr
    result: Any = spearmanr(x, y)
    return float(result.statistic)


def top_set(values):
    """The eight largest absolute coefficients. When several coefficients are tied at the eighth
    position (Copilot: five), none of the tied ones is counted, so the result never depends on
    arbitrary ordering (it would otherwise vary between computers)."""
    a = values.abs().round(TIE_DECIMALS)
    cutoff = a.nlargest(TOP_OVERLAP_K).iloc[-1]
    if int((a >= cutoff).sum()) > TOP_OVERLAP_K:
        return set(a[a > cutoff].index)
    return set(a[a >= cutoff].index)


def alignment_table(coef):
    """Directionality, Spearman, cosine, NRMSE similarity, Pearson, top-8 overlap and composite score."""
    c = coef.round(TIE_DECIMALS)
    fmf = c["FMF"].to_numpy()
    meaningful = np.abs(fmf) > EPS_FMF
    fmf_top = top_set(coef["FMF"])
    rows = []
    for model in [m for m in c.columns if m != "FMF"]:
        x = c[model].to_numpy()
        direction = float(np.mean(np.sign(fmf[meaningful]) == np.sign(x[meaningful])))
        three = lambda v: np.where(np.abs(v) < TOLERANCE, 0, np.sign(v))   # negative / null / positive
        direction_tol = float(np.mean(three(fmf) == three(x)))
        spearman = spearman_rho(fmf, x)
        pearson = pearson_r(fmf, x)
        cosine = float(fmf @ x / (np.linalg.norm(fmf) * np.linalg.norm(x)))
        nrmse = float(np.sqrt(np.mean((x - fmf) ** 2)) / np.ptp(fmf))
        nrmse_sim = 1.0 / (1.0 + nrmse)
        top8 = len(fmf_top & top_set(coef[model])) / TOP_OVERLAP_K
        composite = (WEIGHTS["directionality"] * direction + WEIGHTS["spearman"] * max(spearman, 0.0)
                     + WEIGHTS["cosine"] * max(cosine, 0.0) + WEIGHTS["nrmse_similarity"] * nrmse_sim)
        slope, intercept = np.polyfit(fmf, x, 1)
        rows.append({"Model": model, "Pearson r": pearson, "Spearman rho": spearman,
                     "Directional concordance": direction, "Cosine similarity": cosine,
                     "NRMSE similarity": nrmse_sim, "Top-eight overlap": top8, "Composite score": composite,
                     "NRMSE": nrmse, "Regression slope": slope, "Regression intercept": intercept,
                     "R2": pearson ** 2, "Directional concordance (tolerance 0.10)": direction_tol})
    return pd.DataFrame(rows).set_index("Model").sort_index(key=lambda s: s.str.lower())


ALTERNATIVE_WEIGHTS = {
    "Manuscript 0.30/0.30/0.25/0.15": (0.30, 0.30, 0.25, 0.15),
    "Equal 0.25 each": (0.25, 0.25, 0.25, 0.25),
    "Direction-led 0.40/0.20/0.20/0.20": (0.40, 0.20, 0.20, 0.20),
    "Rank-led 0.20/0.40/0.20/0.20": (0.20, 0.40, 0.20, 0.20),
    "Magnitude-led 0.15/0.25/0.25/0.35": (0.15, 0.25, 0.25, 0.35)}


def sensitivity_table(df, table1):
    """Composite score under alternative weights, and with other kernel widths of the surrogate."""
    global WEIGHTS, KERNEL_MULTIPLIER
    saved_w, saved_k = dict(WEIGHTS), KERNEL_MULTIPLIER
    rows = {}
    for label, w in ALTERNATIVE_WEIGHTS.items():
        rows[f"Weights: {label}"] = (w[0] * table1["Directional concordance"] + w[1] * table1["Spearman rho"].clip(lower=0)
                                     + w[2] * table1["Cosine similarity"].clip(lower=0) + w[3] * table1["NRMSE similarity"])
    for k in (0.5, 1.0, 2.0):
        KERNEL_MULTIPLIER = k
        rows[f"Kernel multiplier {k} (width {k * 4:.1f})"] = alignment_table(
            tidy_coefficients(predictor_table(apply_surrogate_coding(df))))["Composite score"]
    WEIGHTS, KERNEL_MULTIPLIER = saved_w, saved_k
    predictor_table(apply_surrogate_coding(df))      # restore the fidelity of the main fit
    out = pd.DataFrame(rows).T
    return out[table1.sort_values("Composite score", ascending=False).index]


# =============================================================================
# 3. ABSOLUTE AGREEMENT WITH FMF, on the logit scale
# =============================================================================
def logit(p):
    p = np.clip(np.asarray(p, float), EPSILON, 1 - EPSILON)
    return np.log(p) - np.log1p(-p)


def absolute_agreement(df, model_columns, fmf_column):
    y = logit(df[fmf_column])
    ref = df.loc[pd.to_numeric(df["Patient_no"]) == 1].iloc[0]
    rows = [{"Model": "FMF", "Reference (%)": 100 * ref[fmf_column], "Maximum (%)": 100 * df[fmf_column].max(),
             "Distinct values": df[fmf_column].nunique()}]
    for col in model_columns:
        x = logit(df[col]); d = x - y
        slope, intercept = np.polyfit(x, y, 1)          # logit(FMF) regressed on logit(model)
        sd = d.std(ddof=1)
        rows.append({"Model": display_name(col), "Reference (%)": 100 * ref[col],
                     "Maximum (%)": 100 * df[col].max(), "Distinct values": df[col].nunique(),
                     "Pearson r (logit)": pearson_r(x, y),
                     "Mean abs. log-odds diff.": np.mean(np.abs(d)),
                     "Calib. intercept": intercept, "Calib. slope": slope,
                     "Bland-Altman bias": d.mean(), "LoA lower": d.mean() - 1.96 * sd,
                     "LoA upper": d.mean() + 1.96 * sd})
    out = pd.DataFrame(rows).set_index("Model")
    out["Bland-Altman bias (95% LoA)"] = [
        "" if pd.isna(b) else f"{b:.3f} ({lo:.3f} to {hi:.3f})"
        for b, lo, hi in zip(out["Bland-Altman bias"], out["LoA lower"], out["LoA upper"])]
    return out


# =============================================================================
# 4. FIGURES
# =============================================================================
def _font():
    """Palatino, as in the original figures; TeX Gyre Pagella (a Palatino clone) if Palatino is absent."""
    import matplotlib.font_manager as fm
    names = {f.name for f in fm.fontManager.ttflist}
    if not names & {"Palatino Linotype", "Palatino", "Book Antiqua", "TeX Gyre Pagella"}:
        for path in fm.findSystemFonts(fontext="ttf"):   # "ttf" also lists .otf files
            if "pagella" in Path(path).name.lower():
                fm.fontManager.addfont(path)
        names = {f.name for f in fm.fontManager.ttflist}
    for f in ("Palatino Linotype", "Palatino", "Book Antiqua", "TeX Gyre Pagella", "DejaVu Serif"):
        if f in names:
            return f
    return "DejaVu Serif"


def _save(fig, path):
    fig.savefig(path.with_suffix(".png"), dpi=300, bbox_inches="tight", facecolor="white")


def figure_heatmap(coef, order, path):
    import matplotlib.pyplot as plt
    data = coef[["FMF"] + order].T
    lim = float(np.nanmax(np.abs(data.to_numpy())))
    fig, ax = plt.subplots(figsize=(20, 1.05 * len(data) + 4.6))
    im = ax.imshow(data.to_numpy(), cmap="RdBu_r", vmin=-lim, vmax=lim, aspect="auto")
    ax.set_xticks(range(data.shape[1]), data.columns, rotation=45, ha="right", fontsize=21)
    ax.set_yticks(range(data.shape[0]), data.index, fontsize=23)
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            v = data.iat[i, j]
            ax.text(j, i, f"{0.0 if abs(v) < 0.005 else v:.2f}", ha="center", va="center", fontsize=19,
                    color="white" if abs(v) > 0.6 * lim else "black")
    ax.set_xlabel("Encoded predictor", fontsize=24)
    ax.set_ylabel("Model", fontsize=24)
    cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.015)
    cb.ax.tick_params(labelsize=19)
    cb.set_label("Surrogate coefficient (log-odds)", fontsize=22)
    fig.tight_layout(); _save(fig, path); plt.close(fig)


def figure_radar(table, order, path):
    import matplotlib.pyplot as plt
    labels = ["Pearson\nCorrelation", "Directionality\nConcordance", "Cosine\nSimilarity",
              "NRMSE\nSimilarity", "Spearman Rank\nSimilarity", f"Top-{TOP_OVERLAP_K}\nOverlap"]
    cols = ["Pearson r", "Directional concordance", "Cosine similarity", "NRMSE similarity",
            "Spearman rho", "Top-eight overlap"]
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False)
    closed = np.concatenate([angles, angles[:1]])
    fig, ax = plt.subplots(figsize=(14, 11.5), subplot_kw={"projection": "polar"})
    ax.set_xticks(angles); ax.set_xticklabels(labels, fontsize=24); ax.tick_params(axis="x", pad=20)
    for lab, angle in zip(ax.get_xticklabels(), angles):           # keep labels outside the circle
        lab.set_horizontalalignment("left" if np.cos(angle) > 0.1 else "right" if np.cos(angle) < -0.1 else "center")
    ax.set_ylim(0, 1.05); ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels([])
    for r in (0.2, 0.4, 0.6, 0.8, 1.0):                           # scale numbers drawn on top of the lines
        ax.text(np.pi / 2, r, f"{r:.1f}", ha="center", va="center", fontsize=24, fontweight="bold", zorder=30,
                bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=1.5))
    for m in order:
        v = np.clip(table.loc[m, cols].to_numpy(float), 0, 1)     # negative values shown as 0
        v = np.concatenate([v, v[:1]])
        ax.plot(closed, v, color=COLORS.get(m), lw=2.4, marker="o", ms=8, label=m)
        ax.fill(closed, v, color=COLORS.get(m), alpha=0.08)
    ax.plot(closed, np.ones(len(closed)), color="0.30", lw=2.4, ls=(0, (5, 3)), label="FMF (reference)", zorder=10)
    ax.legend(loc="upper left", bbox_to_anchor=(1.16, 1.02), frameon=True, fontsize=21)
    fig.subplots_adjust(left=0.10, right=0.70, top=0.91, bottom=0.08)
    _save(fig, path); plt.close(fig)


def _format_correlation(value):
    """Truncate plot labels to three decimals without changing the statistics."""
    from decimal import Decimal, ROUND_DOWN
    return format(Decimal(str(value)).quantize(Decimal("0.001"), rounding=ROUND_DOWN), ".3f")


def figure_scatter(coef, order, path):
    import matplotlib.pyplot as plt
    x = coef["FMF"].to_numpy()
    allv = coef[["FMF"] + order].to_numpy().ravel()
    lo, hi = allv.min() - 0.08, allv.max() + 0.08
    fig, axes = plt.subplots(2, 4, figsize=(20, 11))
    for k, (ax, m) in enumerate(zip(axes.ravel(), order)):
        y = coef[m].to_numpy()
        r = pearson_r(x, y)
        slope, intercept = np.polyfit(x, y, 1)
        ax.axhline(0, color="lightgray", lw=1.5, zorder=0); ax.axvline(0, color="lightgray", lw=1.5, zorder=0)
        ax.plot([lo, hi], [lo, hi], ls="--", color="gray", lw=1.6, zorder=1)
        ax.plot([lo, hi], [slope * lo + intercept, slope * hi + intercept], color=COLORS.get(m), lw=2.2, alpha=0.85)
        ax.scatter(x, y, s=95, color=COLORS.get(m), alpha=0.75, edgecolor="white", lw=0.6, zorder=3)
        ax.text(0.04, 0.955, f"r = {_format_correlation(r)}\nR² = {_format_correlation(r * r)}", transform=ax.transAxes, va="top", fontsize=19,
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="black", lw=0.9))
        ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
        ax.set_title(m, fontsize=24, fontweight="bold")
        ax.tick_params(labelsize=18)
        if k >= 4:
            ax.set_xlabel("FMF coefficient", fontsize=21)
        if k % 4 == 0:
            ax.set_ylabel("LLM coefficient", fontsize=21)
    fig.tight_layout(); _save(fig, path); plt.close(fig)


BAR_FIGSIZE = (12.5, 7.5)
COMPOSITE_LABEL = "FMF–LLM Risk-Factor Alignment Score (0–1)"
COMPOSITE_TITLE = "Composite FMF–LLM Risk-Factor Alignment Scores"


def figure_composite_vertical(table, order, path):
    import matplotlib.pyplot as plt
    scores = table.loc[order, "Composite score"].to_numpy(float)
    fig, ax = plt.subplots(figsize=BAR_FIGSIZE)
    bars = ax.bar(np.arange(len(order)), scores, width=0.68, edgecolor="black", linewidth=0.6)
    for bar, score in zip(bars, scores):
        ax.text(bar.get_x() + bar.get_width() / 2, min(score + 0.015, 1.025), f"{score:.3f}",
                va="bottom", ha="center", fontsize=14, fontweight="bold")
    ax.set_xticks(np.arange(len(order)), order)
    ax.set_ylim(0.0, 1.07); ax.set_ylabel(COMPOSITE_LABEL); ax.set_xlabel("Large language model")
    ax.set_title(COMPOSITE_TITLE, pad=14)
    ax.yaxis.grid(True, alpha=0.25); ax.set_axisbelow(True)
    fig.subplots_adjust(left=0.10, right=0.98, top=0.88, bottom=0.14)
    _save(fig, path); plt.close(fig)


def figure_composite_horizontal(table, order, path):
    import matplotlib.pyplot as plt
    scores = table.loc[order, "Composite score"].to_numpy(float)
    y = np.arange(len(order))
    fig, ax = plt.subplots(figsize=BAR_FIGSIZE)
    bars = ax.barh(y, scores, height=0.68, edgecolor="black", linewidth=0.6)
    for bar, score in zip(bars, scores):
        ax.text(min(score + 0.012, 1.01), bar.get_y() + bar.get_height() / 2, f"{score:.3f}",
                va="center", ha="left", fontsize=14, fontweight="bold")
    ax.set_yticks(y, order); ax.invert_yaxis()
    ax.set_xlim(0.0, 1.07); ax.set_xlabel(COMPOSITE_LABEL)
    ax.set_title(COMPOSITE_TITLE, pad=14)
    ax.xaxis.grid(True, alpha=0.25); ax.set_axisbelow(True)
    fig.subplots_adjust(left=0.17, right=0.95, top=0.88, bottom=0.12)
    _save(fig, path); plt.close(fig)


def figure_composite_components(table, order, path):
    """Weighted contribution of each component to the composite score."""
    import matplotlib.pyplot as plt
    parts = [("Directional concordance", "directionality", "Directionality"),
             ("Spearman rho", "spearman", "Spearman"),
             ("Cosine similarity", "cosine", "Cosine"),
             ("NRMSE similarity", "nrmse_similarity", "NRMSE similarity")]
    y = np.arange(len(order)); left = np.zeros(len(order))
    colors = plt.rcParams["axes.prop_cycle"].by_key()["color"]
    fig, ax = plt.subplots(figsize=BAR_FIGSIZE)
    for k, (column, weight_key, label) in enumerate(parts):
        values = WEIGHTS[weight_key] * np.clip(table.loc[order, column].to_numpy(float), 0, 1)
        ax.barh(y, values, left=left, height=0.68, color=colors[k], edgecolor="white", linewidth=0.7,
                label=f"{label} ({WEIGHTS[weight_key]:.0%})")
        left += values
    for yy, total in zip(y, table.loc[order, "Composite score"].to_numpy(float)):
        ax.text(min(total + 0.012, 1.01), float(yy), f"{total:.3f}", va="center", ha="left", fontsize=14, fontweight="bold")
    ax.set_yticks(y, order); ax.invert_yaxis()
    ax.set_xlim(0.0, 1.07); ax.set_xlabel("Weighted contribution to the composite score")
    ax.set_title("FMF–LLM Risk-Factor Alignment Score:\nWeighted Component Decomposition", pad=14)
    ax.xaxis.grid(True, alpha=0.25); ax.set_axisbelow(True)
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.27), ncol=4, frameon=True, fontsize=12.5)
    fig.subplots_adjust(left=0.17, right=0.95, top=0.86, bottom=0.21)
    _save(fig, path); plt.close(fig)


def figure_bland_altman(df, columns, fmf_column, path):
    import matplotlib.pyplot as plt
    y = logit(df[fmf_column])
    fig, axes = plt.subplots(2, 4, figsize=(20, 10.5))
    for ax, col in zip(axes.ravel(), columns):
        m = display_name(col); x = logit(df[col]); d = x - y; avg = (x + y) / 2
        bias, sd = d.mean(), d.std(ddof=1)
        ax.scatter(avg, d, s=28, color=COLORS.get(m), alpha=0.75, edgecolor="white", lw=0.5)
        ax.axhline(0, color="lightgray", lw=1.5, zorder=0)
        ax.axhline(bias, color="black", lw=1.4)
        for v in (bias - 1.96 * sd, bias + 1.96 * sd):
            ax.axhline(v, color="black", lw=1.1, ls="--")
        ax.text(0.03, 0.96, f"bias = {bias:.3f}\nLoA {bias - 1.96 * sd:.3f} to {bias + 1.96 * sd:.3f}",
                transform=ax.transAxes, va="top", fontsize=13,
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="black", lw=0.8))
        ax.set_title(m, fontsize=17, fontweight="bold")
        ax.set_xlabel("Mean of logits (model, FMF)", fontsize=15); ax.set_ylabel("Logit(model) − logit(FMF)", fontsize=15)
    fig.suptitle("Bland–Altman Agreement of Absolute Risk Estimates with FMF (logit scale)", fontsize=21, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96)); _save(fig, path); plt.close(fig)


def figure_response_curves(df, columns, fmf_column, path):
    import matplotlib.pyplot as plt
    variables = ["Height", "Weight", "Last_pregnancy_interval_years", "Previous_last_birth_gestational_age",
                 "Previous_birthweight_z-score", "EFW_z-score", "Uterine_artery_PI_MOM"]
    features = list(df.columns[1:17])
    ref = df.loc[pd.to_numeric(df["Patient_no"]) == 1].iloc[0]
    multi = df[df["Parity"].astype(str).str.strip().str.lower().eq("multipara")]
    fig, axes = plt.subplots(2, 4, figsize=(20, 10.5))
    for ax, var in zip(axes.ravel(), variables):
        others = [c for c in features if c != var]
        rows = multi[(multi[others].astype(str) == ref[others].astype(str)).all(axis=1)].copy()
        rows["_v"] = pd.to_numeric(rows[var]); rows = rows.sort_values("_v")
        for col in [fmf_column] + columns:
            m = display_name(col)
            dy = logit(rows[col]) - logit([ref[col]])[0]
            ax.plot(rows["_v"], dy, marker="o", ms=3.5, lw=2.6 if m == "FMF" else 1.3,
                    color="black" if m == "FMF" else COLORS.get(m), label=m, zorder=5 if m == "FMF" else 3)
        ax.axhline(0, color="lightgray", lw=1.2, zorder=0)
        ax.set_title(predictor_label(var), fontsize=17, fontweight="bold")
        ax.set_xlabel("Value", fontsize=15); ax.set_ylabel("Δ logit vs reference", fontsize=15)
    last = axes.ravel()[-1]; last.axis("off")
    handles, labels = axes.ravel()[0].get_legend_handles_labels()
    last.legend(handles, labels, loc="center", fontsize=16, frameon=False)
    fig.suptitle("Response Curves for Continuous Predictors (multiparous scenarios)", fontsize=21, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96)); _save(fig, path); plt.close(fig)


# =============================================================================
# 5. RUN EVERYTHING
# =============================================================================
def select_input_file():
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    try:
        return filedialog.askopenfilename(
            parent=root, title="Select Supplementary Table S1 (.xlsx)",
            initialdir=str(BASE_FOLDER if BASE_FOLDER.is_dir() else Path.cwd()),
            filetypes=[("Excel workbooks", "*.xlsx")], defaultextension=".xlsx")
    finally:
        root.destroy()


def write_excel(path, sheets, decimals):
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for name, frame in sheets.items():
            frame.to_excel(writer, sheet_name=name)
            ws = writer.sheets[name]
            ws.column_dimensions["A"].width = 26
            for cells in list(ws.columns)[1:]:
                ws.column_dimensions[cells[0].column_letter].width = 16
                for cell in cells[1:]:
                    if isinstance(cell.value, float):
                        cell.number_format = "0." + "0" * decimals.get(name, 3)


def main(argv=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    parser = argparse.ArgumentParser(description="S5: coefficients, agreement tables and figures.")
    parser.add_argument("input", nargs="?", help="Supplementary Table S1 (.xlsx); omit to open the file picker.")
    args = parser.parse_args([a for a in (argv if argv is not None else sys.argv[1:]) if a.lower() != "input"])
    selected = args.input or select_input_file()
    if not selected:
        return 0
    source = Path(selected)
    if not source.exists():
        source = Path(__file__).resolve().parent / selected
    source = source.resolve()
    plt.rcParams.update({"font.family": _font(), "font.size": 14, "axes.titlesize": 20,
                         "axes.titleweight": "bold", "axes.labelsize": 15, "xtick.labelsize": 14,
                         "ytick.labelsize": 14, "legend.fontsize": 13})

    df = pd.read_excel(source, sheet_name=0)
    df = df.loc[:, [c for c in df.columns if not str(c).startswith("Unnamed")]]
    model_columns = [c for c in df.columns[17:] if any(m in str(c).lower() for m in MODEL_NAMES)
                     and "logit" not in str(c).lower() and "fmf" not in str(c).lower()]
    fmf_column = [c for c in df.columns[17:] if "fmf" in str(c).lower() and "logit" not in str(c).lower()][0]

    raw = predictor_table(apply_surrogate_coding(df))                    # 1. coefficients
    coef = tidy_coefficients(raw)
    fidelity = pd.Series({display_name(k): v for k, v in LAST_FIDELITY.items() if k != "_ess"},
                         name="Weighted R2 (surrogate fidelity)").to_frame()
    fidelity.loc["Effective sample size", fidelity.columns[0]] = LAST_FIDELITY["_ess"]
    table1 = alignment_table(coef)                                       # 2. Table 1
    sensitivity = sensitivity_table(df, table1)
    table2 = absolute_agreement(df, model_columns, fmf_column)           # 3. absolute agreement
    order = list(table1.sort_values("Composite score", ascending=False).index)

    stem = source.with_name(source.stem.replace(" ", "_"))
    out_xlsx = Path(f"{stem}_S5_results.xlsx")
    write_excel(out_xlsx, {
        "Coefficients": coef,
        "Table1_alignment": table1[["Pearson r", "Spearman rho", "Directional concordance", "Cosine similarity",
                                    "NRMSE similarity", "Top-eight overlap", "Composite score"]],
        "Table1_extra": table1[["Directional concordance (tolerance 0.10)", "NRMSE", "Regression slope",
                                "Regression intercept", "R2"]],
        "Fidelity": fidelity,
        "Sensitivity_composite": sensitivity,
        "Absolute_agreement": table2[["Reference (%)", "Maximum (%)", "Distinct values", "Pearson r (logit)",
                                   "Mean abs. log-odds diff.", "Calib. intercept", "Calib. slope",
                                   "Bland-Altman bias (95% LoA)"]],
    }, decimals={"Coefficients": 4, "Absolute_agreement": 3})

    figure_heatmap(coef, order, Path(f"{stem}_Fig_coefficients"))       # 4. figures
    figure_radar(table1, order, Path(f"{stem}_Fig_radar"))
    figure_composite_vertical(table1, order, Path(f"{stem}_Fig_composite_vertical"))
    figure_composite_horizontal(table1, order, Path(f"{stem}_Fig_composite_horizontal"))
    figure_composite_components(table1, order, Path(f"{stem}_Fig_composite_components"))
    figure_scatter(coef, order, Path(f"{stem}_Fig_scatterplots"))
    model_order_cols = sorted(model_columns, key=lambda c: order.index(display_name(c)))
    figure_bland_altman(df, model_order_cols, fmf_column, Path(f"{stem}_Fig_bland_altman"))
    figure_response_curves(df, model_order_cols, fmf_column, Path(f"{stem}_Fig_response_curves"))

    pd.set_option("display.width", 200)
    print("\nTable 1\n", table1.iloc[:, :7].round(3).to_string())
    print("\nAbsolute agreement\n", table2[["Reference (%)", "Maximum (%)", "Distinct values", "Pearson r (logit)",
                                  "Mean abs. log-odds diff.", "Calib. intercept", "Calib. slope",
                                  "Bland-Altman bias (95% LoA)"]].round(3).to_string())
    print(f"\nSaved: {out_xlsx}\nFigures: {stem.name}_Fig_*.png")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError) as error:
        raise SystemExit(f"ERROR: {error}")
