SUPPLEMENTARY MATERIALS FOR APPLIEDMATH SUBMISSION
Exact Beta-P Margins for Dependent Competing Risks: Partial Identification and Sensitivity Bounds

Supplementary File S1/ — Public bmtcrr data and descriptive clinical outputs, with a limited reproduction script.
Supplementary File S2/ — Source code, data, numerical fits, dependence profile, fixed-margin and refitted sensitivity calculations, clinical comparisons, independent numerical audit, and a 300-replicate complete-estimator validation on an explicitly constrained parameter space.

Read the included README and START_HERE documents before executing scripts.
The archives document numerical solutions and finite-sample validation. They do not certify unconstrained global optimality, confidence coverage at a boundary, or unverified Clayton claims.
No unpublished or personally identifiable patient-level data are introduced beyond the publicly distributed bmtcrr data.
