"""Reproduce Aalen-Johansen event-free survival and independent Beta-P predictions.
This does not reproduce Clayton refits or parametric-bootstrap simulations.
Run: python betap_clinical_reproduce.py bmtcrr.csv
"""
import sys
import numpy as np
import pandas as pd
p=sys.argv[1] if len(sys.argv)>1 else 'bmtcrr.csv'
d=pd.read_csv(p)
t=d['ftime'].to_numpy(float)
c=d['Status'].to_numpy(int)
a=np.array([0.025581357380310598,0.13958543077237426])
b=np.array([1.3790832594333793,1.7802044789261926])
th=np.array([6.866962326788793,1.8360113737053507])
for time in [3,6,9,12,18,24,36,48,60]:
 s=1.0
 for u in np.sort(np.unique(t[(c>0)&(t<=time)])):
  s*=1-np.sum((t==u)&(c>0))/np.sum(t>=u)
 sm=float(np.exp(-np.sum(a*np.log1p((time/b)**th))))
 print(f'{time:>3} months: AJ event-free={s:.6f}, independent Beta-P={sm:.6f}')
