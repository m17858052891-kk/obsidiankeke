# Optimization stability audit (supplementary diagnostic)

This folder records an expanded audit of the numerical profile and a deliberately exploratory full-estimator pilot. It is included to make optimizer limitations reproducible; the pilot is not presented as successful validation.

## Clinical profile audit

`robust_profile_boundaries.py` repeats the 25 fixed-δ profile values with 12 L-BFGS-B starts per candidate face and checks the interior plus exact κ₁=0, κ₂=0, and κ₁=κ₂=0 faces. `robust_profile_boundaries_reverse.py` repeats the continuation in reverse grid order. The six free log parameters are bounded by [-15, 8]; options are maxiter=2500, ftol=1e-13, gtol=1e-7, maxls=60, and maxcor=30. The scripts write the corresponding result CSVs.

The best recorded log-likelihood remained -561.21071984 at δ=0. The selected solutions' maximum absolute numerical-gradient component was 1.14e-4. Forward and reverse continuation agreed within 1e-4 at 23/25 values; two reverse-path fits fell into inferior local solutions. Across-start objective spreads remained large (up to 3264.47 in the selected-face starts), even though the best objective was recovered on the forward path. Exact κ₁=0 faces were selected at several positive δ values. These findings do not certify a global maximum.

## Full-estimator pilot

`full_estimator_profile_mc.py` simulates the complete shared-gamma model at n=177 and re-estimates all six marginal parameters over a δ profile grid, checking interior and exact boundary faces. The included pilot has only 10 replicates per scenario and is a diagnostic of instability, not a dependable operating-characteristic study. Its optimizer reports 100% nominal success flags, but across-start objective gaps were substantial and selected gradients were occasionally large. Estimates were variable and often selected δ=0 even under positive true dependence.

A start-count sensitivity run increased from three to ten starts on one replicate per scenario (`full_estimator_profile_mc_10start.py`). The selected δ values did not change, but large objective spreads persisted and one profile included invalid/overflowing candidate objectives. This does not remedy the full-estimator instability. The simulation must not be cited as proof of estimator reliability, calibrated tests, or confidence-interval coverage.

The pilot is disclosed rather than used as evidence that the reviewer’s full-model validation request has been satisfied. A reliable full-estimator Monte Carlo study remains outstanding unless the likelihood optimization is further stabilized or the claims are narrowed with the editor's agreement.
