from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import approx_fprime
P=Path(__file__).resolve().parent
D=pd.read_csv(P/'bmtcrr.csv'); t=D.ftime.to_numpy(); y=D.Status.to_numpy()
def nll(z,delta):
 a=delta+np.exp(z[:2]);b=np.exp(z[2:4]);q=np.exp(z[4:6]);h=(t[:,None]/b)**q;hp=q/b*(t[:,None]/b)**(q-1)
 s=-delta*np.log1p(h.sum(axis=1))-np.sum((a-delta)*np.log1p(h),axis=1)
 for j in (1,2):
  mask=y==j;v=h[mask];s[mask]+=np.log(hp[mask,j-1])+np.log((a[j-1]-delta)/(1+v[:,j-1])+delta/(1+v.sum(axis=1)))
 return -s.sum()
prof=pd.read_csv(P/'profile.csv'); rows=[]
for r in prof.itertuples():
 z=np.log([r.alpha1-r.delta,r.alpha2-r.delta,r.beta1,r.beta2,r.theta1,r.theta2]); calc=nll(z,r.delta)
 # gradient diagnostic in log parameter coordinates; finite difference is independent of optimizer implementation
 grad=approx_fprime(z,lambda x:nll(x,r.delta),1e-6)
 rows.append(dict(delta=r.delta,recorded_nll=r.nll,recomputed_nll=calc,absolute_difference=abs(calc-r.nll),gradient_norm=np.linalg.norm(grad),max_gradient=np.max(np.abs(grad)),converged=r.converged,start_spread_nll=r.range_nll))
out=pd.DataFrame(rows);out.to_csv(P/'independent_profile_checks.csv',index=False)
print('rows',len(out),'max objective difference',out.absolute_difference.max(),'max gradient norm',out.gradient_norm.max(),'median gradient norm',out.gradient_norm.median(),'max spread',out.start_spread_nll.max())
print(out[['delta','absolute_difference','gradient_norm','start_spread_nll']].to_string(index=False))
