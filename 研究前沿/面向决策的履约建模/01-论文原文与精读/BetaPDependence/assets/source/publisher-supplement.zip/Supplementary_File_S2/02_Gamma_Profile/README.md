# Step 2: Profile likelihood for the shared-Gamma dependence parameter

Dataset: `bmtcrr.csv` (177 records). Run `python profile.py` with Python 3, NumPy, pandas, and SciPy to regenerate `profile.csv`. The archived `profile_likelihood.png` is a supplied output; `profile.py` does not create the plot. The likelihood uses right-censored competing-risks observations, joint survival, and cause-specific subdensities.

The script evaluates 25 fixed values of absolute delta on [0, 0.20]: 0, 0.0025, 0.0050, 0.0075, 0.0100, 0.0125, 0.0150, 0.0175, 0.0200, 0.0225, 0.0242, 0.0275, 0.0300, 0.0325, 0.0350, 0.0375, 0.0400, 0.0450, 0.0500, 0.0750, 0.1000, 0.1250, 0.1500, 0.1750, and 0.2000. At delta=0 it uses four L-BFGS-B starts. At each positive grid point it uses five: two baseline starts, a warm start from the preceding grid solution, and two seeded normal perturbations (standard deviation 0.3) around the first baseline start. Seed: 20261017.

The parameterization is alpha_j = delta + exp(z_j), beta_j = exp(u_j), and theta_j = exp(v_j). Each of the six log parameters is bounded by [-15, 8]. L-BFGS-B options are maxiter=950, ftol=1e-11, and maxls=35. `profile.csv` records estimates, convergence flags, and objective ranges across starts. All 25 grid points have at least one converged run; this does not establish global optimality. The across-start negative-log-likelihood range is large (maximum about 532.45 at delta=0.2), demonstrating substantial start sensitivity.

**Findings and limits:** The best recorded log likelihood is -561.21071984 at delta=0, and no positive tested grid value improves it. This is a multi-start grid result, not proof of independence or a global maximum. The grid covers only [0,0.2], not the full feasible parameter space. The profile uses exp(z_j)>0 and does not evaluate exact kappa_j=0 boundaries as separate candidates. The conventional LR display is illustrative only; no calibrated confidence limit or p-value is claimed.

An expanded check of exact component boundaries, reverse continuation, and optimizer stability is supplied in `../09_Optimization_Stability/`. The original `profile.py` remains the baseline interior-profile reproduction script.
