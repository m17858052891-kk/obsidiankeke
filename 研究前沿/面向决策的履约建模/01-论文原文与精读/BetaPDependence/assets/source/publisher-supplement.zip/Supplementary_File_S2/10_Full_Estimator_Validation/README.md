# Complete-estimator validation

This directory records the reproducible investigation and validation of the complete seven-parameter profile-grid estimator. It distinguishes numerical optimization stability from statistical information at the clinical sample size.

## Why a compact parameter space is required

The initial unrestricted pilot revealed a nonregular likelihood path in some simulated samples: alpha approached zero while theta increased toward the numerical upper bound and the likelihood continued to improve. `likelihood_ridge_diagnostic.py` reproduces this behavior and writes `likelihood_ridge_diagnostic.csv`. Increasing the number of starts cannot remove such a likelihood ridge.

The validation estimator is therefore defined on a prespecified compact space. Positive free kappa components lie in [1e-4, 2], beta components in [0.10, 120], and theta components in [0.20, 20]. Exact kappa1=0, kappa2=0, and joint-zero faces are still evaluated. The generating values lie strictly inside the limits. The results apply to this explicitly constrained finite-grid estimator.

## Optimization and replication design

`full_estimator_validation.py` uses an analytic gradient verified against centered finite differences. At every positive delta grid point it refits all six nuisance parameters on the interior and three exact boundary faces. Each face receives two independent batches of 12 starts. If their best objectives differ by more than 1e-6, two additional independent 12-start batches are run. The selected solution is checked using the KKT projected gradient. The independent delta=0 model is fitted separately by the same batch-agreement principle.

The final run uses 100 Monte Carlo replicates at each of three true dependence settings, for 300 complete fits at n=177. Random seeds, package versions, optimizer settings, parameter limits, and the delta grid are stored in `final_100x3/full_estimator_validation_settings.json`. Replicate-level results and a scenario summary are stored as CSV files. `full_estimator_validation_checkpoint.csv` is a recoverable progress file and is not needed after successful completion.

The study assesses numerical reproducibility, finite-sample bias, RMSE, boundary selection, optimizer agreement, projected gradients, and parameter-limit contacts. It does not prove global optimality outside the stated compact space and does not establish confidence-region coverage.
