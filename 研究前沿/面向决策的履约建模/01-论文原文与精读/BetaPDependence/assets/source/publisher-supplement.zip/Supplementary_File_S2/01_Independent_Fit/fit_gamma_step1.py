import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
D=pd.read_csv(__import__('pathlib').Path(__file__).parent/'bmtcrr.csv');t=D.ftime.to_numpy(); y=D.Status.to_numpy();n=len(t)
# z=log alpha1 alpha2 beta1 beta2 theta1 theta2; fraction shared logistic(z6)
def likelihood(z,mode='dep'):
 try:
  a=np.exp(z[:2]);b=np.exp(z[2:4]);q=np.exp(z[4:6]);d=0 if mode=='ind' else min(a)*expit(z[6]);
  h=(t[:,None]/b)**q;hp=q/b*(t[:,None]/b)**(q-1)
  L=-d*np.log1p(h.sum(axis=1))-((a-d)*np.log1p(h)).sum(axis=1)
  for j in (1,2):
   ix=y==j
   L[ix]+=np.log(hp[ix,j-1])+np.log((a[j-1]-d)/(1+h[ix,j-1])+d/(1+h[ix].sum(axis=1)))
  return -L.sum() if np.isfinite(L).all() else 1e20
 except (FloatingPointError,ValueError,OverflowError):return 1e20
z0=np.log([.02558,.13959,1.37908,1.78020,6.86695,1.83601])
print('base',likelihood(z0,'ind'))
for mode in ['ind','dep']:
 results=[]
 for k in range(12 if mode=='dep' else 5):
  rng=np.random.default_rng(k+21)
  init=z0.copy() if k==0 else z0+rng.normal(0,.5,6)
  if mode=='dep':init=np.r_[init,(-3 if k==0 else rng.uniform(-5,3))]
  r=minimize(lambda z:likelihood(z,mode),init,method='L-BFGS-B',bounds=[(-12,8)]*6+([(-14,12)] if mode=='dep' else []),options={'maxiter':1400,'ftol':1e-12,'maxls':40})
  results.append(r)
  print(mode,k,round(r.fun,9),r.success,r.message,flush=True)
 best=min(results,key=lambda r:r.fun);z=best.x;a=np.exp(z[:2]);b=np.exp(z[2:4]);q=np.exp(z[4:6]);d=0 if mode=='ind' else min(a)*expit(z[6]);
 print('BEST',mode,'nll',best.fun,'alpha',a,'beta',b,'theta',q,'delta',d,'AIC',2*len(z)+2*best.fun,'BIC',np.log(n)*len(z)+2*best.fun,flush=True)
 np.savez(str(__import__('pathlib').Path(__file__).parent/('gamma_'+mode+'.npz')),z=z,nll=best.fun,success=best.success)
