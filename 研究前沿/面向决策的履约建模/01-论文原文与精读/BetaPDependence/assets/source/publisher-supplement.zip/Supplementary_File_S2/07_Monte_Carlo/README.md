# Monte Carlo validation of probability formulas

Run `python mc_probability_validation.py` with Python 3, NumPy, pandas, and SciPy.

The fixed seed is 20261104. The script generates 500,000 latent-time pairs for each of three shared-gamma shapes (delta = 0, 0.08, 0.24), using alpha = (0.8, 1.2), beta = (12, 9), and theta = (1.2, 0.9). Shared and cause-specific frailties are independent unit-rate Gamma variables. Conditional latent times are generated as `T_j = beta_j * (E_j / U_j)^(1/theta_j)`, with independent unit exponential thresholds `E_j`.

The script compares empirical marginal survivals at 6, 12, and 24 months with the exact Beta-P survival function. It also compares Monte Carlo frequencies for net cause-specific risks and the crude two-cause risk over [0,12) and [12,24) with one-dimensional quadrature of the model's cause-specific subdensities. It writes `marginal_mc_validation.csv` and `active_risk_mc_validation.csv`; settings and parameter values are recorded in `mc_validation_settings.json`.

This validation checks implementation of the probability formulas under the stated model. It does not study estimation of delta, bias, RMSE, test size, power, or confidence-region coverage.
