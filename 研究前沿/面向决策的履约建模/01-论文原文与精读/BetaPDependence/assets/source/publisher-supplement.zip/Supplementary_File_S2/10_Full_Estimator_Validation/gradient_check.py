"""Check the analytic score against centered finite differences."""

from pathlib import Path
import importlib.util

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "validation_gradient", HERE / "full_estimator_validation.py")
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)

rng = np.random.default_rng(91)
times, causes = model.simulate(rng, 0.5 * model.ALPHA.min())
base = np.log(np.array([0.02, 0.12, 1.4, 1.8, 5.5, 1.9]))
rows = []
for face in model.FACES:
    free = [i for i in range(6) if i not in face]
    z = base[free]
    _, analytic = model.objective_gradient(z, 0.01, times, causes, face)
    finite = []
    for j in range(len(z)):
        step = 1e-6
        plus, minus = z.copy(), z.copy()
        plus[j] += step
        minus[j] -= step
        f_plus = model.objective_gradient(plus, 0.01, times, causes, face)[0]
        f_minus = model.objective_gradient(minus, 0.01, times, causes, face)[0]
        finite.append((f_plus - f_minus) / (2 * step))
    finite = np.asarray(finite)
    rows.append({
        "face": "interior" if not face else "+".join(map(str, face)),
        "free_parameters": len(free),
        "maximum_absolute_difference": float(np.max(np.abs(analytic - finite))),
    })

result = pd.DataFrame(rows)
result.to_csv(HERE / "gradient_check.csv", index=False)
print(result.to_string(index=False))
