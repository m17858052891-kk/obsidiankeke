# Numerical report — Step 2: Profile likelihood

- **Model/data:** Shared-Gamma frailty competing risks with exact Beta-P margins; 177 records (56 cause-1 events, 75 cause-2 events, 46 right censored).
- **Procedure:** 25 fixed delta values on [0, 0.20]; six nuisance parameters reoptimized at each value using L-BFGS-B with transformed parameters bounded in log scale by [-15, 8]. Four starts at delta=0 and five at each positive delta; settings and seed are in `README.md` and `profile.py`.
- **Best recorded solution:** delta=0, log likelihood=-561.21071984. No positive tested grid point improves the independence-boundary likelihood.
- **Numerical limitation:** Across-start objective ranges are substantial, reaching about 532.45 in negative log likelihood at delta=0.20. Convergence flags and multiple starts do not certify global optima; the best recorded solution is only best among evaluated starts.
- **Interpretation:** This result does not establish true independence, a global maximum over the full feasible space, or a calibrated confidence interval/p-value. The exact kappa_j=0 boundaries are not separate candidates in the interior profile.
- **Reproducibility:** `profile.py` regenerates `profile.csv`; the PNG is an archived visualization.
