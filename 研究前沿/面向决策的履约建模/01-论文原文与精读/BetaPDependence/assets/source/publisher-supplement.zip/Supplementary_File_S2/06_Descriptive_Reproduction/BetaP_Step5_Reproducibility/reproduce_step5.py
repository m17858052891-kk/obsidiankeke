"""Deterministic reproducibility of manuscript Tables 2, 6, 7 (12-month values).
Run from this directory: python reproduce_step5.py
No optimization or simulation is performed. Parameters are rounded as printed in Table 4.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import quad

HERE=Path(__file__).resolve().parent
DATA=pd.read_csv(HERE/'bmtcrr.csv')
t=DATA.ftime.to_numpy(float); status=DATA.Status.to_numpy(int)
A=np.array([.02558,.13959]); B=np.array([1.37908,1.78020]); TH=np.array([6.86695,1.83601]); DM=float(min(A))

def H(u):return (u/B)**TH
def Hp(u):return TH/B*(u/B)**(TH-1)
def surv(u,d):
 h=H(u)
 return float(np.exp(-d*np.log1p(h.sum())-np.dot(A-d,np.log1p(h))))
def cif(u,d,j):
 def density(x):
  h=H(x)
  return surv(x,d)*Hp(x)[j]*((A[j]-d)/(1+h[j])+d/(1+h.sum()))
 return quad(density,0,u,epsabs=1e-11,epsrel=1e-11,limit=300)[0]
def aj(u):
 s=1.;f=np.zeros(2)
 for x in sorted(set(t[(t<=u)&(status>0)])):
  n=(t>=x).sum();n1=((t==x)&(status==1)).sum();n2=((t==x)&(status==2)).sum()
  f+=s*np.array([n1,n2])/n
  s*=1-(n1+n2)/n
 return np.r_[s,f]

obs=aj(12)
rows=[]
for frac in (0,.25,.5,.75,1):
 d=frac*DM
 values=np.array([surv(12,d),cif(12,d,0),cif(12,d,1)])
 assert abs(values.sum()-1)<2e-9,(d,values.sum())
 rows.append(dict(fraction=frac,delta=d,survival_12=values[0],relapse_cif_12=values[1],competing_cif_12=values[2],probability_sum=values.sum()))
frame=pd.DataFrame(rows)
frame.to_csv(HERE/'sensitivity_12_months.csv',index=False,float_format='%.12f')
comparison=pd.DataFrame({'quantity':['Event-free survival','Relapse CIF','Competing-event CIF'],'AJ':obs,'independent':frame.iloc[0][['survival_12','relapse_cif_12','competing_cif_12']].to_numpy(float),'endpoint':frame.iloc[-1][['survival_12','relapse_cif_12','competing_cif_12']].to_numpy(float)})
comparison['independent_minus_AJ']=comparison.independent-comparison.AJ
comparison['endpoint_minus_AJ']=comparison.endpoint-comparison.AJ
comparison.to_csv(HERE/'comparison_12_months.csv',index=False,float_format='%.12f')
# Explicit verification against manuscript's 6-decimal displayed values.
expected=np.array([[.417607,.251308,.331085],[.427150,.250494,.322356],[.436910,.249696,.313394],[.446894,.248914,.304192],[.457106,.248148,.294745]])
actual=frame[['survival_12','relapse_cif_12','competing_cif_12']].to_numpy()
assert np.max(abs(actual-expected))<1.1e-6,(actual-expected)
assert np.max(abs(obs-np.array([.326930,.271375,.401695])))<1.1e-6,obs
print('PASS: sensitivity grid matches manuscript Table 6 within 0.0000011')
print('PASS: Aalen-Johansen at 12 months matches manuscript Table 7')
print('PASS: survival + both CIFs = 1 at all five grid points')
print('Observed AJ:',obs)
print(frame.to_string(index=False))
print(comparison.to_string(index=False))
