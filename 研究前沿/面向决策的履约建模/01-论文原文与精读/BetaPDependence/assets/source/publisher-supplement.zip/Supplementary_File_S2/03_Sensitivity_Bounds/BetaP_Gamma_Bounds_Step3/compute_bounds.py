from pathlib import Path
import numpy as np,pandas as pd
from scipy.integrate import quad
from scipy.optimize import minimize_scalar
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
profile=pd.read_csv(P/'profile.csv'); base=float(profile.nll.min()); threshold=3.841458820694124

def vals(t,a,b,q):
 h=(t/b)**q
 return h,q/b*(t/b)**(q-1)
def prob(t,a,b,q,d):
 def surv(x):
  h,_=vals(x,a,b,q)
  return np.exp(-d*np.log1p(h.sum())-np.dot(a-d,np.log1p(h)))
 def cif(j):
  def f(x):
   h,hp=vals(x,a,b,q)
   return surv(x)*hp[j]*((a[j]-d)/(1+h[j])+d/(1+h.sum()))
  return quad(f,0,t,epsabs=1e-10,epsrel=1e-10,limit=300)[0]
 s=surv(t);c1=cif(0);c2=cif(1)
 assert abs(s+c1+c2-1)<1e-7,(t,d,s,c1,c2)
 return s,c1,c2
rows=[]
for r in profile.itertuples():
 a=np.array([r.alpha1,r.alpha2]);b=np.array([r.beta1,r.beta2]);q=np.array([r.theta1,r.theta2]);d=r.delta
 if np.any(a<d-1e-10):raise ValueError('invalid gamma shapes')
 for t in (12,24):
  s,c1,c2=prob(t,a,b,q,d)
  rows.append({'months':t,'delta':d,'lr_drop':2*(r.nll-base),'screen_lr_3_84':2*(r.nll-base)<=threshold,'survival':s,'cif_relapse':c1,'cif_competing':c2,'sum_check':s+c1+c2})
out=pd.DataFrame(rows);out.to_csv(P/'profiled_probabilities.csv',index=False)
summary=[]
for t in (12,24):
 for scope,sel in [('all_evaluated',out[out.months==t]),('illustrative_LR_screen_3_84',out[(out.months==t)&(out.screen_lr_3_84)])]:
  for v in ('survival','cif_relapse','cif_competing'):
   low=sel.loc[sel[v].idxmin()];high=sel.loc[sel[v].idxmax()]
   summary.append({'months':t,'scope':scope,'quantity':v,'min':low[v],'delta_at_min':low.delta,'max':high[v],'delta_at_max':high.delta,'number_of_grid_points':len(sel)})
summ=pd.DataFrame(summary);summ.to_csv(P/'grid_envelopes.csv',index=False)
# Continuous fixed-margin structural sensitivity, distinct from profile-reestimated analysis
r=profile.iloc[0];a=np.array([r.alpha1,r.alpha2]);b=np.array([r.beta1,r.beta2]);q=np.array([r.theta1,r.theta2]);dmax=a.min()
struct=[]
for t in (12,24):
 for j,name in enumerate(('survival','cif_relapse','cif_competing')):
  def fun(d):return prob(t,a,b,q,d)[j]
  # Screen the full interval, refine every detected local extremum on its
  # neighboring bracket, and independently rerun the bounded optimizer on
  # the full interval. Include both endpoints explicitly.
  mesh=np.linspace(0.,dmax,2001); grid_vals=np.array([fun(x) for x in mesh])
  mins=[]; maxs=[]
  for k in range(1,len(mesh)-1):
   if grid_vals[k]<=grid_vals[k-1] and grid_vals[k]<=grid_vals[k+1]:
    r=minimize_scalar(fun,bounds=(mesh[k-1],mesh[k+1]),method='bounded',options={'xatol':1e-12,'maxiter':1000})
    mins.append(r)
   if grid_vals[k]>=grid_vals[k-1] and grid_vals[k]>=grid_vals[k+1]:
    r=minimize_scalar(lambda x:-fun(x),bounds=(mesh[k-1],mesh[k+1]),method='bounded',options={'xatol':1e-12,'maxiter':1000})
    maxs.append(r)
  mini=minimize_scalar(fun,bounds=(0.,dmax),method='bounded',options={'xatol':1e-12,'maxiter':1000})
  maxi=minimize_scalar(lambda x:-fun(x),bounds=(0.,dmax),method='bounded',options={'xatol':1e-12,'maxiter':1000})
  cands=[(0.,fun(0.)),(dmax,fun(dmax)),(mini.x,mini.fun),(maxi.x,-maxi.fun)]
  cands += [(r.x,r.fun) for r in mins]
  cands += [(r.x,-r.fun) for r in maxs]
  lo=min(cands,key=lambda z:z[1]);hi=max(cands,key=lambda z:z[1]);struct.append({'months':t,'quantity':name,'min':lo[1],'delta_at_min':lo[0],'max':hi[1],'delta_at_max':hi[0],'fixed_margin_delta_max':dmax})
  struct[-1].update({'screen_points':len(mesh),'local_minima_refined':len(mins),'local_maxima_refined':len(maxs),
                     'full_interval_min_success':bool(mini.success),'full_interval_max_success':bool(maxi.success),
                     'dense_grid_min_gap':float(lo[1]-grid_vals.min()),'dense_grid_max_gap':float(grid_vals.max()-hi[1]),
                     'optimizer_xatol':1e-12})
fixed=pd.DataFrame(struct);fixed.to_csv(P/'fixed_margin_numerical_extrema.csv',index=False)
fig,axes=plt.subplots(1,2,figsize=(11,4.5))
for ax,t in zip(axes,(12,24)):
 z=out[out.months==t]
 for name,label in [('survival','Event-free survival'),('cif_relapse','Relapse CIF'),('cif_competing','Competing CIF')]:ax.plot(z.delta,z[name],marker='.',label=label)
 ax.axvline(.065,color='gray',ls=':',alpha=.5);ax.set(title=f'{t} months — profiled marginal parameters',xlabel='Shared Gamma shape delta',ylabel='Probability');ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.tight_layout();fig.savefig(P/'profiled_probability_curves.png',dpi=170)
print('PROFILE GRID ENVELOPES\n',summ.to_string(index=False,float_format=lambda x:f'{x:.6f}'))
print('\nFIXED MARGIN NUMERICAL EXTREMA\n',pd.DataFrame(struct).to_string(index=False,float_format=lambda x:f'{x:.6f}'))
