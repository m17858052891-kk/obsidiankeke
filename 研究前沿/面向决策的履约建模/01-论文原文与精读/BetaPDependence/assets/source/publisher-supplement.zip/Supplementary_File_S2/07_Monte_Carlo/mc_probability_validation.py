"""Independent Monte Carlo check of the shared-gamma Beta-P probability formulas.

Run: python mc_probability_validation.py
Requirements: numpy, pandas, scipy
This validates probability calculations under the data-generating model; it does not
assess finite-sample estimation, calibration, or coverage for the dependence parameter.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.integrate import quad

SEED=20261104
N=500_000
PARAMS={
    'independence':dict(alpha=np.array([.8,1.2]),beta=np.array([12.,9.]),theta=np.array([1.2,.9]),delta=0.),
    'weak_dependence':dict(alpha=np.array([.8,1.2]),beta=np.array([12.,9.]),theta=np.array([1.2,.9]),delta=.08),
    'moderate_dependence':dict(alpha=np.array([.8,1.2]),beta=np.array([12.,9.]),theta=np.array([1.2,.9]),delta=.24),
}
INTERVALS=((0.,12.),(12.,24.))
SETS={'net cause 1':(0,), 'net cause 2':(1,), 'crude both causes':(0,1)}
OUT=Path(__file__).resolve().parent

def H(t,p): return (t/p['beta'])**p['theta']
def survival(t,active,p):
    h=H(t,p)[list(active)]; d=p['delta']; a=p['alpha'][list(active)]
    return float(np.exp(-d*np.log1p(h.sum())-np.sum((a-d)*np.log1p(h))))
def subdensity(t,j,active,p):
    h=H(t,p); hp=p['theta'][j]/p['beta'][j]*(t/p['beta'][j])**(p['theta'][j]-1)
    ar=list(active); hs=h[ar]; d=p['delta']; a=p['alpha']
    c=d/(1+hs.sum())+(a[j]-d)/(1+h[j])
    return survival(t,active,p)*hp*c

def exact(a,b,j,active,p):
    return quad(lambda x:subdensity(x,j,active,p),a,b,epsabs=1e-11,epsrel=1e-11,limit=300)[0]

def simulate(rng,p,n):
    d=p['delta']; v0=rng.gamma(d,1.,n) if d else np.zeros(n)
    u=np.column_stack([v0+rng.gamma(p['alpha'][j]-d,1.,n) for j in range(2)])
    e=rng.exponential(size=(n,2))
    return p['beta'][None,:]*(e/u)**(1/p['theta'][None,:])

def main():
    rows=[]; marginal=[]
    for si,(name,p) in enumerate(PARAMS.items()):
        rng=np.random.default_rng(SEED+si)
        latent=simulate(rng,p,N)
        for j in range(2):
            for t in (6.,12.,24.):
                emp=float(np.mean(latent[:,j]>t)); theo=float((1+(t/p['beta'][j])**p['theta'][j])**(-p['alpha'][j]))
                se=float(np.sqrt(theo*(1-theo)/N))
                marginal.append(dict(scenario=name,cause=j+1,time=t,empirical=emp,exact=theo,se=se,z=(emp-theo)/se,abs_error=abs(emp-theo)))
        for setname,active in SETS.items():
            active_arr=np.asarray(active)
            win_local=np.argmin(latent[:,active_arr],axis=1)
            min_time=np.min(latent[:,active_arr],axis=1)
            win_cause=active_arr[win_local]
            for a,b in INTERVALS:
                for j in active:
                    x=(win_cause==j)&(min_time>=a)&(min_time<b)
                    emp=float(x.mean()); theo=exact(a,b,j,active,p); se=float(np.sqrt(theo*(1-theo)/N))
                    rows.append(dict(scenario=name,active_set=setname,cause=j+1,interval=f'[{a:g},{b:g})',n=N,mc_probability=emp,integral_probability=theo,mc_se=se,z_score=(emp-theo)/se if se else np.nan,abs_error=abs(emp-theo)))
    pd.DataFrame(rows).to_csv(OUT/'active_risk_mc_validation.csv',index=False)
    pd.DataFrame(marginal).to_csv(OUT/'marginal_mc_validation.csv',index=False)
    summary={'seed':SEED,'replicates_per_scenario':N,'true_parameters':{k:{'alpha':v['alpha'].tolist(),'beta':v['beta'].tolist(),'theta':v['theta'].tolist(),'delta':v['delta']} for k,v in PARAMS.items()},'intervals_months':[list(x) for x in INTERVALS],'active_sets':{k:[j+1 for j in v] for k,v in SETS.items()},'simulation':'Shared and cause-specific independent Gamma frailties with unit rate; conditional independent exponential thresholds; T_j=beta_j*(E_j/U_j)^(1/theta_j).','validation_scope':'Checks exact marginal Beta-P survival and active-set interval probability integrals against independent Monte Carlo frequencies. Does not evaluate parameter-estimation bias, test size, power, or confidence-interval coverage.'}
    (OUT/'mc_validation_settings.json').write_text(json.dumps(summary,indent=2))
    print('Active risk validation:')
    print(pd.DataFrame(rows).groupby(['scenario','active_set']).agg(max_abs_error=('abs_error','max'),max_abs_z=('z_score',lambda x:np.max(np.abs(x)))).to_string())
    print('Marginal validation: max abs error',pd.DataFrame(marginal).abs_error.max())
if __name__=='__main__':main()
