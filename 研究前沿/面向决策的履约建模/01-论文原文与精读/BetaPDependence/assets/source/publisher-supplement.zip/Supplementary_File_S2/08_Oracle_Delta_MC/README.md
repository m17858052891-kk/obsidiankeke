# Oracle fixed-margin Monte Carlo for δ

This reproducible simulation evaluates estimation of the shared-gamma dependence parameter δ when all six Beta-P marginal parameters are fixed at their generating values. It is an oracle conditional experiment, not a simulation of the complete seven-parameter estimation procedure.

Run `python oracle_delta_mc.py` to reproduce the replicate-level output and summary in the current directory. The script uses the fixed seed and settings in `oracle_delta_mc_settings.json`; it generates n=177 competing-risk observations per replication, applies independent administrative censoring at 60 months, and estimates δ by bounded scalar optimization over [0, min(α1,α2)] with explicit endpoint comparisons. There are 2,000 replications at each of δ=0, 0.5δmax, and 0.9δmax.

The reported bias, RMSE, and boundary rates are conditional on known marginal parameters. They do not establish joint-estimator performance, test size or power, interval coverage, global optimization, or goodness-of-fit for the clinical dataset. The high boundary rates are part of the finite-sample finding and should be interpreted with the oracle scope in mind.
