from pathlib import Path
import pandas as pd,numpy as np
from docx import Document
from docx.shared import Inches,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from scipy.integrate import quad
P=Path(__file__).resolve().parent; D=P; out=P
profile=pd.read_csv(D/'profile.csv'); probs=pd.read_csv(D/'profiled_probabilities.csv');data=pd.read_csv(D/'bmtcrr.csv'); t=data.ftime.to_numpy(); status=data.Status.to_numpy()
def aj(u):
 s=1.;f=np.zeros(2)
 for x in sorted(set(t[(t<=u)&(status>0)])):
  n=(t>=x).sum();ev=np.array([((t==x)&(status==j)).sum() for j in (1,2)])
  f+=s*ev/n;s*=1-ev.sum()/n
 return np.r_[s,f]
base=profile.nll.min(); filtered=probs[probs.screen_lr_3_84]
rows=[]
for month in (12,24):
 observed=aj(month);ind=probs[(probs.months==month)&(probs.delta==0)].iloc[0]
 for j,(name,col) in enumerate([('Event-free survival','survival'),('Relapse CIF','cif_relapse'),('Competing-event CIF','cif_competing')]):
  sub=filtered[filtered.months==month]; lo=sub.loc[sub[col].idxmin()];hi=sub.loc[sub[col].idxmax()]
  rows.append(dict(month=month,quantity=name,AJ=observed[j],independent=ind[col],independent_minus_AJ=ind[col]-observed[j],profile_grid_min=lo[col],profile_grid_max=hi[col],delta_at_min=lo.delta,delta_at_max=hi.delta,profile_grid_min_minus_AJ=lo[col]-observed[j],profile_grid_max_minus_AJ=hi[col]-observed[j]))
res=pd.DataFrame(rows);res.to_csv(out/'clinical_comparison_12_24.csv',index=False,float_format='%.12f')
print(res.to_string(index=False))
