"""Rerun batch-disagreement cases with doubled starts per batch."""

from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import sys

import pandas as pd

HERE = Path(__file__).resolve().parent
FINAL = HERE / "final_100x3"
sys.path.insert(0, str(HERE))
import full_estimator_validation as model

raw = pd.read_csv(FINAL / "full_estimator_validation_replicates.csv")
unstable = raw.loc[~raw.all_selected_faces_agree]
tasks = [
    (int(row.scenario), int(row.replicate), float(row.delta_true), int(row.seed), 24, 1e-6)
    for row in unstable.itertuples(index=False)
]
with ProcessPoolExecutor(max_workers=min(4, len(tasks))) as executor:
    corrected = list(executor.map(model.one_replicate, tasks))
pd.DataFrame(corrected).sort_values(["scenario", "replicate"]).to_csv(
    FINAL / "full_estimator_validation_retried.csv", index=False)
print(pd.DataFrame(corrected).to_string(index=False))
