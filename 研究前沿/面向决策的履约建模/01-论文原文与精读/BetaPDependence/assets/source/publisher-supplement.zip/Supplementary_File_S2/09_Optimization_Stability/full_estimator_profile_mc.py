"""Full seven-parameter shared-Gamma estimator validation by profile-grid refitting.

This explicitly refits all six nuisance margin parameters at every delta, includes
independence and exact kappa_j=0 faces, and records optimizer diagnostics. The
profile is a numerical grid approximation, not a confidence interval or proof of
continuous/global optimality.
"""
from pathlib import Path
import json, sys
import numpy as np, pandas as pd
from scipy.optimize import minimize
OUT=Path(__file__).parent
SEED=20261106; N=177; ADMIN_CENSOR=60.0
TRUE_ALPHA=np.array([0.02558137,0.13958528]); TRUE_BETA=np.array([1.37908308,1.78020412]); TRUE_THETA=np.array([6.866957,1.83601277])
TRUE_DELTAS=[0.0,0.5*min(TRUE_ALPHA),0.9*min(TRUE_ALPHA)]
DGRID=np.r_[0,np.arange(.001,.051,.001),.06,.08]
LOG_BOUNDS=(-15,8)

def simulate(rng,d):
 v0=np.zeros(N) if d==0 else rng.gamma(d,1.,N)
 v1=rng.gamma(TRUE_ALPHA[0]-d,1.,N) if TRUE_ALPHA[0]>d else np.zeros(N)
 v2=rng.gamma(TRUE_ALPHA[1]-d,1.,N) if TRUE_ALPHA[1]>d else np.zeros(N)
 u=np.column_stack([v0+v1,v0+v2]); e=rng.exponential(1.,(N,2))
 tt=TRUE_BETA*(e/u)**(1/TRUE_THETA); ev=np.min(tt,axis=1); cause=np.argmin(tt,axis=1)+1
 return np.minimum(ev,ADMIN_CENSOR),np.where(ev<=ADMIN_CENSOR,cause,0)

def nll_params(kap,beta,theta,d,t,y):
 with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
  a=d+kap; h=(t[:,None]/beta)**theta; hp=theta/beta*(t[:,None]/beta)**(theta-1)
  ll=-d*np.log1p(h.sum(axis=1))-(kap*np.log1p(h)).sum(axis=1)
  for cause,j in [(1,0),(2,1)]:
   ix=y==cause
   if np.any(ix):
    mix=kap[j]/(1+h[ix,j])+d/(1+h[ix].sum(axis=1))
    ll[ix]+=np.log(hp[ix,j])+np.log(mix)
  val=-ll.sum()
 return float(val) if np.isfinite(val) else 1e100

def fit_ind(t,y,rng,starts=5):
 base=np.log([.05,.12,1.5,2.0,5.,1.8]); fits=[]
 for i in range(starts):
  x=base if i==0 else base+rng.normal(0,[.7,.7,.5,.5,.8,.5])
  def f(z): return nll_params(np.exp(z[:2]),np.exp(z[2:4]),np.exp(z[4:]),0.,t,y)
  fits.append(minimize(f,x,method='L-BFGS-B',bounds=[LOG_BOUNDS]*6,options={'maxiter':2500,'ftol':1e-12,'gtol':1e-7,'maxls':60,'maxcor':30}))
 return min(fits,key=lambda r:r.fun),fits

def fit_face(d,zero,base_params,prev_params,t,y,rng,starts=3):
 free=[i for i in range(6) if i not in zero]
 def to_full(z):
  v=np.zeros(6);v[free]=np.exp(z);return v
 def f(z):
  v=to_full(z);return nll_params(v[:2],v[2:4],v[4:],d,t,y)
 def init(param):
  v=param.copy();v[:2]=np.maximum(v[:2]-d,1e-5);return np.log(v[free])
 xs=[init(prev_params),init(base_params)]
 xs += [xs[1]+rng.normal(0,.35,len(free)) for _ in range(max(0,starts-2))]
 fits=[minimize(f,x,method='L-BFGS-B',bounds=[LOG_BOUNDS]*len(free),options={'maxiter':2500,'ftol':1e-12,'gtol':1e-7,'maxls':60,'maxcor':30}) for x in xs[:starts]]
 best=min(fits,key=lambda r:r.fun); v=to_full(best.x)
 return {'nll':float(best.fun),'params':np.r_[d+v[:2],v[2:]],'face':str(tuple(j+1 for j in zero)) if zero else 'interior','success':bool(best.success),'grad_inf':float(np.max(np.abs(best.jac))),'spread':float(max(r.fun for r in fits)-best.fun),'nstarts':len(fits),'nsuccess':sum(bool(r.success) for r in fits)}

def fit_full(t,y,rng):
 ri,ifits=fit_ind(t,y,rng)
 indpar=np.exp(ri.x); candidates=[]; prev=indpar.copy(); all_spread=[]; all_grad=[]; all_success=[]
 # Exact delta=0 candidate is the independent model; positive delta is profiled,
 # with interior and each exact kappa face considered separately.
 candidates.append({'delta':0.,'nll':float(ri.fun),'params':indpar,'face':'independence','success':bool(ri.success),'grad_inf':float(np.max(np.abs(ri.jac))),'spread':float(max(r.fun for r in ifits)-ri.fun),'nstarts':len(ifits),'nsuccess':sum(bool(r.success) for r in ifits)})
 for d in DGRID[1:]:
  faces=[]
  for zero in [( ),(0,),(1,),(0,1)]:
   q=fit_face(float(d),zero,indpar,prev,t,y,rng,starts=3)
   faces.append(q);all_spread.append(q['spread']);all_grad.append(q['grad_inf']);all_success.append(q['nsuccess']/q['nstarts'])
  best=min(faces,key=lambda q:q['nll']);prev=best['params'];best['delta']=float(d);candidates.append(best)
 best=min(candidates,key=lambda q:q['nll'])
 return best, {'independent_spread':float(max(r.fun for r in ifits)-ri.fun),'median_face_spread':float(np.median(all_spread)),'max_face_spread':float(max(all_spread)),'median_face_success_rate':float(np.median(all_success)),'max_selected_grid_grad_inf':float(max(all_grad)),'upper_grid_selected':bool(best['delta']==DGRID[-1]),'profile_points':len(DGRID)}

def main(reps=100):
 rows=[]
 for si,dtrue in enumerate(TRUE_DELTAS):
  print(f'scenario {si+1}/3: delta={dtrue:.8f}',flush=True)
  for r in range(reps):
   rg=np.random.default_rng(SEED+si*100000+r)
   t,y=simulate(rg,dtrue);best,diag=fit_full(t,y,rg);p=best['params']
   rows.append({'scenario':si,'replicate':r+1,'delta_true':dtrue,'delta_hat':best['delta'],'alpha1_hat':p[0],'alpha2_hat':p[1],'beta1_hat':p[2],'beta2_hat':p[3],'theta1_hat':p[4],'theta2_hat':p[5],'nll':best['nll'],'selected_face':best['face'],'optimizer_success':best['success'],'selected_gradient_inf':best['grad_inf'],**diag,'events1':int((y==1).sum()),'events2':int((y==2).sum()),'censored':int((y==0).sum())})
   if (r+1)%10==0:print(f'  {r+1}/{reps}',flush=True)
 raw=pd.DataFrame(rows);raw.to_csv(OUT/'full_estimator_profile_mc_replicates.csv',index=False)
 summaries=[]
 for si,g in raw.groupby('scenario'):
  row={'scenario':si,'delta_true':g.delta_true.iloc[0],'replicates':len(g),'delta_bias':float((g.delta_hat-g.delta_true).mean()),'delta_rmse':float(np.sqrt(np.mean((g.delta_hat-g.delta_true)**2))),'delta_mc_sd':float(g.delta_hat.std(ddof=1)),'independence_boundary_rate':float((g.delta_hat==0).mean()),'upper_grid_rate':float(g.upper_grid_selected.mean()),'optimizer_success_rate':float(g.optimizer_success.mean()),'median_selected_gradient_inf':float(g.selected_gradient_inf.median()),'max_selected_gradient_inf':float(g.selected_gradient_inf.max()),'median_profile_face_spread':float(g.median_face_spread.median()),'median_profile_face_success_rate':float(g.median_face_success_rate.median())}
  for k,true in [('alpha1',TRUE_ALPHA[0]),('alpha2',TRUE_ALPHA[1]),('beta1',TRUE_BETA[0]),('beta2',TRUE_BETA[1]),('theta1',TRUE_THETA[0]),('theta2',TRUE_THETA[1])]:
   err=g[k+'_hat']-true;row[k+'_bias']=float(err.mean());row[k+'_rmse']=float(np.sqrt(np.mean(err**2)))
  summaries.append(row)
 summ=pd.DataFrame(summaries);summ.to_csv(OUT/'full_estimator_profile_mc_summary.csv',index=False)
 settings={'seed':SEED,'n':N,'replicates_per_scenario':reps,'administrative_censoring_months':ADMIN_CENSOR,'true_alpha':TRUE_ALPHA.tolist(),'true_beta':TRUE_BETA.tolist(),'true_theta':TRUE_THETA.tolist(),'true_delta_scenarios':TRUE_DELTAS,'delta_profile_grid':DGRID.tolist(),'profile_method':'At each positive fixed delta, all six nuisance margins are refitted over the interior and exact kappa1=0, kappa2=0, and both-zero faces. Three deterministic starts per face include independent-fit initialization and continuation; L-BFGS-B; bounds for transformed free positive parameters [-15,8]. Exact independence is included as delta=0. Selected fit is the best among all evaluated grid points and starts.','optimizer':{'method':'L-BFGS-B','maxiter':2500,'ftol':1e-12,'gtol':1e-7,'maxls':60,'maxcor':30,'independent_starts':5,'starts_per_positive_delta_face':3},'metrics':'bias, RMSE, MC SD, boundary and upper-grid selection, success flags, gradient and across-start diagnostics. Grid-profile estimates are approximate; no continuous profile or confidence coverage claim.'}
 (OUT/'full_estimator_profile_mc_settings.json').write_text(json.dumps(settings,indent=2))
 print(summ.to_string(index=False))
if __name__=='__main__':main(int(sys.argv[1]) if len(sys.argv)>1 else 100)
