# Numerical findings: sensitivity envelopes at 12 and 24 months

The six marginal parameters were reestimated at each shared-Gamma dependence parameter in the 25-point step-2 profile. The cumulative incidence was integrated numerically from the model's cause-specific subdensities, with `S(t)+CIF1(t)+CIF2(t)=1` verified to within 1e-7.

## Exploratory LR-screened profile-grid envelopes (2 Delta log-likelihood <=3.84146)
| Time | Quantity | Grid minimum | Grid maximum |
|---|---|---:|---:|
| 12 months | Event-free survival | 0.412903 | 0.417656 |
| 12 months | Relapse CIF | 0.251319 | 0.254310 |
| 12 months | Competing-event CIF | 0.330870 | 0.335044 |
| 24 months | Event-free survival | 0.299038 | 0.310474 |
| 24 months | Relapse CIF | 0.295156 | 0.304632 |
| 24 months | Competing-event CIF | 0.394187 | 0.396330 |

These are grid envelopes, **not** confidence intervals, sharp bounds, or certified global extrema. They use refitted marginal parameters. The profile grid covers delta in [0,0.20], and 21 of 25 tested points pass the illustrative screen.

## Fixed-margin structural sensitivity (independent-fit margins held constant)
| Time | Quantity | Numerical min | Numerical max |
|---|---|---:|---:|
| 12 months | Event-free survival | 0.417605 | 0.457107 |
| 12 months | Relapse CIF | 0.248162 | 0.251321 |
| 12 months | Competing-event CIF | 0.294731 | 0.331074 |
| 24 months | Event-free survival | 0.310474 | 0.350897 |
| 24 months | Relapse CIF | 0.295339 | 0.297081 |
| 24 months | Competing-event CIF | 0.352021 | 0.394187 |

Numerical extrema from bounded scalar optimization with endpoint comparison over delta in [0, 0.02558137]. They are *not* the profile-grid envelopes and do not estimate dependence from the data.
