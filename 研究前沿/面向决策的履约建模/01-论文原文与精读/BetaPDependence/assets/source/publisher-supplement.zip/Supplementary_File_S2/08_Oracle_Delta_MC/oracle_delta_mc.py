"""Oracle fixed-margin Monte Carlo profile for the shared-gamma shape delta.

The six Beta-P marginal parameters are fixed at their generating values. This
isolates the one-dimensional dependence likelihood and is not a joint-estimation
study. It uses independent fixed administrative censoring at 60 months.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar

OUT=Path(__file__).parent
SEED=20261104
N=177
REPS=2000
CENSOR=60.0
ALPHA=np.array([0.02558137,0.13958528])
BETA=np.array([1.37908308,1.78020412])
THETA=np.array([6.866957,1.83601277])
DMAX=float(np.min(ALPHA))
FRACS=[0.0,0.5,0.9]

def sim(rng, delta):
    v0=np.zeros(N) if delta==0 else rng.gamma(delta,1.0,N)
    v1=rng.gamma(ALPHA[0]-delta,1.0,N) if ALPHA[0]>delta else np.zeros(N)
    v2=rng.gamma(ALPHA[1]-delta,1.0,N) if ALPHA[1]>delta else np.zeros(N)
    u=np.column_stack([v0+v1,v0+v2])
    e=rng.exponential(1.0,(N,2))
    tt=BETA*(e/u)**(1/THETA)
    cause=np.argmin(tt,axis=1)+1
    et=np.min(tt,axis=1)
    y=np.where(et<=CENSOR,cause,0)
    return np.minimum(et,CENSOR),y

def nll(delta,t,y):
    with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
        h=(t[:,None]/BETA)**THETA
        hp=THETA/BETA*(t[:,None]/BETA)**(THETA-1)
        L=-delta*np.log1p(np.sum(h,axis=1))-np.sum((ALPHA-delta)*np.log1p(h),axis=1)
        for j in (1,2):
            ix=y==j
            mix=(ALPHA[j-1]-delta)/(1+h[ix,j-1])+delta/(1+np.sum(h[ix],axis=1))
            L[ix]+=np.log(hp[ix,j-1])+np.log(mix)
        ans=-float(np.sum(L))
    return ans if np.isfinite(ans) else 1e100

def main():
    rows=[]
    for frac in FRACS:
        dtrue=frac*DMAX
        print(f'scenario {frac:.2f}; delta={dtrue:.8f}',flush=True)
        for i in range(REPS):
            rng=np.random.default_rng(SEED+int(frac*10000)*REPS+i)
            t,y=sim(rng,dtrue)
            opt=minimize_scalar(lambda d:nll(d,t,y),bounds=(0,DMAX),method='bounded',options={'xatol':1e-12,'maxiter':1000})
            candidates=[(0.0,nll(0,t,y)),(float(opt.x),float(opt.fun)),(DMAX,nll(DMAX,t,y))]
            dh,nh=min(candidates,key=lambda z:z[1])
            rows.append({'scenario_fraction_delta_max':frac,'replicate':i+1,'delta_true':dtrue,
                         'delta_hat':dh,'nll_hat':nh,'events_1':int(np.sum(y==1)),
                         'events_2':int(np.sum(y==2)),'censored':int(np.sum(y==0)),
                         'at_lower_boundary':dh==0.0,'at_upper_boundary':dh==DMAX})
            if (i+1)%500==0: print(f'  {i+1}/{REPS}',flush=True)
    raw=pd.DataFrame(rows);raw.to_csv(OUT/'oracle_delta_mc_replicates.csv',index=False)
    summary=[]
    for frac,g in raw.groupby('scenario_fraction_delta_max'):
        true=float(g.delta_true.iloc[0]);err=g.delta_hat-true
        summary.append({'scenario_fraction_delta_max':frac,'delta_true':true,'replicates':len(g),
          'mean_delta_hat':g.delta_hat.mean(),'bias':err.mean(),'rmse':np.sqrt(np.mean(err**2)),
          'mc_sd':g.delta_hat.std(ddof=1),'lower_boundary_rate':g.at_lower_boundary.mean(),
          'upper_boundary_rate':g.at_upper_boundary.mean(),'mean_events1':g.events_1.mean(),
          'mean_events2':g.events_2.mean(),'mean_censored':g.censored.mean()})
    summ=pd.DataFrame(summary);summ.to_csv(OUT/'oracle_delta_mc_summary.csv',index=False)
    settings={'seed':SEED,'n':N,'replicates_per_scenario':REPS,'administrative_censoring_months':CENSOR,
      'fixed_margins':{'alpha':ALPHA.tolist(),'beta':BETA.tolist(),'theta':THETA.tolist()},
      'delta_scenarios':[{'fraction_delta_max':f,'delta':f*DMAX} for f in FRACS],
      'generator':'V0~Gamma(delta,1); Vj~Gamma(alpha_j-delta,1); Uj=V0+Vj; Tj=beta_j*(E_j/Uj)^(1/theta_j), E_j iid Exp(1)',
      'estimation':'For each generated sample, minimize the exact observed competing-risk negative log likelihood over the closed interval [0,min(alpha)] with fixed true marginal parameters; bounded scalar optimization plus explicit comparison of both endpoints.',
      'optimizer':{'method':'bounded scalar minimization','xatol':1e-12,'maxiter':1000},
      'scope':'Oracle fixed-margin assessment of delta estimation only. It does not estimate marginal parameters, assess joint-estimator bias, interval coverage, or global optimization of the seven-parameter likelihood.'}
    (OUT/'oracle_delta_mc_settings.json').write_text(json.dumps(settings,indent=2))
    print(summ.to_string(index=False))
if __name__=='__main__':main()
