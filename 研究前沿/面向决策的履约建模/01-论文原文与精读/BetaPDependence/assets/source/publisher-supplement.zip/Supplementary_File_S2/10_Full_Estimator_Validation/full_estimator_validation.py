"""Reproducible validation of the complete seven-parameter estimator.

The six nuisance parameters are re-estimated at every fixed value of delta.
For each interior/boundary face, two independent batches of 12 starts are run.
Agreement of the two batch minima is used as the primary optimization-stability
diagnostic.  Analytic gradients are used throughout.
"""

from __future__ import annotations

import argparse
import json
import platform
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.optimize import minimize
from threadpoolctl import threadpool_limits

N = 177
ADMIN = 60.0
ALPHA = np.array([0.02558137, 0.13958528])
BETA = np.array([1.37908308, 1.78020412])
THETA = np.array([6.86695700, 1.83601277])
DELTA_GRID = np.r_[0.0, np.arange(0.001, 0.020, 0.001), 0.021, 0.023, 0.025,
                   0.035, 0.050, 0.080]
# Compact, prespecified parameter space used for the validation estimator.
# It contains the generating values well in its interior and prevents the
# alpha -> 0, theta -> infinity likelihood ridge found in the unrestricted fit.
LOWER = np.array([1e-4, 1e-4, 0.10, 0.10, 0.20, 0.20])
UPPER = np.array([2.00, 2.00, 120.0, 120.0, 20.0, 20.0])
LOG_BOUNDS = list(zip(np.log(LOWER), np.log(UPPER)))
OPT = {"maxiter": 2500, "ftol": 1e-12, "gtol": 1e-7,
       "maxls": 60, "maxcor": 30}
FACES = ((), (0,), (1,), (0, 1))


def simulate(rng: np.random.Generator, delta: float):
    common = np.zeros(N) if delta == 0 else rng.gamma(delta, 1.0, N)
    specific1 = rng.gamma(ALPHA[0] - delta, 1.0, N)
    specific2 = rng.gamma(ALPHA[1] - delta, 1.0, N)
    frailty = np.column_stack((common + specific1, common + specific2))
    threshold = rng.exponential(1.0, (N, 2))
    latent = BETA * (threshold / frailty) ** (1.0 / THETA)
    observed = latent.min(axis=1)
    cause = latent.argmin(axis=1) + 1
    return np.minimum(observed, ADMIN), np.where(observed <= ADMIN, cause, 0)


def objective_gradient(z, delta, times, causes, zero_face=()):
    free = np.array([i for i in range(6) if i not in zero_face])
    values = np.zeros(6)
    values[free] = np.exp(z)
    kappa, beta, theta = values[:2], values[2:4], values[4:]
    log_t = np.log(times)
    log_beta = np.log(beta)
    eta = theta[None, :] * (log_t[:, None] - log_beta[None, :])
    log1ph = np.logaddexp(0.0, eta)
    log_hsum = np.logaddexp(eta[:, 0], eta[:, 1])
    log1phsum = np.logaddexp(0.0, log_hsum)
    r = np.exp(eta - log1ph)
    q = np.exp(eta - log1phsum[:, None])

    ll = -delta * log1phsum - (log1ph * kappa[None, :]).sum(axis=1)
    d_eta = -delta * q - kappa[None, :] * r
    grad_log = np.zeros(6)
    grad_log[:2] = -(kappa * log1ph.sum(axis=0))
    grad_log[2:4] = np.sum(d_eta * (-theta[None, :]), axis=0)
    grad_log[4:6] = np.sum(d_eta * eta, axis=0)

    for j in (0, 1):
        index = causes == (j + 1)
        if not index.any():
            continue
        log_hprime = (np.log(theta[j]) - log_beta[j]
                      + (theta[j] - 1.0) * (log_t[index] - log_beta[j]))
        if kappa[j] > 0:
            log_a = np.log(kappa[j]) - log1ph[index, j]
        else:
            log_a = np.full(index.sum(), -np.inf)
        if delta > 0:
            log_b = np.log(delta) - log1phsum[index]
        else:
            log_b = np.full(index.sum(), -np.inf)
        log_mix = np.logaddexp(log_a, log_b)
        weight_a = np.exp(log_a - log_mix)
        weight_b = np.exp(log_b - log_mix)
        ll[index] += log_hprime + log_mix
        grad_log[j] += weight_a.sum()
        mix_eta = -weight_b[:, None] * q[index]
        mix_eta[:, j] -= weight_a * r[index, j]
        grad_log[2:4] += np.sum(mix_eta * (-theta[None, :]), axis=0)
        grad_log[4:6] += np.sum(mix_eta * eta[index], axis=0)
        grad_log[2 + j] -= theta[j] * index.sum()
        grad_log[4 + j] += np.sum(1.0 + eta[index, j])

    value = -float(ll.sum())
    gradient = -grad_log[free]
    if not np.isfinite(value) or not np.all(np.isfinite(gradient)):
        return 1e100, np.zeros_like(z)
    return value, gradient


def optimize_starts(times, causes, delta, zero_face, starts):
    free = [i for i in range(6) if i not in zero_face]
    results = []
    for start in starts:
        result = minimize(
            objective_gradient, start, args=(delta, times, causes, zero_face),
            jac=True, method="L-BFGS-B", bounds=[LOG_BOUNDS[i] for i in free],
            options=OPT,
        )
        results.append(result)
    valid = [r for r in results if np.isfinite(r.fun)]
    return min(valid, key=lambda r: r.fun), results


def make_batch(rng, anchors, free, batch_size=12):
    starts = [np.asarray(a)[free] for a in anchors]
    scales = (0.12, 0.25, 0.45, 0.70, 1.00, 1.40)
    anchor = np.asarray(anchors[-1])[free]
    i = 0
    while len(starts) < batch_size:
        starts.append(anchor + rng.normal(0.0, scales[i % len(scales)], len(free)))
        i += 1
    return starts[:batch_size]


def unpack(result, delta, zero_face):
    free = [i for i in range(6) if i not in zero_face]
    values = np.zeros(6)
    values[free] = np.exp(result.x)
    return np.r_[delta + values[:2], values[2:]]


def projected_gradient_inf(result, free):
    """Infinity norm of the KKT projected gradient for box constraints."""
    gradient = np.asarray(result.jac, dtype=float).copy()
    x = np.asarray(result.x)
    tolerance = 1e-7
    for j, parameter_index in enumerate(free):
        lower, upper = LOG_BOUNDS[parameter_index]
        if x[j] <= lower + tolerance and gradient[j] > 0:
            gradient[j] = 0.0
        elif x[j] >= upper - tolerance and gradient[j] < 0:
            gradient[j] = 0.0
    return float(np.max(np.abs(gradient)))


def fit_complete_profile(times, causes, rng, batch_size=12, agreement_tol=1e-6):
    base = np.log(np.array([0.05, 0.12, 1.5, 2.0, 5.0, 1.8]))
    independent_batches = []
    for _ in range(2):
        starts = [base]
        starts.extend(base + rng.normal(0.0, [0.7, 0.7, 0.5, 0.5, 0.8, 0.5])
                      for _ in range(batch_size - 1))
        independent_batches.append(optimize_starts(times, causes, 0.0, (), starts)[0])
    independent_gap = abs(independent_batches[0].fun - independent_batches[1].fun)
    if independent_gap > agreement_tol:
        for _ in range(2):
            starts = [base]
            starts.extend(base + rng.normal(0.0, [0.7, 0.7, 0.5, 0.5, 0.8, 0.5])
                          for _ in range(batch_size - 1))
            independent_batches.append(optimize_starts(times, causes, 0.0, (), starts)[0])
        ordered_independent = sorted(independent_batches, key=lambda r: r.fun)
        independent_gap = abs(ordered_independent[0].fun - ordered_independent[1].fun)
    independent = min(independent_batches, key=lambda r: r.fun)
    independent_values = np.exp(independent.x)
    previous = independent_values.copy()
    profile = [{"delta": 0.0, "objective": independent.fun,
                "parameters": independent_values, "face": "independence",
                "batch_gap": independent_gap,
                "gradient_inf": projected_gradient_inf(independent, list(range(6))),
                "success": bool(independent.success)}]

    all_batch_gaps = [independent_gap]
    selected_batch_gaps = []
    selected_gradients = []
    retry_count = 0
    for delta in DELTA_GRID[1:]:
        face_solutions = []
        previous_kappa = np.maximum(previous[:2] - delta, 1e-7)
        independent_kappa = np.maximum(independent_values[:2] - delta, 1e-7)
        anchor_previous = np.r_[np.log(previous_kappa), np.log(previous[2:])]
        anchor_independent = np.r_[np.log(independent_kappa), np.log(independent_values[2:])]
        for zero_face in FACES:
            free = [i for i in range(6) if i not in zero_face]
            batches = []
            for _ in range(2):
                starts = make_batch(rng, (anchor_previous, anchor_independent), free,
                                    batch_size=batch_size)
                batches.append(optimize_starts(times, causes, float(delta), zero_face, starts)[0])
            initial_gap = abs(batches[0].fun - batches[1].fun)
            if initial_gap > agreement_tol:
                retry_count += 1
                for _ in range(2):
                    starts = make_batch(rng, (anchor_previous, anchor_independent), free,
                                        batch_size=batch_size)
                    batches.append(optimize_starts(
                        times, causes, float(delta), zero_face, starts)[0])
            ordered = sorted(batches, key=lambda r: r.fun)
            gap = abs(ordered[0].fun - ordered[1].fun)
            all_batch_gaps.append(gap)
            best = ordered[0]
            face_solutions.append({
                "objective": best.fun, "parameters": unpack(best, delta, zero_face),
                "face": "interior" if not zero_face else "+".join(f"kappa{i+1}=0" for i in zero_face),
                "batch_gap": gap,
                "gradient_inf": projected_gradient_inf(best, free),
                "success": bool(best.success),
            })
        chosen = min(face_solutions, key=lambda r: r["objective"])
        previous = chosen["parameters"]
        profile.append({"delta": float(delta), **chosen})
        selected_batch_gaps.append(chosen["batch_gap"])
        selected_gradients.append(chosen["gradient_inf"])

    chosen = min(profile, key=lambda r: r["objective"])
    diagnostic = {
        "max_selected_batch_gap": float(max(selected_batch_gaps + [independent_gap])),
        "max_all_face_batch_gap": float(max(all_batch_gaps)),
        "selected_gradient_inf": float(chosen["gradient_inf"]),
        "selected_success": bool(chosen["success"]),
        "retry_count": retry_count,
        "all_selected_faces_agree": bool(
            max(selected_batch_gaps + [independent_gap]) <= agreement_tol),
    }
    return chosen, diagnostic


def one_replicate(task):
    scenario, replicate, delta_true, seed, batch_size, agreement_tol = task
    threadpool_limits(limits=1)
    rng = np.random.default_rng(seed)
    times, causes = simulate(rng, delta_true)
    started = time.time()
    chosen, diagnostic = fit_complete_profile(times, causes, rng, batch_size, agreement_tol)
    p = chosen["parameters"]
    return {
        "scenario": scenario, "replicate": replicate, "seed": seed,
        "delta_true": delta_true, "delta_hat": chosen["delta"],
        "alpha1_hat": p[0], "alpha2_hat": p[1],
        "beta1_hat": p[2], "beta2_hat": p[3],
        "theta1_hat": p[4], "theta2_hat": p[5],
        "selected_face": chosen["face"], "negative_loglikelihood": chosen["objective"],
        "events1": int((causes == 1).sum()), "events2": int((causes == 2).sum()),
        "censored": int((causes == 0).sum()), "seconds": time.time() - started,
        **diagnostic,
    }


def summarize(raw):
    rows = []
    truths = {"alpha1": ALPHA[0], "alpha2": ALPHA[1], "beta1": BETA[0],
              "beta2": BETA[1], "theta1": THETA[0], "theta2": THETA[1]}
    for scenario, group in raw.groupby("scenario"):
        delta_true = group.delta_true.iloc[0]
        row = {
            "scenario": int(scenario), "delta_true": delta_true,
            "replicates": len(group),
            "delta_bias": float((group.delta_hat - delta_true).mean()),
            "delta_rmse": float(np.sqrt(np.mean((group.delta_hat - delta_true) ** 2))),
            "delta_mc_sd": float(group.delta_hat.std(ddof=1)),
            "delta_bias_mcse": float(group.delta_hat.std(ddof=1) / np.sqrt(len(group))),
            "independence_boundary_rate": float((group.delta_hat == 0).mean()),
            "upper_grid_rate": float((group.delta_hat == DELTA_GRID[-1]).mean()),
            "selected_optimizer_success_rate": float(group.selected_success.mean()),
            "selected_batch_agreement_rate": float(group.all_selected_faces_agree.mean()),
            "selected_gradient_median": float(group.selected_gradient_inf.median()),
            "selected_gradient_max": float(group.selected_gradient_inf.max()),
            "median_max_selected_batch_gap": float(group.max_selected_batch_gap.median()),
            "max_selected_batch_gap": float(group.max_selected_batch_gap.max()),
            "median_retries": float(group.retry_count.median()),
            "theta1_upper_limit_rate": float(np.isclose(group.theta1_hat, UPPER[4], atol=1e-6).mean()),
            "theta2_upper_limit_rate": float(np.isclose(group.theta2_hat, UPPER[5], atol=1e-6).mean()),
            "beta1_limit_rate": float((np.isclose(group.beta1_hat, LOWER[2], atol=1e-6)
                                       | np.isclose(group.beta1_hat, UPPER[2], atol=1e-6)).mean()),
            "beta2_limit_rate": float((np.isclose(group.beta2_hat, LOWER[3], atol=1e-6)
                                       | np.isclose(group.beta2_hat, UPPER[3], atol=1e-6)).mean()),
            "interior_face_rate": float((group.selected_face == "interior").mean()),
            "kappa_boundary_face_rate": float(
                (~group.selected_face.isin(["interior", "independence"])).mean()),
        }
        for name, truth in truths.items():
            error = group[f"{name}_hat"] - truth
            row[f"{name}_bias"] = float(error.mean())
            row[f"{name}_rmse"] = float(np.sqrt(np.mean(error ** 2)))
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replicates", type=int, default=100)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20261104)
    parser.add_argument("--batch-size", type=int, default=12)
    parser.add_argument("--agreement-tol", type=float, default=1e-6)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    delta_scenarios = (0.0, 0.5 * ALPHA.min(), 0.9 * ALPHA.min())
    tasks = []
    for scenario, delta_true in enumerate(delta_scenarios):
        for replicate in range(1, args.replicates + 1):
            seed = args.seed + scenario * 100000 + replicate
            tasks.append((scenario, replicate, float(delta_true), seed,
                          args.batch_size, args.agreement_tol))
    rows = []
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(one_replicate, task) for task in tasks]
        for i, future in enumerate(as_completed(futures), 1):
            rows.append(future.result())
            if i % 10 == 0 or i == len(futures):
                pd.DataFrame(rows).sort_values(["scenario", "replicate"]).to_csv(
                    args.output / "full_estimator_validation_checkpoint.csv", index=False)
                print(f"completed {i}/{len(futures)}", flush=True)
    raw = pd.DataFrame(rows).sort_values(["scenario", "replicate"])
    summary = summarize(raw)
    prefix = args.output / "full_estimator_validation"
    raw.to_csv(prefix.with_name(prefix.name + "_replicates.csv"), index=False)
    summary.to_csv(prefix.with_name(prefix.name + "_summary.csv"), index=False)
    settings = {
        "generated_utc": pd.Timestamp.utcnow().isoformat(),
        "python": platform.python_version(), "numpy": np.__version__,
        "scipy": scipy.__version__, "pandas": pd.__version__,
        "seed": args.seed, "n": N, "replicates_per_scenario": args.replicates,
        "workers": args.workers, "administrative_censoring_months": ADMIN,
        "true_alpha": ALPHA.tolist(), "true_beta": BETA.tolist(),
        "true_theta": THETA.tolist(), "true_delta_scenarios": list(delta_scenarios),
        "delta_profile_grid": DELTA_GRID.tolist(),
        "optimizer": {"method": "L-BFGS-B", "analytic_gradient": True,
                      "two_independent_batches": True,
                      "starts_per_batch_per_face": args.batch_size,
                      "adaptive_retry_starts": 2 * args.batch_size,
                      "batch_agreement_tolerance": args.agreement_tol,
                      "faces": ["interior", "kappa1=0", "kappa2=0", "both-zero"],
                      "free_parameter_lower_bounds": LOWER.tolist(),
                      "free_parameter_upper_bounds": UPPER.tolist(), **OPT},
        "constraint_rationale": "The unrestricted likelihood exhibited a nonregular alpha-to-zero, theta-to-infinity ridge in pilot samples. The validation therefore targets a prespecified compact-parameter estimator. Exact kappa boundary faces remain explicitly evaluated; positive free kappa components are bounded below by 1e-4. The generating values lie strictly inside these limits.",
        "interpretation": "Complete seven-parameter profile-grid estimator validation. Results assess the implemented finite-grid estimator; they do not prove global optimality or confidence-interval coverage.",
    }
    prefix.with_name(prefix.name + "_settings.json").write_text(
        json.dumps(settings, indent=2), encoding="utf-8")
    print(summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
