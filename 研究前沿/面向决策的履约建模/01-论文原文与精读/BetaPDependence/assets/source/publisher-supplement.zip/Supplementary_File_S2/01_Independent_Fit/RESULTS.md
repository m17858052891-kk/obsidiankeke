# Step 1 — Dependent correlated-gamma Beta-P maximum-likelihood fitting

Dataset: 177 observations, with 56 relapse, 75 competing events, 46 censored.

The fitted model has cause-specific cumulative hazards H_j(t)=(t/beta_j)^theta_j and gamma frailty marginal shapes alpha_j, shared component shape delta in [0,min(alpha_1,alpha_2)]. For observed time t and cause j, likelihood contribution is S_delta(t,t) * H'_j(t) * [(alpha_j-delta)/(1+H_j(t)) + delta/(1+H_1(t)+H_2(t))]; for censoring it is S_delta(t,t).

Independent benchmark (best among five starts): negative log-likelihood 561.2107198384; alpha=(0.02558137, 0.13958528), beta=(1.37908308, 1.78020412), theta=(6.866957, 1.83601277); delta=0. AIC 1134.42144; BIC 1153.47834.

Dependent model (best among twelve starts): negative log-likelihood 561.2107216861; alpha=(0.02557114, 0.13959198), beta=(1.37894996, 1.78026590), theta=(6.86939901, 1.83596324); delta=0.0000003094. AIC 1136.42144; BIC 1158.65449 (counting 7 fitted parameters).

The dependent model nests the independent model exactly at delta=0. Consequently, its global maximum log-likelihood cannot be smaller than that of the independent model. The slight numerical shortfall of the interior solution confirms that the optimizer has approached but not attained the exact boundary. The best *observed* fit among interior and boundary candidates is therefore the independent boundary solution, but global optimality of that boundary has NOT been certified.

Interpretation: positive dependence did not improve the likelihood in the starts examined. This does not establish absence of dependence. Profile-likelihood optimization and global/multistart diagnostics remain for Step 2, not completed here. Some random initializations converged to inferior local optima. No inferential p-value or confidence interval has been claimed. This result does not independently establish model identifiability or publication readiness.

Run: python fit_gamma_step1.py (requires numpy, pandas, scipy). Input path in the script refers to the original mounted data; if running elsewhere, change it to `bmtcrr.csv` in this folder.
