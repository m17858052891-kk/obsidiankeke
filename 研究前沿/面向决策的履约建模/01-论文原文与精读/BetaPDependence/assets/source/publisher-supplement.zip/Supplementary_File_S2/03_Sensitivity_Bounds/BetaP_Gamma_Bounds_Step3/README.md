# Step 3 — Numerical sensitivity envelopes

## Run
`python compute_bounds.py` after installing `numpy pandas scipy matplotlib`.

Inputs: `profile.csv` (25 evaluated shared-Gamma shape values from step 2, with six marginal parameters reoptimized at each point). `bmtcrr.csv` is included for provenance; step 3 uses the already fitted profile and does not refit raw data.

Outputs:
- `profiled_probabilities.csv`: cause-specific cumulative incidence and event-free survival at 12 and 24 months, using the *refitted marginal parameters* at each delta.
- `grid_envelopes.csv`: min and max over evaluated grid points, both all 25 and those with the **exploratory** LR-drop screen <=3.84145882.
- `fixed_margin_numerical_extrema.csv`: separately optimized fixed-margin sensitivity values, using independent-fit margins and delta in [0,min(alpha)]. This is not a profile-likelihood bound.
- `profiled_probability_curves.png`: probability versus delta on the evaluated grid.

## Interpretive limits
1. The grid envelopes are min/max of **evaluated solutions only**, not sharp or continuous-domain bounds. Optimizers may reach local optima; no global optimum certificate is asserted.
2. The LR screen is NOT a validated 95% confidence region: boundary null, possible weak identification, and unverified regularity conditions invalidate automatic chi-square inference.
3. Fixed-margin numerical extrema were calculated by bounded scalar optimization with endpoints checked. They are illustrative numerical extrema, not analytically proved global sharp bounds.
4. The maximum delta in the refitted grid is 0.20. The larger feasible parameter domain has not been exhaustively explored.
5. The numeric results do not show an improvement in data fit with positive dependence. In particular, the fixed-margin sensitivity exercise is not a fitted dependent-model comparison.
