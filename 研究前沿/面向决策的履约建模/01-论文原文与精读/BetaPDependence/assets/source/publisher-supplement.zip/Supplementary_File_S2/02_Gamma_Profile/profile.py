import numpy as np, pandas as pd
from pathlib import Path
from scipy.optimize import minimize
P=Path(__file__).parent
D=pd.read_csv(P/'bmtcrr.csv'); t=D.ftime.to_numpy(); y=D.Status.to_numpy(); n=len(t)
ind=np.load(P/'gamma_ind.npz')['z']; rng=np.random.default_rng(20261017)
def nll(x,d):
 with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
  a=d+np.exp(x[:2]);b=np.exp(x[2:4]);q=np.exp(x[4:6]);h=(t[:,None]/b)**q;hp=q/b*(t[:,None]/b)**(q-1)
  S=-d*np.log1p(h.sum(axis=1))-((a-d)*np.log1p(h)).sum(axis=1)
  ix1=y==1;ix2=y==2
  for ix,j in [(ix1,0),(ix2,1)]:
   S[ix]+=np.log(hp[ix,j])+np.log((a[j]-d)/(1+h[ix,j])+d/(1+h[ix].sum(axis=1)))
  val=-S.sum()
 return val if np.isfinite(val) else 1e20

def run_grid():
 grid=np.r_[0,np.linspace(.001,.03,16),.035,.04,.05,.065,.08,.1,.14,.2]
 rows=[]; prev=None
 for d in grid:
  starts=[np.r_[np.log(np.maximum(np.exp(ind[:2])-d,1e-4)),ind[2:]],np.r_[np.log(np.maximum(np.exp(ind[:2])*.5,1e-4)),ind[2:]]]
  if prev is not None: starts.insert(0,prev)
  for k in range(2): starts.append(starts[0]+rng.normal(0,.3,6))
  fits=[]
  for z in starts:
   r=minimize(nll,z,args=(d,),method='L-BFGS-B',bounds=[(-15,8)]*6,options={'maxiter':950,'ftol':1e-11,'maxls':35})
   fits.append(r)
  best=min(fits,key=lambda r:r.fun);prev=best.x
  a=d+np.exp(best.x[:2]);b=np.exp(best.x[2:4]);q=np.exp(best.x[4:6]);
  rows.append(dict(delta=d,loglik=-best.fun,nll=best.fun,alpha1=a[0],alpha2=a[1],beta1=b[0],beta2=b[1],theta1=q[0],theta2=q[1],converged=best.success,starts=len(fits),range_nll=max(r.fun for r in fits)-min(r.fun for r in fits)))
  print('delta',round(d,6),'nll',round(best.fun,8),'success',best.success,'spread',round(rows[-1]['range_nll'],5),flush=True)
 out=pd.DataFrame(rows);out.to_csv(P/'profile.csv',index=False)
 return out
if __name__=='__main__':run_grid()
