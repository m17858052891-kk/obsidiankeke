# Step 5 — Independent computational and novelty audit

## Scope
Reviewed the Step-4 manuscript, the 25-point Gamma profile grid, its source likelihood, and selected published literature. This audit is independent of the optimizer in that it recomputes the likelihood and finite-difference gradients from the saved estimates. It is not a proof of global optimum, a complete literature systematic review, or a formal identifiability theorem.

## Independent numerical checks
- Dataset: 177 observations; right-censoring and causes 1/2 retained.
- Profile points independently recomputed: 25/25.
- Maximum absolute discrepancy between stored and independently computed negative log-likelihood: 2.274e-13.
- Median finite-difference gradient Euclidean norm (log nuisance parameters): 1.039e-4.
- Largest finite-difference gradient norm: 2.660e-2, at delta = 0.0242; this grid point warrants qualification as an approximate optimizer solution.
- All 25 recorded fits have optimizer success=True; that flag does not establish global optimality.
- Maximum gap between best and worst starting-point negative log-likelihood at a fixed delta: 532.45; demonstrates substantial local-solution sensitivity.
- Among stored grid solutions the best objective is at delta=0 (negative log-likelihood 561.210720). No global optimum claim is justified.

## Novelty: literature comparisons
1. Tsiatis (1975), *A nonidentifiability aspect of the problem of competing risks*, PNAS, DOI 10.1073/pnas.72.1.20: nonidentification of net survival from ordinary competing-risks data is established. Not novel here.
2. Peterson (1978), *Dependent competing risks: Bounds for net survival functions with fixed crude survival functions*, Environment International, DOI 10.1016/0160-4120(78)90013-2: bounds for dependent competing risks predate this paper. Generic sensitivity bounds are not novel.
3. *Competing Risks with Common Shocks: Joint Survival, Copulas, Censoring, Frailty, and Marshall–Olkin Models* (2026), Computation, https://www.mdpi.com/2079-3197/14/7/152: shared gamma frailty, competing-risk likelihood, and multi-start optimization have been treated recently. Shared gamma frailty itself is not novel.
4. The candidate distinct contribution is the PARTICULAR exact Beta-P margin construction combined with derived active-risk probabilities and its model-relative sensitivity analysis. A complete exhaustive prior-art check has not been performed, so uniqueness of that combination cannot be certified.

## Audit disposition
**Qualified pass for Step 5 (computational replication and honest novelty positioning).** The manuscript may state that the stored profile values are independently reproducible to machine precision, but not that global optimality or formal frequentist coverage was proved. It should explicitly limit novelty to the particular construction and derived functionals. The Step-6 editorial update must integrate the audit qualifications and references; no new modeling workflow is requested by this audit.

## Reproduction
`python audit.py` with numpy, pandas and scipy. Files `profile.csv`, `bmtcrr.csv` and `independent_profile_checks.csv` are supplied.
