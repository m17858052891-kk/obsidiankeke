"""Profile likelihood including exact kappa_j=0 face candidates."""
import numpy as np,pandas as pd
from pathlib import Path
from scipy.optimize import minimize
P=Path(__file__).resolve().parents[1]/'02_Gamma_Profile'
D=pd.read_csv(P/'bmtcrr.csv'); t=D.ftime.to_numpy(); y=D.Status.to_numpy(); ind=np.load(P/'gamma_ind.npz')['z']
base=np.r_[np.maximum(np.exp(ind[:2]),1e-4),np.exp(ind[2:])]
rng=np.random.default_rng(20261105)
def nll_full(v,d):
 with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
  kap=v[:2]; b=v[2:4]; q=v[4:6]; a=d+kap
  h=(t[:,None]/b)**q; hp=q/b*(t[:,None]/b)**(q-1)
  L=-d*np.log1p(h.sum(axis=1))-(kap*np.log1p(h)).sum(axis=1)
  for ix,j in [(y==1,0),(y==2,1)]: L[ix]+=np.log(hp[ix,j])+np.log(kap[j]/(1+h[ix,j])+d/(1+h[ix].sum(axis=1)))
  z=-L.sum()
 return float(z) if np.isfinite(z) else 1e100
def expand(z,free):
 v=np.zeros(6);v[list(free)]=np.exp(z)
 return v
def fit_regime(d,zero_k,prev,nstarts=12):
 free=[i for i in range(6) if i not in zero_k]
 starts=[]
 v0=prev.copy();v0[:2]=np.maximum(v0[:2]-d,1e-4)
 starts.append(np.log(v0[free]))
 v1=base.copy();v1[:2]=np.maximum(v1[:2]-d,1e-4);starts.append(np.log(v1[free]))
 for sig in [.15,.4,.8,1.2]:
  for _ in range(2): starts.append(starts[0]+rng.normal(0,sig,len(free)))
 while len(starts)<nstarts:
  x=np.log(base[free])+rng.normal(0,.9,len(free));starts.append(x)
 fits=[]
 def f(z): return nll_full(expand(z,free),d)
 for z in starts[:nstarts]:
  r=minimize(f,z,method='L-BFGS-B',bounds=[(-15,8)]*len(free),options={'maxiter':2500,'ftol':1e-13,'gtol':1e-7,'maxls':60,'maxcor':30})
  fits.append(r)
 best=min(fits,key=lambda r:r.fun)
 return best,free,len(fits),sum(r.success for r in fits),max(r.fun for r in fits)-best.fun,sum(abs(r.fun-best.fun)<=1e-4 for r in fits)
prev=base.copy();rows=[]
grid=np.r_[0,np.linspace(.001,.03,16),.035,.04,.05,.065,.08,.1,.14,.2]
for ix,d in enumerate(grid[::-1]):
 candidates=[]; regimes=[()] if d==0 else [(),(0,),(1,),(0,1)]
 for zero in regimes:
  res,free,n,s,spread,repeat=fit_regime(d,zero,prev,12)
  v=expand(res.x,free)
  candidates.append((res.fun,v,zero,res,free,n,s,spread))
 best=min(candidates,key=lambda x:x[0]); prev=best[1]
 nll,v,zero,res,free,n,s,spread=best
 rows.append({'delta':d,'nll':nll,'loglik':-nll,'kappa1':v[0],'kappa2':v[1],'alpha1':d+v[0],'alpha2':d+v[1],'beta1':v[2],'beta2':v[3],'theta1':v[4],'theta2':v[5],'active_boundary':str(tuple(j+1 for j in zero)) if zero else 'interior','starts_for_selected_face':n,'successful_starts_selected_face':s,'selected_face_start_spread':spread,'selected_face_starts_within_1e-4':repeat,'gradient_inf':float(np.max(np.abs(res.jac))),'faces_tested':len(regimes)})
 print(f'{ix+1:02d}/{len(grid)} d={d:.6f} nll={nll:.8f} face={zero} kappa=({v[0]:.3g},{v[1]:.3g}) spreads={spread:.3g}',flush=True)
out=pd.DataFrame(rows);out.to_csv(Path(__file__).parent/'robust_profile_boundary_reverse_results.csv',index=False)
print(out[['delta','loglik','active_boundary','kappa1','kappa2','gradient_inf']].to_string(index=False))
