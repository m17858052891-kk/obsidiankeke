# Complete-estimator Monte Carlo results

The final study used 100 replicates per scenario (300 complete fits). Four initial batch-disagreement cases were rerun with 24 starts per batch; all four then met the 1e-6 batch-agreement criterion.

| true delta | bias | RMSE | delta=0 rate | upper-grid rate | batch agreement | theta1 upper-limit rate | median projected gradient |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.000000 | 0.011700 | 0.018519 | 43.00% | 1.00% | 100.00% | 19.00% | 7.27e-07 |
| 0.012791 | -0.003581 | 0.012792 | 50.00% | 0.00% | 100.00% | 13.00% | 1.00e-06 |
| 0.023023 | -0.008533 | 0.018948 | 35.00% | 2.00% | 100.00% | 25.00% | 8.69e-07 |

Interpretation: optimization of the explicitly constrained estimator was reproducible, but the complete estimator remained weakly identified at n=177. Boundary selection, theta-limit contacts, and non-negligible delta bias/RMSE preclude claims of precise dependence estimation or calibrated confidence coverage.
