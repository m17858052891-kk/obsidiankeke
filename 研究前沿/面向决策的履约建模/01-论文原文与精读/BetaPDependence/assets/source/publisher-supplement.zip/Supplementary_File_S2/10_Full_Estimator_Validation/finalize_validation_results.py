"""Merge doubled-start retries and produce final summaries."""

from pathlib import Path
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
FINAL = HERE / "final_100x3"
sys.path.insert(0, str(HERE))
import full_estimator_validation as model

raw = pd.read_csv(FINAL / "full_estimator_validation_replicates.csv")
retried = pd.read_csv(FINAL / "full_estimator_validation_retried.csv")
for corrected in retried.itertuples(index=False):
    mask = ((raw.scenario == corrected.scenario)
            & (raw.replicate == corrected.replicate))
    for column in raw.columns:
        raw.loc[mask, column] = getattr(corrected, column)

raw = raw.sort_values(["scenario", "replicate"])
summary = model.summarize(raw)
raw.to_csv(FINAL / "full_estimator_validation_replicates.csv", index=False)
summary.to_csv(FINAL / "full_estimator_validation_summary.csv", index=False)

lines = [
    "# Complete-estimator Monte Carlo results",
    "",
    "The final study used 100 replicates per scenario (300 complete fits). Four initial batch-disagreement cases were rerun with 24 starts per batch; all four then met the 1e-6 batch-agreement criterion.",
    "",
    "| true delta | bias | RMSE | delta=0 rate | upper-grid rate | batch agreement | theta1 upper-limit rate | median projected gradient |",
    "|---:|---:|---:|---:|---:|---:|---:|---:|",
]
for row in summary.itertuples(index=False):
    lines.append(
        f"| {row.delta_true:.6f} | {row.delta_bias:.6f} | {row.delta_rmse:.6f} | "
        f"{row.independence_boundary_rate:.2%} | {row.upper_grid_rate:.2%} | "
        f"{row.selected_batch_agreement_rate:.2%} | {row.theta1_upper_limit_rate:.2%} | "
        f"{row.selected_gradient_median:.2e} |")
lines.extend([
    "",
    "Interpretation: optimization of the explicitly constrained estimator was reproducible, but the complete estimator remained weakly identified at n=177. Boundary selection, theta-limit contacts, and non-negligible delta bias/RMSE preclude claims of precise dependence estimation or calibrated confidence coverage.",
])
(FINAL / "RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(summary.to_string(index=False))
