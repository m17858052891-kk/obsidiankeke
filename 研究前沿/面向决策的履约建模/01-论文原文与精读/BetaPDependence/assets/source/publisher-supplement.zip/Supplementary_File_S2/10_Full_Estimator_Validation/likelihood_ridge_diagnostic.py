"""Reproduce the nonregular alpha-to-zero, theta-to-infinity likelihood path."""

from pathlib import Path
import importlib.util

import numpy as np
import pandas as pd
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "validation", HERE / "full_estimator_validation.py")
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)

rows = []
cases = ((20261105, 0.0), (20461106, 0.9 * model.ALPHA.min()))
for seed, delta_true in cases:
    rng = np.random.default_rng(seed)
    times, causes = model.simulate(rng, float(delta_true))
    z = np.log(np.r_[5e-5, 0.10, 1.2, 1.4, 100.0, 2.0])
    for upper in (6.0, 8.0, 10.0, 12.0, 14.0):
        result = minimize(
            model.objective_gradient, z, args=(0.0, times, causes, ()),
            jac=True, method="L-BFGS-B", bounds=[(-20.0, upper)] * 6,
            options=model.OPT,
        )
        z = result.x
        values = np.exp(z)
        rows.append({
            "seed": seed, "delta_true": delta_true,
            "common_log_upper_bound": upper,
            "negative_loglikelihood": result.fun,
            "alpha1": values[0], "alpha2": values[1],
            "beta1": values[2], "beta2": values[3],
            "theta1": values[4], "theta2": values[5],
            "raw_gradient_inf": float(np.max(np.abs(result.jac))),
        })

pd.DataFrame(rows).to_csv(HERE / "likelihood_ridge_diagnostic.csv", index=False)
print(pd.DataFrame(rows).to_string(index=False))
