# Beta-P competing risks: reproducibility supplement

## Run

Python 3.10+; install `numpy`, `pandas`, and `scipy` (`pip install -r requirements.txt`).

From this folder run `python reproduce_step5.py`.

The script reads `bmtcrr.csv` (177 observations), reproduces 12-month Aalen–Johansen event-free survival and cause-specific CIFs, evaluates five fixed-margin gamma-dependence sensitivity cases, and writes `sensitivity_12_months.csv` and `comparison_12_months.csv`. Assertions compare values against manuscript Tables 6 and 7 at approximately six decimal places and verify probability conservation.

**Parameters**: `A=[0.02558,0.13959]`, `B=[1.37908,1.78020]`, `TH=[6.86695,1.83601]` are rounded parameter estimates *transcribed from manuscript Table 4*, not refitted by this script. The survival law uses `H_j(t)=(t/B_j)^TH_j` and marginal survival `(1+H_j(t))^-A_j`.

**Limits**: This is an independently runnable verification of **reported 12-month observable probabilities**, not an independent refit of the six Beta-P parameters, dependent gamma frailty, likelihood-profile regions, bootstrap, simulations, or Clayton model. The script does not establish sharp continuous-domain bounds or uncertainty intervals. The Aalen–Johansen computation treats Status=0 as censoring, 1 as relapse, 2 as competing event. No claim about the specific clinical meaning of Status=2 is made here.

## Contents
- `reproduce_step5.py`: executable calculation and assertions.
- `bmtcrr.csv`: public secondary dataset distributed with R casebase.
- `sensitivity_12_months.csv`: five-grid-point output.
- `comparison_12_months.csv`: nonparametric vs conditional model predictions.
- `requirements.txt`: dependencies.
